﻿
$(document).ready(function () {

    isValid = "";
    $("SpecialityOrCondition").prop('checked', true);
    $("#ErrorMessageForInfo").empty();
    $('#showpanel').slideUp("slow");
    $("#ErrorMessageForSearchNow").empty();
    $("#divConditions").hide();
    $("#divFocus").hide();
    $("#headingErrorMsg").empty();
    $("#errorMsgZipState").empty();
    
    /* autosuggestions based on search criteria when user keys in two characters */
    $(function () {
        function split(val) {
            return val.split(/,\s*/);
        }
        function extractLast(term) {
            return split(term).pop();
        }
        $("#txtProviderName").bind("keydown", function (event) {
            if (event.keyCode === $.ui.keyCode.TAB && $(this).data("autocomplete").menu.active) {
                event.preventDefault();
            }
        })
        $("#txtProviderName").autocomplete({
            source: function (request, response) {
                //define a function to call your Action (assuming UserController)
                var searchRequest = new Object();
                var NetworkType = new Object();
                var forgeryId = $("#forgeryToken").val();
                NetworkType.NetworkId = $('input[name=NetworkType]:checked').val();
                NetworkType.NetworkName = $('input[name=NetworkType]:checked').attr('networktype-name');
                searchRequest.NetworkType = NetworkType;
                searchRequest.ClientSpecificCode = $("#txtClientSpcNet").val();
                var providerType = new Object();

                providerType.ProviderTypeID = $('input[name="ProviderType"]:checked').val();
                providerType.ProviderTypeName = $('input[name="ProviderType"]:checked').attr('provider-name');
                providerType.ProviderTypeNameSpanish = $('input[name="ProviderType"]:checked').attr('provider-name1');
                searchRequest.ProviderType = providerType;
                searchRequest.CustomerType = $('input[name=UserType]:checked').val();
                if ($('#txtZipCode').val().trim() != "") {
                    searchRequest.Zipcode = $('#txtZipCode').val();
                    searchRequest.Radius = $('#txtRadiusValue').val();
                }
                else if ($('#textbox').html() != "State" && $('#textbox').html() !='Estado') {
                   
                    ////Start Code change related to new dropdown
                   searchRequest.State = $('#ulState li[aria-selected="true"]').attr('id').trim();// $('#textbox').html();

                    //CountyList Start 
                   var options_str = '';
                   var $selectedOptions = $('li[aria-selected="true"]', $('#ulCounty'));
                   if ($selectedOptions.length > 0) {
                       $selectedOptions.each(function () {
                           options_str += $(this).text() + ', ';
                       });
                       options_str = options_str.slice(0, -2);
                }
                   var countyList = [];
                   if (options_str != '')
                       countyList = options_str.split(",").map(function (item) {
                           return item.trim();
                       });;

                   searchRequest.CountyCodes = countyList;
                    //County List END

                   //CityList Start 
                   var options_str1 = '';
                   var $selectedOptions1 = $('li[aria-selected="true"]', $('#ulCity'));
                   if ($selectedOptions1.length > 0) {
                       $selectedOptions1.each(function () {
                           options_str1 += $(this).text() + ', ';
                       });
                       options_str1 = options_str1.slice(0, -2);
                   }
                   var cityList = [];
                   if (options_str1 != '') {
                       cityList = options_str1.split(",").map(function (item) {
                           return item.trim();
                       })
                   };
                   searchRequest.CityCodes = cityList;
                    //CityList End
                    //// End Code change related to new dropdown

                }
                if ($('#txtProviderName').val() != undefined && $('#txtProviderName').val() != null && $('#txtProviderName').val().trim() != "") {
                    searchRequest.ProviderName = request.term;
                }
                //// 
                $.ajax({
                    url: '/LocateProvider/GetProviderNameSearchCriteria',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify({ query: request.term, searchRequest: searchRequest }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    term: extractLast(request.term),
                    success: function (data) {
                        
                        response($.map(data, function (item) {
                            //// 
                            return {
                                label: item.PhysicanName,
                                value: item.PhysicanNum     // EDIT
                            }
                        }));
                    }
                })
            },
            search: function () {
                // custom minLength
                var term = extractLast(this.value);
                if (term.length < 2) {
                    return false;
                }
            },
            focus: function (event, ui) {
                event.preventDefault();
            },
            select: function (event, ui) {
                event.preventDefault();
                $("#txtProviderName").val(ui.item.label);
                $("#ProviderNameHiddenValue").val(ui.item.value);
            }
        });

    });

    //filter the specialty dropdown based on the value enters in the textbox
    jQuery.fn.filterByText1 = function (textbox, selectSingleMatch) {
        return this.each(function () {
            var select = this;
            var options = [];
            $("#specialities").find('option').each(function () {
                options.push({ value: $(this).val(), text: $(this).text(), data_eng: $(this).attr("data-eng"), data_spn: $(this).attr("data-spn") });
            });
            $("#specialities").data('options', options);
            $(textbox).bind('change keyup', function () {
                var options = $("#specialities").empty().data('options');
                var search = $.trim($(this).val());
                var regex = new RegExp(search, "gi");

                $.each(options, function (i) {
                    var option = options[i];
                    if (option.text.match(regex) !== null) {
                        $("#specialities").append(
                        $('<option>').text(option.text).val(option.value).attr("data-spn", option.data_spn).attr("data-eng", option.data_eng)
                        );
                    }
                });
                if (selectSingleMatch === true && $("#specialities").children().length === 1) {
                    $("#specialities").children().get(0).selected = true;
                }
            });
        });
    };
    $(function () {
        $('select[id$=specialities]').filterByText1($('input[id$=selectedSpeciality]'), true);

    });

    //filter the condition dropdown based on the value enters in the textbox
    jQuery.fn.filterByText2 = function (textbox, selectSingleMatch) {
        return this.each(function () {
            var select = this;
            var options = [];
            $("#SelectCondition").find('option').each(function () {
                options.push({ value: $(this).val(), text: $(this).text(), data_eng: $(this).attr("data-eng"), data_spn: $(this).attr("data-spn") });
            });
            $("#SelectCondition").data('options', options);
            $(textbox).bind('change keyup', function () {
                var options = $("#SelectCondition").empty().data('options');
                var search = $.trim($(this).val());
                var regex = new RegExp(search, "gi");

                $.each(options, function (i) {
                    var option = options[i];
                    if (option.text.match(regex) !== null) {
                        $("#SelectCondition").append(
                        $('<option>').text(option.text).val(option.value).attr("data-spn", option.data_spn).attr("data-eng", option.data_eng)
                        );
                    }
                });
                if (selectSingleMatch === true && $("#SelectCondition").children().length === 1) {
                    $("#SelectCondition").children().get(0).selected = true;
                }
            });
        });
    };

    //filter the focus dropdown based on the value enters in the textbox
    jQuery.fn.filterByText3 = function (textbox, selectSingleMatch) {
        return this.each(function () {
            var select = this;
            var options = [];
            $("#focusTypes").find('option').each(function () {
                options.push({ value: $(this).val(), text: $(this).text(), data_eng: $(this).attr("data-eng"), data_spn: $(this).attr("data-spn") });
            });
            $("#focusTypes").data('options', options);
            $(textbox).bind('change keyup', function () {
                var options = $("#focusTypes").empty().data('options');
                var search = $.trim($(this).val());
                var regex = new RegExp(search, "gi");

                $.each(options, function (i) {
                    var option = options[i];
                    if (option.text.match(regex) !== null) {
                        $("#focusTypes").append(
                            $('<option>').text(option.text).val(option.value).attr("data-spn", option.data_spn).attr("data-eng", option.data_eng)
                        );
                    }
                });
                if (selectSingleMatch === true && $("#focusTypes").children().length === 1) {
                    $("#focusTypes").children().get(0).selected = true;
                }
            });
        });
    };
    $(function () {
        $('select[id$=focusTypes]').filterByText3($('input[id$=selectedFocus]'), true);

    });


    $(function () {
        $('select[id$=SelectCondition]').filterByText2($('input[id$=selectedCondition]'), true);


        //Code fixed for Issue 1963.Restricting to select 5 specialities only.
        var last_valid_selection = null;
        var lastSelFocus = null; 

        $('#specialities').change(function (event) {
            // 
            var mappedItemsLength = $('#Mappedspecialities').children('option').length;
            var remainingItemsLength = 5 - mappedItemsLength;
           
            var noOfItemsToSelect = 0;
            if (mappedItemsLength == 0) {
                noOfItemsToSelect = 5;
            }
            else {
                noOfItemsToSelect = remainingItemsLength;
            }
            if ($(this).val() != null) {
                if ($(this).val().length > noOfItemsToSelect) {

                    $(this).val(last_valid_selection);
                } else {
                    last_valid_selection = $(this).val();
                }
            }

        });

        $('#focusTypes').change(function (event) {
            // 
            var mappedItemsLength = $('#Mappedfocus').children('option').length;
            var remainingItemsLength = 5 - mappedItemsLength;

            var noOfItemsToSelect = 0;
            if (mappedItemsLength == 0) {
                noOfItemsToSelect = 5;
            }
            else {
                noOfItemsToSelect = remainingItemsLength;
            }
            if ($(this).val() != null) {
                if ($(this).val().length > noOfItemsToSelect) {

                    $(this).val(lastSelFocus);
                } else {
                    lastSelFocus = $(this).val();
                }
            }

        });
    }); 
    

    //selecting only one state from the drop down   
    $('#SearchState').multiselect({
        buttonWidth: '100%',
        enableFiltering: true,
        maxHeight: 200,
        nonSelectedText: GetResources("txtStateRequired"),
        enableCaseInsensitiveFiltering: true,
        enableFullValueFiltering: true,
        enableHTML: false,
        onDropdownShown: function (even) {
            this.$filter.find('.multiselect-search').focus();
            $(document).find(".multiselect-container li a").on("keydown", function (e) {
                if (e.keyCode == 9 && e.shiftKey) {
                    $(this).parent().parent().find('.multiselect-search')[0].focus();
                    e.preventDefault();
                }
            })
        },
    });
    // selecting maximum of 7 cities from the dropdown

    $('#SearchCity').multiselect({
        numberDisplayed: 7,
        buttonWidth: '100%',
        nonSelectedText: GetResources("txtEnterCity"),
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        enableFullValueFiltering: true,
        enableHTML: false,
        onDropdownShown: function (even) {
            this.$filter.find('.multiselect-search').focus();
            $(document).find(".multiselect-container li a").on("keydown", function (e) {
                if (e.keyCode == 9 && e.shiftKey) {
                    $(this).parent().parent().find('.multiselect-search')[0].focus();
                    e.preventDefault();
                }
            })
        },
    });
    // selecting maximum of 7 counties from the dropdown

    $('#SearchCounty').multiselect({
        numberDisplayed: 7,
        buttonWidth: '100%',
        nonSelectedText: GetResources("txtEnterCounty"),
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        enableFullValueFiltering: true,
        enableHTML: false,
        onDropdownShown: function (even) {
            this.$filter.find('.multiselect-search').focus();
            $(document).find(".multiselect-container li a").on("keydown", function (e) {
                if (e.keyCode == 9 && e.shiftKey) {
                    $(this).parent().parent().find('.multiselect-search')[0].focus();
                    e.preventDefault();
                }
            })
        },
    });
    

    //choosing the specialty or condition radio button
    $('input[name="SpecialityOrCondition"]').on('click', function () {
        $("#ErrorMessageForSearchNow").empty();
        var specialityOrCondition = $(this).val();
        if (specialityOrCondition == "Condition") {
            $("#divSpeciality").hide();
            $("#divFocus").hide();
            $("#divConditions").show();
            $('#btnAddRemoveError').empty();
            $("#headingErrorMsg").empty();
        }
        else if (specialityOrCondition === "Focus") {
            $("#divSpeciality").hide();
            $("#divConditions").hide();
            $("#divFocus").show();
            $('#btnAddRemoveError').empty();
            $("#headingErrorMsg").empty();
        }
        else {
            $("#divSpeciality").show();
            $("#divConditions").hide();
            $("#divFocus").hide();
        }
    });

    //search by state or div events start
    $("#zipDiv").show();  // search by zip radio button is preselected by default and state div is hidden
    $("#stateDiv").hide();

    $('#txtProviderPhNo').on('focusout', function () {
        $('#txtProviderPhNo').val($('#txtProviderPhNo').val().trim());
               if ((jQuery.isNumeric($('#txtProviderPhNo').val())== false) || ($('#txtProviderPhNo').val().length < 10 && $('#txtProviderPhNo').val().trim() != "")) {
            // 
            $('#errorMsgProviderPhNo').html("");
            $('#errorMsgProviderPhNo').html(GetResources("lblEnterValidData"));
        }
        else {
            $('#errorMsgProviderPhNo').html("");
            if ($('#txtProviderPhNo').val().length == 10) {                              
                $("#txtProviderPhNo").val('(' + $("#txtProviderPhNo").val().substr(0, 3) + ')' + $("#txtProviderPhNo").val().substr(3, 3) + '-' + $("#txtProviderPhNo").val().substr(6, 4));
            }
        }
        if($('#txtProviderPhNo').val() == "")
        $('#errorMsgProviderPhNo').html("");

    });
    $("#txtProviderPhNo").keydown(function (e) {
        //
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            //allow copy paste
            (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
            (e.keyCode == 86 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

    function EditPhoneMode() {

        $("#txtProviderPhNo").val($("#txtProviderPhNo").val().substr(1, 3) + $("#txtProviderPhNo").val().substr(5, 3) + $("#txtProviderPhNo").val().substr(9, 4));

    }
    $("#txtProviderPhNo").focusin(function () {
        if ($("#txtProviderPhNo").val() != "" && $("#txtProviderPhNo").val().length == 13) {
            EditPhoneMode();

        }
    })
    $('#txtProviderNPI').on('focusout', function () {
        $('#txtProviderNPI').val($('#txtProviderNPI').val().trim());
        if ((jQuery.isNumeric($('#txtProviderNPI').val()) == false) || ($('#txtProviderNPI').val().length < 10 && $('#txtProviderNPI').val().trim() != "")) {
            // 
            $('#errorMsgProviderNPI').html("");
            $('#errorMsgProviderNPI').html(GetResources("lblEnterValidData"));
            //$('#txtProviderNPI').focus();

        }
        else { $('#errorMsgProviderNPI').html(""); }
        if($('#txtProviderNPI').val() == "")
        $('#errorMsgProviderNPI').html("");
    });
    $("#txtProviderNPI").keydown(function (e) {
        //
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            //allow copy paste
            (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
            (e.keyCode == 86 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    //validation the Medical license number
    $('#txtMedicalLicNo').on('focusout', function () {
        $('#txtMedicalLicNo').val($('#txtMedicalLicNo').val().trim());
        var RE_NAME = /^[a-zA-Z0-9]+$/i;
        if (!RE_NAME.test($('#txtMedicalLicNo').val())) {
            
            // 
            $('#errorMsgProviderMedLicNo').html("");
            $('#errorMsgProviderMedLicNo').html(GetResources("lblSpecialCharsNotAllowed"));
            //$('#txtProviderNPI').focus();

        }
        else { $('#errorMsgProviderMedLicNo').html(""); }
        if ($('#txtMedicalLicNo').val() == "")
            $('#errorMsgProviderMedLicNo').html("");
    });

    $('#txtMedicalLicNo').alphanumeric({
        ichars: '<>=*&+-/][.,`\\'
    });

    $('#txtMedicalLicNo').keydown(function (e) {
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
             (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||

            // Allow: home, end, left, right, down, up
             (e.keyCode >= 35 && e.keyCode <= 40) ||
            //allow copy paste
            (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
            (e.keyCode == 86 && (e.ctrlKey === true || e.metaKey === true))) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number or character and stop the keypress
        if ((e.shiftKey && ((e.keyCode > 47 && e.keyCode < 58) || e.keyCode > 105)) || e.keyCode == 32) {
            e.preventDefault();
        }
    });


    //validating the zipcode entered in the textbox
    $('#txtZipCode').on('change', function () {

        var txtZip = $('#txtZipCode').val();
        var forgeryId = $("#forgeryToken").val();

        $("#headingErrorMsg").find('.optionalCriteria').remove();
        $("#headingErrorMsg").find('.zipMandatoryOnSearchNow').remove();
        $("#errorMsgZipState").find('.zipErrorOnSearchNow').remove();
        $("#headingErrorMsg").find('.zipMandatory').remove();
        $("#errorMsgZipState").find('.zipError').remove();
        $("#ErrorMessageForInfo").empty();
        if (!jQuery.isNumeric($('#txtZipCode').val())) {
            $('#showpanel').slideUp("slow");
            var result = GetResources("lblShowOptions");
            var link = $("#open");
            link.html('<a aria-expanded="false" id="seeMoreDetails" style="background-color:white;border:none;color:#0067a6;font-weight:bold;font-size:18px;padding-left:16px;">' + result + '</a>');

            $("#headingErrorMsg").find('.zipValid').remove();
            $("#errorMsgZipState").find(".zipCheckValid").remove();
            var errorMsgZipNumeric = GetResources("lblErrorMsgEnterNumericValuesInZip");
            if ($("#errorMsgZipState").find(".zipError").length == 0)
                $('#errorMsgZipState').append('<div class="zipError">' + errorMsgZipNumeric + '</div>');

            if ($("headingErrorMsg").find('.zipMandatory').length == 0)
                $('#headingErrorMsg').append("<div class='zipMandatory'>" + errorMsgZipNumeric + "</div>");
        }
        else {
            if (txtZip != "") {
                $.ajax({
                    type: 'POST',
                    url: '/LocateProvider/CheckZipCode',
                    contentType: "application/json; charset=utf-8",
                    datatype: 'json',
                    data: JSON.stringify({ txtZip: txtZip }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    success: function (result) {
                        if (result == "True") {
                            $("#headingErrorMsg").find(".zipValid").remove();
                            $("#errorMsgZipState").find(".zipCheckValid").remove();
                            $("#errorMsgZipState").find(".zipError").remove();
                            $("headingErrorMsg").find('.zipMandatory').remove();
                            if ($('#showpanel').is(":visible")) {
                                var result = GetResources("lblHideOptions");
                                var link = $("#open");
                                link.html('<a aria-expanded="true" id="seeMoreDetails" style="background-color:white;border:none;color:#0067a6;font-weight:bold;font-size:18px;padding-left:16px;">' + result + '</a>');

                            }
                        }
                        else {
                            var errorMsgValidZip = GetResources("lblErrorMsgValidZip");
                            if ($("#headingErrorMsg").find(".zipValid").length == 0)
                                $("#headingErrorMsg").append('<div  class="zipValid">' + errorMsgValidZip + '</div>');
                            if ($("#errorMsgZipState").find(".zipCheckValid").length == 0)
                                $('#errorMsgZipState').append('<div class="zipCheckValid">' + errorMsgValidZip + '</div>');
                            $('#showpanel').slideUp("slow");
                            var result = GetResources("lblShowOptions");
                            var link = $("#open");
                            link.html('<a aria-expanded="false" id="seeMoreDetails" style="background-color:white;border:none;color:#0067a6;font-weight:bold;font-size:18px;padding-left:16px;">' + result + '</a>');

                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                    }
                });
            }
        }
    });
    $("#txtZipCode").keydown(function (e) {
        //
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }


    });

    $('#txtZipCode').on('keyup', function () {
        var txtZip = $('#txtZipCode').val();
        var forgeryId = $("#forgeryToken").val();
        $("#headingErrorMsg").find('.optionalCriteria').remove();
        $("#headingErrorMsg").find('.zipMandatoryOnSearchNow').remove();
        $("#errorMsgZipState").find('.zipErrorOnSearchNow').remove();
        $("#headingErrorMsg").find('.zipMandatory').remove();
        $("#errorMsgZipState").find('.zipError').remove();
        $("#ErrorMessageForInfo").empty();
        if (!jQuery.isNumeric($('#txtZipCode').val()) && txtZip != "") {
            $('#showpanel').slideUp("slow");
            var result = GetResources("lblShowOptions");
            var link = $("#open");
            link.html('<a aria-expanded="false" id="seeMoreDetails" style="background-color:white;border:none;color:#0067a6;font-weight:bold;font-size:18px;padding-left:16px;">' + result + '</a>');

            $("#headingErrorMsg").find('.zipValid').remove();
            $("#errorMsgZipState").find(".zipCheckValid").remove();
            var errorMsgZipNumeric = GetResources("lblErrorMsgEnterNumericValuesInZip");
            if ($("#errorMsgZipState").find(".zipError").length == 0)
                $('#errorMsgZipState').append('<div class="zipError">' + errorMsgZipNumeric + '</div>');

            if ($("headingErrorMsg").find('.zipMandatory').length == 0)
                $('#headingErrorMsg').append("<div class='zipMandatory'>" + errorMsgZipNumeric + "</div>");
        }
    })
    /* checking for values entered in radius textbox and displaying appropriate errror messages */
    $('#txtRadiusValue').on('change', function (e) {
        $("#headingErrorMsg").find('.zipMandatoryOnSearchNow').remove();
        $("#errorMsgZipState").find('.zipErrorOnSearchNow').remove();
        $("#headingErrorMsg").find('.optionalCriteria').remove();
        $("#ErrorMessageForInfo").empty();
        if (!jQuery.isNumeric($('#txtRadiusValue').val())) {
            var errorNumericRadius = GetResources("lblEnterNumericRadiusErrorMessage");
            if ($("#errorMsgZipState").find(".slideMandatory").length == 0)
                $('#errorMsgZipState').append('<div class="slideMandatory">' + errorNumericRadius + '</div>');

            if ($("#headingErrorMsg").find(".slideError").length == 0)
                $('#headingErrorMsg').append('<div class="slideError">' + errorNumericRadius + '</div>');
            $('#txtRadiusValue').focus();
        }
        else {
            $("#headingErrorMsg").find(".slideError").remove();
            $("#errorMsgZipState").find(".slideMandatory").remove();
            if ($(this).val() > 100 || $(this).val() < 5) {
                $(this).val("10");
            }
            $('#RadiusSlider').slider({
                value: $('#txtRadiusValue').val()
            });
            if (!jQuery.isNumeric($('#txtZipCode').val())) {
                $('#showpanel').slideUp("slow");
                var result = GetResources("lblShowOptions");
                var link = $("#open");
                link.html('<a aria-expanded="false" id="seeMoreDetails" style="background-color:white;border:none;color:#0067a6;font-weight:bold;font-size:18px;padding-left:16px;">' + result + '</a>');
                $("#headingErrorMsg").find('.slideError').remove();
                $("#errorMsgZipState").find('.slideMandatory').remove();
            }
            else {
                //$("#errorMsgZipState").find(".zipError").remove();
                $("#errorMsgZipState").find(".stateError").remove();
            }
        }

    });

    $("#txtRadiusValue").keydown(function (e) {
        //
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
    });

    $('#txtRadiusValue').on('keyup', function (e) {
        $("#headingErrorMsg").find('.zipMandatoryOnSearchNow').remove();
        $("#errorMsgZipState").find('.zipErrorOnSearchNow').remove();
        $("#headingErrorMsg").find('.optionalCriteria').remove();
        $("#headingErrorMsg").find('.slideError').remove();
        $("#errorMsgZipState").find('.slideMandatory').remove();
        $("#ErrorMessageForInfo").empty();
        if (!jQuery.isNumeric($('#txtRadiusValue').val()) && $('#txtRadiusValue').val() != "") {
            var errorNumericRadius = GetResources("lblEnterNumericRadiusErrorMessage");
            if ($("#errorMsgZipState").find(".slideMandatory").length == 0)
                $('#errorMsgZipState').append('<div class="slideMandatory">' + errorNumericRadius + '</div>');

            if ($("#headingErrorMsg").find(".slideError").length == 0)
                $('#headingErrorMsg').append('<div class="slideError">' + errorNumericRadius + '</div>');
            $('#txtRadiusValue').focus();
        }
    })
    // checking whether TIN entered is a number or alphabet
    $('#txtTIN').on('keyup', function () {
        if ($('#txtTIN').val() != null && $('#txtTIN').val() != "") {
            if (!jQuery.isNumeric($('#txtTIN').val())) {
                var errorTinNumeric = GetResources("lblTinNumericErrorMessage");
                $("#headingErrorMsg").html(errorTinNumeric);

                var errorEnterNumericValuesInTin = GetResources("lblEnterNumericValuesInTin");
                $('#errorMsgTinOrProvider').html(errorEnterNumericValuesInTin);
            }
            else {
                $("#headingErrorMsg").empty();
                $('#errorMsgTinOrProvider').empty();
            }
        }
        else {
            $("#headingErrorMsg").empty();
            $('#errorMsgTinOrProvider').empty();
        }
    });

    var fixScroll = function (event, ui) {
        $(event.target).find('.ui-accordion-content').css('overflow', 'visible');
    }
    //display the accordion for the criteria entered by the user
    $("#YourCriteriaAccordion").accordion({
        collapsible: true,
        active: false,
        autoFill: true,
        autoHeight: false,
        heightStyle: "content"
    });

    // display an accordion for the providers selected for comparison
    $("#CompareListAccordion").accordion({
        collapsible: true,
        active: false,
        autoFill: true,
        autoHeight: false,
        heightStyle: "content"
    });
    // displaying location accordion in search result page
    $("#RefineLocationAccordion").accordion({
        collapsible: true,
        active: false,
        autoFill: true,
        autoHeight: false,
        heightStyle: "content",
        create: fixScroll,
        change: fixScroll
    });

    // displaying refine result accordion in search result page
    $("#NarrowResultAccordion").accordion({
        collapsible: true,
        active: false,
        autoFill: true,
        autoHeight: false,
        heightStyle: "content"
    });

    //displaying other information accordion in search result page
    $("#OtherImportantInformationAccordion").accordion({
        collapsible: true,
        active: false,
        autoFill: true,
        autoHeight: false,
        heightStyle: "content"
    });
    
    $(".ui-accordion").attr("role", "navigation");
    $(".ui-accordion-header").attr("role", "button");
});

// clearing all the search criteria

function functionClear() {
    var forgeryId = $("#forgeryToken").val();
    var searchRequest = new Object();
    var NetworkType = new Object();
    NetworkType.NetworkId = $('input[name=NetworkType]:checked').val();
    NetworkType.NetworkName = $('input[name=NetworkType]:checked').attr('networktype-name');
    searchRequest.NetworkType = NetworkType;
    searchRequest.ClientSpecificCode = $("#txtClientSpcNet").val();
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/ClearCriteria',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        data: JSON.stringify({ search: searchRequest }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            window.location.href = '/LocateProvider/LocateProviderSearch';
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            //
        }
    });
}

//validating the zip and state field
function validateField() {
    //// 
    var result = 0;
    var UserType = $('.radioChoosenForUser input:radio:checked').val();
    var ProvType = $('.radioChoosen input:radio:checked').val();
    var txtZip = $('#txtZipCode').val();
    var txtState = $('#textbox').html();//$('#SearchState').val();



    if ($("input:radio[id='rbByZip']").is(":checked")) {

        if (txtZip == "" || txtZip == null) {
            var errorZipMandatory = GetResources("lblZipMandatoryOnZipSelection");
            var errorSelectZip = GetResources("lblSelectZipBeforeSearchNow");
            if ($("#headingErrorMsg").find('.zipMandatoryOnSearchNow').length == 0)
                $("#headingErrorMsg").append("<div class='zipMandatoryOnSearchNow'>" + errorZipMandatory + "</div>");

            if ($("#errorMsgZipState").find('.zipErrorOnSearchNow').length == 0)
                $("#errorMsgZipState").append('<div class="zipErrorOnSearchNow">' + errorSelectZip + '</div>');
            result = -1;
            $('#txtZipCode').focus();
        }
    }
    else if ($("input:radio[id='rbByState']").is(":checked")) {
        $('#txtZipCode').empty();
        if (txtState == "" || txtState == "State" || txtState == null || txtState == 'Estado') {
            var errorStateMandatory = GetResources("lblStateMandatoryOnStateSelection");
            var errorSelectState = GetResources("lblSelectStateBeforeSearchNow");
            if ($('#headingErrorMsg').find('.stateMandatory').length == 0)
                $("#headingErrorMsg").append("<div class='stateMandatory'>" + errorStateMandatory + "</div>");

            if ($("#errorMsgZipState").find('.stateError').length == 0)
                $("#errorMsgZipState").append('<div class="stateError">' + errorSelectState + '</div>');
            //$('#SearchState').dropdown('show');
        }

    }
    if (ProvType != null) {
    }
    else {
        var errorProviderTypeMandatory = GetResources("lblProviderTypeIsMandatory");
        var errorSelectProvider = GetResources("lblSelectProviderTypeErrorMessage");
        if ($("#headingErrorMsg").find('.providerMandatory').length == 0)
            $("#headingErrorMsg").append("<div class='providerMandatory'>" + errorProviderTypeMandatory + "</div>");

        $("#errorMsgProviderType").html(errorSelectProvider);
        result = -1;
        $('.radioChoosen input:radio').focus();
    }
    if ($("#UserTypePanelDiv").is(':visible')) {
        if (UserType != null) { }
        else {
            var errorUserTypeMandatory = GetResources("lblUserTypeMandatory");
            var errorSelectUserType = GetResources("lblSelectUserType");
            if ($("#headingErrorMsg").find('.userTypeMandatory').length == 0)
                $("#headingErrorMsg").append("<div class='userTypeMandatory'>" + errorUserTypeMandatory + "</div>");

            $("#errorMsgUserType").html(errorSelectUserType);
            result = -1;
            $('.radioChoosenForUser input:radio').focus();
        }
    }
    return result;
}

// fetching the information on the basis of criteria entered and displaying in the result page on the click of the button
function SearchNowCheck() {
    $("#headingErrorMsg").find('.optionalCriteria').remove();
    $("#ErrorMessageForInfo").empty();
    var providerType = false;
    var userType = true;
    var location = false;
    var forgeryId = $("#forgeryToken").val();
    var ProvType = $('.radioChoosen input:radio:checked').val();
    var UserType = $('.radioChoosenForUser input:radio:checked').val();
    if (ProvType != null) {
        providerType = true;
    }
    if ($("#UserTypePanelDiv").is(':visible')) {
        if (UserType == null) {
            userType = false;
        }
    }

    if ($('#txtZipCode').val() != null && $('#txtZipCode').val().trim() != "" && $('#txtZipCode').val().length == 5) {
        if (document.getElementById("txtRadiusValue").value > 4 && document.getElementById("txtRadiusValue").value <= 100) {
            if ($('#txtTIN').val() != undefined && $('#txtTIN').val() != null && $('#txtTIN').val().trim() != "") {
                if (jQuery.isNumeric($('#txtTIN').val()) && $('#txtTIN').val().length <= 9) {
                    location = true;
                }
                else
                    location = false;
                $('#txtTIN').focus();

            }
            else
                location = true;
            //check npi length

            if ($('#txtProviderNPI').val() != undefined && $('#txtProviderNPI').val() != null && $('#txtProviderNPI').val().trim() != "") {
                if (jQuery.isNumeric($('#txtProviderNPI').val()) && $('#txtProviderNPI').val().length == 10) {
                    location = true;
                }
                else {
                    location = false;
                    $('#txtProviderNPI').focus();
                    return;
                }


            }

            if ($('#txtMedicalLicNo').val() != undefined && $('#txtMedicalLicNo').val() != null && $('#txtMedicalLicNo').val().trim() != "") {
                var RE_NAME = /^[a-zA-Z0-9]+$/i;
                
                if (RE_NAME.test($('#txtMedicalLicNo').val())) {
                    location = true;
                }
                else {
                    location = false;
                    $('#txtMedicalLicNo').focus();
                    return;
                }


            }
            if ( $('#txtProviderPhNo').val() != undefined && $('#txtProviderPhNo').val() != null && $('#txtProviderPhNo').val().trim() != "") {
                if (jQuery.isNumeric($("#txtProviderPhNo").val().substr(1, 3) + $("#txtProviderPhNo").val().substr(5, 3) + $("#txtProviderPhNo").val().substr(9, 4))
                && $('#txtProviderPhNo').val().length > 10) {
                    location = true;
                }
                else {
                    location = false;
                    $('#txtProviderPhNo').focus();
                    return;
                }


            }

        }
        else {
            location = false;
            $('#txtRadiusValue').focus();
        }
    }

    if ($('#textbox').html() != "State" && $('#textbox').html().trim() != "" && $('#textbox').html() != 'Estado') {
        //if ($('#SearchState').val() != null && $('#SearchState').val().trim() != "") {
            {
            if ($('#txtTIN').val() != undefined && $('#txtTIN').val() != null && $('#txtTIN').val().trim() != "") {
                if (jQuery.isNumeric($('#txtTIN').val()) && $('#txtTIN').val().length <= 9) {
                    location = true;
                }
                else
                    location = false;
                $('#txtTIN').focus();
            }
            else
                location = true;
            //check npi length
             
            if ($('#txtProviderNPI').val() != undefined && $('#txtProviderNPI').val() != null && $('#txtProviderNPI').val().trim() != "") {
                if ($('#txtProviderNPI').val().length == 10) {
                    location = true;
                }
                else {
                    location = false;
                    $('#txtProviderNPI').focus();
                    return;
                }
            }
            if ($('#txtProviderPhNo').val() != undefined && $('#txtProviderPhNo').val() != null && $('#txtProviderPhNo').val().trim() != "") {
                if ($('#txtProviderPhNo').val().length > 10) {
                    location = true;
                }
                else {
                    location = false;
                    $('#txtProviderPhNo').focus();
                    return;
                }


            }

        }
    }

    if (providerType && location && userType) {
        $("#headingErrorMsg").find('.stateMandatory').remove();
        $("#headingErrorMsg").find('.providerMandatory').remove();
        $("#headingErrorMsg").find('.userTypeMandatory').remove();
        $("#headingErrorMsg").find('.zipMandatory').remove();
        $("#headingErrorMsg").find('.zipValid').remove();
        $("#errorMsgZipState").empty();
        $("#errorMsgProviderType").empty();
        $("#errorMsgUserType").empty();
        var searchRequest = new Object();
        var NetworkType = new Object();
        NetworkType.NetworkId = $('input[name=NetworkType]:checked').val();
        NetworkType.NetworkName = $('input[name=NetworkType]:checked').attr('networktype-name');
        searchRequest.NetworkType = NetworkType;
        searchRequest.ClientSpecificCode = $("#txtClientSpcNet").val();

        var providerType = new Object();
        providerType.ProviderTypeID = $('input[name="ProviderType"]:checked').val();
        providerType.ProviderTypeName = $('input[name="ProviderType"]:checked').attr('provider-name');
        providerType.ProviderTypeNameSpanish = $('input[name="ProviderType"]:checked').attr('provider-name1');
        searchRequest.ProviderType = providerType;
        searchRequest.AcceptingNewPatients = $('input[name="ProviderAcceptingNewPatient"]:checked').val();
        
        searchRequest.CustomerType = $('input[name=UserType]:checked').val();
        if ($('#txtZipCode').val().trim() != "") {
            searchRequest.Zipcode = $('#txtZipCode').val();
            searchRequest.Radius = $('#txtRadiusValue').val();
        }
        else if ($('#textbox').html() != "State" && $('#textbox').html().trim() != "" && $('#textbox').html() != 'Estado') {
            //
            ////Start Code change related to new dropdown
            searchRequest.State = $('#ulState li[aria-selected="true"]').attr('id').trim();// $('#textbox').html();

            //CountyList Start 
            var options_str = '';
            var $selectedOptions = $('li[aria-selected="true"]', $('#ulCounty'));
            if ($selectedOptions.length > 0) {
                $selectedOptions.each(function () {
                    options_str += $(this).text() + ', ';
                });
                options_str = options_str.slice(0, -2);
            }
            var countyList = [];
            if (options_str != '')
                countyList = options_str.split(",").map(function (item) {
                    return item.trim();
                });;

            searchRequest.CountyCodes = countyList;
            //County List END

            //CityList Start 
            var options_str1 = '';
            var $selectedOptions1 = $('li[aria-selected="true"]', $('#ulCity'));
            if ($selectedOptions1.length > 0) {
                $selectedOptions1.each(function () {
                    options_str1 += $(this).text() + ', ';
                });
                options_str1 = options_str1.slice(0, -2);
            }
            var cityList = [];
            if (options_str1 != '') {
                cityList = options_str1.split(",").map(function (item) {
                    return item.trim();
                })
            };
            searchRequest.CityCodes = cityList;
            //CityList End
            //// End Code change related to new dropdown
        }

       
        if ($('#txtProviderName').val() != undefined && $('#txtProviderName').val() != null && $('#txtProviderName').val().trim() != "") {
            searchRequest.ProviderName = $('#txtProviderName').val().trim();
        }
        if ($('#txtPracticeName').val() != undefined && $('#txtPracticeName').val() != null && $('#txtPracticeName').val().trim() != "") {
            searchRequest.RefinePracticename = $('#txtPracticeName').val().trim();
        }
        if ($('#txtProviderPhNo').val() != undefined && $('#txtProviderPhNo').val() != null && $('#txtProviderPhNo').val().trim() != "") {
            searchRequest.ProviderPhNo = $('#txtProviderPhNo').val().trim().substr(1, 3) + $('#txtProviderPhNo').val().trim().substr(5, 3) + $('#txtProviderPhNo').val().trim().substr(9, 4);
        }
        if ($('#txtMedicalLicNo').val() != undefined && $('#txtMedicalLicNo').val() != null && $('#txtMedicalLicNo').val().trim() != "") {
            searchRequest.ProviderMedicalLicNo = $('#txtMedicalLicNo').val().trim();
        }
        if ($('#txtProviderNPI').val() != undefined && $('#txtProviderNPI').val() != null && $('#txtProviderNPI').val().trim() != "") {
            searchRequest.ProviderNPI = $('#txtProviderNPI').val().trim();
        }
        if ($('#ProviderNameHiddenValue').val() != undefined && $('#ProviderNameHiddenValue').val() != null && $('#ProviderNameHiddenValue').val().trim() != "") {
            searchRequest.ProviderNumber = $('#ProviderNameHiddenValue').val().trim();
        }
        if ($('#txtTIN').val() != undefined && $('#txtTIN').val() != null && $('#txtTIN').val().trim() != "") {
            searchRequest.Tin = $('#txtTIN').val().trim();
        }

        var specialityOrCondition = $('input[name="SpecialityOrCondition"]:checked').val();

        if (specialityOrCondition == "Speciality") {
            var SpecialtyCodes = [];
            //
            $('#Mappedspecialities option').each(function (i, selected) {
                if ($(selected).val() != "-1") {
                    //
                    var SpecialtyEntity = new Object();
                    SpecialtyEntity.SpecialtyCode = $(selected).val();
                    SpecialtyEntity.SpecialtyName = $(selected).attr("data-eng");
                    SpecialtyEntity.SpecialtySpanish = $(selected).attr("data-spn");
                    SpecialtyCodes.push(SpecialtyEntity);


                }
            });
            searchRequest.SpecialtyCodes = SpecialtyCodes;

        }
        else if (specialityOrCondition == "Condition") {
            var ConditionCodes = [];
            $('#SelectCondition :selected').each(function (i, selected) {
                if ($(selected).val() != "-1") {
                    var Conditions = new Object();
                    Conditions.ConditionCode = $(selected).val();
                    Conditions.ConditionsName = $(selected).attr("data-eng");
                    Conditions.ConditionSpanish = $(selected).attr("data-spn");
                    ConditionCodes.push(Conditions);

                }
            });
            searchRequest.ConditionCodes = ConditionCodes;
        }
        else if (specialityOrCondition == "Focus") {
            var focusCodes = [];
            //
            $('#Mappedfocus option').each(function (i, selected) {
                if ($(selected).val() != "-1") {
                    //
                    var focusEntity = new Object();
                    focusEntity.FocusCode = $(selected).val();
                    focusEntity.FocusName = $(selected).attr("data-eng");
                    focusEntity.FocusSpanish = $(selected).attr("data-spn");
                    focusCodes.push(focusEntity);


                }
            });
            searchRequest.FocusCodes = focusCodes;
        }
        $.ajax({
            type: 'POST',
            url: '/LocateProvider/SaveSearchRequestToSession',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ search: searchRequest }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                $.ajax({
                    type: 'POST',
                    url: '/LocateProvider/SaveRefineRequestToSession',
                    contentType: "application/json; charset=utf-8",
                    datatype: 'json',
                    data: JSON.stringify({ search: searchRequest }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    success: function (result) {
                        //$("#spinnerPopup").modal('show');
                        $('#spinnerPopup').modal({
                            focus: this,
                            show: true
                        })
                        window.location.href = '/LocateProvider/LocateProviderSearchResult/';
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        //
                    }
                });
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                //
            }
        });

    }

}


// validating the zipcode enters by the user
function CheckZipDesktop(id) {
    var forgeryId = $("#forgeryToken").val();
    $("#headingErrorMsg").find('.zipMandatoryOnSearchNow').remove();
    $("#errorMsgZipState").find('.zipErrorOnSearchNow').remove();

    //// 
    var result = validateField();
    if (($("input:radio[id='rbByZip']").is(":checked")) && result == 0) {
        var txtZip = $('#txtZipCode').val();
        if (!jQuery.isNumeric($('#txtZipCode').val())) {
            $("#headingErrorMsg").find(".zipMandatory").remove();
            $('#errorMsgZipState').find(".zipError").remove();
            $("#headingErrorMsg").find('.zipValid').remove();
            $('#errorMsgZipState').find(".zipCheckValid").remove();
            var errorZipNumeric = GetResources("lblErrorMsgEnterNumericValuesInZip");
            if ($("#errorMsgZipState").find(".zipError").length == 0)
                $('#errorMsgZipState').append('<div class="zipError">' + errorZipNumeric + '</div>');

            if ($("headingErrorMsg").find('.zipMandatory').length == 0)
                $('#headingErrorMsg').append("<div class='zipMandatory'>" + errorZipNumeric + "</div>");
            $('#txtZipCode').focus();
        }
        else {
            $("#headingErrorMsg").find(".zipMandatory").remove();
            $('#errorMsgZipState').find(".zipError").remove();
            $.ajax({
                type: 'POST',
                url: '/LocateProvider/CheckZipCode',
                contentType: "application/json; charset=utf-8",
                datatype: 'json',
                data: JSON.stringify({ txtZip: txtZip }),
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {
                    if (result == "True") {
                        $("#headingErrorMsg").find(".zipValid").remove();
                        $('#errorMsgZipState').find(".zipCheckValid").remove();
                        isValid = result;
                        if (id == "open") {
                            ShowDetails();
                        }
                        else
                            SearchNowCheck();
                    }
                    else {
                        var errorZipValid = GetResources("lblErrorMsgValidZip");
                        if ($("#headingErrorMsg").find(".zipValid").length == 0)
                            $("#headingErrorMsg").append('<div  class="zipValid">' + errorZipValid + '</div>');

                        if ($("#errorMsgZipState").find(".zipCheckValid").length == 0)
                            $('#errorMsgZipState').html('<div class="zipCheckValid">' + errorZipValid + '</div>');
                        $('#showpanel').slideUp("slow");
                        var result = GetResources("lblShowOptions");
                        var link = $("#open");
                        link.html('<a aria-expanded="false" id="seeMoreDetails" style="background-color:white;border:none;color:#0067a6;font-weight:bold;font-size:18px;padding-left:16px;">' + result + '</a>');
                        $('#txtZipCode').focus();
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    //
                }
            });
        }
    }
    else {
        // 
        if (id == "open")
            ShowDetails();
        else
            SearchNowCheck();
    }
}



// changing heading of the collapsible panel to espanol and vice versa
function GetResources(key) {
    var forgeryId = $("#forgeryToken").val();
    var returnValue;
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/GetResources',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        async: false,
        data: JSON.stringify({ key: key }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            //// 
            returnValue = result;

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
    //// 
    return returnValue;
}

// go to specialty page
function GoToSpecialtyPage() {
    var forgeryId = $("#forgeryToken").val();
    var providerType = false;
    var userType = true;
    var location = false;
    var ProvType = $('.radioChoosen input:radio:checked').val();
    if (ProvType != null) {
        providerType = true;
    }

    var UserType = $('.radioChoosenForUser input:radio:checked').val();
    if ($("#UserTypePanelDiv").is(':visible')) {
        if (UserType == null) {
            userType = false;
        }
    }
    if ($('#txtZipCode').val() != null && $('#txtZipCode').val().trim() != "" && $('#txtZipCode').val().length == 5) {
        if (document.getElementById("txtRadiusValue").value > 4 && document.getElementById("txtRadiusValue").value <= 100) {
            location = true;
        }
        else {
            location = false
        }
    }

    if ($('#textbox').html() != "" || $('#textbox').html() != "State" || $('#textbox').html() != null || $('#textbox').html() != 'Estado') {
    //if ($('#SearchState').val() != null && $('#SearchState').val().trim() != "") {
        location = true;
    }

    if (providerType && location && userType) {
        $("#headingErrorMsg").find('.stateMandatory').remove();
        $("#headingErrorMsg").find('.providerMandatory').remove();
        $("#headingErrorMsg").find('.userTypeMandatory').remove();
        $("#headingErrorMsg").find('.zipMandatory').remove();
        $("#errorMsgZipState").find('.zipError').remove();
        $("#headingErrorMsg").find('.zipMandatoryOnSearchNow').remove();
        $("#errorMsgZipState").find('.zipErrorOnSearchNow').remove();
        $("#headingErrorMsg").find('.zipValid').remove();
        $("#errorMsgZipState").empty();
        $("#errorMsgProviderType").empty();
        $("#errorMsgUserType").empty();
        var searchRequest = new Object();
        var NetworkType = new Object();
        NetworkType.NetworkId = $('input[name=NetworkType]:checked').val();
        NetworkType.NetworkName = $('input[name=NetworkType]:checked').attr('networktype-name');
        searchRequest.NetworkType = NetworkType;
        searchRequest.ClientSpecificCode = $("#txtClientSpcNet").val();
        var providerType = new Object();

        providerType.ProviderTypeID = $('input[name="ProviderType"]:checked').val();
        providerType.ProviderTypeName = $('input[name="ProviderType"]:checked').attr('provider-name');
        providerType.ProviderTypeName = $('input[name="ProviderType"]:checked').attr('provider-name1');
        searchRequest.ProviderType = providerType;
        searchRequest.AcceptingNewPatients = $('input[name="ProviderAcceptingNewPatient"]:checked').val();
        

        searchRequest.CustomerType = $('input[name=UserType]:checked').val();
        //// 
        if ($('#txtZipCode').val().trim() != "") {
            searchRequest.Zipcode = $('#txtZipCode').val();
            searchRequest.Radius = $('#txtRadiusValue').val();
        }
        else if ($('#textbox').html() != "State" && $('#textbox').html().trim() != "" && $('#textbox').html() != 'Estado') {
            //
            ////Start Code change related to new dropdown
            searchRequest.State = $('#ulState li[aria-selected="true"]').attr('id').trim();// $('#textbox').html();

            //CountyList Start 
            var options_str = '';
            var $selectedOptions = $('li[aria-selected="true"]', $('#ulCounty'));
            if ($selectedOptions.length > 0) {
                $selectedOptions.each(function () {
                    options_str += $(this).text() + ', ';
                });
                options_str = options_str.slice(0, -2);
            }
            var countyList = [];
            if (options_str != '')
                countyList = options_str.split(",").map(function (item) {
                    return item.trim();
                });;

            searchRequest.CountyCodes = countyList;
            //County List END

            //CityList Start 
            var options_str1 = '';
            var $selectedOptions1 = $('li[aria-selected="true"]', $('#ulCity'));
            if ($selectedOptions1.length > 0) {
                $selectedOptions1.each(function () {
                    options_str1 += $(this).text() + ', ';
                });
                options_str1 = options_str1.slice(0, -2);
            }
            var cityList = [];
            if (options_str1 != '') {
                cityList = options_str1.split(",").map(function (item) {
                    return item.trim();
                })
            };
            searchRequest.CityCodes = cityList;
            //CityList End
            //// End Code change related to new dropdown
        }

        if ($('#txtProviderName').val() != undefined && $('#txtProviderName').val() != null && $('#txtProviderName').val().trim() != "") {
            searchRequest.ProviderName = $('#txtProviderName').val().trim();
        }
        if ($('#txtPracticeName').val() != undefined && $('#txtPracticeName').val() != null && $('#txtPracticeName').val().trim() != "") {
            searchRequest.RefinePracticename = $('#txtPracticeName').val().trim();

        }
        if ($('#txtProviderPhNo').val() != undefined && $('#txtProviderPhNo').val() != null && $('#txtProviderPhNo').val().trim() != "") {
            searchRequest.ProviderPhNo = $('#txtProviderPhNo').val().trim().substr(1, 3) + $('#txtProviderPhNo').val().trim().substr(5, 3) + $('#txtProviderPhNo').val().trim().substr(9, 4);
        }
        if ($('#txtMedicalLicNo').val() != undefined && $('#txtMedicalLicNo').val() != null && $('#txtMedicalLicNo').val().trim() != "") {
            searchRequest.ProviderMedicalLicNo = $('#txtMedicalLicNo').val().trim();
        }
        if ($('#txtProviderNPI').val() != undefined && $('#txtProviderNPI').val() != null && $('#txtProviderNPI').val().trim() != "") {
            searchRequest.ProviderNPI = $('#txtProviderNPI').val().trim();
        }
        if ($('#ProviderNameHiddenValue').val() != undefined && $('#ProviderNameHiddenValue').val() != null && $('#ProviderNameHiddenValue').val().trim() != "") {
            searchRequest.ProviderNumber = $('#ProviderNameHiddenValue').val().trim();
        }
        if ($('#txtTIN').val() != undefined && $('#txtTIN').val() != null && $('#txtTIN').val().trim() != "") {
            searchRequest.Tin = $('#txtTIN').val().trim();
        }

        var specialityOrCondition = $('input[name="SpecialityOrCondition"]:checked').val();

        if (specialityOrCondition == "Speciality") {
            var SpecialtyCodes = [];
            //
            $('#Mappedspecialities option').each(function (i, selected) {
                if ($(selected).val() != "-1") {
                    //
                    var SpecialtyEntity = new Object();
                    SpecialtyEntity.SpecialtyCode = $(selected).val();
                    SpecialtyEntity.SpecialtyName = $(selected).attr("data-eng");
                    SpecialtyEntity.SpecialtySpanish = $(selected).attr("data-spn");

                    SpecialtyCodes.push(SpecialtyEntity);


                }
            });
            searchRequest.SpecialtyCodes = SpecialtyCodes;

        }
        else if (specialityOrCondition == "Condition") {
            var ConditionCodes = [];

            $('#SelectCondition :selected').each(function (i, selected) {
                if ($(selected).val() != "-1") {
                    var Conditions = new Object();
                    Conditions.ConditionCode = $(selected).val();
                    Conditions.ConditionsName = $(selected).attr("data-eng");
                    Conditions.ConditionSpanish = $(selected).attr("data-spn");

                    ConditionCodes.push(Conditions);

                }
            });
            searchRequest.ConditionCodes = ConditionCodes;
        }
        else if (specialityOrCondition == "Focus") {

            var focusCodes = [];
            //
            $('#Mappedfocus option').each(function (i, selected) {
                if ($(selected).val() != "-1") {
                    //
                    var focusEntity = new Object();
                    focusEntity.FocusCode = $(selected).val();
                    focusEntity.FocusName = $(selected).attr("data-eng");
                    focusEntity.FocusSpanish = $(selected).attr("data-spn");
                    focusCodes.push(focusEntity);
                }
            });
            searchRequest.FocusCodes = focusCodes;

        }
        $.ajax({
            type: 'POST',
            url: '/LocateProvider/SaveSearchRequestToSession',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ search: searchRequest }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                $.ajax({
                    type: 'POST',
                    url: '/LocateProvider/SaveRefineRequestToSession',
                    contentType: "application/json; charset=utf-8",
                    datatype: 'json',
                    data: JSON.stringify({ search: searchRequest }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    success: function (result) {
                        window.location.href = '/LocateProviderSpecialityDefination/Index';
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                    }
                });

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                //
            }
        });

    }
    else {

    }


}
function keyHandler(event, id) {
    // 

    if (event.which === 13) {
        return CheckZipDesktop(id);
    }
    return true;
}




function UserTypeSelectionChange(userTypeId) {
    $("#errorMsgUserType").empty();
    var forgeryId = $("#forgeryToken").val();
    $('input[name="ProviderType"]').prop('checked', false);
    $('#txtZipCode').val('');
    $('#txtRadiusValue').val('10');
    $("#RadiusSlider").slider({
        value: $('#txtRadiusValue').val()
    });
    $("#txtProviderName").val("");
    $("#txtPracticeName").val("");
    $("#txtProviderPhNo").val("");
    $("#txtMedicalLicNo").val("");
    $("#txtProviderNPI").val("");
    $("#txtTIN").val("");
    $("#rbByState").prop('checked', false);
    $("#rbByZip").prop('checked', true);
    $("#zipDiv").show();
    $("#stateDiv").hide();
    $("#selectedSpeciality").val("");
    $("#countOfSpecialty").val('------------5' + GetResources("lblSpecialtiesRemaining"));
    $("#Mappedspecialities").empty();
    $("#selectedFocus").val("");
    $("#countOfFocus").val('------------5' + GetResources("lblFocusRemaining"));
    $("#Mappedfocus").empty();
    $("#selectedCondition").val("");
    $("#headingErrorMsg").empty();
    $("#errorMsgZipState").empty();
    $("#ErrorMessageForInfo").empty();
    $("#errorMsgProviderType").empty();
    $("#btnAddRemoveError").empty();
    $('#errorMsgTinOrProvider').empty();
    $('#SearchCounty').empty();

    $('#SearchCounty').multiselect("deselectAll", false).multiselect("rebuild");
    $('#SearchCity').multiselect("deselectAll", false).multiselect("rebuild");
    $('#SearchState').multiselect("deselectAll", false).multiselect("rebuild");

    $('#selectedCounty').empty();
    $('#selectedCity').empty();
    $('#SearchCounty').multiselect('rebuild')
    //$("#SearchCounty").trigger("change");
    $('#SearchCity').empty();
    $('#SearchCity').multiselect('rebuild')
    //$("#SearchCity").trigger("change");

    $('#showpanel').slideUp("slow");
    var result = GetResources("lblShowOptions");
    var link = $("#open");
    link.html('<a aria-expanded="false" id="seeMoreDetails" style="background-color:white;border:none;color:#0067a6;font-weight:bold;font-size:18px;padding-left:16px;">' + result + '</a>');

}

function RemoveItems(itemValue, element, parentId) {
    var selectedOptions = $("#" + element + ' option').filter(function () {
        return $(this).is(':selected');
    });
    selectedOptions.each(function () {
        var input = $('input[value="' + $(this).val() + '"]');
        input.prop('checked', false);

    });
    $("#" + parentId + itemValue).remove();
}
function AddItemsToDiv(itemValue, element, parentId) {
    $("#" + parentId).empty();
    for (var i = 0; i < itemValue.length; i++) {
        $("#" + parentId).append('<span class="tab">' + itemValue[i].value + '</span>');

    }
}
function DisableCheckboxes(selector, selectedDiv) {
    // 
    // Get selected options.
    var selectedOptions = $('#' + selector + ' option:selected');
    AddItemsToDiv(selectedOptions, selector, selectedDiv);

    if (selectedOptions.length >= 7) {
        // Disable all other checkboxes.
        var nonSelectedOptions = $('#' + selector + ' option').filter(function () {
            return !$(this).is(':selected');
        });

        nonSelectedOptions.each(function () {
            var input = $('input[value="' + $(this).val() + '"]');
            input.prop('disabled', true);
            input.parent('li').addClass('disabled');
        });
    }
    else {
        // Enable all checkboxes.
        $('#' + selector + ' option').each(function () {
            var input = $('input[value="' + $(this).val() + '"]');
            input.prop('disabled', false);
            input.parent('li').addClass('disabled');
        });
    }
}
