﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;
using System.Web.Mvc;


namespace NABWebsite.Models
{
    //ViewModel for "Claim Activity Report"
   [Serializable()]
    public class ReportGenerationCriteriaModel
    {
        public List<NetworkClaimActivity> NetworkList { get; set; }

        public List<ClaimType> ClaimTypeList { get; set; }

        public string FacilityCheck { get; set; }

        //public List<ClaimType> ClaimTypeListChosen { get; set; }

        public List<BillType> BillTypeList { get; set; }

        public string DateBasedOnSelected { get; set; }

        public string DateSelected { get; set; }

        public IEnumerable<DateBasedOn> DateBasedList { get; set; }

        public string DateRangeValue { get; set; }

        public string StartDate { get; set; }
       

        public string EndDate { get; set; }
        //public string StartDateVal { get; set; }

        public AllTins TinDropDown { get; set; }

        public string TinChosen { get; set; }
        public string Tins { get; set; }

        public string ProviderSelected { get; set; }

        public IEnumerable<Provider> ProviderList { get; set; }

        public string NetworkChosenView { get; set; }
        public string NetworkChosen { get; set; }

        public List<NetworkRecordCount> RecordCounts { get; set; }

        public NetworkRecordCount NetworkRecordChosen { get; set; }

        public string Tin { get; set; }

        public IEnumerable<string> TinNumbers { get; set; }

        public IEnumerable<TinNumbers> TinList { get; set; }


        public FilterData DataFilters { get; set; }



        public string ProviderNamesArray { get; set; }

        public string ProviderNamesArrayDisplay { get; set; }

        public RecordDataModel RecordDataInfo { get; set; }

        public string DateSummary { get; set; }

        public string ClaimSummary { get; set; }

        public string FileId { get; set; }

        public string FileType { get; set; }

        public string FileName { get; set; }

        public int ChosenNetworkCount { get; set; }
   
        public List<SavedReportModel> ModelObjects { get; set; }

        public string ChosenId { get; set; }
        public string ChosenGlyph { get; set; }

        public string PayerNumber { get; set; }

        public string PayerNumberAll { get; set; }

        public IEnumerable<SelectListItem> PayerDropDown { get; set; }

        public string PayerChosen { get; set; }

        public string PayerTotal { get; set; }

        public IEnumerable<GroupNumbers> GroupList { get; set; }

        public IEnumerable<string> PayerNumbers { get; set; }

        public string GroupNamesArray { get; set; }

        public string GroupNamesArrayDisplay { get; set; }

        public string PayerDropDownValues { get; set; }

        public string ReportButton { get; set; }

        public string TinProviderList { get; set; }

        public string PayerGroupList { get; set; }
        public string NetworkSelected { get; set; }
    }
    
    //ViewModel for details of Saved criteria of "Claim Activity Report"
     [Serializable()]
    public class SavedReportModel
    {
        public string Id { get; set; }
        public string ReportDetails { get; set; }
        public string ProductType { get; set; }
        public string FormType1 { get; set; }
        public string FormType2 { get; set; }
        public string BillType { get; set; }
        public string SearchType { get; set; }
        public string Tin { get; set; }
        public string ProviderName { get; set; }
        public string ProviderNameDisplay { get; set; }
        public string Payers { get; set; }
        public string GroupNames { get; set; }
        public string GroupNamesDisplay { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string ClaimForm { get; set; }
        public string ReportDates { get; set; }

    }


    //ViewModel for Paging and sorting of "Claim Activity Report"
     [Serializable()]
    public class RecordDataModel
    {
        public RecordDataModel()
        {
            this.Pages = new List<OutputDataEntity>();
        }
        public int PageNo { get; set; }
        public int TotalPages { get; set; }
        public string SortBy { get; set; }
        public string SortType { get; set; }
        public IEnumerable<OutputDataEntity> Pages { get; set; }
    }
}