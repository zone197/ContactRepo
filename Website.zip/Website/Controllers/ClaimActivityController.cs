﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NABWebsite.DTO;
using NABWebsite.BLL;
using NABWebsite.Models;
using System.Text;
using System.Globalization;
using System.Configuration;
using Aetna.Cofinity.Admin.Entities.Response;
using Utilities;


namespace NABWebsite.Controllers
{
    public class ClaimActivityController : BaseController
    {
        ReportGenerationCriteriaBLL ReportGenerationCriteriaObjectBLL = new ReportGenerationCriteriaBLL();

        delegate void DgGenerateFile(string emailId, ReportCriteriaEntity callingObject);


        #region Report Generation Search Criteria Page

        /// <summary>
        /// Load the index page of claim activity report
        /// </summary>
        /// <returns></returns>
        [CheckAccess(Function = "Claims Activity Report")]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] != null && ((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    Session[Constants.CurrentController] = Constants.ClaimActivityController;
                    Session[Constants.CurrentAction] = "Index";
                    Session[Constants.Header] = Constants.ClaimActivityReportHead;

                    ReportGenerationCriteriaModel ReportGenerationCriteriaObjectModel = new ReportGenerationCriteriaModel();

                    MakeIndexPageListObjects(ReportGenerationCriteriaObjectModel);

                    if (ConfigurationManager.AppSettings[Constants.Site].ToUpperInvariant() == Constants.External.ToUpperInvariant())
                    {
                        if (((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Provider.ToUpperInvariant())
                        {
                            bool isEmployee = false;
                            if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                            {
                                isEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                            }
                            List<NetworkClaimActivity> networkList = new List<NetworkClaimActivity>();
                            //List<string> networkList = new List<string>();
                            string network = string.Empty;
                            if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                            {
                                //get selected role
                                Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                                //get the network for selcted function
                                //networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuClaimActivity, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                                networkList = ReportGenerationCriteriaObjectModel.NetworkList;
                            }
                            int SrcsystemIds = 0;
                            if (networkList != null)
                            {
                                if (networkList.Count > 1)
                                {
                                    foreach (var item in networkList)
                                    {
                                        if (item.ClaimNetworkType == true && item.ClaimNetworkValue == Constants.ActivityFirstHealth)
                                        {
                                            network = item.ClaimNetworkValue;
                                            SrcsystemIds = Constants.ThreeCount;
                                        }

                                    }
                                }
                                else
                                {
                                    foreach (var item in networkList)
                                    {
                                        if (item.ClaimNetworkType == true && item.ClaimNetworkValue == Constants.ActivityFirstHealth)
                                        {
                                            network = item.ClaimNetworkValue;
                                            SrcsystemIds = Constants.ThreeCount;
                                        }
                                        else if (item.ClaimNetworkType == true && item.ClaimNetworkValue == Constants.Cofinity)
                                        {
                                            network = item.ClaimNetworkValue;
                                            SrcsystemIds = Constants.OneCount;
                                        }
                                    }
                                }
                            }



                            ReportGenerationCriteriaObjectModel.TinDropDown = ReportGenerationCriteriaObjectBLL.GetAllTinlist(((UserDetails)Session[Constants.UserDetails]).UserId, ((UserDetails)Session[Constants.UserDetails]).SelectedRole, isEmployee, network, SrcsystemIds);
                        }
                        else
                            if (((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                            {
                                ReportCriteriaEntity modelObject = new ReportCriteriaEntity();
                                List<string> networkList = new List<string>();
                                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                                && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                                && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                                {
                                    //get selected role
                                    Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                                    //get the network for selcted function
                                    networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuClaimActivity, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                                }


                                if (networkList != null)
                                {
                                    modelObject.NetworkChosen = string.Join(",", networkList);
                                }
                                SetUserAccess(modelObject);
                                ReportGenerationCriteriaObjectModel.PayerDropDown = ReportGenerationCriteriaObjectBLL.GetAllPayerList(modelObject);
                            }
                    }
                    traceLog.AppendLine(" & End: ClaimActivityController, Index Method");
                    return View("Index", ReportGenerationCriteriaObjectModel);
                }
                else
                    traceLog.AppendLine(" & End: ClaimActivityController, Index Method");
                return RedirectToAction("Index", "Home");

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private void MakeIndexPageListObjects(ReportGenerationCriteriaModel ReportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, MakeIndexPageListObjects Method with Param ReportGenerationCriteriaObjectModel: " + ReportGenerationCriteriaObjectModel);
                List<string> networkList = new List<string>();
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                                    && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                                    && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                {
                    //get selected role
                    Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                    //get the network for selcted function
                    networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuClaimActivity, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                }

                ReportGenerationCriteriaObjectModel.NetworkList = GetNetworkTypes(networkList).ToList();
                ReportGenerationCriteriaObjectModel.ClaimTypeList = GetClaimTypes().ToList();
                ReportGenerationCriteriaObjectModel.BillTypeList = GetBillTypes().ToList();
                ReportGenerationCriteriaObjectModel.DateBasedList = GetDateBasedList().ToList();
                ReportGenerationCriteriaObjectModel.ProviderList = ((UserDetails)Session[Constants.UserDetails]).SelectedRole == Constants.Provider ? GetProviderSelectList() : GetPayerSelectList();
                traceLog.AppendLine(" & End: ClaimActivityController, MakeIndexPageListObjects Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// fetch network type for claim activity home page
        /// </summary>
        /// <returns></returns>
        private static IEnumerable<NetworkClaimActivity> GetNetworkTypes(List<string> networkList)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, GetNetworkTypes Method with Param: " + networkList);
                List<NetworkClaimActivity> listObject = new List<NetworkClaimActivity>();
                //{
                //    new NetworkClaimActivity{ClaimNetworkType=false, ClaimNetworkDisplay=Constants.ActivityFirstHealth,ClaimNetworkValue = Constants.ActivityFirstHealth},
                //    new NetworkClaimActivity{ClaimNetworkType=false, ClaimNetworkDisplay=Constants.Cofinity,ClaimNetworkValue = Constants.Cofinity}
                //};
                foreach (var item in networkList)
                {
                    NetworkClaimActivity network = null;
                    if (item == Constants.ActivityFirstHealth)
                    {
                        network = new NetworkClaimActivity() { ClaimNetworkType = true, ClaimNetworkDisplay = item, ClaimNetworkValue = item };// id= 3 for FH.
                    }
                    else if (item == Constants.Cofinity)
                    {
                        network = new NetworkClaimActivity() { ClaimNetworkType = true, ClaimNetworkDisplay = item, ClaimNetworkValue = item };// id=1 for cofinity.
                    }
                    listObject.Add(network);

                }
                traceLog.AppendLine(" & End: ClaimActivityController, GetNetworkTypes Method");
                return listObject;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }



        /// <summary>
        /// fetch claim type for claim activity home page
        /// </summary>
        /// <returns></returns>
        private static IEnumerable<ClaimType> GetClaimTypes()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, GetClaimTypes Method");
                List<ClaimType> listobject = new List<ClaimType> 
                {
                    new ClaimType{ClaimFormType=false,ClaimFormDisplay=Constants.ProfessionalDisplay,ClaimFormValue=Constants.Professional},
                    new ClaimType{ClaimFormType=false,ClaimFormDisplay=Constants.FacilityDisplay,ClaimFormValue=Constants.Facility},
                };
                traceLog.AppendLine(" & End: ClaimActivityController, GetClaimTypes Method");
                return listobject;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// fetch bill type for claim activity home page
        /// </summary>
        /// <returns></returns>
        private static IEnumerable<BillType> GetBillTypes()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, GetBillTypes Method");
                List<BillType> listobject = new List<BillType>
                {
                    new BillType{BillFormType=false,BillTypeDisplay=Constants.Inpatient ,BillTypeValue=Constants.InpatientValue},
                    new BillType{BillFormType=false,BillTypeDisplay=Constants.Outpatient,BillTypeValue=Constants.OutpatientValue},
            
                };

                traceLog.AppendLine(" & End: ClaimActivityController, GetBillTypes Method");
                return listobject;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        ///  fetch date type for claim activity home page
        /// </summary>
        /// <returns></returns>
        private static IEnumerable<DateBasedOn> GetDateBasedList()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, GetDateBasedList Method");
                List<DateBasedOn> listobject = new List<DateBasedOn>
                {
                    new DateBasedOn{ DateBasedSelectionDisplay=Constants.ServiceDate , DateBasedSelectionValue=Constants.Dos},
                    new DateBasedOn{ DateBasedSelectionDisplay=Constants.DateRepricedNetwork , DateBasedSelectionValue=Constants.Priced},
                };
                traceLog.AppendLine(" & End: ClaimActivityController, GetDateBasedList Method");
                return listobject;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// fetch provider Select type for claim activity home page
        /// </summary>
        /// <returns></returns>
        private static IEnumerable<Provider> GetProviderSelectList()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, GetProviderSelectList Method");
                List<Provider> listobject = new List<Provider>
                    {
                        new Provider{ProviderSelectDisplay=Constants.AllProviderDisplay , ProviderSelectValue=Constants.AllProvider},
                        new Provider{ProviderSelectDisplay=Constants.SelectedProviderDisplay , ProviderSelectValue=Constants.SelectedProvider},
                    };
                traceLog.AppendLine(" & End: ClaimActivityController, GetProviderSelectList Method");
                return listobject;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// fetch payer Select type for claim activity home page
        /// </summary>
        /// <returns></returns>
        private static IEnumerable<Provider> GetPayerSelectList()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, GetPayerSelectList Method");
                List<Provider> listobject = new List<Provider>
                    {
                        new Provider{ProviderSelectDisplay=Constants.AllPayerDisplay , ProviderSelectValue=Constants.AllGroup},
                        new Provider{ProviderSelectDisplay=Constants.SelectedPayerDisplay , ProviderSelectValue=Constants.SelectedGroup},
                    };
                traceLog.AppendLine(" & End: ClaimActivityController, GetPayerSelectList Method");
                return listobject;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }



        /// <summary>
        /// make partial view for the provider names along with tin
        /// </summary>
        /// <param name="reportGenerationCriteriaObjectModel"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult SelectedProvider(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, SelectedProvider Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, SelectedProvider Method");
                    return Content(Constants.ContentHome);
                }
                var network = "";

                if (reportGenerationCriteriaObjectModel != null)
                {

                    network = string.Join(",", reportGenerationCriteriaObjectModel
                                        .NetworkList
                                        .Where(y => y.ClaimNetworkType)
                                        .Select(y => y.ClaimNetworkValue.ToString()));


                    ReportCriteriaEntity inputEntity = new ReportCriteriaEntity();

                    SetUserAccess(inputEntity);

                    inputEntity.NetworkChosen = network;
                    inputEntity.TinNo = reportGenerationCriteriaObjectModel.Tins;


                    if (!string.IsNullOrEmpty(inputEntity.NetworkChosen) && !string.IsNullOrEmpty(inputEntity.TinNo))
                    {
                        if (Validation.IsValidContent(inputEntity.NetworkChosen) && IsValidTinController(inputEntity.TinNo))
                        {
                            List<TinNumbers> listProviderDetails = ReportGenerationCriteriaObjectBLL.GetProviderDetailsByTin(inputEntity).ToList();
                            reportGenerationCriteriaObjectModel.TinList = listProviderDetails;
                            traceLog.AppendLine(" & End: ClaimActivityController, SelectedProvider Method");
                            return PartialView("SelectedProvider", reportGenerationCriteriaObjectModel);
                        }
                    }
                }
                traceLog.AppendLine(" & End: ClaimActivityController, SelectedProvider Method");
                return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult SelectedPayer(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, SelectedPayer Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, SelectedPayer Method");
                    return Content(Constants.ContentHome);
                }
                var network = "";

                if (reportGenerationCriteriaObjectModel != null)
                {
                    network = string.Join(",", reportGenerationCriteriaObjectModel
                                          .NetworkList
                                          .Where(y => y.ClaimNetworkType)
                                          .Select(y => y.ClaimNetworkValue.ToString()));


                    ReportCriteriaEntity inputEntity = new ReportCriteriaEntity();
                    SetUserAccess(inputEntity);

                    inputEntity.NetworkChosen = network;
                    inputEntity.PayerNumber = reportGenerationCriteriaObjectModel.PayerNumberAll;


                    if (!string.IsNullOrEmpty(inputEntity.NetworkChosen) && !string.IsNullOrEmpty(inputEntity.PayerNumber))
                    {
                        if (Validation.IsValidContent(inputEntity.NetworkChosen) && Validation.IsValidContent(inputEntity.PayerNumber))
                        {
                            List<GroupNumbers> listProviderDetails = ReportGenerationCriteriaObjectBLL.GetGroupDetailsByPayer(inputEntity).ToList();
                            reportGenerationCriteriaObjectModel.GroupList = listProviderDetails;
                            traceLog.AppendLine(" & End: ClaimActivityController, SelectedPayer Method");
                            return PartialView("_Selectedpayer", reportGenerationCriteriaObjectModel);
                        }
                    }
                }
                traceLog.AppendLine(" & End: ClaimActivityController, SelectedPayer Method");
                return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// make partial view for the provider names with separate TIN tabs 
        /// </summary>
        /// <param name="reportGenerationCriteriaObjectModel"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult SelectedProviderByTin(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, SelectedProviderByTin Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, SelectedProviderByTin Method");
                    return Content(Constants.ContentHome);
                }
                var network = "";
                if (reportGenerationCriteriaObjectModel != null)
                {
                    network = string.Join(",", reportGenerationCriteriaObjectModel
                                        .NetworkList
                                        .Where(y => y.ClaimNetworkType)
                                        .Select(y => y.ClaimNetworkValue.ToString()));


                    ReportCriteriaEntity inputEntity = new ReportCriteriaEntity();
                    SetUserAccess(inputEntity);
                    inputEntity.NetworkChosen = network;
                    inputEntity.TinNo = reportGenerationCriteriaObjectModel.Tins;


                    if (!string.IsNullOrEmpty(inputEntity.NetworkChosen) && !string.IsNullOrEmpty(inputEntity.TinNo))
                    {
                        if (Validation.IsValidContent(inputEntity.NetworkChosen))
                        {
                            List<TinNumbers> listProviderDetails = ReportGenerationCriteriaObjectBLL.GetProviderDetailsByTin(inputEntity).ToList();
                            reportGenerationCriteriaObjectModel.TinList = listProviderDetails;
                            reportGenerationCriteriaObjectModel.Tin = reportGenerationCriteriaObjectModel.Tins;

                            string[] TinCollection = reportGenerationCriteriaObjectModel.Tins.Split(',');

                            reportGenerationCriteriaObjectModel.TinNumbers = new List<string>(TinCollection);
                            traceLog.AppendLine(" & End: ClaimActivityController, SelectedProviderByTin Method");
                            return PartialView("SelectedProviderByTin", reportGenerationCriteriaObjectModel);

                        }
                    }

                }
                traceLog.AppendLine(" & End: ClaimActivityController, SelectedProviderByTin Method");
                return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult SelectedGroupByPayer(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, SelectedGroupByPayer Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, SelectedGroupByPayer Method");
                    return Content(Constants.ContentHome);
                }
                var network = "";
                if (reportGenerationCriteriaObjectModel != null)
                {
                    network = string.Join(",", reportGenerationCriteriaObjectModel
                                        .NetworkList
                                        .Where(y => y.ClaimNetworkType)
                                        .Select(y => y.ClaimNetworkValue.ToString()));


                    ReportCriteriaEntity inputEntity = new ReportCriteriaEntity();
                    SetUserAccess(inputEntity);

                    inputEntity.NetworkChosen = network;
                    inputEntity.PayerNumber = reportGenerationCriteriaObjectModel.PayerNumberAll;


                    if (!string.IsNullOrEmpty(inputEntity.NetworkChosen) && !string.IsNullOrEmpty(inputEntity.PayerNumber))
                    {
                        if (Validation.IsValidContent(inputEntity.NetworkChosen) && Validation.IsValidContent(inputEntity.PayerNumber))
                        {
                            List<GroupNumbers> listProviderDetails = ReportGenerationCriteriaObjectBLL.GetGroupDetailsByPayer(inputEntity).ToList();
                            reportGenerationCriteriaObjectModel.GroupList = listProviderDetails;
                            reportGenerationCriteriaObjectModel.PayerTotal = reportGenerationCriteriaObjectModel.PayerNumberAll;

                            string[] PayerCollection = reportGenerationCriteriaObjectModel.PayerNumberAll.Split(',');
                            reportGenerationCriteriaObjectModel.PayerNumbers = new List<string>(PayerCollection);
                            traceLog.AppendLine(" & End: ClaimActivityController, SelectedGroupByPayer Method");
                            return PartialView("_SelectedGroupByPayer", reportGenerationCriteriaObjectModel);

                        }
                    }

                }
                traceLog.AppendLine(" & End: ClaimActivityController, SelectedGroupByPayer Method");
                return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }


        }

        #endregion

        #region Report Generation Summary Page

        /// <summary>
        /// generate report summary page load
        /// </summary>
        /// <param name="reportGenerationCriteriaObjectModel"></param>
        /// <returns></returns>
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult GenerateReport(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            //return RedirectToAction("Index", "Home");
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, GenerateReport Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, GenerateReport Method");
                    return RedirectToAction("Index", "Home");
                }


                if (reportGenerationCriteriaObjectModel != null)
                {

                    ReportCriteriaEntity entityObject = new ReportCriteriaEntity();
                    entityObject = MakeInputCriteria(reportGenerationCriteriaObjectModel);

                    if (entityObject != null)
                    {
                        //validate object Sever Side
                        if (!ValidateObject(entityObject))
                        {
                            throw new ArgumentException("Validation Error");
                        }
                        ReportCriteriaEntity callingObject = new ReportCriteriaEntity();
                        callingObject = SetValues(entityObject);
                        SetUserAccess(callingObject);
                        List<NetworkRecordCount> listNetworkRecordCount = new List<NetworkRecordCount>();
                        listNetworkRecordCount = ReportGenerationCriteriaObjectBLL.GetNoOfRecords(callingObject).ToList();

                        if (listNetworkRecordCount.Count == 0)
                        {
                            traceLog.AppendLine(" & End: ClaimActivityController, GenerateReport Method");
                            return Redirect("/Error/Index");
                        }

                        reportGenerationCriteriaObjectModel.RecordCounts = listNetworkRecordCount;
                        if (reportGenerationCriteriaObjectModel.DateBasedOnSelected == Constants.DateOfServiceValue)
                            reportGenerationCriteriaObjectModel.DateSummary = Constants.AllClaimsWithDateOfService
                                                                                 + Constants.From
                                                                                 + (string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.DateRangeValue) ? (entityObject.DateFrom + Constants.To + entityObject.DateEnd) : (Constants.Last + reportGenerationCriteriaObjectModel.DateRangeValue + Constants.Days));

                        else
                            reportGenerationCriteriaObjectModel.DateSummary = Constants.AllClaimsWithDateRepricedByNetwork
                                                                                + Constants.From
                                                                                + (string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.DateRangeValue) ? (entityObject.DateFrom + Constants.To + entityObject.DateEnd) : (Constants.Last + reportGenerationCriteriaObjectModel.DateRangeValue + Constants.Days));


                        if (entityObject.ClaimForm.Contains(','))
                            reportGenerationCriteriaObjectModel.ClaimSummary = Constants.BothClaim;
                        else
                            reportGenerationCriteriaObjectModel.ClaimSummary = entityObject.ClaimForm == Constants.Professional ? Constants.ProfessionalDisplay : Constants.FacilityDisplay;

                        if (entityObject.ClaimForm.Contains(Constants.Facility))
                            reportGenerationCriteriaObjectModel.FacilityCheck = Constants.One;

                        traceLog.AppendLine(" & End: ClaimActivityController, GenerateReport Method");

                        Session["generateReport"] = null;
                        //Session to save back button 
                        Session["generateReport"] = reportGenerationCriteriaObjectModel;
                        return View("GenerateReport", reportGenerationCriteriaObjectModel);

                    }
                    else
                    {
                        traceLog.AppendLine(" & End: ClaimActivityController, GenerateReport Method");
                        return Redirect("/ClaimActivity/Index");
                    }
                }
                traceLog.AppendLine(" & End: ClaimActivityController, GenerateReport Method");
                return Redirect("/Error/Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        public ActionResult GenerateReportIndex()
        {
            if (Session["generateReport"] != null)
            {
                var reportGenerationCriteriaModel = Session["generateReport"] as ReportGenerationCriteriaModel;
                return View("GenerateReport", reportGenerationCriteriaModel);
            }
            else
                return RedirectToAction("Index");
            
        }



        private ReportCriteriaEntity SetValues(ReportCriteriaEntity entityObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, SetValues Method with Param entityObject: " + entityObject);
                //change network to source system
                var srcSystem = entityObject.NetworkChosen;
                srcSystem = srcSystem.Replace(Constants.Cofinity, Constants.One);
                srcSystem = srcSystem.Replace(Constants.NetworkFirstHealthText, Constants.Three);

                //change claimform. if both then pass blank 
                var claimForm = entityObject.ClaimForm;
                if (claimForm.Contains(Constants.Professional) && claimForm.Contains(Constants.Facility))
                    claimForm = "";
                else
                {
                    claimForm = claimForm.Replace(Constants.Professional, Constants.Prof);
                    claimForm = claimForm.Replace(Constants.Facility, Constants.Inst);
                }


                //change bill type.
                var billType = entityObject.DisplayBillType;
                if (billType.Contains(Constants.InpatientValue) && billType.Contains(Constants.OutpatientValue))
                    billType = "";
                else
                {
                    billType = billType.Replace(Constants.InpatientValue, Constants.InpatientPassToSP);
                    billType = billType.Replace(Constants.OutpatientValue, Constants.OutpatientPassToSP);
                }

                //change date type
                var dateType = entityObject.DateBased;
                dateType = dateType.Replace(Constants.Dos, Constants.DosValue);
                dateType = dateType.Replace(Constants.Priced, Constants.PricedValue);

                var tinProvider = entityObject.TinProviderPair;
                var payerGroup = entityObject.PayerGroupPair;

                ReportCriteriaEntity obj = new ReportCriteriaEntity()
                {
                    SrcSystem = srcSystem,
                    ClaimForm = claimForm,
                    DisplayBillType = billType,
                    DateBased = dateType,
                    DateFrom = entityObject.DateFrom,
                    DateEnd = entityObject.DateEnd,
                    TinProviderPair = tinProvider,
                    PayerGroupPair = payerGroup,
                    CanCheckRestrictedMembers = entityObject.CanCheckRestrictedMembers,
                    IsEmployee = entityObject.IsEmployee,
                    session = entityObject.session

                };
                traceLog.AppendLine(" & End: ClaimActivityController, SetValues Method");
                return obj;
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }


        }

        /// <summary>
        /// save the search criteria
        /// </summary>
        /// <param name="reportGenerationCriteriaObjectModel"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public JsonResult SaveCriteria(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, SaveCriteria Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                int result = 0;
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    result = -1;
                }

                if (reportGenerationCriteriaObjectModel != null)
                {
                    ReportCriteriaEntity searchObject = new ReportCriteriaEntity();
                    searchObject = MakeInputCriteria(reportGenerationCriteriaObjectModel);


                    //validate object Sever Side
                    if (!ValidateObject(searchObject))
                    {
                        result = -1;
                    }

                    InsertCriteriaEntity entityObject = new InsertCriteriaEntity();
                    entityObject = MakeInsertCriteria(searchObject);

                    entityObject.FileName = reportGenerationCriteriaObjectModel.FileName;
                    entityObject.DateRange = reportGenerationCriteriaObjectModel.DateRangeValue;
                    if (result != -1)
                        result = ReportGenerationCriteriaObjectBLL.InsertSearchCriteria(entityObject);
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
                traceLog.AppendLine(" & End: ClaimActivityController, SaveCriteria Method");
                return null;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public JsonResult GetSaveCriteriaName(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, GetSaveCriteriaName Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                string name = "";
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    name = null;
                }
                if (reportGenerationCriteriaObjectModel != null)
                {

                    ReportGenerationCriteriaModel x = new ReportGenerationCriteriaModel();
                    string networkChosen = string.Join(",", reportGenerationCriteriaObjectModel
                                          .NetworkList
                                          .Where(y => y.ClaimNetworkType)
                                          .Select(y => y.ClaimNetworkValue.ToString()));
                    x = reportGenerationCriteriaObjectModel;
                    name = networkChosen + "-" + Constants.Dates +
                                      (x.StartDate != null ? x.StartDate : string.Empty) + "-" +
                                      (x.EndDate != null ? x.EndDate : string.Empty);
                    traceLog.AppendLine(" & End: ClaimActivityController, GetSaveCriteriaName Method");
                    return Json(name, JsonRequestBehavior.AllowGet);
                }
                traceLog.AppendLine(" & End: ClaimActivityController, GetSaveCriteriaName Method");

                return null;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }


        #endregion

        #region Saved Criteria

        /// <summary>
        ///saved criteria page Load  
        /// </summary>
        /// <returns></returns>
        public ActionResult SavedCriteria()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, SavedCriteria Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, SavedCriteria Method");
                    return RedirectToAction("Index", "Home");
                }

                string userId = string.Empty;
                string userRole = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                }
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole))
                {
                    userRole = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                }

                ReportGenerationCriteriaModel reports = new ReportGenerationCriteriaModel();

                if (Validation.IsValidContent(userId))
                {
                    reports.ModelObjects = GetAllReports(userId, userRole).ToList();
                    reports.ChosenId = string.Empty;
                    traceLog.AppendLine(" & End: ClaimActivityController, SavedCriteria Method");
                    return View("SavedCriteria", reports);
                }
                traceLog.AppendLine(" & End: ClaimActivityController, SavedCriteria Method");
                return Redirect("/Error/Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// delete the selected criteria
        /// </summary>
        /// <param name="reportGenerationCriteriaObject"></param>
        /// <returns></returns>
        [ValidateAntiForgeryToken]
        public ActionResult DeleteCriteria(ReportGenerationCriteriaModel reportGenerationCriteriaObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, DeleteCriteria Method with Param reportGenerationCriteriaObject: " + reportGenerationCriteriaObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, DeleteCriteria Method");
                    return RedirectToAction("Index", "Home");
                }
                if (reportGenerationCriteriaObject != null)
                {
                    if (Validation.IsValidContent(reportGenerationCriteriaObject.ChosenId.ToString(CultureInfo.CurrentCulture)))
                    {
                        int id = reportGenerationCriteriaObject.ChosenId != null ? Convert.ToInt32(reportGenerationCriteriaObject.ChosenId, CultureInfo.CurrentCulture) : 0;
                        string userId = string.Empty;
                        if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                        {
                            userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                        }

                        int result = -1;
                        if (!string.IsNullOrEmpty(userId))
                            result = ReportGenerationCriteriaObjectBLL.DeleteCriteria(userId, id);
                        if (result > Constants.ZeroCount)
                            traceLog.AppendLine(" & End: ClaimActivityController, DeleteCriteria Method");
                        {
                            return RedirectToAction("SavedCriteria");
                        }

                    }
                }
                traceLog.AppendLine(" & End: ClaimActivityController, DeleteCriteria Method");
                return Redirect("/Error/Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// load the selected criteria
        /// </summary>
        /// <param name="reportGenerationCriteriaObject"></param>
        /// <returns></returns>
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult LoadCriteria(ReportGenerationCriteriaModel reportGenerationCriteriaObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, LoadCriteria Method with Param reportGenerationCriteriaObject: " + reportGenerationCriteriaObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, LoadCriteria Method");
                    return RedirectToAction("Index", "Home");
                }

                if (reportGenerationCriteriaObject != null)
                {

                    List<string> networkList1 = new List<string>();
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                    {
                        //get selected role
                        Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                        //get the network for selcted function
                        networkList1 = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuClaimActivity, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                    }

                    List<GetSavedCriteriaOutput> dt = null;
                    int id = reportGenerationCriteriaObject.ChosenId != null ? Convert.ToInt32(reportGenerationCriteriaObject.ChosenId, CultureInfo.CurrentCulture) : 0;
                    string userId = string.Empty;
                    string userRole = string.Empty;
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                    {
                        userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    }
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole))
                    {
                        userRole = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                    }
                    if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(userRole) && id != 0)
                        dt = ReportGenerationCriteriaObjectBLL.GetSpecificReports(userId, userRole, id).ToList();
                    IEnumerable<GetSavedCriteriaOutput> obj = dt;

                    GetSavedCriteriaOutput outputObject = obj.First();

                    reportGenerationCriteriaObject = MakeLoadCriteria(outputObject, networkList1);

                    if (ConfigurationManager.AppSettings[Constants.Site].ToUpperInvariant() == Constants.External.ToUpperInvariant())
                    {
                        if (((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                        {
                            ReportCriteriaEntity modelObject = new ReportCriteriaEntity();
                            bool isEmployee = false;
                            List<string> networkList = new List<string>();
                            string network = string.Empty;
                            if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                            {
                                isEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;

                                //get selected role
                                Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                                //get the network for selcted function
                                networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuClaimActivity, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                            }
                            if (networkList != null)
                            {
                                network = string.Join(",", networkList);
                            }
                            modelObject.NetworkChosen = network;
                            SetUserAccess(modelObject);
                            reportGenerationCriteriaObject.PayerDropDown = ReportGenerationCriteriaObjectBLL.GetAllPayerList(modelObject);
                            List<SelectListItem> dropdownValues = reportGenerationCriteriaObject.PayerDropDown.ToList();
                            var payerArray = outputObject.Payers.Contains(',') ? outputObject.Payers.Split(',') : new string[] { outputObject.Payers };
                            var payerDropDownValues = "";

                            for (int i = 0; i < payerArray.Length; i++)
                            {
                                for (int j = 0; j < dropdownValues.Count; j++)
                                {
                                    if (payerArray[i] == dropdownValues[j].Value)
                                    {
                                        payerDropDownValues += dropdownValues[j].Text + ",";
                                    }
                                }
                            }

                            if (payerDropDownValues.Substring(payerDropDownValues.Length - 1) == ",")
                                payerDropDownValues = payerDropDownValues.Substring(0, payerDropDownValues.Length - 1);

                            reportGenerationCriteriaObject.PayerDropDownValues = payerDropDownValues;
                        }
                    }

                    ReportCriteriaEntity entityObject = new ReportCriteriaEntity();
                    entityObject = MakeInputCriteria(reportGenerationCriteriaObject);

                    if (entityObject != null)
                    {
                        //validate object Sever Side
                        if (!ValidateObject(entityObject))
                        {
                            traceLog.AppendLine(" & End: ClaimActivityController, LoadCriteria Method");
                            return Redirect("/Error/Index");
                        }

                        ReportCriteriaEntity callingObject = new ReportCriteriaEntity();
                        callingObject = SetValues(entityObject);
                        SetUserAccess(callingObject);
                        List<NetworkRecordCount> listNetworkRecordCount = new List<NetworkRecordCount>();
                        listNetworkRecordCount = ReportGenerationCriteriaObjectBLL.GetNoOfRecords(callingObject).ToList();

                        if (listNetworkRecordCount.Count == 0)
                        {
                            traceLog.AppendLine(" & End: ClaimActivityController, LoadCriteria Method");
                            return Redirect("/Error/Index");
                        }

                        reportGenerationCriteriaObject.RecordCounts = listNetworkRecordCount;


                        if (reportGenerationCriteriaObject.DateBasedOnSelected == Constants.DateOfServiceValue)
                            reportGenerationCriteriaObject.DateSummary = Constants.AllClaimsWithDateOfService
                                                                                 + Constants.From
                                                                                     + (outputObject.DateRangeValue == Constants.Zero ? (entityObject.DateFrom + Constants.To + entityObject.DateEnd) : (Constants.Last + outputObject.DateRangeValue + Constants.Days));

                        else
                            reportGenerationCriteriaObject.DateSummary = Constants.AllClaimsWithDateRepricedByNetwork
                                                                                + Constants.From
                                                                                   + (outputObject.DateRangeValue == Constants.Zero ? (entityObject.DateFrom + Constants.To + entityObject.DateEnd) : (Constants.Last + outputObject.DateRangeValue + Constants.Days));


                        if (entityObject.ClaimForm.Contains(','))
                            reportGenerationCriteriaObject.ClaimSummary = Constants.BothClaim;
                        else
                            reportGenerationCriteriaObject.ClaimSummary = entityObject.ClaimForm == Constants.Professional ? Constants.ProfessionalDisplay : Constants.FacilityDisplay;

                        if (entityObject.ClaimForm.Contains(Constants.Facility))
                            reportGenerationCriteriaObject.FacilityCheck = Constants.One;

                        traceLog.AppendLine(" & End: ClaimActivityController, LoadCriteria Method");
                        return View("GenerateReport", reportGenerationCriteriaObject);
                    }


                }

                return Redirect("/Error/Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        #endregion

        #region Report Generation PDF/CSV
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult ReportGeneration(string buttonValue, ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, ReportGeneration Method with Param buttonValue: " + buttonValue + "and param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                if (reportGenerationCriteriaObjectModel != null)
                {
                    string[] format = buttonValue.Split(';');
                    reportGenerationCriteriaObjectModel.NetworkChosen = format[1];
                    reportGenerationCriteriaObjectModel.ChosenNetworkCount = reportGenerationCriteriaObjectModel.RecordCounts.Where(x => x.Network == format[1]).Select(x => x.NetworkCount).First();

                    UserDetails user = (UserDetails)Session[Constants.UserDetails];
                    string emailId = user.UserData.Email;
                    ReportCriteriaEntity entityObject = new ReportCriteriaEntity();
                    entityObject = MakeInputCriteria(reportGenerationCriteriaObjectModel);
                    ReportCriteriaEntity callingObject = new ReportCriteriaEntity();

                    if (entityObject != null)
                    {
                        //validate object Sever Side
                        if (!ValidateObject(entityObject))
                        {
                            throw new ArgumentException("Validation Error");
                        }

                        callingObject = SetValues(entityObject);
                        SetUserAccess(callingObject);

                        callingObject.SrcSystem = format[1] == "Cofinity" ? "1" : "3";

                    }


                    switch (format[0])
                    {
                        case "PDF":
                            {
                                callingObject.FileName = Constants.ClaimReport + DateTime.Now.Month + DateTime.Now.Day + DateTime.Now.Year + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + ".pdf";
                                callingObject.ExportFormat = "pdf";

                                if (reportGenerationCriteriaObjectModel.ChosenNetworkCount >= Convert.ToInt32(ConfigurationManager.AppSettings[Constants.ClaimReportMaxCount]))
                                {
                                    DgGenerateFile dgGenerateFile = CreateAsyncFile;//new DgGenerateFile(PDF);
                                    dgGenerateFile.BeginInvoke(emailId, callingObject, null, null);
                                }
                                else if (reportGenerationCriteriaObjectModel.ChosenNetworkCount < Convert.ToInt32(ConfigurationManager.AppSettings[Constants.ClaimReportMaxCount]))
                                {
                                    reportGenerationCriteriaObjectModel.FileId = CreateFile(callingObject);
                                }

                                reportGenerationCriteriaObjectModel.FileType = "PDF";
                                traceLog.AppendLine(" & End: ClaimActivityController, ReportGeneration Method");
                                return PartialView("_DownloadPopUp", reportGenerationCriteriaObjectModel);
                            }
                        case "CSV":
                            {
                                callingObject.FileName = Constants.ClaimReport + DateTime.Now.Month + DateTime.Now.Day + DateTime.Now.Year + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + ".csv";
                                callingObject.ExportFormat = "csv";

                                if (reportGenerationCriteriaObjectModel.ChosenNetworkCount >= Convert.ToInt32(ConfigurationManager.AppSettings[Constants.ClaimReportMaxCount]))
                                {
                                    DgGenerateFile dgGenerateFile = CreateAsyncFile;//new DgGenerateFile(CSV);
                                    dgGenerateFile.BeginInvoke(emailId, callingObject, null, null);
                                }
                                else if (reportGenerationCriteriaObjectModel.ChosenNetworkCount < Convert.ToInt32(ConfigurationManager.AppSettings[Constants.ClaimReportMaxCount]))
                                {
                                    reportGenerationCriteriaObjectModel.FileId = CreateFile(callingObject);
                                }

                                reportGenerationCriteriaObjectModel.FileType = "CSV";
                                traceLog.AppendLine(" & End: ClaimActivityController, ReportGeneration Method");
                                return PartialView("_DownloadPopUp", reportGenerationCriteriaObjectModel);
                            }

                    }
                }
                traceLog.AppendLine(" & End: ClaimActivityController, ReportGeneration Method");
                return null;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        //[AjaxValidateAntiForgeryToken]
        //[HttpPost]
        //public JsonResult DeleteDownloadedRow(string id)
        //{
        //    try
        //    {
        //        int result = 0;
        //        if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
        //        {
        //            result = -1;
        //        }

        //        if (!string.IsNullOrEmpty(id))
        //        {
        //            var user =(UserDetails)Session[Constants.UserDetails];

        //            string userId = user.UserId;

        //            int idTobeDeleted = Convert.ToInt32(id);
        //            result = ReportGenerationCriteriaObjectBLL.DeleteClaimActivityReport(idTobeDeleted, userId);
        //            return Json(result, JsonRequestBehavior.AllowGet);
        //        }

        //        return null;
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //}


        #region !--Generate PDF--!

        public string CreateFile(ReportCriteriaEntity callingObject)
        {
            StringBuilder traceLog = new StringBuilder();
            string id = "";
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, CreateFile Method with Param callingObject: " + callingObject);
                if (callingObject != null)
                {
                    id = CreateCrystalReport(callingObject);

                }
                traceLog.AppendLine(" & End: ClaimActivityController, CreateFile Method");
                return id;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        public void CreateAsyncFile(string emailId, ReportCriteriaEntity callingObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, CreateAsyncFile Method with Param emailId: " + emailId + "and with Param callingObject: " + callingObject);
                if (callingObject != null)
                {
                    string id = CreateCrystalReport(callingObject);

                    if (id != "")
                    {
                        SendMailToUser(emailId);
                    }
                }
                traceLog.AppendLine(" & End: ClaimActivityController, CreateAsyncFile Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private string CreateCrystalReport(ReportCriteriaEntity callingObject)
        {
            StringBuilder traceLog = new StringBuilder();
            int insertedRowValue = 0;
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, CreateCrystalReport Method with Param callingObject: " + callingObject);
                insertedRowValue = ReportGenerationCriteriaObjectBLL.GetClaimActivityReportId(callingObject);
                traceLog.AppendLine(" & End: ClaimActivityController, CreateCrystalReport Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return insertedRowValue.ToString();
        }


       



        #region send mail to user after async call

        private void SendMailToUser(string email)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, SendMailToUser Method with Param email: " + email);
                if (!string.IsNullOrEmpty(email))
                {
                    string[] emailId = { email };
                    string subject = Constants.ClaimReportSubject;
                    string body = GetEmailBody();
                    ReportGenerationCriteriaObjectBLL.SendMail(emailId, subject, body);
                }
                traceLog.AppendLine(" & End: ClaimActivityController, SendMailToUser Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private string GetEmailBody()
        {
            StringBuilder traceLog = new StringBuilder();
            StringBuilder sbMailBody = new StringBuilder();
            sbMailBody.Append(Constants.BreakLine);
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, GetEmailBody Method ");
                sbMailBody.Append(Constants.ClaimReportHeading);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.ClaimReport1stLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.ClaimReport2ndLine);
                sbMailBody.Append(Constants.WebAdd);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.ClaimReport3rdLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.ClaimReport4thLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.ClaimReport5thLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.ClaimReport6thLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.ClaimReport7thLine);
                sbMailBody.Append(Constants.Bold);
                sbMailBody.Append(Constants.CustomerCareNumber);
                sbMailBody.Append(Constants.BoldEnd);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.or);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.ClaimReport8thLine);
                sbMailBody.Append(Constants.CustomerCareHelpDeskEmail);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.ClaimReport10thLine);
                sbMailBody.Append(Constants.BreakLine);
                sbMailBody.Append(Constants.DoNotReply);
                traceLog.AppendLine(" & End: ClaimActivityController, GetEmailBody Method");
                return sbMailBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        #endregion

        #endregion

        #region !--DownloadFile--!

        public ActionResult Download(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, Download Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                if (reportGenerationCriteriaObjectModel != null)
                {
                    string userId = "";
                    UserDetails user = (UserDetails)Session[Constants.UserDetails];
                    userId = user.UserId;
                    int id = Convert.ToInt32(reportGenerationCriteriaObjectModel.FileId);
                    GetClaimActivityReport reportObject = new GetClaimActivityReport();

                    reportObject = ReportGenerationCriteriaObjectBLL.GetClaimReportContent(id, userId);
                    traceLog.AppendLine(" & End: ClaimActivityController, Download Method");
                    return File(reportObject.ReportContent, "application/octet-stream", reportObject.FileName);

                }
                traceLog.AppendLine(" & End: ClaimActivityController, Download Method");
                return View("Download");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        public ActionResult DownloadFile(string fileId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, DownloadFile Method with Param fileId: " + fileId);
                if (fileId != null)
                {
                    string userId = "";
                    UserDetails user = (UserDetails)Session[Constants.UserDetails];
                    userId = user.UserId;
                    int id = Convert.ToInt32(fileId);
                    GetClaimActivityReport reportObject = new GetClaimActivityReport();

                    reportObject = ReportGenerationCriteriaObjectBLL.GetClaimReportContent(id, userId);
                    traceLog.AppendLine(" & End: ClaimActivityController, DownloadFile Method");
                    return File(reportObject.ReportContent, "application/octet-stream", reportObject.FileName);

                }
                traceLog.AppendLine(" & End: ClaimActivityController, DownloadFile Method");
                return View("Download");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        #endregion


        #endregion

        #region Report Generation View

        /// <summary>
        /// view page for a specific network with all criteria load
        /// </summary>
        /// <param name="networkChosen"></param>
        /// <param name="reportGenerationCriteriaObjectModel"></param>
        /// <returns></returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Claims Activity Report")]
        public ActionResult ViewRecords(string networkChosen, ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, ViewRecords Method with Param networkChosen: " + networkChosen + "and with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, ViewRecords Method");
                    return RedirectToAction("Index", "Home");
                }

                if (string.IsNullOrEmpty(networkChosen))
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, ViewRecords Method");
                    return Redirect("/Error/Index");
                }
                else
                {
                    if (reportGenerationCriteriaObjectModel != null)
                    {
                        if (Validation.IsValidContent(networkChosen))
                        {
                            reportGenerationCriteriaObjectModel.NetworkChosenView = networkChosen;
                        }

                        NetworkRecordCount NetworkRecordChosenObject = new NetworkRecordCount
                        {
                            Network = reportGenerationCriteriaObjectModel
                                                    .RecordCounts
                                                    .Where(x => x.Network == networkChosen)
                                                    .Select(x => x.Network).FirstOrDefault(),

                            NetworkCount = reportGenerationCriteriaObjectModel
                                            .RecordCounts
                                            .Where(x => x.Network == networkChosen)
                                            .Select(x => x.NetworkCount).FirstOrDefault(),

                            NetworkDisplay = reportGenerationCriteriaObjectModel
                                    .RecordCounts
                                    .Where(x => x.Network == networkChosen)
                                    .Select(x => x.NetworkDisplay).FirstOrDefault()
                        };


                        reportGenerationCriteriaObjectModel.NetworkRecordChosen = NetworkRecordChosenObject;

                        ReportCriteriaEntity entityObject = new ReportCriteriaEntity();

                        entityObject = MakeInputCriteria(reportGenerationCriteriaObjectModel);

                        if (!ValidateObject(entityObject))
                        {
                            traceLog.AppendLine(" & End: ClaimActivityController, ViewRecords Method");
                            return Redirect("/Error/Index");
                        }

                        if (reportGenerationCriteriaObjectModel.RecordDataInfo.PageNo == Constants.ZeroCount)
                        {
                            reportGenerationCriteriaObjectModel.RecordDataInfo.PageNo = Constants.OneCount;
                        }

                        RecordData recordObject = new RecordData();
                        recordObject.PageNo = reportGenerationCriteriaObjectModel.RecordDataInfo.PageNo;
                        recordObject.SortBy = reportGenerationCriteriaObjectModel.RecordDataInfo.SortBy;
                        recordObject.SortType = reportGenerationCriteriaObjectModel.RecordDataInfo.SortType;
                        entityObject.RecordsData = recordObject;

                        entityObject.NetworkChosen = NetworkRecordChosenObject.Network;
                        ReportCriteriaEntity callingObject = new ReportCriteriaEntity();
                        callingObject = SetValues(entityObject);
                        SetUserAccess(callingObject);
                        callingObject.RecordsData = recordObject;

                        OutputDataEntityFinal finalObject = new OutputDataEntityFinal();
                        finalObject = ReportGenerationCriteriaObjectBLL.FetchClaimActivityForView(callingObject);


                        reportGenerationCriteriaObjectModel.RecordDataInfo.Pages = finalObject.ResultGrid;

                        FilterData dataObject = MakeViewPageFilter(reportGenerationCriteriaObjectModel);

                        if (entityObject.UserRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                        {
                            if (finalObject.TinFilter != null)
                                dataObject.TinPayerDropDown = finalObject.TinFilter;
                        }


                        IEnumerable<SelectListItem> payers = null;

                        if (entityObject.UserType.ToUpperInvariant() == Constants.External.ToUpperInvariant() &&
                        entityObject.UserRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                        {
                            if (reportGenerationCriteriaObjectModel.PayerDropDownValues.Contains(','))
                            {
                                payers = reportGenerationCriteriaObjectModel.PayerDropDownValues.Split(',').Select(x => new
                                SelectListItem
                                {
                                    Text = x.ToString(),
                                    Value = x.Substring(0, x.IndexOf('('))
                                }).ToList<SelectListItem>();
                                dataObject.PayerDropDown = payers;
                            }
                        }



                        int countNoOfRecord = 0;

                        countNoOfRecord = reportGenerationCriteriaObjectModel.NetworkRecordChosen.NetworkCount;

                        reportGenerationCriteriaObjectModel.RecordDataInfo.TotalPages = Convert.ToInt32(System.Math.Ceiling(Convert.ToDouble(countNoOfRecord) / 10));

                        reportGenerationCriteriaObjectModel.DataFilters = dataObject;

                        reportGenerationCriteriaObjectModel.DataFilters.TotalFilterCount = -1;
                        traceLog.AppendLine(" & End: ClaimActivityController, ViewRecords Method");
                        return View(reportGenerationCriteriaObjectModel);
                    }
                }
                traceLog.AppendLine(" & End: ClaimActivityController, ViewRecords Method");
                return RedirectToAction("Error", "Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// pagination and sorting and filter for view page
        /// </summary>
        /// <param name="reportGenerationCriteriaObjectModel"></param>
        /// <returns></returns>        
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult ViewRecordsTable(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, ViewRecordsTable Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);

                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, ViewRecordsTable Method");
                    return Content(Constants.ContentHome);
                }

                if (reportGenerationCriteriaObjectModel != null)
                {

                    ReportCriteriaEntity entityObject = new ReportCriteriaEntity();

                    entityObject = MakeInputCriteria(reportGenerationCriteriaObjectModel);
                    if (reportGenerationCriteriaObjectModel.RecordDataInfo.PageNo == Constants.ZeroCount)
                    {
                        reportGenerationCriteriaObjectModel.RecordDataInfo.PageNo = Constants.OneCount;
                    }

                    RecordData recordObject = new RecordData();
                    recordObject.PageNo = reportGenerationCriteriaObjectModel.RecordDataInfo.PageNo;
                    recordObject.SortBy = reportGenerationCriteriaObjectModel.RecordDataInfo.SortBy;
                    recordObject.SortType = reportGenerationCriteriaObjectModel.RecordDataInfo.SortType;
                    entityObject.RecordsData = recordObject;
                    FilterData dataFilterObject = MakeViewPageFilter(reportGenerationCriteriaObjectModel);

                    int changeData = ModifyFilterData(reportGenerationCriteriaObjectModel, entityObject, dataFilterObject);

                    //validate object Sever Side
                    if (!ValidateObject(entityObject) && !ValidatePagination(entityObject.RecordsData))
                    {
                        traceLog.AppendLine(" & End: ClaimActivityController, ViewRecordsTable Method");
                        return Content(Constants.ContentError);
                    }
                    //-----------------------------//

                    entityObject.NetworkChosen = reportGenerationCriteriaObjectModel.NetworkRecordChosen.Network;


                    ReportCriteriaEntity callingObject = new ReportCriteriaEntity();
                    callingObject = SetValues(entityObject);
                    if (changeData == 1)
                    {
                        //if()
                        callingObject.TinNo = dataFilterObject.TinNoFilter;
                        callingObject.PayerNumber = dataFilterObject.PayerFilter;
                    }
                    SetUserAccess(callingObject);
                    callingObject.RecordsData = recordObject;

                    OutputDataEntityFinal finalObject = new OutputDataEntityFinal();
                    finalObject = ReportGenerationCriteriaObjectBLL.FetchClaimActivityForView(callingObject);
                    reportGenerationCriteriaObjectModel.RecordDataInfo.Pages = finalObject.ResultGrid;

                    if (entityObject.UserRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                    {
                        if (finalObject.TinFilter != null)
                            dataFilterObject.TinPayerDropDown = finalObject.TinFilter;
                    }

                    IEnumerable<SelectListItem> payers = null;

                    if (entityObject.UserType.ToUpperInvariant() == Constants.External.ToUpperInvariant() &&
                        entityObject.UserRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                    {
                        bool flag = false;
                        if (!string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.PayerDropDownValues) && !reportGenerationCriteriaObjectModel.PayerDropDownValues.Contains(','))
                        {
                            flag = true;
                            reportGenerationCriteriaObjectModel.PayerDropDownValues += ",";
                        }

                        if (reportGenerationCriteriaObjectModel.PayerDropDownValues.Contains(','))
                        {
                            payers = reportGenerationCriteriaObjectModel.PayerDropDownValues.Split(',').Select(x => new
                                SelectListItem
                            {
                                Text = x.ToString(),
                                //Value = x.Substring(0, x.IndexOf('('))
                                Value = x.ToString() == string.Empty ? string.Empty : x.Substring(0, x.IndexOf('('))
                            }).ToList<SelectListItem>();
                        }

                        if (flag == true)
                        {
                            reportGenerationCriteriaObjectModel.PayerDropDownValues = reportGenerationCriteriaObjectModel.PayerDropDownValues.TrimEnd(',');
                        }
                        dataFilterObject.PayerDropDown = payers;
                    }



                    int countNoOfRecord = 0;

                    if (changeData == Constants.OneCount)
                    {
                        List<NetworkRecordCount> NetworkRecordCountList = new List<NetworkRecordCount>();
                        //ReportCriteriaEntity callingObject1 = new ReportCriteriaEntity();
                        //callingObject1 = SetValues(entityObject);
                        //SetUserAccess(callingObject1);
                        NetworkRecordCountList = ReportGenerationCriteriaObjectBLL.GetNoOfRecords(callingObject).ToList();
                        countNoOfRecord = NetworkRecordCountList[0].NetworkCount;
                        dataFilterObject.TotalFilterCount = countNoOfRecord;

                    }
                    else
                    {
                        countNoOfRecord = reportGenerationCriteriaObjectModel.NetworkRecordChosen.NetworkCount;
                        dataFilterObject.TotalFilterCount = -1;
                    }

                    reportGenerationCriteriaObjectModel.RecordDataInfo.TotalPages = Convert.ToInt32(System.Math.Ceiling(Convert.ToDouble(countNoOfRecord) / 10));


                    reportGenerationCriteriaObjectModel.DataFilters = dataFilterObject;
                    traceLog.AppendLine(" & End: ClaimActivityController, ViewRecordsTable Method");
                    return PartialView("_RecordTable", reportGenerationCriteriaObjectModel);
                }
                traceLog.AppendLine(" & End: ClaimActivityController, ViewRecordsTable Method");
                return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [CheckAccess(Function = "Claims Activity Report")]
        public ActionResult Coversheet(string id)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, Coversheet Method with Param id: " + id);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                ClaimInquiryBL claimBL = new ClaimInquiryBL();
                var batchId = id;
                if (!string.IsNullOrWhiteSpace(batchId))
                {
                     if (System.Configuration.ConfigurationManager.AppSettings[Constants.Site] == "External")
                     {
                         FlexMapperRelay.MapResult mrr = claimBL.GetCoverSheetRelay(batchId);
                         if (mrr != null)
                         {
                             Response.ClearHeaders();
                             Response.ContentType = Constants.ResponseContentPdf;
                             Response.AddHeader(Constants.ContentDisposition, Constants.FileNamePdfDownload);
                             try
                             {
                                 Response.OutputStream.Write(mrr.FileContent, 0, mrr.FileContent.Length);
                             }
                             finally
                             {
                                 Response.OutputStream.Flush();
                                 Response.OutputStream.Close();
                             }
                         }
                         else
                         {
                             traceLog.AppendLine(" & End: ClaimInquiryController, Coversheet Method");
                             return View("_CoverSheet");
                         }
                     }
                     else
                     {
                         FlexMapper.MapperService.MapResult mr = claimBL.GetCoverSheet(batchId);
                         if (mr != null)
                         {
                             Response.ClearHeaders();
                             Response.ContentType = Constants.ResponseContentPdf;
                             Response.AddHeader(Constants.ContentDisposition, Constants.FileNamePdfDownload);
                             try
                             {
                                 Response.OutputStream.Write(mr.FileContent, 0, mr.FileContent.Length);
                             }
                             finally
                             {
                                 Response.OutputStream.Flush();
                                 Response.OutputStream.Close();
                             }
                         }
                         else
                         {
                             traceLog.AppendLine(" & End: ClaimInquiryController, Coversheet Method");
                             return View("_CoverSheet");
                         }
                     } 
                }
                traceLog.AppendLine(" & End: ClaimInquiryController, Coversheet Method");
                return View("_CoverSheet");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion

        #region validation

        /// <summary>
        /// input validation for search criteria object
        /// </summary>
        /// <param name="ReportCriteriaEntityObject"></param>
        /// <returns></returns>
        private static bool ValidateObject(ReportCriteriaEntity ReportCriteriaEntityObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, ValidateObject Method with Param ReportCriteriaEntityObject: " + ReportCriteriaEntityObject);
                bool result = false;

                if (ReportCriteriaEntityObject != null)
                {
                    result =

                                NullOrEmptyAndValidationCheck(ReportCriteriaEntityObject) ?
                                (
                                    ValidateConditionCheck(ReportCriteriaEntityObject) ?
                                        (
                                            ValidateDateCheck(ReportCriteriaEntityObject.DateFrom, ReportCriteriaEntityObject.DateEnd) ?
                                                (
                                                    true
                                                )
                                                : false
                                        )
                                        : false
                                )
                                    : false;
                }
                traceLog.AppendLine(" & End: ClaimActivityController, ValidateObject Method");
                return result;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// validation for startdate and enddate
        /// </summary>
        /// <param name="dateFrom"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        private static bool ValidateDateCheck(string dateFrom, string dateTo)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, ValidateDateCheck Method with Param dateFrom: " + dateFrom + "and with Param dateTo: " + dateTo);
                bool check = false;
                if (!string.IsNullOrEmpty(dateFrom) && !string.IsNullOrEmpty(dateTo))
                {
                    //validation for date

                    var isValidDateFrom = IsValidDosDateRange(dateFrom);//check 3 year previous date && validate date
                    var isValidDateTo = IsValidDosDateRange(dateTo);//check 3 year previous date && validate date
                    var rangeCheck = 1;
                    if (isValidDateFrom && isValidDateTo)
                        rangeCheck = CompareDate(dateFrom, dateTo);
                    check = rangeCheck == 0 ? true : false;


                    //----------------------//
                }
                traceLog.AppendLine(" & End: ClaimActivityController, ValidateDateCheck Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// validation for conditional input
        /// </summary>
        /// <param name="ReportCriteriaEntityObject"></param>
        /// <returns></returns>
        private static bool ValidateConditionCheck(ReportCriteriaEntity ReportCriteriaEntityObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, ValidateConditionCheck Method with Param ReportCriteriaEntityObject: " + ReportCriteriaEntityObject);
                bool result = true;
                if (ReportCriteriaEntityObject.ClaimForm.Contains(Constants.Facility))
                {
                    result = string.IsNullOrEmpty(ReportCriteriaEntityObject.DisplayBillType);
                    if (!result)
                        result = Validation.IsValidContent(ReportCriteriaEntityObject.DisplayBillType);
                }

                if (ReportCriteriaEntityObject.Searchby.Contains(Constants.SelectedProvider))
                {
                    result = string.IsNullOrEmpty(ReportCriteriaEntityObject.ProviderName);
                    if (!result)
                        result = Validation.IsValidContent(ReportCriteriaEntityObject.ProviderName);
                }

                if (ReportCriteriaEntityObject.Searchby.Contains(Constants.SelectedGroup))
                {
                    result = string.IsNullOrEmpty(ReportCriteriaEntityObject.GroupName);
                    if (!result)
                        result = Validation.IsValidContent(ReportCriteriaEntityObject.GroupName);
                }

                traceLog.AppendLine(" & End: ClaimActivityController, ValidateConditionCheck Method");
                return result;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// validation for null and empty check
        /// </summary>
        /// <param name="ReportCriteriaEntityObject"></param>
        /// <returns></returns>
        private static bool NullOrEmptyAndValidationCheck(ReportCriteriaEntity ReportCriteriaEntityObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, NullOrEmptyAndValidationCheck Method with Param ReportCriteriaEntityObject: " + ReportCriteriaEntityObject);
                bool check = false;

                if (!string.IsNullOrEmpty(ReportCriteriaEntityObject.NetworkChosen))
                    check = Validation.IsValidContent(ReportCriteriaEntityObject.NetworkChosen);

                if (check && !string.IsNullOrEmpty(ReportCriteriaEntityObject.ClaimForm))
                    check = Validation.IsValidContent(ReportCriteriaEntityObject.ClaimForm);

                if (check && !string.IsNullOrEmpty(ReportCriteriaEntityObject.DateFrom))
                    check = Validation.IsValidContent(ReportCriteriaEntityObject.DateFrom);

                if (check && !string.IsNullOrEmpty(ReportCriteriaEntityObject.DateEnd))
                    check = Validation.IsValidContent(ReportCriteriaEntityObject.DateEnd);

                if (check && !string.IsNullOrEmpty(ReportCriteriaEntityObject.DateBased))
                    check = Validation.IsValidContent(ReportCriteriaEntityObject.DateBased);

                if (check && !string.IsNullOrEmpty(ReportCriteriaEntityObject.Searchby))
                    check = Validation.IsValidContent(ReportCriteriaEntityObject.Searchby);

                if (check && !string.IsNullOrEmpty(ReportCriteriaEntityObject.Userid))
                    check = Validation.IsValidContent(ReportCriteriaEntityObject.Userid);

                if (check && !string.IsNullOrEmpty(ReportCriteriaEntityObject.UserRole))
                    check = Validation.IsValidContent(ReportCriteriaEntityObject.UserRole);

                if (check && !string.IsNullOrEmpty(ReportCriteriaEntityObject.UserType))
                    check = Validation.IsValidContent(ReportCriteriaEntityObject.UserType);
                traceLog.AppendLine(" & End: ClaimActivityController, NullOrEmptyAndValidationCheck Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// validation for pagination object
        /// </summary>
        /// <param name="recordDataObject"></param>
        /// <returns></returns>
        private static bool ValidatePagination(RecordData recordDataObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, ValidatePagination Method with Param recordDataObject: " + recordDataObject);
                bool check = false;

                if (recordDataObject.PageNo != 0 && recordDataObject.PageNo > recordDataObject.TotalPages)
                    check = Validation.IsValidNumber(recordDataObject.PageNo.ToString(CultureInfo.CurrentCulture));

                if (!string.IsNullOrEmpty(recordDataObject.SortBy))
                    check = check && Validation.IsValidContent(recordDataObject.SortBy);

                if (!string.IsNullOrEmpty(recordDataObject.SortType))
                    check = check && Validation.IsValidContent(recordDataObject.SortType);
                traceLog.AppendLine(" & End: ClaimActivityController, ValidatePagination Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// validation for tin or multiple tin
        /// </summary>
        /// <param name="tin"></param>
        /// <returns></returns>
        private static bool IsValidTinController(string tin)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, IsValidTinController Method with Param tin: " + tin);
                bool check = false;

                if (!string.IsNullOrEmpty(tin))
                {
                    var lengthTin = tin.Length;

                    if (lengthTin < 9)
                        check = false;
                    else
                    {
                        switch (lengthTin)
                        {
                            case 9:
                                check = Validation.IsValidTin(tin);
                                break;

                            default:
                                var tinArray = tin.Split(',');
                                foreach (var item in tinArray)
                                    check = Validation.IsValidTin(item);
                                break;
                        }
                    }
                }

                traceLog.AppendLine(" & End: ClaimActivityController, IsValidTinController Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// validation for check 3 year previous date && validate date
        /// </summary>
        /// <param name="valueDate"></param>
        /// <returns></returns>
        private static bool IsValidDosDateRange(string valueDate)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, IsValidDosDateRange Method with Param valueDate: " + valueDate);
                DateTime dt = Convert.ToDateTime(valueDate, CultureInfo.CurrentCulture);
                DateTime dtToday = DateTime.Now;

                int intValidYr = (dtToday.Year - 3);

                if (dt.Year < intValidYr)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, IsValidDosDateRange Method");
                    return false;
                }

                if (dt <= dtToday)
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, IsValidDosDateRange Method");
                    return Validation.IsValidDate(valueDate);
                }
                else
                {
                    traceLog.AppendLine(" & End: ClaimActivityController, IsValidDosDateRange Method");
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);

                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// compare 92 days validation
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        private static int CompareDate(string startDate, string endDate)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, CompareDate Method with Param startDate: " + startDate + "and with Param endDate: " + endDate);
                var compareFlag = 0;
                var date1 = DateTime.Parse(startDate, CultureInfo.CurrentCulture);
                var date2 = DateTime.Parse(endDate, CultureInfo.CurrentCulture);
                var daysDiff = Convert.ToInt32((date2 - date1).TotalDays);
                if (daysDiff > 92 || daysDiff < 0)
                {
                    compareFlag = -1;
                }
                traceLog.AppendLine(" & End: ClaimActivityController, CompareDate Method");
                return compareFlag;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }






        #endregion

        #region private methods

        /// <summary>
        /// private method to make insertCriteria object 
        /// </summary>
        /// <param name="searchObject"></param>
        /// <returns></returns>
        private static InsertCriteriaEntity MakeInsertCriteria(ReportCriteriaEntity searchObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, MakeInsertCriteria Method with Param searchObject: " + searchObject);
                InsertCriteriaEntity entityObject = new InsertCriteriaEntity();

                if (searchObject != null)
                {
                    entityObject.Network = searchObject.NetworkChosen;
                    entityObject.FormType1 = searchObject.ClaimForm.Contains(Constants.Professional) ? Constants.ProfessionalSave : null;
                    entityObject.FormType2 = searchObject.ClaimForm.Contains(Constants.Facility) ? Constants.FacilitySave : null;
                    entityObject.BillType = searchObject.DisplayBillType;
                    entityObject.DateBased = searchObject.DateBased;
                    entityObject.StartDate = searchObject.DateFrom;
                    entityObject.EndDate = searchObject.DateEnd;
                    entityObject.Tins = searchObject.TinNo;
                    entityObject.ProviderNames = searchObject.ProviderName;
                    entityObject.Userid = searchObject.Userid;
                    entityObject.UserRole = searchObject.UserRole;
                    entityObject.Payers = searchObject.PayerNumber;
                    entityObject.GroupNames = searchObject.GroupName;

                }
                traceLog.AppendLine(" & End: ClaimActivityController, MakeInsertCriteria Method");
                return entityObject;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// private method to get all saved criteria for specific user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private IEnumerable<SavedReportModel> GetAllReports(string userId, string userRole)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, GetAllReports Method with Param userId: " + userId + "and with Param userRole: " + userRole);
                List<SavedReportModel> modelList = new List<SavedReportModel>();
                List<GetSavedCriteriaOutput> dt = new List<GetSavedCriteriaOutput>();
                if (ReportGenerationCriteriaObjectBLL.GetSavedReports(userId, userRole) != null)
                {
                    dt = ReportGenerationCriteriaObjectBLL.GetSavedReports(userId, userRole).ToList();

                    modelList = dt.Select(x =>
                        new SavedReportModel
                        {
                            ReportDetails = x.FileName + "-" + Constants.Created +
                                      (x.CreatedDate == null ? null : x.CreatedDate.ToShortDateString()) + "-" +
                                      (x.CreatedDate == null ? null : x.CreatedDate.ToString("HH:mm:ss", CultureInfo.CurrentCulture)),
                            Id = x.Id.ToString(CultureInfo.CurrentCulture),
                            FormType1 = x.FormType1 != null ? x.FormType1 : string.Empty,
                            FormType2 = x.FormType2 != null ? x.FormType2 : string.Empty,
                            BillType = x.BillType != null ? x.BillType : string.Empty,
                            SearchType = x.SearchType != null ? x.SearchType : string.Empty,
                            Tin = x.Tin != null ? x.Tin : string.Empty,
                            ProviderName = x.ProviderName != null ? x.ProviderName : string.Empty,
                            Payers = x.Payers != null ? x.Payers : string.Empty,
                            GroupNames = x.GroupNames != null ? x.GroupNames : string.Empty,
                            GroupNamesDisplay = string.IsNullOrEmpty(x.GroupNames) ? Constants.All : x.GroupNames,
                            ProviderNameDisplay = string.IsNullOrEmpty(x.ProviderName) ? Constants.All : x.ProviderName,
                            StartDate = x.StartDate != null ? x.StartDate : string.Empty,
                            EndDate = x.EndDate != null ? x.EndDate : string.Empty,
                            ClaimForm = (!(string.IsNullOrEmpty(x.FormType1)) && !(string.IsNullOrEmpty(x.FormType2))) ? Constants.BothClaim : ((!(string.IsNullOrEmpty(x.FormType1)) && (string.IsNullOrEmpty(x.FormType2))) ? Constants.ProfessionalDisplay : Constants.FacilityDisplay),
                            ReportDates = (x.SearchType == Constants.Dos ? Constants.AllClaimsWithDateOfService + Constants.From : Constants.AllClaimsWithDateRepricedByNetwork + Constants.From) +
                            (x.DateRangeValue == Constants.Zero ? (x.StartDate + Constants.To + x.EndDate) : (Constants.Last + x.DateRangeValue + Constants.Days)),

                        }).ToList<SavedReportModel>();
                }
                traceLog.AppendLine(" & End: ClaimActivityController, GetAllReports Method");
                return modelList;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// private method to make object for load the criteria
        /// </summary>
        /// <param name="outputObject"></param>
        /// <returns></returns>
        private static ReportGenerationCriteriaModel MakeLoadCriteria(GetSavedCriteriaOutput outputObject, List<string> network)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, MakeLoadCriteria Method with Param outputObject: " + outputObject + "and with Param network: " + network);
                ReportGenerationCriteriaModel modelObject = new ReportGenerationCriteriaModel();
                if (outputObject != null)
                {
                    MakeInputList(outputObject, modelObject, network);

                    MakeInputString(outputObject, modelObject);

                }
                traceLog.AppendLine(" & End: ClaimActivityController, MakeLoadCriteria Method");
                return modelObject;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// make input parameter of string type to object
        /// </summary>
        /// <param name="outputObject"></param>
        /// <param name="modelObject"></param>
        private static void MakeInputString(GetSavedCriteriaOutput outputObject, ReportGenerationCriteriaModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, MakeInputString Method with Param outputObject: " + outputObject + "and with Param modelObject: " + modelObject);
                if (outputObject != null && modelObject != null)
                {
                    modelObject.DateBasedOnSelected = outputObject.SearchType;

                    modelObject.StartDate = outputObject.StartDate;

                    modelObject.EndDate = outputObject.EndDate;

                    modelObject.Tins = outputObject.Tin;

                    modelObject.ProviderNamesArray = outputObject.ProviderName;

                    modelObject.PayerNumberAll = outputObject.Payers;

                    if (string.IsNullOrEmpty(outputObject.Payers))
                        modelObject.ProviderSelected = !string.IsNullOrEmpty(outputObject.ProviderName) ? Constants.SelectedProvider : Constants.AllProvider;
                    else
                        modelObject.ProviderSelected = !string.IsNullOrEmpty(outputObject.GroupNames) ? Constants.SelectedGroup : Constants.AllGroup;

                    modelObject.GroupNamesArray = outputObject.GroupNames;
                }
                traceLog.AppendLine(" & End: ClaimActivityController, MakeInputString Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// make input parameter of list type to object
        /// </summary>
        /// <param name="outputObject"></param>
        /// <param name="modelObject"></param>
        private static void MakeInputList(GetSavedCriteriaOutput outputObject, ReportGenerationCriteriaModel modelObject, List<string> networkList)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, MakeInputList Method with Param outputObject: " + outputObject + "and with Param modelObject: " + modelObject + "and with Param networkList: " + networkList);
                if (outputObject != null && modelObject != null)
                {
                    modelObject.NetworkList = GetNetworkTypes(networkList).ToList();
                    modelObject.ClaimTypeList = GetClaimTypes().ToList();
                    modelObject.BillTypeList = GetBillTypes().ToList();
                    modelObject.ProviderList = GetProviderSelectList();

                    NetworkSelect(outputObject, modelObject);

                    FormTypeSelect(outputObject, modelObject);

                    BillTypeSelect(outputObject, modelObject);

                }
                traceLog.AppendLine(" & End: ClaimActivityController, MakeInputList Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        private static void FormTypeSelect(GetSavedCriteriaOutput outputObject, ReportGenerationCriteriaModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, FormTypeSelect Method with Param outputObject: " + outputObject + "and with Param modelObject: " + modelObject);
                if (!string.IsNullOrEmpty(outputObject.FormType1))
                    modelObject.ClaimTypeList.Where(x => x.ClaimFormValue == Constants.Professional).ToList<ClaimType>().ForEach(x => x.ClaimFormType = true);

                if (!string.IsNullOrEmpty(outputObject.FormType2))
                    modelObject.ClaimTypeList.Where(x => x.ClaimFormValue == Constants.Facility).ToList<ClaimType>().ForEach(x => x.ClaimFormType = true);
                traceLog.AppendLine(" & End: ClaimActivityController, FormTypeSelect Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private static void BillTypeSelect(GetSavedCriteriaOutput outputObject, ReportGenerationCriteriaModel modelObject)
        {

            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, BillTypeSelect Method with Param outputObject: " + outputObject + "and with Param modelObject: " + modelObject);
                if (outputObject.BillType.Contains(","))
                    modelObject.BillTypeList.ForEach(x => x.BillFormType = true);
                else
                    modelObject.BillTypeList.Where(x => x.BillTypeValue == outputObject.BillType).ToList<BillType>().ForEach(x => x.BillFormType = true);
                traceLog.AppendLine(" & End: ClaimActivityController, BillTypeSelect Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private static void NetworkSelect(GetSavedCriteriaOutput outputObject, ReportGenerationCriteriaModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, NetworkSelect Method with Param outputObject: " + outputObject + "and with Param modelObject: " + modelObject);
                if (outputObject.Network.Contains(","))
                    modelObject.NetworkList.ForEach(x => x.ClaimNetworkType = true);
                else
                    modelObject.NetworkList.Where(x => x.ClaimNetworkValue == outputObject.Network).ToList<NetworkClaimActivity>().ForEach(x => x.ClaimNetworkType = true);
                traceLog.AppendLine(" & End: ClaimActivityController, NetworkSelect Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
       



        /// <summary>
        /// adding or removing filter data 
        /// </summary>
        /// <param name="reportGenerationCriteriaObjectModel"></param>
        /// <param name="entityObject"></param>
        /// <param name="dataFilterObject"></param>
        /// <returns></returns>
        private static int ModifyFilterData(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel, ReportCriteriaEntity entityObject, FilterData dataFilterObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, ModifyFilterData Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel + "and with Param entityObject: " + entityObject + "and with Param dataFilterObject: " + dataFilterObject);
                int result = 0;
                if (reportGenerationCriteriaObjectModel != null && entityObject != null)
                {

                    if (!string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.DataFilters.PayerFilter))
                    {
                        entityObject.PayerNumber = reportGenerationCriteriaObjectModel.DataFilters.PayerFilter;
                        dataFilterObject.PayerFilter = reportGenerationCriteriaObjectModel.DataFilters.PayerFilter;
                        result = 1;
                    }


                    if (!string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.DataFilters.TinNoFilter))
                    {
                        entityObject.TinNo = reportGenerationCriteriaObjectModel.DataFilters.TinNoFilter;
                        dataFilterObject.TinNoFilter = reportGenerationCriteriaObjectModel.DataFilters.TinNoFilter;
                        result = 1;
                    }



                    if (!string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.DataFilters.ClaimFilter))
                    {
                        entityObject.ClaimForm = reportGenerationCriteriaObjectModel.DataFilters.ClaimFilter;
                        dataFilterObject.ClaimFilter = reportGenerationCriteriaObjectModel.DataFilters.ClaimFilter;
                        result = 1;
                    }



                    if (!string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.DataFilters.DosBeginFilter))
                    {
                        entityObject.DateFrom = reportGenerationCriteriaObjectModel.DataFilters.DosBeginFilter;
                        dataFilterObject.DosBeginFilter = reportGenerationCriteriaObjectModel.DataFilters.DosBeginFilter;
                        result = 1;
                    }


                    if (!string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.DataFilters.DosEndFilter))
                    {
                        entityObject.DateEnd = reportGenerationCriteriaObjectModel.DataFilters.DosEndFilter;
                        dataFilterObject.DosEndFilter = reportGenerationCriteriaObjectModel.DataFilters.DosEndFilter;
                        result = 1;
                    }

                }
                traceLog.AppendLine(" & End: ClaimActivityController, ModifyFilterData Method");
                return result;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// make input criteria object 
        /// </summary>
        /// <param name="reportGenerationCriteriaObjectModel"></param>
        /// <returns></returns>
        private ReportCriteriaEntity MakeInputCriteria(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, MakeInputCriteria Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                ReportCriteriaEntity inputEntity = new ReportCriteriaEntity();

               
                List<NetworkClaimActivity> listObject = new List<NetworkClaimActivity>();
                NetworkClaimActivity network = null;
                if (!String.IsNullOrEmpty(reportGenerationCriteriaObjectModel.NetworkSelected))
                {
                    if (reportGenerationCriteriaObjectModel.NetworkSelected == Constants.ActivityFirstHealth)
                    {
                        network = new NetworkClaimActivity() { ClaimNetworkType = true, ClaimNetworkDisplay = Constants.ActivityFirstHealth, ClaimNetworkValue = Constants.ActivityFirstHealth };// id= 3 for FH.

                    }
                    else if (reportGenerationCriteriaObjectModel.NetworkSelected == Constants.Cofinity)
                    {
                        network = new NetworkClaimActivity() { ClaimNetworkType = true, ClaimNetworkDisplay = Constants.Cofinity, ClaimNetworkValue = Constants.Cofinity };// id=1 for cofinity.

                    }

                }
                else
                {
                    foreach(var item in reportGenerationCriteriaObjectModel.NetworkList)
                    {
                        network = new NetworkClaimActivity() { ClaimNetworkType = true, ClaimNetworkDisplay = item.ClaimNetworkDisplay, ClaimNetworkValue = item.ClaimNetworkValue };
                    }
                   
                }
                listObject.Add(network);
                reportGenerationCriteriaObjectModel.NetworkList = listObject;

                if (reportGenerationCriteriaObjectModel != null)
                {

                    string claimForm = string.Empty;
                    string dispBillType = string.Empty;
                    string networkChosen = string.Empty;
                    string dateBased = string.Empty;
                    string dateFrom = string.Empty;
                    string dateEnd = string.Empty;
                    string tin = string.Empty;
                    string provName = string.Empty;
                    string provSelectRadio = string.Empty;
                    string payer = string.Empty;
                    string groupName = string.Empty;
                    string payerSelectRadio = string.Empty;
                    string payerGroup = string.Empty;
                    string tinProvider = string.Empty;

                    networkChosen = string.Join(",", reportGenerationCriteriaObjectModel
                                         .NetworkList
                                         .Where(x => x.ClaimNetworkType)
                                         .Select(x => x.ClaimNetworkValue.ToString()));
                    
                    claimForm = string.Join(",", reportGenerationCriteriaObjectModel
                                           .ClaimTypeList
                                           .Where(x => x.ClaimFormType)
                                           .Select(x => x.ClaimFormValue.ToString()));

                    if (claimForm.Contains(@Constants.Facility))
                    {
                        int countBillType = reportGenerationCriteriaObjectModel
                                             .BillTypeList
                                             .Count(x => x.BillFormType);

                        switch (countBillType)
                        {
                            case 1:
                                dispBillType = string.Join(",", reportGenerationCriteriaObjectModel
                                        .BillTypeList
                                        .Where(x => x.BillFormType)
                                        .Select(x => x.BillTypeValue.ToString()));
                                break;

                            default:
                                dispBillType = string.Join(",", reportGenerationCriteriaObjectModel
                                       .BillTypeList
                                       .Select(x => x.BillTypeValue.ToString()));
                                break;

                        }

                    }

                    tin = reportGenerationCriteriaObjectModel.Tins;
                    payer = reportGenerationCriteriaObjectModel.PayerNumberAll;

                    CheckProviderGroup(reportGenerationCriteriaObjectModel, ref provName, ref provSelectRadio, ref groupName, ref payerSelectRadio, ref payerGroup, ref tinProvider);


                    dateBased = reportGenerationCriteriaObjectModel.DateBasedOnSelected;
                    dateFrom = reportGenerationCriteriaObjectModel.StartDate;
                    dateEnd = reportGenerationCriteriaObjectModel.EndDate;

                    SetUserAccess(inputEntity);
                    inputEntity.PayerGroupPair = payerGroup;
                    inputEntity.TinProviderPair = tinProvider;
                    inputEntity.NetworkChosen = networkChosen;
                    inputEntity.DateBased = dateBased;
                    inputEntity.ClaimForm = claimForm;
                    inputEntity.DisplayBillType = dispBillType;
                    inputEntity.ProviderName = provName;
                    inputEntity.DateFrom = dateFrom;
                    inputEntity.DateEnd = dateEnd;
                    inputEntity.TinNo = tin;
                    inputEntity.PayerNumber = payer;
                    inputEntity.GroupName = groupName;
                    inputEntity.Searchby = !string.IsNullOrEmpty(provSelectRadio) ? provSelectRadio : payerSelectRadio;
                    inputEntity.session = Session.SessionID;


                }
                traceLog.AppendLine(" & End: ClaimActivityController, MakeInputCriteria Method");
                return inputEntity;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

       

        private static void CheckProviderGroup(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel, ref string provName, ref string provSelectRadio, ref string groupName, ref string payerSelectRadio, ref string payerGroup, ref string tinProvider)
        {
            StringBuilder traceLog = new StringBuilder();
            provName = string.Empty;
            provSelectRadio = string.Empty;
            groupName = string.Empty;
            payerSelectRadio = string.Empty;
            payerGroup = string.Empty;
            tinProvider = string.Empty;
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, CheckProviderGroup Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                if (reportGenerationCriteriaObjectModel.ProviderSelected.Contains(Constants.Provider))
                {
                    var tinsArray = reportGenerationCriteriaObjectModel.Tins.Split(',');
                    var onlyTinPair = "";
                    for (int i = 0; i < tinsArray.Length; i++)
                    {
                        onlyTinPair += tinsArray[i] + "-,";
                    }

                    if (onlyTinPair.Substring(onlyTinPair.Length - 1) == ",")
                        onlyTinPair = onlyTinPair.Substring(0, onlyTinPair.Length - 1);                  

                    if (reportGenerationCriteriaObjectModel.ProviderSelected == Constants.SelectedProvider)
                    {
                        tinProvider = reportGenerationCriteriaObjectModel.TinProviderList;
                        provName = string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.ProviderNamesArray) ? string.Empty : reportGenerationCriteriaObjectModel.ProviderNamesArray;
                        reportGenerationCriteriaObjectModel.ProviderNamesArrayDisplay = provName.Contains(",") ? provName.Replace(",", ", ") : string.Empty;
                        provSelectRadio = reportGenerationCriteriaObjectModel.ProviderSelected;
                    }
                    else
                    {
                        tinProvider = onlyTinPair;
                        reportGenerationCriteriaObjectModel.ProviderNamesArrayDisplay = "All";
                        provSelectRadio = reportGenerationCriteriaObjectModel.ProviderSelected;
                    }
                    if (string.IsNullOrEmpty(tinProvider) && provSelectRadio.Contains("Selected"))
                    {
                        tinProvider = onlyTinPair;
                    }

                }
                else
                    if (reportGenerationCriteriaObjectModel.ProviderSelected.Contains("Group"))
                    {
                        var groupsArray = reportGenerationCriteriaObjectModel.PayerNumberAll.Split(',');
                        var onlyPayerPair = "";
                        for (int i = 0; i < groupsArray.Length; i++)
                        {
                            onlyPayerPair += groupsArray[i] + "-,";
                        }

                        if (onlyPayerPair.Substring(onlyPayerPair.Length - 1) == ",")
                            onlyPayerPair = onlyPayerPair.Substring(0, onlyPayerPair.Length - 1);


                        if (reportGenerationCriteriaObjectModel.ProviderSelected == Constants.SelectedGroup)
                        {
                            payerGroup = reportGenerationCriteriaObjectModel.PayerGroupList;
                            groupName = string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.GroupNamesArray) ? string.Empty : reportGenerationCriteriaObjectModel.GroupNamesArray;
                            reportGenerationCriteriaObjectModel.GroupNamesArrayDisplay = groupName.Contains(",") ? groupName.Replace(",", ", ") : string.Empty;
                        }
                        else
                        {
                            payerGroup = onlyPayerPair;
                            reportGenerationCriteriaObjectModel.GroupNamesArrayDisplay = "All";
                        }

                        payerSelectRadio = reportGenerationCriteriaObjectModel.ProviderSelected;


                        if (string.IsNullOrEmpty(payerGroup) && payerSelectRadio.Contains("Selected"))
                        {
                            payerGroup = onlyPayerPair;
                        }
                    }
                traceLog.AppendLine(" & End: ClaimActivityController, CheckProviderGroup Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                traceLog.Append(provName.ToString());
                traceLog.Append(provSelectRadio.ToString());
                traceLog.Append(groupName.ToString());
                traceLog.Append(payerSelectRadio.ToString());
                traceLog.Append(payerGroup.ToString());
                traceLog.Append(tinProvider.ToString());
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// make filter object for view page
        /// </summary>
        /// <param name="reportGenerationCriteriaObjectModel"></param>
        /// <returns></returns>
        private static FilterData MakeViewPageFilter(ReportGenerationCriteriaModel reportGenerationCriteriaObjectModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, MakeViewPageFilter Method with Param reportGenerationCriteriaObjectModel: " + reportGenerationCriteriaObjectModel);
                List<SelectListItem> listClaimForm = null;
                List<SelectListItem> listTin = null;
                List<SelectListItem> listPayer = null;


                //-------------dropdown for claim Forms ----------------------------//

                listClaimForm = reportGenerationCriteriaObjectModel
                                    .ClaimTypeList
                                    .Where(x => x.ClaimFormType)
                                    .Select(x =>
                                    new SelectListItem
                                    {
                                        Text = x.ClaimFormDisplay,
                                        Value = x.ClaimFormValue
                                    }).ToList<SelectListItem>();
                //-----------------dropdown for Tins/Payers --------------------------------//     


                listTin = !string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.Tins) ? reportGenerationCriteriaObjectModel.Tins.Split(',').Select(x => new SelectListItem { Text = x, Value = x }).ToList<SelectListItem>() : new List<SelectListItem>();


                listPayer = !string.IsNullOrEmpty(reportGenerationCriteriaObjectModel.PayerNumberAll) ? reportGenerationCriteriaObjectModel.PayerNumberAll.Split(',').Select(x => new SelectListItem { Text = x, Value = x }).ToList<SelectListItem>() : new List<SelectListItem>();

                FilterData filterDataObject = new FilterData();
                filterDataObject.ClaimFormDropDown = listClaimForm;
                filterDataObject.TinDropDown = listTin;
                filterDataObject.PayerDropDown = listPayer;
                filterDataObject.DosBeginFilter = string.Empty;
                filterDataObject.DosEndFilter = string.Empty;
                filterDataObject.TinNoFilter = string.Empty;
                filterDataObject.NetworkFilter = string.Empty;
                traceLog.AppendLine(" & End: ClaimActivityController, MakeViewPageFilter Method");
                return filterDataObject;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }


        }

        private void SetUserAccess(ReportCriteriaEntity reportObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, SetUserAccess Method with Param reportObject: " + reportObject);
                UserDetails user = (UserDetails)Session[Constants.UserDetails];
                if (user != null)
                {
                    List<string> networkList = new List<string>();
                    string network = "";
                    if (!string.IsNullOrEmpty(user.UserId))
                    {
                        reportObject.Userid = user.UserId;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole))
                    {
                        reportObject.UserRole = user.SelectedRole;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole)
                        && user.UserRoles != null
                        && user.UserRoles.Count() > 0)
                    {
                        reportObject.IsEmployee = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault().IsEmployee;
                        IEnumerable<CanCheckRestrictedMember> canCheckRestrictedList = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                        if (canCheckRestrictedList != null) reportObject.CanCheckRestrictedMembers = canCheckRestrictedList.FirstOrDefault().RestrictedCheck == 1 ? true : false;
                        else reportObject.CanCheckRestrictedMembers = false;

                        Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();

                        //get the network for selected function
                        networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuClaimActivity, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                    }

                    if (networkList != null)
                    {
                        network = string.Join(",", networkList);
                        reportObject.NetworkChosen = network;
                    }

                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    reportObject.UserType = ConfigurationManager.AppSettings[Constants.Site];
                }
                traceLog.AppendLine(" & End: ClaimActivityController, SetUserAccess Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        #endregion

        #region My DownLoads
        /// <summary>
        /// To Get all claim activity report downloads files 
        /// </summary>
        /// <returns></returns>
        public ActionResult MyDownLoads()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimActivityController, MyDownLoads Method");
                string userId = "";
                UserDetails user = (UserDetails)Session[Constants.UserDetails];
                userId = user.UserId;
                IEnumerable<MyDownloadReport> reportObject = null;
                traceLog.AppendLine("Calling GetMyDownLoadReports Method with param : " + userId);
                reportObject = ReportGenerationCriteriaObjectBLL.GetMyDownLoadReports(userId);
                traceLog.AppendLine(" & End: ClaimActivityController, MyDownLoads Method");
                return View(reportObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        #endregion

    }
}