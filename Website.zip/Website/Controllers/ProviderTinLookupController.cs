﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Models;
using System.Globalization;
using System.Reflection;
using System.Configuration;
using Aetna.Cofinity.Admin.Entities.Response;
using System.Web.Security.AntiXss;
using System.Text;
using Utilities;

namespace NABWebsite.Controllers
{
    public class ProviderTinLookupController : BaseController
    {
        //StringBuilder traceLog = new StringBuilder();
        /// <summary>
        /// Provider tin lookup home page
        /// </summary>
        /// <returns>ActionResult</returns>
        [CheckAccess(Function = "Provider TIN Look-Up")]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderTinLookupController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ProviderTinLookupController, Index Method");
                    return RedirectToAction("Index", "Home");
                }
                //if required can be used
                //Session[Constants.Currentcontroller] = "ProviderTINLookup";
                //Session[Constants.Currentaction] = "Index";
                Session[Constants.Header] = Constants.ProviderTinLookupHead;
                ProviderTinLookupModel modelObject = new ProviderTinLookupModel();
                ProviderTinLookup tinlookup = new ProviderTinLookup();
                ProviderTin objBll = new ProviderTin();
                Access access = new Access();
                SetUserAccess(access);
                tinlookup.UserRoleAccess = access;
                List<string> networkList = new List<string>();
                
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                {
                    tinlookup.IsEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                    IEnumerable<CanCheckRestrictedMember> canCheckRestrictedList = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                    if (canCheckRestrictedList != null) tinlookup.CanCheckRestrictedMembers = canCheckRestrictedList.FirstOrDefault().RestrictedCheck == 1 ? true : false;
                    else tinlookup.CanCheckRestrictedMembers = false;

                    //get selected role
                    Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                    //get the network for selcted function
                    networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuProviderTin, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
               
                }
                if (networkList != null)
                {
                    tinlookup.Network = string.Join(",", networkList);
                }
                tinlookup = objBll.GetAllClient(tinlookup);
                tinlookup.AllSubClient = new List<SelectListItem>() { new SelectListItem() { Text = Constants.SelectSubClient, Value = Constants.SelectSubClient } };
                modelObject.ProviderTin = tinlookup;
                traceLog.AppendLine(" & End: ProviderTinLookupController, Index Method");
                return View("ProviderTinLookUp", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }
        }

        /// <summary>
        /// Search results
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Provider TIN Look-Up")]
        [HttpPost]
        public ActionResult Index(ProviderTinLookupModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderTinLookupController, Index Method with Param modelObject: " + modelObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ProviderTinLookupController, Index Method");
                    return RedirectToAction("Index", "Home");
                }

                if (modelObject != null)
                {
                    if (modelObject.ProviderTin.PageNo == Constants.PageZero)
                    {
                        modelObject.ProviderTin.PageNo = Constants.PageOne;
                    }
                    ProviderTin objBll = new ProviderTin();
                    Access access = new Access();
                    SetUserAccess(access);
                    if (modelObject.ProviderTin != null)
                    {
                        modelObject.ProviderTin.UserRoleAccess = access;
                        if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                        {
                            modelObject.ProviderTin.IsEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                            IEnumerable<CanCheckRestrictedMember> canCheckRestrictedList = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                            if (canCheckRestrictedList != null) modelObject.ProviderTin.CanCheckRestrictedMembers = canCheckRestrictedList.FirstOrDefault().RestrictedCheck == 1 ? true : false;
                            else modelObject.ProviderTin.CanCheckRestrictedMembers = false;
                            //modelObject.ProviderTin.CanCheckRestrictedMembers = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                        }
                        modelObject.ProviderTin = objBll.GetAllClient(modelObject.ProviderTin);

                        if (modelObject.ProviderTin.Client != Constants.SelectClient)
                        {
                            modelObject.ProviderTin.AllSubClient = GetSubClientByClient(modelObject.ProviderTin.Client);
                        }
                        else
                        {
                            modelObject.ProviderTin.AllSubClient = new List<SelectListItem>() { new SelectListItem() { Text = Constants.SelectSubClient, Value = Constants.SelectSubClient } };
                        }
                    }
                    if (ModelInputValidation(modelObject.ProviderTin))
                    {
                        
                        modelObject.ProviderTin = objBll.GetProviderDetails(modelObject.ProviderTin);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: ProviderTinLookupController, Index Method");
                        return Content("<script type='text/javascript'>alert('Input contains invalid content');window.location='/ProviderTinLookUp/Index'</Script>");
                    }
                }
                traceLog.AppendLine(" & End: ProviderTinLookupController, Index Method");
                return View("ProviderTinLookUp", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }
        }
        /// <summary>
        /// partial view for pagination and sorting
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult TinLookupPartial(ProviderTinLookupModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderTinLookupController, TinLookupPartial Method with Param modelObject: " + modelObject);
                if (modelObject != null)
                {
                    if (modelObject.ProviderTin.PageNo == Constants.PageZero)
                        modelObject.ProviderTin.PageNo = Constants.PageOne;
                    ProviderTin objBll = new ProviderTin();
                    Access access = new Access();
                    SetUserAccess(access);
                    if (modelObject.ProviderTin != null)
                    {
                        modelObject.ProviderTin.UserRoleAccess = access;
                        if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                        {
                            modelObject.ProviderTin.IsEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                            IEnumerable<CanCheckRestrictedMember> canCheckRestrictedList = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                            if (canCheckRestrictedList != null) modelObject.ProviderTin.CanCheckRestrictedMembers = canCheckRestrictedList.FirstOrDefault().RestrictedCheck == 1 ? true : false;
                            else modelObject.ProviderTin.CanCheckRestrictedMembers = false;
                        }
                        modelObject.ProviderTin = objBll.GetAllClient(modelObject.ProviderTin);
                        if (modelObject.ProviderTin.Client != Constants.SelectClient)
                        {
                            modelObject.ProviderTin.AllSubClient = GetSubClientByClient(modelObject.ProviderTin.Client);
                        }
                        else
                        {
                            modelObject.ProviderTin.AllSubClient = new List<SelectListItem>() { new SelectListItem() { Text = Constants.SelectSubClient, Value = Constants.SelectSubClient } };
                        }
                    }
                    if (ModelInputValidation(modelObject.ProviderTin))
                    {                        
                        modelObject.ProviderTin = objBll.GetProviderDetails(modelObject.ProviderTin);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: ProviderTinLookupController, TinLookupPartial Method");
                        return Content("<script type='text/javascript'> window.location='/Error/Index'</script>");
                    }
                }
                traceLog.AppendLine(" & End: ProviderTinLookupController, TinLookupPartial Method");
                return PartialView("_SearchTINProvider", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }
        }
        
        /// <summary>
        /// Fetch subclient by client
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        private IEnumerable<SelectListItem> GetSubClientByClient(string client)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderTinLookupController, GetSubClientByClient Method with Param client: " + client);
                ProviderTin objBll = new ProviderTin();
                List<SelectListItem> subClient = new List<SelectListItem>();
                if (client != null)
                {
                    Access access = new Access();
                    SetUserAccess(access);
                    SelectListItem startObject = new SelectListItem() { Text = Constants.SelectSubClient, Value = Constants.SelectSubClient };
                    subClient.Add(startObject);
                    IEnumerable<SelectListItem> subClientList = objBll.GetSubClientByClient(client, access);
                    if (subClientList != null)
                    {
                        subClient.AddRange(subClientList.Select(x => new SelectListItem { Text = x.Text, Value = x.Value }).ToList());
                    }
                }
                traceLog.AppendLine(" & End: ProviderTinLookupController, GetSubClientByClient Method");
                return subClient;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
                
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch subclient by client
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns>JsonResult</returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetSubClientByClientByJson(string clientId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderTinLookupController, GetSubClientByClientByJson Method with Param client: " + clientId);
                clientId = AntiXssEncoder.HtmlEncode(clientId, true);//Added on 17-Jul-18 to fix Reflected XSS       
                 var client = GetSubClientByClient(clientId);
                 traceLog.AppendLine(" & End: ProviderTinLookupController, GetSubClientByClientByJson Method");
                return Json(client, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Set user access in model object
        /// </summary>
        /// <param name="objAccess"></param>
        private void SetUserAccess(Access objAccess)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderTinLookupController, SetUserAccess Method with Param objAccess: " + objAccess);
                List<string> networkList = new List<string>();
                UserDetails user = (UserDetails)Session[Constants.UserDetails];
                if (user != null)
                {
                    if (!string.IsNullOrEmpty(user.UserId))
                    {
                        objAccess.User = user.UserId;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole))
                    {
                        objAccess.Role = user.SelectedRole;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole)
                                && user.UserRoles != null
                                && user.UserRoles.Count() > 0)
                    {
                        objAccess.IsEmployee = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault().IsEmployee;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole)
                                    && user.UserRoles != null
                                    && user.UserRoles.Count() > 0)
                    {
                        //get selected role
                        Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault();
                        //get the network for selcted function
                        networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuProviderTin, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                    }
                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    objAccess.UserType = ConfigurationManager.AppSettings[Constants.Site];
                }
                if (networkList != null)
                {
                    objAccess.Network = string.Join(",", networkList);
                }
                traceLog.AppendLine(" & End: ProviderTinLookupController, SetUserAccess Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// validate user inputs
        /// </summary>
        /// <param name="objInputCriteria"></param>
        /// <returns>bool</returns>
        private static bool ModelInputValidation(ProviderTinLookup objInputCriteria)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderTinLookupController, ModelInputValidation Method with Param objInputCriteria: " + objInputCriteria);
                bool check = true;
                if (!string.IsNullOrEmpty(objInputCriteria.Network))
                {
                    check = Validation.IsValidContent(objInputCriteria.Network);
                }
                if (check)
                {
                    Type type = objInputCriteria.GetType();
                    PropertyInfo[] properties = type.GetProperties();

                    foreach (PropertyInfo property in properties)
                    {
                        var propertyValue = property.GetValue(objInputCriteria, null);
                        if (propertyValue != null)
                        {
                            if (Validation.IsValidContent(propertyValue.ToString()))
                            {
                                switch (property.Name)
                                {
                                    case Constants.Tin:
                                    case Constants.Tin1:
                                        if (!Validation.IsValidTin(propertyValue.ToString()))
                                            check = false;
                                        break;
                                    case Constants.LastName:
                                    case Constants.LastName1:
                                        if (!Validation.IsAlphaWithSpace(propertyValue.ToString()))
                                            check = false;
                                        break;
                                    default: break;
                                }
                            }
                            else
                            {
                                if (property.Name != Constants.AllClient && property.Name != Constants.AllSubClient)
                                {
                                    check = false;
                                    break;
                                }
                            }
                        }
                    }
                }
                traceLog.AppendLine(" & End: ProviderTinLookupController, ModelInputValidation Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
    }
}