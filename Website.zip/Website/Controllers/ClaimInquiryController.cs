﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System.ServiceModel;
using System.Configuration;
using FlexMapper.MapperService;
using System.Globalization;
using Org.BouncyCastle.Crypto;
using System.Text;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Engines;
using System.Reflection;
using Aetna.Cofinity.Admin.Entities.Response;
using Utilities;
using System.IO;
using System.Security;

namespace NABWebsite.Controllers
{
    public class ClaimInquiryController : BaseController
    {
        /// <summary>
        /// Fetch Claim Attachment
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ActionResult</returns>
        [CheckAccess(Function = "Claims Inquiry")]
        public ActionResult Attachment(string id)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, Attachment Method with Param id: " + id);
                id = id.Replace("\\", "").Replace("..", "");//Added on 18-Jul to Fix PAth Traversal issue
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                ClaimInquiryBL claimBL = new ClaimInquiryBL();
                string attachmentType = string.Empty;
                string barcode = string.Empty;
                attachmentType = id.Substring(0, id.IndexOf('_'));
                barcode = id.Substring(id.IndexOf('_') + 1, id.Length - id.IndexOf('_') - 1);
                if (attachmentType.ToUpperInvariant().Equals(Constants.AttachmentTypeKIT.ToUpperInvariant()))
                {
                    NABWebsite.DTO.FileContent file = claimBL.GetKITFile(barcode);
                    if (file != null && file.Name != null)
                    {
                        string filetype = file.Name.Substring(file.Name.IndexOf('.') + 1, file.Name.Length - file.Name.IndexOf('.') - 1);
                        traceLog.AppendLine(" & End: ClaimInquiryController, Attachment Method");
                        return File(file.Content, filetype, file.Name);
                    }
                }
                else if (attachmentType.ToUpperInvariant().Equals(Constants.AttachmentTypeGEHA.ToUpperInvariant()))
                {
                    NABWebsite.DTO.FileContent file = claimBL.GetFile(barcode, "", ((UserDetails)Session[Constants.UserDetails]).UserId);
                    if (file != null && file.Name != null)
                    {
                        string filetype = file.Name.Substring(file.Name.IndexOf('.') + 1, file.Name.Length - file.Name.IndexOf('.') - 1);
                        traceLog.AppendLine(" & End: ClaimInquiryController, Attachment Method");
                        return File(file.Content, filetype, file.Name);
                    }
                }
                else
                {
                    //var barCode = id;
                    var currentTime = DateTime.UtcNow.AddMinutes(30);
                    var formatGMT = currentTime.Year.ToString(CultureInfo.InvariantCulture) + AppendZero(currentTime.Month) + AppendZero(currentTime.Day) + AppendZero(currentTime.Hour)
                        + AppendZero(currentTime.Minute) + AppendZero(currentTime.Second);
                    var urlToGo = ConfigurationManager.AppSettings[Constants.DocumentUrl];
                    var urlToEncode = string.Empty;
                    urlToEncode = Constants.Barcode + barcode + Constants.Format + formatGMT;
                    var appendUrl = string.Empty;
                   IStreamCipher cipher = new RC4Engine();
                    byte[] key = Encoding.UTF8.GetBytes(ConfigurationManager.AppSettings[Constants.DocumentPrivateKey]);
                    byte[] input = Encoding.UTF8.GetBytes(urlToEncode);
                    byte[] cipherText = new byte[input.Length];
                    cipher.Init(true, new KeyParameter(key));
                    cipher.ProcessBytes(input, 0, input.Length, cipherText, 0);
                    appendUrl = Convert.ToBase64String(cipherText);
                    var path = urlToGo + appendUrl;
                    //Response.Write(Constants.ScriptWindowOpen + path + Constants.ScriptWindowClose);
                    return Redirect(path);
                }
                traceLog.AppendLine(" & End: ClaimInquiryController, Attachment Method");
                return null;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }


        }
        /// <summary>
        ///Format the date field
        /// </summary>
        /// <param name="number"></param>
        /// <returns>string</returns>

        private static string AppendZero(int number)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, AppendZero Method with Param number: " + number);
                if (number > 0 && number < 10)
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, AppendZero Method");
                    return Constants.Zero + number.ToString(CultureInfo.InvariantCulture);
                }
                else if (number == 0)
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, AppendZero Method");
                    return Constants.Zero + Constants.Zero;
                }
                else
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, AppendZero Method");
                    return number.ToString(CultureInfo.InvariantCulture);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch CoverSheet
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ActionResult</returns>


        /// <summary>
        /// Claim Search Home Page
        /// </summary>
        /// <returns>ActionResult</returns>
        [CheckAccess(Function = "Claims Inquiry")]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ClaimEnquiryHead;
                ClaimInquiry claims = new ClaimInquiry();
                ClaimInquiryBL claimBL = new ClaimInquiryBL();


                List<SelectListItem> items = new List<SelectListItem>();

                items.Add(new SelectListItem { Text = Constants.Dash + Constants.Select + Constants.Dash, Value = Constants.Start });
                //if (((UserDetails)Session[Constants.UserDetails]).SelectedRole == "Provider")
                //{
                //    items.Add(new SelectListItem { Text = Constants.TINNumber, Value = Constants.TIN });
                //}
                //items.Add(new SelectListItem { Text = Constants.ClaimNo, Value = Constants.Claim });
                //items.Add(new SelectListItem { Text = Constants.AccountNo, Value = Constants.Account });
                //items.Add(new SelectListItem { Text = Constants.MemberId, Value = Constants.Ssn });
                //items.Add(new SelectListItem { Text = Constants.MemberDetails, Value = Constants.Member });

                claims.SearchCriteria = items;
                if (((UserDetails)Session[Constants.UserDetails]).SelectedRole != null && ConfigurationManager.AppSettings[Constants.Site] != null)
                {
                    if (ConfigurationManager.AppSettings[Constants.Site].ToUpperInvariant().Equals(Constants.External.ToUpperInvariant()) && ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant().Equals(Constants.Provider.ToUpperInvariant()))
                    {
                        bool isEmployee = false;
                        string network = string.Empty;
                        List<Network> networkList = new List<Network>();
                        if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                        {
                            isEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                        }
                        if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                                && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                                && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                        {
                            //get selected role
                            Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                            //get the network for selcted function
                            networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuClaimInquiry, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList<Network>();
                        }
                        if (networkList != null)
                        {
                            List<string> networklst = new List<string>();
                            foreach (var item in networkList)
                            {
                                networklst.Add(item.NetworkName);
                            }
                            network = string.Join(",", networklst);
                        }
                        int SrcsystemIds = Constants.ThreeCount;
                        claims.TinList = claimBL.GetAllTinlist(((UserDetails)Session[Constants.UserDetails]).UserId, ((UserDetails)Session[Constants.UserDetails]).SelectedRole, isEmployee, network, SrcsystemIds);
                    }
                }
                else
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, Index Method");
                    return RedirectToAction("Index", "Home");
                }
                traceLog.AppendLine(" & End: ClaimInquiryController, Index Method");
                return View("ClaimInquiry", claims);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [CheckAccess(Function = "Claims Inquiry")]
        [HttpGet]
        public JsonResult ClaimDropdown(string id)
        {
            ClaimInquiry claims = new ClaimInquiry();
            List<SelectListItem> items = new List<SelectListItem>();

            items.Add(new SelectListItem { Text = Constants.Dash + Constants.Select + Constants.Dash, Value = Constants.Start });

            if (id != null)
            {
                if (((UserDetails)Session[Constants.UserDetails]).SelectedRole == Constants.Provider && (id == Constants.ActivityFirstHealth || id=="3"))
                {
                    items.Add(new SelectListItem { Text = Constants.TINNumber, Value = Constants.TIN });
                }
                items.Add(new SelectListItem { Text = Constants.ClaimNo, Value = Constants.Claim });
                items.Add(new SelectListItem { Text = Constants.AccountNo, Value = Constants.Account });
                items.Add(new SelectListItem { Text = Constants.MemberId, Value = Constants.Ssn });
                items.Add(new SelectListItem { Text = Constants.MemberDetails, Value = Constants.Member });
            }
            claims.SearchCriteria = items;
            return Json(claims.SearchCriteria, JsonRequestBehavior.AllowGet);

        }
        int pageSize = ConfigurationManager.AppSettings[Constants.RecordsPerPage] != null ? Convert.ToInt32(ConfigurationManager.AppSettings[Constants.RecordsPerPage], CultureInfo.InvariantCulture) : Constants.PageSize;

        /// <summary>
        /// Claim Result
        /// </summary>
        /// <param name="claimObject"></param>
        /// <returns>ActionResult</returns>
        #region Search Results
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Claims Inquiry")]
        public ActionResult ClaimSearch(ClaimInquiry claimObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, ClaimSearch Method with Param claimObject: " + claimObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }

                ClaimInquiryBL claimBL = new ClaimInquiryBL();

                ProcessedClaim processClaim = new ProcessedClaim();
                if (claimObject != null)
                {

                    claimObject.ProcessedClaim = processClaim;

                    if (claimObject.ProcessedClaim.PageNo == Constants.PageZero)
                    {
                        claimObject.ProcessedClaim.PageNo = Constants.PageOne;
                        claimObject.ProcessedClaim.TotalPages = Constants.PageOne;
                        claimObject.ProcessedClaim.SortType = Constants.AscendingText;
                        claimObject.ProcessedClaim.SortBy = Constants.DosBegin;
                    }

                    ProcessedClaimSearchCriteria ProcessClaimSearchCriteria = new ProcessedClaimSearchCriteria();
                    ProcessClaimSearchCriteria.SelectedSearchCriteria = claimObject.SelectedSearchCriteria;
                    ProcessClaimSearchCriteria.Network = claimObject.Network;
                    ProcessClaimSearchCriteria.SrcSystemID = claimObject.SrcSystemID;
                    SetUserAccess(ProcessClaimSearchCriteria);
                    ProcessClaimSearchCriteria.ProcessClaim = claimObject.ProcessedClaim;
                    ProcessClaimSearchCriteria.ClaimSearchCriteria = claimObject.ClaimSearchCriteria;
                    ProcessClaimSearchCriteria.session = Session.SessionID;
                    if (claimObject.SelectedSearchCriteria == Constants.TIN)
                    {
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Tin = claimObject.ClaimSearchCriteria.TINs;
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Tin1 = claimObject.ClaimSearchCriteria.TINs1;
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Tin2 = claimObject.ClaimSearchCriteria.TINs2;
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Dos = claimObject.ClaimSearchCriteria.DOSs;
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Dos1 = claimObject.ClaimSearchCriteria.DOSs1;
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Dos2 = claimObject.ClaimSearchCriteria.DOSs2;
                    }

                    if (ModelInputValidation(ProcessClaimSearchCriteria))
                    {
                        claimObject.ProcessedClaim = claimBL.GetClaims(ProcessClaimSearchCriteria);
                    }
                    else
                    {
                        return Content("<script type='text/javascript'>alert('Input contains invalid content');window.location='/ClaimInquiry/Index'</Script>");//throw new ArgumentException("Validation Error");
                    }

                    claimObject.TotalCount = claimObject.ProcessedClaim.TotalCount;// +claimObject.RejectedClaim.TotalCount;

                    claimObject.ProcessedClaim.TotalPages = Convert.ToInt32(System.Math.Ceiling(
                        Convert.ToDouble(claimObject.ProcessedClaim.TotalCount) / pageSize));
                    claimObject.ProcessedClaim.PageNo = Constants.PageOne;
                    claimObject.ProcessedClaim.SortType = Constants.AscendingText;
                    claimObject.ProcessedClaim.SortBy = Constants.DosBegin;

                    List<SelectListItem> items = new List<SelectListItem>();

                    items.Add(new SelectListItem { Text = Constants.Dash + Constants.Select + Constants.Dash, Value = Constants.Start });
                    if (((UserDetails)Session[Constants.UserDetails]).SelectedRole == Constants.Provider && claimObject.Network == Constants.ActivityFirstHealth)
                    {
                        items.Add(new SelectListItem { Text = Constants.TINNumber, Value = Constants.TIN });
                    }
                    items.Add(new SelectListItem { Text = Constants.ClaimNo, Value = Constants.Claim });
                    items.Add(new SelectListItem { Text = Constants.AccountNo, Value = Constants.Account });
                    items.Add(new SelectListItem { Text = Constants.MemberId, Value = Constants.Ssn });
                    items.Add(new SelectListItem { Text = Constants.MemberDetails, Value = Constants.Member });
                    claimObject.SearchCriteria = items;

                    if (((UserDetails)Session[Constants.UserDetails]).SelectedRole != null && ConfigurationManager.AppSettings[Constants.Site] != null)
                    {
                        if (ConfigurationManager.AppSettings[Constants.Site].ToUpperInvariant().Equals(Constants.External.ToUpperInvariant()) && ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant().Equals(Constants.Provider.ToUpperInvariant()))
                        {
                            bool isEmployee = false;
                            string network = string.Empty;
                            List<Network> networkList = new List<Network>();
                            if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                            {
                                isEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                            }
                            if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                                && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                                && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                            {
                                //get selected role
                                Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                                //get the network for selcted function
                                networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuClaimInquiry, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList <Network>();
                            }
                            if (networkList != null)
                                //network = string.Join(",", networkList);
                                network = String.Join(",", networkList.Select(x => x.NetworkName).ToList<string>());
                            int SrcsystemIds = Constants.ThreeCount;
                            claimObject.TinList = claimBL.GetAllTinlist(((UserDetails)Session[Constants.UserDetails]).UserId, ((UserDetails)Session[Constants.UserDetails]).SelectedRole, isEmployee, network, SrcsystemIds);
                        }
                    }
                }
                traceLog.AppendLine(" & End: ClaimInquiryController, ClaimSearch Method");
                return View("ClaimInquiry", claimObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Claim Result for Processed Claims
        /// </summary>
        /// <param name="claimObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [CheckAccess(Function = "Claims Inquiry")]
        [HttpPost]
        public ActionResult ProcessedClaimSearch(ClaimInquiry claimObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, ProcessedClaimSearch Method with Param claimObject: " + claimObject);
                if (claimObject != null && claimObject.ProcessedClaim != null)
                {
                    int page = claimObject.ProcessedClaim.PageNo;
                    string sortby = claimObject.ProcessedClaim.SortBy;
                    string sorttype = claimObject.ProcessedClaim.SortType;
                    string filtertin = claimObject.ProcessedClaim.ProcessFilterTin;
                    string filterdos = claimObject.ProcessedClaim.ProcessFilterDos;
                    ClaimInquiryBL claimBL = new ClaimInquiryBL();

                    if (claimObject.ProcessedClaim != null && claimObject.ProcessedClaim.PageNo == Constants.PageZero)
                    {
                        claimObject.ProcessedClaim.PageNo = Constants.PageOne;
                        claimObject.ProcessedClaim.TotalPages = Constants.PageOne;
                        claimObject.ProcessedClaim.SortType = Constants.AscendingText;
                        claimObject.ProcessedClaim.SortBy = Constants.DosBegin;
                    }

                    ProcessedClaimSearchCriteria ProcessClaimSearchCriteria = new ProcessedClaimSearchCriteria();
                    SetUserAccess(ProcessClaimSearchCriteria);
                    ProcessClaimSearchCriteria.Network = claimObject.Network;
                    ProcessClaimSearchCriteria.SelectedSearchCriteria = claimObject.SelectedSearchCriteria;
                    ProcessClaimSearchCriteria.ProcessClaim = claimObject.ProcessedClaim;
                    ProcessClaimSearchCriteria.ClaimSearchCriteria = claimObject.ClaimSearchCriteria;
                    ProcessClaimSearchCriteria.SrcSystemID = claimObject.SrcSystemID;
                    ProcessClaimSearchCriteria.session = Session.SessionID;
                    if (claimObject.SelectedSearchCriteria == Constants.TIN)
                    {
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Tin = claimObject.ClaimSearchCriteria.TINs;
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Tin1 = claimObject.ClaimSearchCriteria.TINs1;
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Tin2 = claimObject.ClaimSearchCriteria.TINs2;
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Dos = claimObject.ClaimSearchCriteria.DOSs;
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Dos1 = claimObject.ClaimSearchCriteria.DOSs1;
                        ProcessClaimSearchCriteria.ClaimSearchCriteria.Dos2 = claimObject.ClaimSearchCriteria.DOSs2;
                    }
                    if (ModelInputValidation(ProcessClaimSearchCriteria))
                    {
                        claimObject.ProcessedClaim = claimBL.GetClaims(ProcessClaimSearchCriteria);
                    }
                    else
                    {
                        throw new ArgumentException("Validation Error");
                    }

                    claimObject.ProcessedClaim.TotalPages = Convert.ToInt32(System.Math.Ceiling(
                        Convert.ToDouble(claimObject.ProcessedClaim.TotalCount) / pageSize));

                    claimObject.ProcessedClaim.PageNo = page;
                    claimObject.ProcessedClaim.SortBy = sortby;
                    claimObject.ProcessedClaim.SortType = sorttype;
                    claimObject.ProcessedClaim.ProcessFilterTin = filtertin;
                    claimObject.ProcessedClaim.ProcessFilterDos = filterdos;

                }

                if (((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant().Equals(Constants.Provider.ToUpperInvariant()))
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, ProcessedClaimSearch Method");
                    return PartialView("_ProcessedClaim", claimObject);
                }

                else
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, ProcessedClaimSearch Method");
                    return PartialView("_PayerProcessedClaim", claimObject);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        #endregion

        #region Coversheet for Claim Search

        [CheckAccess(Function = "Claims Inquiry")]
        public ActionResult Coversheet(string id)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, Coversheet Method with Param id: " + id);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                ClaimInquiryBL claimBL = new ClaimInquiryBL();
                var batchId = id;
                if (!string.IsNullOrWhiteSpace(batchId))
                {
                    if (System.Configuration.ConfigurationManager.AppSettings[Constants.Site] == "External")
                    {
                        FlexMapperRelay.MapResult mrr = claimBL.GetCoverSheetRelay(batchId);
                        if (mrr != null)
                        {
                            Response.ClearHeaders();
                            Response.ContentType = Constants.ResponseContentPdf;
                            Response.AddHeader(Constants.ContentDisposition, Constants.FileNamePdfDownload);
                            try
                            {
                                Response.OutputStream.Write(mrr.FileContent, 0, mrr.FileContent.Length);
                            }
                            finally
                            {
                                Response.OutputStream.Flush();
                                Response.OutputStream.Close();
                            }
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: ClaimInquiryController, Coversheet Method");
                            return View("_CoverSheet");
                        }
                    }
                    else
                    {
                        FlexMapper.MapperService.MapResult mr = claimBL.GetCoverSheet(batchId);
                        if (mr != null)
                        {
                            Response.ClearHeaders();
                            Response.ContentType = Constants.ResponseContentPdf;
                            Response.AddHeader(Constants.ContentDisposition, Constants.FileNamePdfDownload);
                            try
                            {
                                Response.OutputStream.Write(mr.FileContent, 0, mr.FileContent.Length);
                            }
                            finally
                            {
                                Response.OutputStream.Flush();
                                Response.OutputStream.Close();
                            }
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: ClaimInquiryController, Coversheet Method");
                            return View("_CoverSheet");
                        }
                    }
                }
                traceLog.AppendLine(" & End: ClaimInquiryController, Coversheet Method");
                return View("_CoverSheet");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion
        #region Set User Access
        /// <summary>
        /// Set model value for user Access for Processed Claim
        /// </summary>
        /// <param name="ProcessClaimSearchCriteria"></param>
        private void SetUserAccess(ProcessedClaimSearchCriteria ProcessClaimSearchCriteria)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, SetUserAccess Method with Param ProcessClaimSearchCriteria: " + ProcessClaimSearchCriteria);
                UserDetails user = (UserDetails)Session[Constants.UserDetails];
                if (user != null)
                {
                    if (!string.IsNullOrEmpty(user.UserId))
                    {
                        ProcessClaimSearchCriteria.Userid = user.UserId;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole))
                    {
                        ProcessClaimSearchCriteria.Role = user.SelectedRole;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole)
                        && user.UserRoles != null
                        && user.UserRoles.Count() > 0)
                    {
                        ProcessClaimSearchCriteria.IsEmployee = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault().IsEmployee;
                        IEnumerable<CanCheckRestrictedMember> canCheckRestrictedList = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                        if (canCheckRestrictedList != null) ProcessClaimSearchCriteria.CanCheckRestrictedMembers = canCheckRestrictedList.FirstOrDefault().RestrictedCheck == 1 ? true : false;
                        else ProcessClaimSearchCriteria.CanCheckRestrictedMembers = false;
                    }
                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    ProcessClaimSearchCriteria.Site = ConfigurationManager.AppSettings[Constants.Site];
                }
                traceLog.AppendLine(" & End: ClaimInquiryController, SetUserAccess Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        #endregion

        #region Input validation
        /// <summary>
        /// Validate user input for Processed Claim
        /// </summary>
        /// <param name="objInputCriteria"></param>
        /// <returns>bool</returns>
        private bool ModelInputValidation(ProcessedClaimSearchCriteria objInputCriteria)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, ModelInputValidation Method with Param objInputCriteria: " + objInputCriteria);
                bool check = false;

                if (!string.IsNullOrEmpty(objInputCriteria.Network))
                {
                    check = Validation.IsValidContent(objInputCriteria.Network);
                }
                if (check && !string.IsNullOrEmpty(objInputCriteria.SelectedSearchCriteria))
                {
                    check = Validation.IsValidContent(objInputCriteria.SelectedSearchCriteria);
                }

                #region ConditionsCheckStart
                if (check)
                {
                    Type type = objInputCriteria.ClaimSearchCriteria.GetType();
                    PropertyInfo[] properties = type.GetProperties();
                    foreach (PropertyInfo property in properties)
                    {
                        var propertyValue = property.GetValue(objInputCriteria.ClaimSearchCriteria, null);
                        if (propertyValue != null)
                        {
                            if (property.Name.ToLower().Contains("account"))
                            {
                                if (Validation.IsValidContent2(propertyValue.ToString()))
                                {
                                    switch (property.Name)
                                    {
                                        case Constants.AccountNumber:
                                        case Constants.AccountNo1:
                                        case Constants.AccountNo2:
                                            if (!Validation.IsAlphanumeric2(propertyValue.ToString()))
                                                check = false;
                                            break;
                                    }
                                }
                                else
                                {
                                    check = false;
                                    break;
                                }
                            }
                            else
                            {
                                if (Validation.IsValidContent(propertyValue.ToString()))
                                {
                                    switch (property.Name)
                                    {
                                        case Constants.ClaimNumber:
                                        case Constants.ClaimNo1:
                                        case Constants.ClaimNo2:
                                            if (!Validation.IsAlphanumeric(propertyValue.ToString()))
                                                check = false;
                                            break;
                                        case Constants.AlternateId:
                                        case Constants.AlternateId1:
                                        case Constants.AlternateId2:
                                        case Constants.MemberAlternateId:
                                        case Constants.MemberAlternateId1:
                                        case Constants.MemberAlternateId2:
                                            if (!Validation.IsValidSsn(propertyValue.ToString()))
                                                check = false;
                                            break;
                                        case Constants.Tin:
                                        case Constants.Tin1:
                                        case Constants.Tin2:
                                        case Constants.MemberTin:
                                        case Constants.MemberTin1:
                                        case Constants.MemberTin2:
                                            if (!Validation.IsValidTin(propertyValue.ToString()))
                                                check = false;
                                            break;
                                        case Constants.FirstName:
                                        case Constants.FirstName1:
                                        case Constants.FirstName2:
                                        case Constants.MemberFirstName:
                                        case Constants.MemberFirstName1:
                                        case Constants.MemberFirstName2:
                                            if (!Validation.IsValidFirstInitial(propertyValue.ToString()))
                                                check = false;
                                            break;
                                        case Constants.LastName:
                                        case Constants.LastName1:
                                        case Constants.LastName2:
                                        case Constants.MemberLastName2:
                                        case Constants.MemberLastName1:
                                        case Constants.MemberLastName:
                                            if (!Validation.IsAlphaWithSpace(propertyValue.ToString()))
                                                check = false;
                                            break;

                                        case Constants.DateOfService:
                                        case Constants.Dos1:
                                        case Constants.Dos2:
                                        case Constants.MemberDos:
                                        case Constants.MemberDos1:
                                        case Constants.MemberDos2:
                                            check = IsValidDosDateRange(propertyValue.ToString());
                                            break;

                                        case Constants.MemberDob:
                                        case Constants.MemberDob1:
                                        case Constants.MemberDob2:
                                        case Constants.Dob:
                                        case Constants.Dob1:
                                        case Constants.Dob2:

                                            check = IsValidDobDateRange(propertyValue.ToString());
                                            break;

                                    }
                                }
                                else
                                {
                                    check = false;
                                    break;
                                }
                            }
                        }
                    }
                }
                traceLog.AppendLine(" & End: ClaimInquiryController, ModelInputValidation Method");
                return check;
                #endregion
                
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// validation for check 3 year previous date && validate date
        /// </summary>
        /// <param name="valueDate"></param>
        /// <returns>bool</returns>
        private static bool IsValidDosDateRange(string valueDate)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, IsValidDosDateRange Method with Param valueDate: " + valueDate);
                DateTime dt = Convert.ToDateTime(valueDate, CultureInfo.CurrentCulture);
                DateTime dtToday = DateTime.Now;
                int intValidYr = (dtToday.Year - 3);

                if (dt.Year < intValidYr)
                {
                    return false;
                }

                if (dt <= dtToday)
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, IsValidDosDateRange Method");
                    return Validation.IsValidDate(valueDate);
                }
                else
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, IsValidDosDateRange Method");
                    return false;
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// validation for check 129 year previous date && validate date
        /// </summary>
        /// <param name="valueDate"></param>
        /// <returns>bool</returns>
        private static bool IsValidDobDateRange(string valueDate)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, IsValidDobDateRange Method with Param valueDate: " + valueDate);
                DateTime dt = Convert.ToDateTime(valueDate, CultureInfo.CurrentCulture);
                DateTime dtToday = DateTime.Now;

                int intValidYr = (dtToday.Year - 129);

                if (dt.Year <= intValidYr)
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, IsValidDobDateRange Method");
                    return false;
                }

                if (dt <= dtToday)
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, IsValidDobDateRange Method");
                    return Validation.IsValidDate(valueDate);
                }
                else
                {
                    traceLog.AppendLine(" & End: ClaimInquiryController, IsValidDobDateRange Method");
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        #endregion

        #region
        /// <summary>
        /// To get Claim data
        /// </summary>
        /// <param name="claimNumber"></param>
        /// <returns></returns>
        [CheckAccess(Function = "Claims Inquiry")]
        
        public ActionResult GetClaimData(string claimNumber)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine(" Start: ClaimInquiryController, GetClaimData Method with param claimNumber:"+ claimNumber);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                claimNumber = Helper.AESEncrypt.DecryptStringAES(claimNumber);//"219-220-E-004499-002-00"; 219-220-E-025455-002-00
                string serviceinfo_clientAppEnv = ConfigurationManager.AppSettings[Constants.MCP_SRVINFO_CLIENTAPPENV];
                string serviceinfo_username = ((UserDetails)Session[Constants.UserDetails]).UserId; // ConfigurationManager.AppSettings[Constants.MCP_SRVINFO_USRNM];
                var ddr_env = ConfigurationManager.AppSettings[Constants.MCP_DDR_ENV] ?? "0";
                MCPS_DataBLL mcps_dataBll = new BLL.MCPS_DataBLL();
                var responsedate = mcps_dataBll.GetMCPS_Data(claimNumber, serviceinfo_clientAppEnv, serviceinfo_username, Int16.Parse(ddr_env));
                if (responsedate.Contains("REQUESTED BY:"))
                    responsedate = responsedate.Replace("REQUESTED BY:", "REQUESTED BY: "+((UserDetails)Session[Constants.UserDetails]).UserData.FirstName.ToUpper()+" " +((UserDetails)Session[Constants.UserDetails]).UserData.LastName.ToUpper());
                var workStream = mcps_dataBll.GetPdfStreamData(responsedate);
                var pswd = new SecureString();
                traceLog.AppendLine(" & End: ClaimInquiryController, GetClaimData Method");
                return new FileStreamResult(workStream, "application/pdf");
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion
    }
}