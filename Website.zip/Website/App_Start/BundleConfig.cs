﻿using System;
using System.Configuration;
using System.Web;
using System.Web.Optimization;

namespace NABWebsite
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            #region pre written
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                    "~/Scripts/jquery.validate*",
                    "~/Scripts/jquery.unobtrusive*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js"));

            bundles.Add(new ScriptBundle("~/bundles/angularjs").Include(
                  "~/Scripts/angular12.js",
                  "~/Scripts/angular-route12.js"
                  ));

            bundles.Add(new ScriptBundle("~/bundles/SemanticUIjs").Include(
                  "~/Scripts/dropdown.js",
                  "~/Scripts/transition.js"
                  ));
            bundles.Add(new StyleBundle("~/Content/SemanticUIcss").Include(
                      "~/Content/semantic.css"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/LeftRightPanelsPopover.css",
                      "~/Content/Site.css"));

            #endregion

            #region Layout

            bundles.Add(new ScriptBundle("~/bundles/LayoutIOEMenueJS").Include(
                     "~/Scripts/modernizr-*", "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery-ui-{version}.js", "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js", "~/Scripts/angular12.js",
                  "~/Scripts/angular-route12.js", "~/Scripts/bootstrapvalidator.min.js", "~/Scripts/CustomLibrary.js"));

            bundles.Add(new StyleBundle("~/Content/LayoutIOEMenueCSS").Include(
                     "~/Content/bootstrap.css", "~/Content/LeftRightPanelsPopover.css",
                      "~/Content/Site.css", "~/Content/bootstrapValidator.min.css"
                     ));

            bundles.Add(new ScriptBundle("~/bundles/LocateProviderLayoutJS").Include(
                      "~/Scripts/modernizr-*", "~/Scripts/jquery-{version}.js",
                       "~/Scripts/jquery-ui-{version}.js", "~/Scripts/bootstrap.js",
                     "~/Scripts/respond.js", "~/Scripts/angular12.js",
                 "~/Scripts/angular-route12.js", "~/Scripts/jquery.validate*",
                   "~/Scripts/jquery.unobtrusive*", "~/Scripts/bootstrapvalidator.min.js", 
                   "~/Scripts/CustomLibrary.js", "~/Scripts/bootstrap-multiselect.js",
                   "~/Scripts/jquery.ui.touch-punch.js"));

            bundles.Add(new StyleBundle("~/Content/LocateProviderLayoutCSS").Include(
               "~/Content/bootstrap.css",
                      "~/Content/LeftRightPanelsPopover.css",
                      "~/Content/Site.css","~/Content/bootstrapValidator.min.css","~/Content/jquery-ui.css",
                "~/Content/semantic.min.css","~/Content/multiselect-Css.css"
                    // "~/Content/bootstrap.css", "~/Content/LeftRightPanelsPopover.css",
                     // "~/Content/Site.css", "~/Content/bootstrapValidator.min.css",
                   //   "~/Content/semantic.min.css", "~/Content/multiselect-Css.css"
                     ));


            bundles.Add(new ScriptBundle("~/bundles/LocateProviderErrorLayoutJS").Include(
                       "~/Scripts/modernizr-*", "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery-ui-{version}.js", "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js", "~/Scripts/angular12.js",
                  "~/Scripts/angular-route12.js", "~/Scripts/jquery.validate*",
                    "~/Scripts/jquery.unobtrusive*", "~/Scripts/bootstrapvalidator.min.js", "~/Scripts/CustomLibrary.js",
                   "~/Scripts/bootstrap-multiselect.js"));

            bundles.Add(new StyleBundle("~/Content/LocateProviderErrorLayoutCSS").Include(
                     "~/Content/bootstrap.css", "~/Content/LeftRightPanelsPopover.css",
                      "~/Content/Site.css", "~/Content/bootstrapValidator.min.css",
                      "~/Content/jquery-ui.css", "~/Content/semantic.min.css", "~/Content/multiselect-Css.css"
                     ));


            bundles.Add(new ScriptBundle("~/bundles/LayoutFunctionsJS").Include(
                        "~/Scripts/modernizr-*", "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery-ui-{version}.js", "~/Scripts/bootstrap.js",
                        "~/Scripts/respond.js", "~/Scripts/angular12.js",
                        "~/Scripts/angular-route12.js", "~/Scripts/jquery.validate*",
                        "~/Scripts/jquery.unobtrusive*", "~/Scripts/bootstrapvalidator.min.js",
                        "~/Scripts/CustomLibrary.js", "~/Scripts/jquery-ui-1.11.4.min.js",
                        "~/Scripts/dropdown.min.js", "~/Scripts/transition.min.js"));

            bundles.Add(new StyleBundle("~/Content/LayoutFunctionsCSS").Include(
                     "~/Content/bootstrap.css", "~/Content/LeftRightPanelsPopover.css",
                     "~/Content/Site.css", "~/Content/bootstrapValidator.min.css",
                     "~/Content/jquery-ui.css", "~/Content/semantic.min.css"
                     ));


            bundles.Add(new ScriptBundle("~/bundles/LayoutProviderJS").Include(
                       "~/Scripts/modernizr-*", "~/Scripts/jquery-{version}.js",
                       "~/Scripts/jquery-ui-{version}.js", "~/Scripts/bootstrap.js",
                       "~/Scripts/respond.js", "~/Scripts/angular12.js",
                       "~/Scripts/angular-route12.js", "~/Scripts/jquery.validate*",
                       "~/Scripts/jquery.unobtrusive*", "~/Scripts/bootstrapvalidator.min.js",
                       "~/Scripts/CustomLibrary.js", "~/Scripts/jquery-ui-1.11.4.min.js",
                       "~/Scripts/dropdown.min.js", "~/Scripts/transition.min.js"));

            bundles.Add(new StyleBundle("~/Content/LayoutProviderCSS").Include(
                     "~/Content/bootstrap.css", "~/Content/LeftRightPanelsPopover.css",
                     "~/Content/Site.css", "~/Content/bootstrapValidator.min.css",
                     "~/Content/jquery-ui.css", "~/Content/semantic.min.css"
                     ));


            bundles.Add(new ScriptBundle("~/bundles/LayoutClaimActivityJS").Include(
                         "~/Scripts/modernizr-*", "~/Scripts/jquery-2.1.4.js",
                         "~/Scripts/bootstrap.js", "~/Scripts/CustomLibrary.js",
                         "~/Scripts/jquery-ui-1.11.4.js", "~/Scripts/bootstrapvalidator.min.js", "~/Scripts/Responsive.js"));

            bundles.Add(new StyleBundle("~/Content/LayoutClaimActivityCSS").Include(
                     "~/Content/bootstrap.css", "~/Content/LeftRightPanelsPopover.css",
                     "~/Content/Site.css", "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/jquery-ui.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/bootstrapValidator.min.css",
                     "~/Content/themes/base/datepicker.css", "~/Content/semantic.min.css", "~/Content/Responsive.css"
                     ));



            bundles.Add(new ScriptBundle("~/bundles/LayoutLoginJS").Include(
                          "~/Scripts/modernizr-*", "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery-ui-{version}.js", "~/Scripts/bootstrap.js",
                        "~/Scripts/respond.js", "~/Scripts/angular12.js",
                        "~/Scripts/angular-route12.js", "~/Scripts/jquery.validate*",
                        "~/Scripts/jquery.unobtrusive*", "~/Scripts/CustomLibrary.js", "~/Scripts/jquery-ui-1.11.4.min.js", 
                        "~/Scripts/aes.js"));
            bundles.Add(new ScriptBundle("~/bundles/AES").Include(
                         "~/Scripts/aes.js"));
            bundles.Add(new StyleBundle("~/Content/LayoutLoginCSS").Include(
                     "~/Content/bootstrap.css", "~/Content/LeftRightPanelsPopover.css",
                     "~/Content/Site.css", "~/Content/jquery-ui.css" 
                     ));

            #endregion

            #region Admin
            bundles.Add(new ScriptBundle("~/bundles/AdminPageEditorJS").Include(
                         "~/Scripts/jquery-{version}.js",
                         "~/Scripts/jquery-ui-{version}.js",
                         "~/Scripts/jquery.validate*",
                         "~/Scripts/jquery.unobtrusive*",
                         "~/scripts/jquery.cleditor.js",
                         "~/Scripts/modernizr-*",
                         "~/Scripts/bootstrap.js",
                         "~/Scripts/respond.js",
                         "~/Scripts/angular12.js",
                         "~/Scripts/angular-route12.js"));

            bundles.Add(new StyleBundle("~/Content/AdminPageEditorCSS").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/LeftRightPanelsPopover.css",
                      "~/Content/Site.css",
                      "~/Content/jquery.cleditor.css"));

            bundles.Add(new ScriptBundle("~/bundles/AdminUploadfileJS").Include(
                         "~/scripts/jquery-2.1.4.js"));
            #endregion

            #region static page bundles
            ///////////////////////Static Pages Bundles////////////////////////////////////////

            bundles.Add(new StyleBundle("~/Content/layoutCss").Include(
              "~/Content/bootstrapValidator.min.css"
            ));

            bundles.Add(new ScriptBundle("~/bundles/layoutJs").Include(
              "~/Scripts/bootstrapvalidator.min.js"
                 , "~/Scripts/CustomLibrary.js"
            ));
            #endregion

            #region Locate Provider Bundle
            ///////////////////////Locate Provider Bundles  ///////////////////////////////////
            
            //PanelStyleSheetCssBundle
            bundles.Add(new StyleBundle("~/Content/PanelStyleSheetCssBundle").Include(
              "~/Content/panelStyleSheet.css"
                      ));

            //bundles.Add(new StyleBundle("~/Content/locateProviderlayoutCss").Include(
            //          "~/Content/bootstrapValidator.min.css", "~/Content/jquery-ui.css",
            //          "~/Content/semantic.min.css", "~/Content/multiselect-Css.css", "~/Content/panelStyleSheet.css"
            //          ));
            bundles.Add(new StyleBundle("~/Content/IndexStylesCss").Include(
                      "~/Content/IndexStyles.css"
                      ));

            //bundles.Add(new ScriptBundle("~/bundles/locateProviderlayoutJs").Include(
            //      "~/Scripts/bootstrapvalidator.min.js", "~/Scripts/CustomLibrary.js", "~/Scripts/jquery.ui.touch-punch.js",
            //      "~/Scripts/bootstrap-multiselect.js"
            //      ));
            bundles.Add(new ScriptBundle("~/bundles/LocateProviderSelectNetworkTypeJs").Include(
                  "~/Scripts/LocateProviderSelectNetworkType.js"
                  ));
            bundles.Add(new ScriptBundle("~/bundles/CompareResultPageJs").Include(
                  "~/Scripts/CompareResultPage.js"
                  ));
            bundles.Add(new ScriptBundle("~/bundles/TaggedCompareResultPageJs").Include(
                  "~/Scripts/TaggedCompareResultPage.js"
                  ));
            bundles.Add(new ScriptBundle("~/bundles/CreateDirectoryPageJs").Include(
                  "~/Scripts/CreateDirectoryPage.js"
                  ));
            //bundles.Add(new ScriptBundle("~/bundles/LocateProviderSearchJs").Include(
            //      "~/Scripts/LocateProviderSearch.js", "~/Scripts/lodash.min.js", "~/Scripts/CustomDropdown.js"
            //      ));
            bundles.Add(new ScriptBundle("~/bundles/GetUserLocationJs").Include(
                  "~/Scripts/GetUserLocation.js"
                  ));
            bundles.Add(new ScriptBundle("~/bundles/LocateProviderSearchResultDesktopJs").Include(
                  "~/Scripts/LocateProviderSearchResultDesktop.js"
                  ));



            bundles.Add(new StyleBundle("~/Content/LocateProviderSearchCSS").Include(
                       "~/Content/panelStyleSheet.css","~/Content/CustomDropdown.css"
                      ));

            bundles.Add(new ScriptBundle("~/bundles/LocateProviderSearchJS").Include(
                  "~/Scripts/LocateProviderSearch.js", "~/Scripts/lodash.min.js", "~/Scripts/CustomDropdown.js"
                  ));

            //Added by NAB-IT on 02-May-18 for locate provider layout index
            #region optimize bundles
            //Css bundle for locate provider layout index
            bundles.Add(new StyleBundle("~/Content/LocateProviderLayoutIndexStyleBundle").Include(
                   "~/Content/bootstrap.css",
                      "~/Content/LeftRightPanelsPopover.css",
                      "~/Content/Site.css", "~/Content/bootstrapValidator.min.css", "~/Content/jquery-ui.css",
                      "~/Content/semantic.min.css", "~/Content/multiselect-Css.css", "~/Content/panelStyleSheet.css"
                 ));
            //Js bundle for locate provider layout index
            bundles.Add(new ScriptBundle("~/bundles/LocateProviderLayoutIndexScriptBundle").Include(
                  "~/Scripts/modernizr-*", "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery-ui-{version}.js", "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js", "~/Scripts/jquery.validate*",
                    "~/Scripts/jquery.unobtrusive*", "~/Scripts/bootstrapvalidator.min.js", "~/Scripts/CustomLibrary.js", "~/Scripts/jquery.ui.touch-punch.js",
                  "~/Scripts/bootstrap-multiselect.js"
                 ));
            //Js bundle for locate provider search result
            bundles.Add(new ScriptBundle("~/bundles/LocateProviderSearchResultScriptBundle").Include(
                 "~/Scripts/LocateProviderSearch.js", "~/Scripts/GetUserLocation.js", "~/Scripts/LocateProviderSearchResultDesktop.js"

                ));

            //Js bundle for left refine panel
            bundles.Add(new ScriptBundle("~/bundles/LocateProviderSearchResultLeftPanelScriptBundle").Include(
                 "~/Scripts/lodash.min.js", "~/Scripts/CustomDropdownRefined.js"
                ));

            //Js bundle for Create directory
            bundles.Add(new ScriptBundle("~/bundles/CreateDirectoryScriptBundle").Include(
                 "~/Scripts/CreateDirectoryPage.js", "~/Scripts/LocateProviderSearch.js",
                 "~/Scripts/jquery.validate.js", "~/Scripts/jquery.validate.unobtrusive.js"
                ));

            //Js bundle for provider search criteria (Mobile)
            bundles.Add(new ScriptBundle("~/bundles/ProviderSearchCriteriaMobileScriptBundle").Include(
                "~/Scripts/LocateProviderSearchMobile.js", "~/Scripts/GetUserZIPFromGeolocation.js"
               ));

            //Css bundle for locate provider error layout
            bundles.Add(new StyleBundle("~/Content/LocateProviderErrorLayoutStyleBundle").Include(
                  "~/Content/bootstrap.css", "~/Content/LeftRightPanelsPopover.css", "~/Content/Site.css", "~/Content/bootstrapValidator.min.css", "~/Content/jquery-ui.css", "~/Content/multiselect-Css.css"
                  ));

            //Js bundle for locate provider error layout
            bundles.Add(new ScriptBundle("~/bundles/LocateProviderLayoutIndexScriptBundle").Include(
                  "~/Scripts/modernizr-*", "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery-ui-{version}.js", "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js", "~/Scripts/jquery.validate*",
                    "~/Scripts/jquery.unobtrusive*", "~/Scripts/bootstrapvalidator.min.js", "~/Scripts/CustomLibrary.js", "~/Scripts/bootstrap-multiselect.js"
                 ));

            //Css bundle for layout
            bundles.Add(new StyleBundle("~/Content/LayoutStyleBundle").Include(
                 "~/Content/bootstrap.css",
                      "~/Content/LeftRightPanelsPopover.css",
                      "~/Content/Site.css", "~/Content/bootstrapValidator.min.css"
                ));

            //Js bundle for layout
            bundles.Add(new ScriptBundle("~/bundles/LayoutIndexScriptBundle").Include(
                  "~/Scripts/modernizr-*", "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery-ui-{version}.js", "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js", "~/Scripts/angular12.js",
                  "~/Scripts/angular-route12.js",
                      "~/Scripts/bootstrapvalidator.min.js"
                 , "~/Scripts/CustomLibrary.js"));

            //Css bundle for layout function
            bundles.Add(new StyleBundle("~/Content/LayoutFunctionStyleBundle").Include(
                 "~/Content/bootstrap.css",
                      "~/Content/LeftRightPanelsPopover.css",
                      "~/Content/Site.css", "~/Content/bootstrapValidator.min.css", "~/Content/jquery-ui.css"
                ));

            //Js bundle for layout function
            bundles.Add(new ScriptBundle("~/bundles/LayoutFunctionScriptBundle").Include(
                  "~/Scripts/modernizr-*", "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery-ui-{version}.js", "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js", "~/Scripts/jquery.validate*",
                    "~/Scripts/jquery.unobtrusive*", "~/Scripts/bootstrapvalidator.min.js", "~/Scripts/CustomLibrary.js", "~/Scripts/dropdown.min.js", "~/Scripts/transition.min.js"));

            #endregion

            #endregion

            #region Locate provider mobile bundle
            ///////////////////////Locate Provider Mobile Bundles////////////////////////////////////////

            bundles.Add(new StyleBundle("~/Content/ProviderSelectionStylesCss").Include(
              "~/Content/ProviderSelectionStyles.css", "~/Content/panelStyleSheet.css"
            ));
            bundles.Add(new StyleBundle("~/Content/ProviderSearchResultStyleCss").Include(
              "~/Content/ProviderSearchResultStyle.css", "~/Content/panelStyleSheet.css"
            ));
            bundles.Add(new StyleBundle("~/Content/SearchCriteriaStyleCss").Include(
              "~/Content/SearchCriteriaStyle.css", "~/Content/panelStyleSheet.css"
            ));
            bundles.Add(new StyleBundle("~/Content/MoreDetailsStyleCss").Include(
              "~/Content/MoreDetailsStyle.css"
            ));

            bundles.Add(new ScriptBundle("~/bundles/IndexPageMobileJs").Include(
                  "~/Scripts/IndexPageMobile.js"
                  ));
            bundles.Add(new ScriptBundle("~/bundles/ProviderTypeSelectionPageMobileJs").Include(
                  "~/Scripts/ProviderTypeSelectionPageMobile.js"
                  ));
            bundles.Add(new ScriptBundle("~/bundles/ProviderSearchResultPageMobileJs").Include(
                  "~/Scripts/ProviderSearchResultPageMobile.js"
                  ));
            bundles.Add(new ScriptBundle("~/bundles/GetUserZIPFromGeolocationJs").Include(
                  "~/Scripts/GetUserZIPFromGeolocation.js"
                  ));
            bundles.Add(new ScriptBundle("~/bundles/GetUserLocationForMobileJs").Include(
                  "~/Scripts/GetUserLocationForMobile.js"
                  ));
            bundles.Add(new ScriptBundle("~/bundles/LocateProviderSearchMobileJs").Include(
                  "~/Scripts/LocateProviderSearchMobile.js"
                  ));
            bundles.Add(new ScriptBundle("~/bundles/ProviderMoreDetailsPageMobileJs").Include(
                  "~/Scripts/ProviderMoreDetailsPageMobile.js"
                  ));
            #endregion

            #region Other bundles
            /////////////////////////////Other Bundles///////////////////////////////////////

            //bundles.Add(new StyleBundle("~/Content/LocateProviderErrorLayoutCss").Include(
            //  "~/Content/bootstrapValidator.min.css", "~/Content/jquery-ui.css", "~/Content/multiselect-Css.css"
            //));

            bundles.Add(new ScriptBundle("~/bundles/LocateProviderErrorLayoutJs").Include(
             "~/Scripts/bootstrapvalidator.min.js", "~/Scripts/CustomLibrary.js", "~/Scripts/bootstrap-multiselect.js"
            ));

            bundles.Add(new StyleBundle("~/Content/LayoutFunctionCss").Include(
               "~/Content/bootstrapValidator.min.css", "~/Content/jquery-ui.css"
             ));

            bundles.Add(new ScriptBundle("~/bundles/LayoutFunctionJs").Include(
              "~/Scripts/bootstrapvalidator.min.js", "~/Scripts/CustomLibrary.js", "~/Scripts/dropdown.min.js", "~/Scripts/transition.min.js"
             ));

            #endregion

            #region ClaimActivity
            bundles.Add(new StyleBundle("~/Content/ClaimActivity_SelectPayerPanelCSS").Include(
              "~/Content/themes/base/tooltip.css"
            ));

            bundles.Add(new StyleBundle("~/Content/ClaimActivityIndexCSS").Include(
             "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/Site.css", "~/Content/Responsive.css", "~/Content/themes/base/datepicker.css"
           ));

            bundles.Add(new ScriptBundle("~/bundles/ClaimActivityIndexJS").Include(
             "~/Scripts/Responsive.js", "~/Scripts/validation.js"
            ));

            bundles.Add(new StyleBundle("~/Content/ClaimActivitySavedCriteriaCSS").Include(
             "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css"
           ));


            #endregion

            #region ClaimAttachment
            bundles.Add(new StyleBundle("~/Content/ClaimAttachmentIndexCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/Responsive.css", "~/Content/layoutCss.css"
             ));

            bundles.Add(new ScriptBundle("~/bundles/ClaimAttachmentIndexJS").Include(
             "~/Scripts/Responsive.js"
            ));
            #endregion

            #region ClaimInquiry
            bundles.Add(new StyleBundle("~/Content/ClaimInquiry_PayerProcessedClaimCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/themes/base/datepicker.css"
             ));

            bundles.Add(new ScriptBundle("~/bundles/ClaimInquiry_PayerProcessedClaimCSS").Include(
             "~/Scripts/jquery-ui-1.11.4.js", "~/Scripts/validation.js"
            ));

            bundles.Add(new StyleBundle("~/Content/ClaimInquiry_ProcessedClaimCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/themes/base/datepicker.css"
             ));

            bundles.Add(new ScriptBundle("~/bundles/ClaimInquiry_ProcessedClaimCSS").Include(
             "~/Scripts/jquery-ui-1.11.4.js", "~/Scripts/validation.js"
            ));

            bundles.Add(new StyleBundle("~/Content/ClaimInquiry_RejectedClaimCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/themes/base/datepicker.css"
             ));

            bundles.Add(new StyleBundle("~/Content/ClaimInquiryCSS").Include(
                "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/themes/base/datepicker.css"
              ));

            bundles.Add(new ScriptBundle("~/bundles/ClaimInquiryJS").Include(
              "~/Scripts/validation.js"
             ));

            #endregion

            #region ekit
            bundles.Add(new StyleBundle("~/Content/ekitClaimKeyInitialCSS").Include(
                "~/Content/e-kit.css", "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/themes/base/datepicker.css"
              ));

            bundles.Add(new ScriptBundle("~/bundles/ekitClaimKeyInitialJS").Include(
              "~/Scripts/jquery-ui-1.11.4.js", "~/Scripts/jquery-2.1.4.js", "~/Scripts/jquery-ui-1.11.4.js", "~/Scripts/JqueryMasking.js"
             ));

            bundles.Add(new StyleBundle("~/Content/ekitCMSEkitCSS").Include(
                           "~/Content/e-kit.css", "~/Content/grid-0.4.3.css", "~/Content/e-kit.css", "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/themes/base/datepicker.css"
                         ));

            bundles.Add(new ScriptBundle("~/bundles/ekitCMSEkitJS").Include(
              "~/Scripts/jquery-ui-1.11.4.js", "~/Scripts/jquery-2.1.4.js", "~/Scripts/jquery-ui-1.11.4.js", "~/Scripts/grid-0.4.3.min.js", "~/Scripts/Dropzone.js", "~/Scripts/shortcut.js", "~/Scripts/JqueryMasking.js"
             ));
            #endregion

            #region FacilityRateSummary
            bundles.Add(new StyleBundle("~/Content/FacilityRateSummaryCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/Site.css", "~/Content/Responsive.css"
             ));

            bundles.Add(new ScriptBundle("~/bundles/FacilityRateSummaryJS").Include(
              "~/Scripts/Responsive.js"
             ));

            #endregion

            #region Home
            bundles.Add(new ScriptBundle("~/bundles/HomeNewSiteMapJS").Include(
              "~/Scripts/jquery.treeview.js"
             ));
            #endregion

            #region MemberInquiry
            bundles.Add(new ScriptBundle("~/bundles/MemberInquiryJS").Include(
              "~/Scripts/validation.js"
             ));

            bundles.Add(new ScriptBundle("~/bundles/MemberInquiryIndexJS").Include(
             "~/Scripts/validation.js", "~/Scripts/Responsive.js"
            ));

            bundles.Add(new StyleBundle("~/Content/MemberInquiryCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/Site.css", "~/Content/Responsive.css", "~/Content/themes/base/datepicker.css"
             ));
            #endregion

            #region MyProfile
            bundles.Add(new StyleBundle("~/Content/MyProfileIndexCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css"
             ));
            #endregion

            #region ProviderDataVerification
            bundles.Add(new StyleBundle("~/Content/ProviderDataVerificationCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/Responsive.css"
             ));

            bundles.Add(new ScriptBundle("~/bundles/ProviderDataVerificationJS").Include(
             "~/Scripts/Responsive.js"
            ));
            
            #endregion

            #region ProviderFileDownload
            bundles.Add(new StyleBundle("~/Content/ProviderFileDownloadCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/Responsive.css", "~/Content/themes/base/datepicker.css"
             ));

            bundles.Add(new ScriptBundle("~/bundles/ProviderFileDownloadJS").Include(
             "~/Scripts/Responsive.js"
            ));
            #endregion

            #region ProviderTinLookup
            bundles.Add(new StyleBundle("~/Content/ProviderTinLookupCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/Responsive.css"
             ));

            bundles.Add(new ScriptBundle("~/bundles/ProviderTinLookupJS").Include(
             "~/Scripts/Responsive.js", "~/Scripts/validation.js"
            ));
            #endregion

            #region SecureEmail
            bundles.Add(new StyleBundle("~/Content/SecureEmailCSS").Include(
               "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/Responsive.css"
             ));

            bundles.Add(new ScriptBundle("~/bundles/SecureEmailJS").Include(
             "~/Scripts/Responsive.js"
            ));
            #endregion

            #region Transplant
            bundles.Add(new StyleBundle("~/Content/TransplantClientSpecificAllReportsCSS").Include(
              "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/Site.css", "~/Content/Responsive.css",
              "~/Content/bootstrap.css"
            ));

            bundles.Add(new ScriptBundle("~/bundles/TransplantClientSpecificAllReportsJS").Include(
             "~/Scripts/Responsive.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/TransplantMapJS").Include(
            "~/Scripts/bootstrap.min.js"
           ));

            bundles.Add(new ScriptBundle("~/bundles/TransplantOnlineTransplantFormJS").Include(
            "~/Scripts/bootstrap.min.js"
           ));
            bundles.Add(new ScriptBundle("~/bundles/TransplantViewReportsJS").Include(
            "~/Scripts/jquery-ui-1.11.4.js", "~/Scripts/Responsive.js"
           ));

            bundles.Add(new ScriptBundle("~/Content/TransplantViewReportsCSS").Include(
             "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css", "~/Content/Site.css", "~/Content/Responsive.css"
           ));
            #endregion

            #region UserAccessVerification
            bundles.Add(new ScriptBundle("~/bundles/UserAccessVerificationUserSearchJS").Include(
            "~/Scripts/Responsive.js"
          ));

            bundles.Add(new ScriptBundle("~/Content/UserAccessVerificationUserSearchCSS").Include(
            "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css", "~/Content/Responsive.css"
           ));
            #endregion 



            #region  Claim Appeal Form           
            bundles.Add(new StyleBundle("~/Content/ClaimAppealFormCSS").Include(
                                "~/Content/theme/base/core.css",                
                "~/Content/theme/base/autocomplete.css",
                "~/Content/theme/base/button.css",
                "~/Content/theme/base/dialog.css",
                "~/Content/theme/base/draggable.css",
                "~/Content/theme/base/menu.css",
                "~/Content/theme/base/resizable.css",
                "~/Content/theme/base/selectable.css",
                "~/Content/theme/base/selectmenu.css",
                "~/Content/theme/base/sortable.css",
                "~/Content/theme/base/slider.css",
                "~/Content/theme/base/spinner.css",
                "~/Content/theme/base/tabs.css",
                "~/Content/theme/base/tooltip.css",
                "~/Content/theme/base/theme.css"
                              ));

            bundles.Add(new ScriptBundle("~/bundles/ClaimAppealFormJS").Include(
                 "~/Scripts/jquery.unobtrusive*",
                    "~/Scripts/jquery.validate*"));

            #endregion

            #region  Demographic update Form
            bundles.Add(new StyleBundle("~/Content/DemographicUpdateFormCSS").Include(
                 "~/Content/theme/base/core.css",
                "~/Content/theme/base/accordion.css",
"~/Content/theme/base/autocomplete.css",
"~/Content/theme/base/button.css",
"~/Content/theme/base/datepicker.css",
"~/Content/theme/base/dialog.css",
"~/Content/theme/base/draggable.css",
"~/Content/theme/base/menu.css",
"~/Content/theme/base/progressbar.css",
"~/Content/theme/base/resizable.css",
"~/Content/theme/base/selectable.css",
"~/Content/theme/base/selectmenu.css",
"~/Content/theme/base/sortable.css",
"~/Content/theme/base/slider.css",
"~/Content/theme/base/spinner.css",
"~/Content/theme/base/tabs.css",
"~/Content/theme/base/tooltip.css",
"~/Content/theme/base/theme.css", "~/Content/themes/base/datepicker.css"
              ));

            bundles.Add(new ScriptBundle("~/bundles/DemographicUpdateFormJS").Include(
                "~/Scripts/jquery.unobtrusive*",
                    "~/Scripts/jquery.validate*"));

            #endregion

            BundleTable.EnableOptimizations = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableBundleOptimizations"]);
        }
    }
}
