﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;

namespace NABWebsite.Models
{
    //ViewModel for "User Access Verification"
    public class UserVerification
    {
        public UserAccessVerification UserAccess { get; set; }
        public IEnumerable<UserClass> UsersModel { get; set; }
        public string Indexes { get; set; }
        public string SelectedChange { get; set; }
        public IEnumerable<UserAccessDetail> QueueData { get; set; }
    }
}