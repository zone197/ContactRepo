﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models;
using System.IO;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System.Configuration;
using NABWebsite.Helper;

namespace NABWebsite.Controllers
{
    public class ClaimAppealController : Controller
    {
        private const string CONST_SUCCESS = "Success";
        // GET: ClaimAppeal
        public ActionResult Index()
        {
            try
            {
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ClaimAppealHeader;

                ClaimInquiryBL claimInquiryBL = new ClaimInquiryBL();
                ClaimAppealForm ModelClaimAppealForm = new ClaimAppealForm();
                var claimAppealReasonsList = claimInquiryBL.GetClaimAppealReasons();

                var selectList = new List<SelectListItem>();

                foreach (var element in claimAppealReasonsList)
                {
                    selectList.Add(new SelectListItem
                    {
                        Value = element.AppealDescription,
                        Text = element.AppealDescription
                    });
                }
                ModelClaimAppealForm.lstClaimAppealReasons = selectList;

                return View(ModelClaimAppealForm);
            }
            catch (Exception e)
            {
                throw;
            }

        }
        [HttpPost]
        public ActionResult ClaimAppeal(ClaimAppealForm formDetails)
        {
            try
            {
                ClaimAppealForm details = new ClaimAppealForm();
                string body = string.Empty;
                Boolean success;
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ClaimAppealHeader;
                using (StreamReader reader = new StreamReader(Server.MapPath("~/Views/ClaimAppeal/EmailTemplate.html")))
                {
                    body = reader.ReadToEnd();
                }

                body = body.Replace("{ClaimNum}", formDetails.ClaimNum);
                if (formDetails.ReasonForAppealDesc == "Other")
                    body = body.Replace("{ReasonForAppeal}", formDetails.OtherReasonForAppealDesc);
                else
                    body = body.Replace("{ReasonForAppeal}", formDetails.ReasonForAppealDesc);
                body = body.Replace("{ExpectedAmt}", formDetails.ExpectedAmt);
                body = body.Replace("{AttempForClaim}", formDetails.AttempForClaim.ToString());

                body = body.Replace("{ReferenceNumId}", string.IsNullOrEmpty(formDetails.ReferenceNum) ? "N/A" : formDetails.ReferenceNum);
                body = body.Replace("{AdditionalDetails}", string.IsNullOrEmpty(formDetails.AdditionalDetails) ? "N/A" : formDetails.AdditionalDetails);
                body = body.Replace("{ContactName}", formDetails.ContactName);
                body = body.Replace("{ContactNum}", string.IsNullOrEmpty(formDetails.ContactNum) ? "N/A" : formDetails.ContactNum);
                body = body.Replace("{ContactEmail}", string.IsNullOrEmpty(formDetails.ContactEmail) ? "N/A" : formDetails.ContactEmail);

                if (ModelState.IsValid)
                {
                    ManageContent contentManager = new ManageContent();
                    string[] emailAddresses;
                    var email = "";
                    email = ConfigurationManager.AppSettings["FromClaimAppealFormInfo"];
                    List<string> emailAddressesList = new List<string>();
                    if (!string.IsNullOrEmpty(email)) emailAddressesList.Add(email);
                    decimal totalAttachedFileSize = 0;
                    emailAddresses = emailAddressesList.ToArray();

                    if (!(formDetails.Files.Contains(null)))
                    {
                        ClaimInquiryBL claimInquiryBL = new ClaimInquiryBL();
                        var claimAppealReasonsList = claimInquiryBL.GetClaimAppealReasons();
                        var selectList = new List<SelectListItem>();
                        foreach (var element in claimAppealReasonsList)
                        {
                            selectList.Add(new SelectListItem
                            {
                                Value = element.AppealDescription,
                                Text = element.AppealDescription
                            });
                        }
                        formDetails.lstClaimAppealReasons = selectList;
                        foreach (var filesList in formDetails.Files)
                        {
                            if (filesList.ContentType.Contains("pdf"))
                            {
                                if (formDetails.Files.Length <= Convert.ToInt32(ConfigurationManager.AppSettings["MaxPDFCountForClaimAppeal"] == null ? Constants.MaxPDFCountForClaimAppeal : ConfigurationManager.AppSettings["MaxPDFCountForClaimAppeal"]))
                                {
                                    totalAttachedFileSize += filesList.ContentLength;
                                }
                                else
                                {
                                    ModelState.AddModelError("Files", "You cannot attach more than " + (System.Configuration.ConfigurationManager.AppSettings["MaxPDFCountForClaimAppeal"] == null ? Constants.MaxPDFCountForClaimAppeal : System.Configuration.ConfigurationManager.AppSettings["MaxPDFCountForClaimAppeal"]) + " PDFs");
                                    return View("Index", formDetails);
                                }
                            }
                            else
                            {
                                ModelState.AddModelError("Files", "Please upload document in pdf format only");
                                return View("Index", formDetails);
                            }
                        }
                        totalAttachedFileSize = ((totalAttachedFileSize / 1024) / 1024);
                        if (totalAttachedFileSize > Convert.ToInt32(ConfigurationManager.AppSettings["MaxPDFAttachedSizeForClaimAppeal"] == null ? Constants.MaxPDFAttachedSizeForClaimAppeal : ConfigurationManager.AppSettings["MaxPDFAttachedSizeForClaimAppeal"]))
                        {
                            ModelState.AddModelError("Files", "Total attached file size should be less than " + (System.Configuration.ConfigurationManager.AppSettings["MaxPDFAttachedSizeForClaimAppeal"] == null ? Constants.MaxPDFAttachedSizeForClaimAppeal : System.Configuration.ConfigurationManager.AppSettings["MaxPDFAttachedSizeForClaimAppeal"]) + " MB");
                            return View("Index", formDetails);
                        }

                        Dictionary<string, byte[]> _fileDetail = new Dictionary<string, byte[]>();
                        string FileName = "";
                        byte[] binData = null;
                        foreach (var filesList in formDetails.Files)
                        {
                            FileName = Path.GetFileName(filesList.FileName);
                            //Improper Resource Shutdown or release Security Vulnerability issue fix on 14-Mar-2019
                            using (BinaryReader b = new BinaryReader(filesList.InputStream))
                            {
                                try
                                {
                                    binData = b.ReadBytes(filesList.ContentLength);
                                }
                                catch (Exception)
                                {
                                    throw;
                                }
                                finally
                                {
                                    if (b != null)
                                    {
                                        b.Close();
                                        b.Dispose();
                                    }
                                }
                            }

                            _fileDetail.Add(FileName, binData);
                        }
                        success = contentManager.SendMailClaimAppealFormInfo(body, emailAddresses, VariableConstant.ClaimAppealFormInfoSubject, formDetails.concatRequest, _fileDetail);
                    }
                    else
                    {
                        success = contentManager.SendMailClaimAppealFormInfo(body, emailAddresses, VariableConstant.ClaimAppealFormInfoSubject, formDetails.concatRequest);
                    }
                    if (success == true)
                    {
                        formDetails.Status = "true";

                        return Content("<script type='text/javascript'>alert('Your form has been submitted.');window.location.href='/ClaimAppeal/Index';</script>");
                    }
                    else
                    {
                        formDetails.Status = "false";
                        return Content("<script type='text/javascript'>alert('Your form cannot be submitted due to an error.');window.location.href='/ClaimAppeal/Index';</script>");
                    }
                }
                else
                {
                    return View("Index");
                }

            }
            catch (Exception e)
            {
                throw;
            }
        }





    }
}