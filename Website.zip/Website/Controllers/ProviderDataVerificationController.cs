﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using NABWebsite.Models;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System.Net;
using System.Text;
using System.Net.Mail;
using System.Configuration;
using NABWebsite.Helper;
using System.Web.Security.AntiXss;
using Utilities;

namespace NABWebsite.Controllers
{
    public class ProviderDataVerificationController : Controller
    {

        private string state = string.Empty;
        /// <summary>
        /// Home page for Provider data verification
        /// </summary>
        /// <param name="providerVerification"></param>
        /// <returns>ActionResult</returns>
        [CheckAccess(Function = "Provider Data Verification")]
        public ActionResult Index(ProviderDataVerificationModel providerVerification)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, Index Method with Param providerVerification: " + providerVerification);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ProviderDataVerificationController, Index Method");
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ProviderDataVerificationHead;
                Access access = new Access();

                if (((UserDetails)Session[Constants.UserDetails]).UserId != null && ((UserDetails)Session[Constants.UserDetails]).SelectedRole != null && ConfigurationManager.AppSettings[Constants.Site] != null)
                {
                    List<string> networkList = new List<string>();
                    access.User = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    access.Role = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                    access.UserType = ConfigurationManager.AppSettings[Constants.Site];
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                    {
                        access.IsEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                    }
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                                    && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                                    && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                    {
                        //get selected role
                        Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                        //get the network for selcted function
                        networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuProviderDataVerification, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                    }

                    if (networkList != null)
                    {
                        access.Network = string.Join(",", networkList);
                    }
                    if (providerVerification != null)
                    {
                        ProviderDataVerification objectProviderDataVerification = new ProviderDataVerification();
                        ProviderVerification objBll = new ProviderVerification();
                        providerVerification.AccessDetails = access;
                        if (providerVerification.ProviderModel == null)
                        {
                            providerVerification.ProviderModel = objectProviderDataVerification;
                        }
                        string alphaConfig = AppSettingHelper.GetAppSettingValue(Constants.ProviderAlphabets);
                        string[] alphaConfigArray = alphaConfig.Split(',');
                        List<string> alphatest = alphaConfigArray.ToList();

                        if (providerVerification.ProviderModel.Parameter == null || providerVerification.ProviderModel.Parameter == "View")
                        {
                            if (providerVerification.ProviderModel.PageNo == Constants.PageZero)
                            {
                                providerVerification.ProviderModel.PageNo = Constants.PageOne;
                                providerVerification.ProviderModel.SortBy = Constants.ProviderName;
                                providerVerification.ProviderModel.SortType = Constants.AscendingText;
                            }

                            providerVerification.ProviderModel = objBll.GetProviderVerificationDetails(providerVerification.ProviderModel, providerVerification.AccessDetails);
                            if (providerVerification.ProviderModel.FirstLetter.Count() > 0)
                            {
                                providerVerification.ProviderModel.Parameter = Constants.View;
                            }
                        }

                        else if (providerVerification.ProviderModel.Parameter.Length == Constants.PageOne)
                        {
                            providerVerification.ProviderModel = objBll.GetProviderVerificationDetailsByAlphabet(providerVerification.ProviderModel, providerVerification.ProviderModel.Parameter, providerVerification.AccessDetails);

                        }
                        providerVerification.ProviderModel.Alpha = alphatest;
                    }
                }
                else
                {
                    traceLog.AppendLine(" & End: ProviderDataVerificationController, Index Method");
                    return RedirectToAction("Index", "Home");
                }
                traceLog.AppendLine(" & End: ProviderDataVerificationController, Index Method");
                return View("Index", providerVerification);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// Fetch Detailed view for a Provider
        /// </summary>
        /// <param name="submitButtonError"></param>
        /// <returns></returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Provider Data Verification")]
        [HttpPost]
        public ActionResult TabView(string provider)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, TabView Method with Param provider: " + provider);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ProviderDataVerificationController, TabView Method");
                    return RedirectToAction("Index", "Home");
                }
                string[] ProviderDetails = new string[7];
                if (!string.IsNullOrEmpty(provider))
                {
                    ProviderDetails = provider.Split(new char[] { '~' });
                }
                string network = string.Empty;
                if (!string.IsNullOrEmpty(ProviderDetails[0]) && ProviderDetails[0].Equals(Constants.Edit))
                {
                    string providerNumber = !string.IsNullOrEmpty(ProviderDetails[1]) ? ProviderDetails[1] : string.Empty;
                    string providerLocationId = !string.IsNullOrEmpty(ProviderDetails[2]) ? ProviderDetails[2] : string.Empty;
                    string providerTin = !string.IsNullOrEmpty(ProviderDetails[3]) ? ProviderDetails[3] : string.Empty;
                    string providerNpi = !string.IsNullOrEmpty(ProviderDetails[4]) ? ProviderDetails[4] : string.Empty;
                    string providerName = !string.IsNullOrEmpty(ProviderDetails[5]) ? ProviderDetails[5] : string.Empty;
                    network = !string.IsNullOrEmpty(ProviderDetails[6]) ? ProviderDetails[6] : string.Empty;

                    ProviderVerification objBll = new ProviderVerification();
                    ProviderDataVerification entityObject = new ProviderDataVerification();
                    ProviderDataVerificationModel modelObject = new ProviderDataVerificationModel();
                    Access access = new Access();
                    access.User = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    access.Role = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                    access.UserType = ConfigurationManager.AppSettings[Constants.Site];
                    entityObject.AccessDetails = access;
                    entityObject = objBll.SearchProvider(providerNumber, providerLocationId, providerTin, providerNpi, providerName, entityObject, network, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                    entityObject.AllStates = GetAllStates();
                    entityObject.Provider.MorningTime = FetchMorningTime();
                    entityObject.Provider.AfternoonTime = FetchMorningTime();
                    entityObject.State = Constants.SelectState;
                    if (entityObject.AddressList.Count() == 0)
                    {
                        ProviderAddressModel initObj = new ProviderAddressModel();
                        List<ProviderAddressModel> linkObj = new List<ProviderAddressModel>();
                        initObj.Allstate = GetAllStates();
                        initObj.AllCity = new List<SelectListItem>() { new SelectListItem() { Text = Constants.SelectCity, Value = Constants.SelectCity } };
                        initObj.AllCounty = new List<SelectListItem>() { new SelectListItem() { Text = Constants.SelectCounty, Value = Constants.SelectCounty } };
                        linkObj.Add(initObj);
                        entityObject.AddressList = linkObj.ToList();
                    }

                    if (entityObject.Bill != null)
                    {
                        entityObject.Bill.Allstate = GetAllStates();
                        entityObject.Bill.AllCity = GetAllCityByState(entityObject.Bill.State);
                    }
                    else
                    {
                        entityObject.Bill = new BillingCompany();
                        entityObject.Bill.Allstate = GetAllStates();
                        entityObject.Bill.AllCity = GetAllCityByState(entityObject.Bill.Allstate.ElementAt(0).Text);
                    }

                    entityObject.AllSpecList = GetAllSpecialties(network);
                    modelObject.ProviderModel = entityObject;

                    string tempPhoString = "";
                    string tempCorrespondenceString = "";
                    string tempPaymentString = "";
                    string tempServiceString = "";
                    string tempTimingString = "";
                    int count = modelObject.ProviderModel.AddressList.Count();
                    for (int i = 0; i < count; i++)
                    {
                        List<string> tempPho = new List<string>();
                        tempPho = modelObject.ProviderModel.PhoList.Where(x => x.ProviderLocationId == modelObject.ProviderModel.AddressList.ElementAt(i).ProviderLocationId).Select(x => x.Pho).ToList();
                        tempPhoString += modelObject.ProviderModel.AddressList.ElementAt(i).ProviderLocationId + "~" + modelObject.ProviderModel.AddressList.ElementAt(i).ProviderAddress + "|";
                        if (tempPho.Count != 0)
                        {
                            foreach (var pho in tempPho)
                            {
                                tempPhoString += pho + "~";
                            }
                        }
                        else
                        {
                            tempPhoString += "~";
                        }
                        tempPhoString += "||";

                        CorrespondenceAddress tempCorrespondence = new CorrespondenceAddress();
                        tempCorrespondence = modelObject.ProviderModel.CorrectAddress.Where(x => x.ProviderLocationId == modelObject.ProviderModel.AddressList.ElementAt(i).ProviderLocationId).Select(x => x).FirstOrDefault();
                        tempCorrespondenceString += modelObject.ProviderModel.AddressList.ElementAt(i).ProviderLocationId + "~" + modelObject.ProviderModel.AddressList.ElementAt(i).ProviderAddress + "|";
                        if (tempCorrespondence != null)
                        {
                            tempCorrespondenceString += tempCorrespondence.Address1 + "~" + tempCorrespondence.Address2 + "~" + tempCorrespondence.State + "~" + tempCorrespondence.City + "~" + tempCorrespondence.ZipCode;
                        }
                        else
                        {
                            tempCorrespondenceString += "~" + "~" + "~" + "~";
                        }
                        tempCorrespondenceString += "||";

                        PaymentAddress tempPayment = new PaymentAddress();
                        tempPayment = modelObject.ProviderModel.Payment.Where(x => x.ProviderLocationId == modelObject.ProviderModel.AddressList.ElementAt(i).ProviderLocationId).Select(x => x).FirstOrDefault();
                        tempPaymentString += modelObject.ProviderModel.AddressList.ElementAt(i).ProviderLocationId + "~" + modelObject.ProviderModel.AddressList.ElementAt(i).ProviderAddress + "|";
                        if (tempCorrespondence != null)
                        {
                            tempPaymentString += tempPayment.Address1 + "~" + tempPayment.Address2 + "~" + tempPayment.State + "~" + tempPayment.City + "~" + tempPayment.ZipCode;
                        }
                        else
                        {
                            tempPaymentString += "~" + "~" + "~" + "~";
                        }
                        tempPaymentString += "||";

                        ProviderAddressModel tempService = new ProviderAddressModel();
                        tempService = modelObject.ProviderModel.AddressList.Where(x => x.ProviderLocationId == modelObject.ProviderModel.AddressList.ElementAt(i).ProviderLocationId).Select(x => x).FirstOrDefault();
                        tempServiceString += modelObject.ProviderModel.AddressList.ElementAt(i).ProviderLocationId + "~" + modelObject.ProviderModel.AddressList.ElementAt(i).ProviderAddress + "|";
                        if (tempService != null)
                        {
                            tempServiceString += tempService.Address1 + "~" + tempService.Address2 + "~" + tempService.State
                        + "~" + tempService.County + "~" + tempService.City + "~" + tempService.ZipCode + "~" + tempService.Phone
                        + "~" + tempService.Extension + "~" + tempService.Fax + "~" + tempService.TollFree
                        + "~" + tempService.Email + "~" + tempService.Web + "~" + tempService.ElectronicBiller
                        + "~" + tempService.IsAccepting + "~" + tempService.IsListed;
                        }
                        else
                        {
                            tempServiceString += "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~";
                        }
                        tempServiceString += "||";

                        OfficeHours tempTiming = new OfficeHours();
                        tempTiming = modelObject.ProviderModel.Timing.Where(x => x.ProviderLocationId == modelObject.ProviderModel.AddressList.ElementAt(i).ProviderLocationId).Select(x => x).FirstOrDefault();
                        tempTimingString += modelObject.ProviderModel.AddressList.ElementAt(i).ProviderLocationId + "~" + modelObject.ProviderModel.AddressList.ElementAt(i).ProviderAddress + "|";
                        if (tempTiming != null)
                        {
                            tempTimingString += tempTiming.MOpeningMon + "~" + tempTiming.MClosingMon + "~" + tempTiming.AFOpeningMon + "~" + tempTiming.AFClosingMon
                                + "~" + tempTiming.MOpeningTue + "~" + tempTiming.MClosingTue + "~" + tempTiming.AFOpeningTue + "~" + tempTiming.AFClosingTue
                                + "~" + tempTiming.MOpeningWed + "~" + tempTiming.MClosingWed + "~" + tempTiming.AFOpeningWed + "~" + tempTiming.AFClosingWed
                                + "~" + tempTiming.MOpeningThursday + "~" + tempTiming.MClosingThursday + "~" + tempTiming.AFOpeningThursday + "~" + tempTiming.AFClosingThursday
                                + "~" + tempTiming.MOpeningFri + "~" + tempTiming.MClosingFri + "~" + tempTiming.AFOpeningFri + "~" + tempTiming.AFClosingFri
                                + "~" + tempTiming.MOpeningSat + "~" + tempTiming.MClosingSat + "~" + tempTiming.AFOpeningSat + "~" + tempTiming.AFClosingSat
                                + "~" + tempTiming.MOpeningSun + "~" + tempTiming.MClosingSun + "~" + tempTiming.AFOpeningSun + "~" + tempTiming.AFClosingSun;
                        }
                        else
                        {
                            tempTimingString += "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" +
                                "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~" + "~";
                        }
                        tempTimingString += "||";
                    }
                    modelObject.AllLocationPho = tempPhoString;
                    modelObject.AllLocationCorrespondence = tempCorrespondenceString;
                    modelObject.AllLocationPayment = tempPaymentString;
                    modelObject.AllLocationTiming = tempTimingString;
                    modelObject.AllLocationService = tempServiceString;
                    traceLog.AppendLine(" & End: ProviderDataVerificationController, TabView Method");
                    return View("TabView", modelObject);
                }
                else
                {
                    traceLog.AppendLine(" & End: ProviderDataVerificationController, TabView Method");
                    return View("Error");
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Show the change details page
        /// </summary>
        /// <param name="form"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        [CheckAccess(Function = "Provider Data Verification")]
        [HttpPost]
        public ActionResult ShowUpdatedChanges(FormCollection form)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, ShowUpdatedChanges Method with Param form: " + form);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ProviderDataVerificationController, ShowUpdatedChanges Method");
                    return RedirectToAction("Index", "Home");
                }
                string changes = string.Empty;

                if (form != null)
                {
                    changes = WebUtility.HtmlDecode(form[Constants.Change]);

                    Session[Constants.ChangeList] = changes;

                    var myModel = new Update
                    {
                        ChangeList = changes,
                        ProviderName = WebUtility.HtmlDecode(form[Constants.ProviderNameShort]),
                        ProviderNPI = WebUtility.HtmlDecode(form[Constants.ProviderNPI]),
                        ProviderTin = WebUtility.HtmlDecode(form[Constants.ProviderTIN])
                    };
                    traceLog.AppendLine(" & End: ProviderDataVerificationController, ShowUpdatedChanges Method");
                    return View(myModel);
                }
                traceLog.AppendLine(" & End: ProviderDataVerificationController, ShowUpdatedChanges Method");
                return null;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch all the specialties
        /// </summary>
        /// <returns>IEnumerable<SelectListItem></returns>
        private IEnumerable<SelectListItem> GetAllSpecialties(string network)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetAllSpecialties Method with Param network: " + network);
                ProviderVerification objProvider = new ProviderVerification();
                List<SelectListItem> specialties = new List<SelectListItem>();
                SelectListItem startObject = new SelectListItem() { Text = Constants.SelectSpecialty, Value = Constants.SelectSpecialty };
                specialties.Add(startObject);
                specialties.AddRange(objProvider.GetAllSpecialties(network, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()).Select(x => new SelectListItem { Text = x.SpecialtyName, Value = x.SpecialtyName }).ToList());
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetAllSpecialties Method");
                return specialties;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// Fetch all states
        /// </summary>
        /// <returns>IEnumerable<SelectListItem></returns>
        private IEnumerable<SelectListItem> GetAllStates()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetAllStates Method");
                ProviderVerification objProvider = new ProviderVerification();
                List<SelectListItem> state1 = new List<SelectListItem>();
                SelectListItem startObject = new SelectListItem() { Text = Constants.SelectState, Value = Constants.SelectState };
                state1.Add(startObject);
                state1.AddRange(objProvider.FetchAllStates(Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()).Select(x => new SelectListItem { Text = x.StateName, Value = x.StateCode }).ToList());
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetAllStates Method");
                return state1;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch all county by state
        /// </summary>
        /// <param name="state"></param>
        /// <returns>IEnumerable<SelectListItem></returns>
        public IEnumerable<SelectListItem> GetAllCountyByState(string stateValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetAllCountyByState Method with Param stateValue: " + stateValue);
                stateValue = AntiXssEncoder.HtmlEncode(stateValue, true);//Added on 17-Jul-18 to fix Reflected XSS
                this.state = stateValue;
                ProviderVerification objProvider = new ProviderVerification();
                List<SelectListItem> county = new List<SelectListItem>();
                SelectListItem startObject = new SelectListItem() { Text = Constants.SelectCounty, Value = Constants.SelectCounty };
                county.Add(startObject);
                county.AddRange(objProvider.GetAllCountyByState(state, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()).Select(x => new SelectListItem { Text = x.CountyName, Value = x.CountyName }).ToList());
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetAllCountyByState Method");
                return county;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch zip by city
        /// </summary>
        /// <param name="city"></param>
        /// <returns>string</returns>
        private string GetZipByCity(string city, string state, string county)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetZipByCity Method with Param city: " + city + "and with Param state: " + state + "and with Param county: " + county);
                ProviderVerification provider = new ProviderVerification();
                if (!string.IsNullOrEmpty(city) && ((UserDetails)Session[Constants.UserDetails]).UserId != null)
                {
                    traceLog.AppendLine(" & End: ProviderDataVerificationController, GetZipByCity Method");
                    return provider.GetZipByCity(city, ((UserDetails)Session[Constants.UserDetails]).UserId, state, county);
                }
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetZipByCity Method");
                return string.Empty;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch all city by state
        /// </summary>
        /// <param name="state"></param>
        /// <returns>IEnumerable<SelectListItem></returns>
        public IEnumerable<SelectListItem> GetAllCityByState(string stateValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetAllCityByState Method with Param stateValue: " + stateValue);
                stateValue = AntiXssEncoder.HtmlEncode(stateValue, true);//Added on 17-Jul-18 to fix Reflected XSS

                this.state = stateValue;
                ProviderVerification objProvider = new ProviderVerification();
                List<SelectListItem> city = new List<SelectListItem>();
                SelectListItem startObject = new SelectListItem() { Text = Constants.SelectCity, Value = Constants.SelectCity };
                city.Add(startObject);
                city.AddRange(objProvider.GetAllCityByState(state, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()).Select(x => new SelectListItem { Text = x.CityName, Value = x.CityName }).ToList());
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetAllCityByState Method");
                return city;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch all city by county
        /// </summary>
        /// <param name="county"></param>
        /// <param name="state"></param>
        /// <returns>IEnumerable<SelectListItem></returns>
        public static IEnumerable<SelectListItem> GetAllCityByCounty(string county, string state, string userName, string prd)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetAllCityByCounty Method with Param county: " + county + "and with Param state: " + state);
                state = AntiXssEncoder.HtmlEncode(state, true);//Added on 17-Jul-18 to fix Reflected XSS
                county = AntiXssEncoder.HtmlEncode(county, true);//Added on 17-Jul-18 to fix Reflected XSS
                ProviderVerification objProvider = new ProviderVerification();
                List<SelectListItem> city = new List<SelectListItem>();
                SelectListItem startObject = new SelectListItem() { Text = Constants.SelectCity, Value = Constants.SelectCity };
                city.Add(startObject);
                city.AddRange(objProvider.GetAllCityByCounty(county, state, userName,prd).Select(x => new SelectListItem { Text = x.CityName, Value = x.CityName }).ToList());
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetAllCityByCounty Method");
                return city;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch all morning time
        /// </summary>
        /// <returns>IEnumerable<SelectListItem></returns>
        public static IEnumerable<SelectListItem> FetchMorningTime()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, FetchMorningTime Method");
                List<SelectListItem> morningTime = new List<SelectListItem>();
                morningTime = new List<SelectListItem>
           {
                  new SelectListItem { Text = Constants.MorningTime0, Value=Constants.MorningTime0},
                  new SelectListItem { Text = Constants.MorningTime1, Value=Constants.MorningTime1},
                  new SelectListItem { Text = Constants.MorningTime2, Value=Constants.MorningTime2 },
                  new SelectListItem { Text = Constants.MorningTime3, Value=Constants.MorningTime3 },
                  new SelectListItem { Text = Constants.MorningTime4, Value=Constants.MorningTime4 },
                  new SelectListItem { Text = Constants.MorningTime5, Value=Constants.MorningTime5 },
                  new SelectListItem { Text = Constants.MorningTime6, Value=Constants.MorningTime6 },
                  new SelectListItem { Text = Constants.MorningTime7, Value=Constants.MorningTime7 },
                  new SelectListItem { Text = Constants.MorningTime8, Value=Constants.MorningTime8 },
                  new SelectListItem { Text = Constants.MorningTime9, Value=Constants.MorningTime9 },
                  new SelectListItem { Text = Constants.MorningTime10 , Value=Constants.MorningTime10 },
                  new SelectListItem { Text = Constants.MorningTime11, Value=Constants.MorningTime11 },
                  new SelectListItem { Text = Constants.MorningTime12, Value=Constants.MorningTime12 },
                  new SelectListItem { Text = Constants.MorningTime13, Value=Constants.MorningTime13 },
                  new SelectListItem { Text = Constants.MorningTime14, Value=Constants.MorningTime14 },
                  new SelectListItem { Text = Constants.MorningTime15, Value=Constants.MorningTime15 },
                  new SelectListItem { Text = Constants.MorningTime16, Value=Constants.MorningTime16 },
                  new SelectListItem { Text = Constants.MorningTime17, Value=Constants.MorningTime17 },
                  new SelectListItem { Text = Constants.MorningTime18, Value=Constants.MorningTime18 },
                  new SelectListItem { Text = Constants.MorningTime19, Value=Constants.MorningTime19 },
                  new SelectListItem { Text = Constants.MorningTime20, Value=Constants.MorningTime20 },
                  new SelectListItem { Text = Constants.MorningTime21, Value=Constants.MorningTime21 },
                  new SelectListItem { Text = Constants.MorningTime22, Value=Constants.MorningTime22 },
                  new SelectListItem { Text = Constants.MorningTime23, Value=Constants.MorningTime23 },
                  new SelectListItem { Text = Constants.MorningTime24, Value=Constants.MorningTime24 },
            };
                traceLog.AppendLine(" & End: ProviderDataVerificationController, FetchMorningTime Method");
                return morningTime;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Return all county by state
        /// </summary>
        /// <param name="state"></param>
        /// <returns>JsonResult</returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetCountyByStateJson(string stateValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetCountyByStateJson Method with Param stateValue: " + stateValue);
                stateValue = AntiXssEncoder.HtmlEncode(stateValue, true);//Added on 17-Jul-18 to fix Reflected XSS
                this.state = stateValue;
                var county = GetAllCountyByState(state);
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetCountyByStateJson Method");
                return Json(county, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Return all city by county
        /// </summary>
        /// <param name="county"></param>
        /// <param name="state"></param>
        /// <returns>JsonResult</returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetCityByCountyJson(string county, string stateValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetCityByCountyJson Method with Param county: " + county + "and with Param stateValue: " + stateValue);
                stateValue = AntiXssEncoder.HtmlEncode(stateValue, true);//Added on 17-Jul-18 to fix Reflected XSS
                this.state = stateValue;
                List<SelectListItem> city = new List<SelectListItem>();
                if (!string.IsNullOrEmpty(county) && !string.IsNullOrEmpty(state))
                {
                    county = AntiXssEncoder.HtmlEncode(county, true);//Added on 27-Jul-18 to fix Reflected XSS
                    if (county.Equals(Constants.SelectCounty))
                    {
                        city = GetAllCityByState(state).ToList();
                    }
                    else
                    {
                        city = GetAllCityByCounty(county, state, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()).ToList();
                    }
                }
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetCityByCountyJson Method");
                return Json(city, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Return all city by state
        /// </summary>
        /// <param name="state"></param>
        /// <returns>JsonResult</returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetCityByStateJson(string stateValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetCityByStateJson Method with Param stateValue: " + stateValue);
                stateValue = AntiXssEncoder.HtmlEncode(stateValue, true);//Added on 17-Jul-18 to fix Reflected XSS
                this.state = stateValue;
                var city = GetAllCityByState(state);
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetCityByStateJson Method");
                return Json(city, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Return zip by city
        /// </summary>
        /// <param name="city"></param>
        /// <returns>JsonResult</returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetZipByCityJson(string city, string state, string county)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetZipByCityJson Method with Param city: " + city + "and with Param state: " + state + "and with Param county: " + county);
                city = AntiXssEncoder.HtmlEncode(city, true);//Added on 17-Jul-18 to fix Reflected XSS
                state = AntiXssEncoder.HtmlEncode(state, true);//Added on 17-Jul-18 to fix Reflected XSS
                county = AntiXssEncoder.HtmlEncode(county, true);//Added on 24-Sept-18 to fix Reflected XSS
                string zip = string.Empty;
                if (String.IsNullOrEmpty(county) || county.Equals(Constants.SelectCounty))
                {
                    zip = GetZipByCity(city, state, string.Empty);
                }
                else
                {
                    zip = GetZipByCity(city, state, county);
                }
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetZipByCityJson Method");
                return Json(zip, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Approve change request
        /// </summary>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Provider Data Verification")]
        [HttpPost]
        public ActionResult Approve(Update update)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, Approve Method with Param update: " + update);
                ProviderVerification objBll = new ProviderVerification();
                User objUser = new User();
                string userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                string userType = ConfigurationManager.AppSettings[Constants.Site];
                objUser = objBll.GetUserDetails(userId, userType);


                string requesterName = ((UserDetails)Session[Constants.UserDetails]).UserId;
                string changeList = (string)Session[Constants.ChangeList];
                if (update != null)
                {
                    changeList = "<b>" + "Changes Submitted For:" + "</b><br/><br/>" + "Provider Name:" + update.ProviderName + "<br/>" + "TAXID:" + update.ProviderTin + "<br/>" + "NPI:" + update.ProviderNPI + "<br/><br/>" + changeList;
                }
                InsertChangedData(changeList, userId, requesterName);
                string toMailUser = objUser.Email;
                string[] mailIdUser = new string[1];
                mailIdUser[0] = toMailUser;
                string toMailProvider = ConfigurationManager.AppSettings[Constants.ProviderRelations];
                string[] mailIdProvider = new string[1];
                mailIdProvider[0] = toMailProvider;
                string[] bccMailId = new string[1];
                string mailIdBCC = ConfigurationManager.AppSettings[Constants.BCCMailAddress];
                bccMailId[0] = mailIdBCC;
                objBll.SendMail(GetMailBody(changeList), mailIdUser, bccMailId, Constants.MessageUser);
                objBll.SendMail(GetMailBodyInt(changeList, userId, objUser), mailIdProvider, bccMailId, Constants.MessageAdmin);
                traceLog.AppendLine(" & End: ProviderDataVerificationController, Approve Method");
                return Content("<script type='text/javascript'> alert('Your request has been sent to the Cofinity Provider Services department.  \\n \\n We have also sent an e-mail confirmation to you.');window.location='/ProviderDataVerification/Index'</script>");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Store the change details in DB
        /// </summary>
        /// <param name="changeList"></param>
        /// <param name="Userid"></param>
        /// <param name="requesterName"></param>
        private static void InsertChangedData(string changeList, string Userid, string requesterName)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, InsertChangedData Method with Param changeList: " + changeList + "and with Param Userid: " + Userid + "and with Param requesterName: " + requesterName);
                changeList = changeList.Replace(Constants.List, "");
                changeList = changeList.Replace(Constants.FontSizeStart, "");
                changeList = changeList.Replace(Constants.FontSizeEnd, "-");
                changeList = changeList.Replace(Constants.ListEnd, "~");
                string VerifiedData = changeList.Trim().TrimEnd('~');

                ProviderVerification objBll = new ProviderVerification();
                objBll.InsertChangedData(VerifiedData, Userid, requesterName);
                traceLog.AppendLine(" & End: ProviderDataVerificationController, InsertChangedData Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Build the mail content for Admin
        /// </summary>
        /// <param name="changeList"></param>
        /// <param name="userId"></param>
        /// <returns>string</returns>
        private string GetMailBodyInt(string changeList, string userId, User objUser)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetMailBodyInt Method with Param changeList: " + changeList + "and with Param userId: " + userId + "and with Param objUser: " + objUser);
                StringBuilder mailBody = new StringBuilder();
                if (objUser != null)
                {

                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.MessageAdmin1);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.BreakLine);

                    mailBody.Append(Constants.TableHeader);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.StyleStart);
                    mailBody.Append(changeList);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.StyleEnd);
                    mailBody.Append(Constants.TableEnd);
                    mailBody.Append(Constants.BreakLine);

                    mailBody.Append(Constants.TableHeader);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.SubmittedBy);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.UserNameLabel + userId);
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.NameLabel + objUser.LastName.ToString().Trim() + Constants.CommaWithSpace + objUser.FirstName.ToString().Trim());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.TitleLabel + objUser.Title.ToString().Trim());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.CompanyNameLabel + objUser.CompanyName.ToString().Trim());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.PhoneLabel + objUser.BusinessPhone.ToString().Trim());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.EmailLabel + objUser.Email.ToString().Trim());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.SubmittedOn + DateTime.Now.ToShortDateString());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.TableEnd);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.BreakLine);

                    mailBody.Append(Constants.TableHeader);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.MessageAdmin2);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.BreakLine);


                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.MessageAdmin3);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.BreakLine);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.MessageAdmin4);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.TableEnd);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.BreakLine);

                    mailBody.Append(Constants.TableHeader);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.CofinityLabel);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.RowStyle);
                    mailBody.Append(Constants.DoNotReply);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.TableEnd);
                }
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetMailBodyInt Method");
                return mailBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Build mail body for user
        /// </summary>
        /// <param name="changeList"></param>
        /// <returns>string</returns>
        private static string GetMailBody(string changeList)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetMailBody Method with Param changeList: " + changeList);
                StringBuilder mailBody = new StringBuilder();

                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.MessageUser3);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);

                mailBody.Append(Constants.TableHeader);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.StyleStart);
                mailBody.Append(changeList);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.StyleEnd);
                mailBody.Append(Constants.TableEnd);

                mailBody.Append(Constants.BreakLine);

                mailBody.Append(Constants.TableHeader);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.MessageUser4);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.TableEnd);

                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);

                mailBody.Append(Constants.TableHeader);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.CofinityLabel);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStyle);
                mailBody.Append(Constants.DoNotReply);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.TableEnd);
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetMailBody Method");
                return mailBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Add new location page
        /// </summary>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Provider Data Verification")]
        public ActionResult AddLocation()
        {
            try
            {
                return View("AddLocation");
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// Fetch Hospital name by state and/or city
        /// </summary>
        /// <param name="state"></param>
        /// <param name="city"></param>
        /// <returns></returns>
        public JsonResult GetHospital(string stateValue, string city)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderDataVerificationController, GetHospital Method with Param stateValue: " + stateValue + "and with Param city: " + city);
                this.state = stateValue;
                ProviderVerification objProvider = new ProviderVerification();
                var hospital = objProvider.GetHospital(state, city);
                traceLog.AppendLine(" & End: ProviderDataVerificationController, GetHospital Method");
                return Json(hospital, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

    }
}
