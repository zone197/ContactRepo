﻿using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Mvc;
using System.Configuration;
using Utilities;
using System.Linq;

namespace NABWebsite
{
    public class ContentController : BaseController
    {

        int langcode = Convert.ToInt32(ConfigurationManager.AppSettings["langCode"]);
        //
        // GET: /Content/
        public ActionResult Index(int PageId = 4002)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ContentController, Index Method with Param PageId: " + PageId);
                ManageContent manageContent = new ManageContent();

                // Currently pageId is hard coded with Dental
                PageInfo pageInfo = manageContent.GetPagContent(PageId, langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());

                var ListGenericContainer = new List<PageSection>();
                if (((UserDetails)Session[Constants.UserDetails] != null)
                 && (((UserDetails)Session[Constants.UserDetails]).SelectedRole != null) && ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                {
                    ListGenericContainer = pageInfo.PageSections;
                }
                else
                {
                    ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
                }


                ContentViewModel contentViewModel = new ContentViewModel();
                contentViewModel.Title = pageInfo.Content.Heading;
                contentViewModel.Contents = pageInfo.Content.ContentText;

                IndexViewModel indexViewModel = new IndexViewModel();
                indexViewModel.Content = contentViewModel;

                //Create Right generic section
                RightSectionGenericContainer objRightSectionGenContainer = null;
                RightSectionNewsContainer objRightSectionNewsContainer = null;

                List<RightSectionGenericContainer> ListRightGeneric = new List<RightSectionGenericContainer>();
                List<RightSectionNewsContainer> ListNews = new List<RightSectionNewsContainer>();

                foreach (var ob in ListGenericContainer)
                {
                    objRightSectionGenContainer = new RightSectionGenericContainer();
                    objRightSectionGenContainer.ImageId = ob.ImageId;
                    objRightSectionGenContainer.ImageName = ob.ImageName;
                    objRightSectionGenContainer.ImageContent = ob.ImageContent;
                    objRightSectionGenContainer.LinkId = ob.LinkId;
                    objRightSectionGenContainer.LinkType = ob.LinkType;
                    objRightSectionGenContainer.LinkUrl = ob.LinkUrl;
                    objRightSectionGenContainer.TargetPageId = ob.TargetPageId;
                    objRightSectionGenContainer.Title = ob.Title;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.GroupType = ob.GroupType;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.SectionOrder = ob.SectionOrder;

                    ListRightGeneric.Add(objRightSectionGenContainer);
                }

                ViewBag.RightFirstContainer = ListRightGeneric;
                /*Ends here*/

                /*Create News Container*/

                // ViewBag.NewsSectionModel = pageInfo.GroupedSections;


                foreach (var ob in pageInfo.GroupedSections)
                {

                    objRightSectionNewsContainer = new RightSectionNewsContainer();
                    objRightSectionNewsContainer.ImageId = ob.ImageId;
                    objRightSectionNewsContainer.ImageName = ob.ImageName;
                    objRightSectionNewsContainer.ImageContent = ob.ImageContent;
                    objRightSectionNewsContainer.LinkId = ob.LinkId;
                    objRightSectionNewsContainer.Title = ob.Title;
                    objRightSectionNewsContainer.SectionId = ob.SectionId;
                    objRightSectionNewsContainer.GroupType = ob.GroupType;
                    objRightSectionNewsContainer.SectionId = ob.SectionId;
                    objRightSectionNewsContainer.SectionOrder = ob.SectionOrder;
                    objRightSectionNewsContainer.NewsEventDate = ob.NewsEventDate;
                    objRightSectionNewsContainer.NewsEventDuration = ob.NewsEventDuration;

                    ListNews.Add(objRightSectionNewsContainer);
                }

                /*Ends here*/

                if (ListRightGeneric != null && ListRightGeneric.Count > 0)
                    indexViewModel.ListGenContainer = ListRightGeneric;

                if (ListRightGeneric != null && ListNews.Count > 0)
                    indexViewModel.ListNewsContainer = ListNews;
                traceLog.AppendLine(" & End: ContentController, Index Method");
                return View("~/views/Content/ExecutiveProfile.cshtml", indexViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Executives profile to be displayed
        /// </summary>
        /// <returns></returns>
        public JsonResult GetProfiles()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ContentController, GetProfiles Method");
                ManageContent content = new ManageContent();
                List<GroupSection> lstExecProfiles = content.GetExecutiveProfiles(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                lstExecProfiles = lstExecProfiles.FindAll(_item => _item.SubType == "EXECUTIVE");


                ExecutiveProfile objExecutive = new ExecutiveProfile();
                List<ExecutiveProfile> lstExecutiveProfile = new List<ExecutiveProfile>();



                if (lstExecProfiles != null)
                {
                    foreach (var ob in lstExecProfiles)
                    {
                        objExecutive = new ExecutiveProfile();
                        objExecutive.ImageId = ob.ImageId;
                        objExecutive.ImageString = Convert.ToBase64String(ob.ImageContent);

                        string[] TempArr = (ob.Title).Split(new string[] { "<br/>" }, StringSplitOptions.None);

                        objExecutive.ExecutiveName = TempArr[0];
                        objExecutive.ExecutiveTitle = TempArr[1];
                        objExecutive.ExecutiveDetails = ob.DetailText;  //.Substring(0,50) + "...";
                        lstExecutiveProfile.Add(objExecutive);
                    }
                }

                var jsonResult = Json(lstExecutiveProfile, JsonRequestBehavior.AllowGet);
                jsonResult.MaxJsonLength = int.MaxValue;
                traceLog.AppendLine(" & End: ContentController, GetProfiles Method");
                return jsonResult;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


    }
}