﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;

namespace NABWebsite.Models
{
    public class TopLeftSectionViewModel
    {
        public TopLeftSectionViewModel(LinkedSection linkedSection)  // Fixed on 20 Sep 2018 for Checkmarx:Inappropriate Encoding for Output Context (Changed datatype of variable Title back to string)
        {
            this.Title = linkedSection.Title;//Changed datatype of "Title" on 13/07/18 to fix Reflected XSS
            this.LinkId = linkedSection.LinkId;
            this.LinkType = linkedSection.LinkType;
            this.LinkUrl = linkedSection.LinkUrl;
            this.PageId = linkedSection.TargetPageId;
        }
        public string Title { get; set; }//Changed datatype of "Title" on 13/07/18 to fix Reflected XSS
        public int LinkId { get; set; }
        public string LinkType { get; set; }
        public string LinkUrl { get; set; }
        public int PageId { get; set; }
    }
}