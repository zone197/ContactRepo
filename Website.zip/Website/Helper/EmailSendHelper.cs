﻿using NABWebsite.BLL;
using NABWebsite.DTO;
using System.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using NABResources;
using Aetna.ProviderContracts.DataContracts;
using NABWebsite.Models.LocateProvider;
using System.Collections;
using System.Text;
using Utilities;
namespace NABWebsite.Helper
{
    public static class EmailSendHelper
    {

        /// <summary>
        /// Get all list of Provider Language Spoken for refine criteria in search result page
        /// </summary>
        /// <param name="provider"></param>
        /// <returns></returns>
        public static string ReturnProviderName(Aetna.ProviderContracts.DataContracts.Provider provider)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: EmailSendHelper, ReturnProviderName Method with Params provider: " + provider); 
                string providerNameDegree = string.Empty;
                if (provider == null)
                    throw new ArgumentNullException(VariableConstant.Provider);
                if (provider.ProviderName.NamePrefix != null)
                { providerNameDegree += provider.ProviderName.NamePrefix + " "; }
                if (provider.ProviderName.FirstName != null)
                { providerNameDegree += provider.ProviderName.FirstName + " "; }
                if (provider.ProviderName.MiddleName != null)
                { providerNameDegree += provider.ProviderName.MiddleName + " "; }
                if (provider.ProviderName.MiddleName == null && provider.ProviderName.MidInitial != null)
                { providerNameDegree += provider.ProviderName.MidInitial + " "; }
                if (provider.ProviderName.LastName != null)
                { providerNameDegree += provider.ProviderName.LastName; }
                if (provider.ProviderName.NameSuffix != null)
                { providerNameDegree += provider.ProviderName.NameSuffix + " "; }
                traceLog.AppendLine(" & End: EmailSendHelper, ReturnProviderName Method");
                return providerNameDegree;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// returns body for sending provider details as text message
        /// </summary>
        /// <param name="provider"></param>
        /// <param name="body"></param>
        /// <param name="searchRequest"></param>
        /// <returns></returns>
        public static ArrayList ReturnProviderInformationForMobile(Aetna.ProviderContracts.DataContracts.Provider provider, string body, SearchRequestEntity searchRequest, string[] providerNumberIndex)
        {
            StringBuilder traceLog = new StringBuilder();

            int addressLoc = 0;
            ArrayList bodyPart = new ArrayList();
            string body2 = " ";
            string checklength = "";
            if (searchRequest == null)
                throw new ArgumentNullException("searchRequest");
            if (provider == null)
                throw new ArgumentNullException("provider");
            try
            {
                traceLog.AppendLine("Start: EmailSendHelper, ReturnProviderInformationForMobile Method with Params provider: " + provider + " and with Param body: " + body + " and with Param searchRequest: " + searchRequest + " and with Param providerNumberIndex: " + providerNumberIndex); 
                //body += EmailBodyConstant.ProviderOnlineSearch + "<br /><br />";
                body += searchRequest.NetworkType.NetworkName.TrimEnd().TrimStart() + " ";



                string providerNameDegree = string.Empty;
                if (provider.ProviderName != null)
                {
                    providerNameDegree = ReturnProviderName(provider);
                    body += providerNameDegree.TrimEnd().TrimStart() + " ";

                }
                string addressLine1 = string.Empty;
                string addressLine2 = string.Empty;
                string distance = string.Empty;
                if (provider.OtherOfficeLocations != null)
                {
                    
                    for (int i = 0; i < provider.OtherOfficeLocations.Count;i++ )
                    {
                        if (provider.OtherOfficeLocations[i].ProvLocationID == providerNumberIndex[1] && provider.OtherOfficeLocations[i].ProvTaxId == providerNumberIndex[2])
                        {
                            addressLoc = i;
                            break;
                        }
                    }
                    if (provider.OtherOfficeLocations[addressLoc].AddressLine1 != null)
                    { addressLine1 += provider.OtherOfficeLocations[addressLoc].AddressLine1 + " "; }
                    else if (provider.OtherOfficeLocations[addressLoc].AddressLine2 != null)
                    { addressLine1 += provider.OtherOfficeLocations[addressLoc].AddressLine2 + " "; }

                    if (provider.OtherOfficeLocations[addressLoc].AddressLine1 != null && provider.OtherOfficeLocations[addressLoc].AddressLine2 != null)
                    { addressLine2 += provider.OtherOfficeLocations[addressLoc].AddressLine2 + " "; }

                    if (provider.OtherOfficeLocations[addressLoc].CITY != null)
                    { addressLine2 += provider.OtherOfficeLocations[addressLoc].CITY + " "; }

                    if (provider.OtherOfficeLocations[addressLoc].State != null)
                    { addressLine2 += provider.OtherOfficeLocations[addressLoc].State + " "; }

                    if (provider.OtherOfficeLocations[addressLoc].Zipcode != null)
                    { addressLine2 += provider.OtherOfficeLocations[addressLoc].Zipcode; }


                    decimal distanceDecimal = provider.OtherOfficeLocations[addressLoc].ProviderDistance;
                    distance = Math.Round(distanceDecimal, 2).ToString(CultureInfo.CurrentCulture) + " " + VariableConstant.Miles;

                }

                if (addressLine1 != null)
                {
                    body2 += addressLine1.TrimEnd().TrimStart();
                    body2 += " ";

                }
                if (addressLine2 != null)
                {
                    body += addressLine2;
                    body += "<br />";
                }

                    body2 += addressLine2.TrimEnd().TrimStart();
                    body2 += " ";
                    body2 = body2.Replace(EmailBodyConstant.Distance, distance);
                    body2 += distance.TrimEnd().TrimStart() + " ";
                    //body += "<br />";
                    string phoneNumber = string.Empty;
                    if (provider.OtherOfficeLocations[addressLoc].PhoneExt != null)
                    { phoneNumber += provider.OtherOfficeLocations[addressLoc].PhoneExt; }
                    if (provider.OtherOfficeLocations[addressLoc].PhoneNbr != null)
                    { phoneNumber += provider.OtherOfficeLocations[addressLoc].PhoneNbr; }

                    body2 += "Ph: " + phoneNumber.TrimEnd().TrimStart() + " ";

                if (provider.AffiliatedHospitalNames != null)
                {
                    body += "Hospital Affiliation -" + provider.AffiliatedHospitalNames + "<br />";
                }
                checklength = body + body2;
                if (checklength.Length <= 140)
                    bodyPart.Add(checklength);
                else
                {
                    bodyPart.Add("(1/2) " + body);
                    bodyPart.Add("(2/2)" + body2);

                }
                traceLog.AppendLine(" & End: EmailSendHelper, ReturnProviderInformationForMobile Method");
                return bodyPart;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
       
        /// <summary>
        /// sending mail for provider details
        /// </summary>
        /// <param name="provider"></param>
        /// <param name="searchRequest"></param>
        /// <param name="server"></param>
        /// <param name="email"></param>
        /// <param name="phoneNumberCarrier"></param>
        /// <param name="providerNumberIndex"></param>
        /// <returns></returns>
        public static bool SendMail(Aetna.ProviderContracts.DataContracts.Provider provider, SearchRequestEntity searchRequest, HttpServerUtilityBase server, string email, string phoneNumberCarrier, string[] providerNumberIndex, string culture, string mailFrom)
        {
            StringBuilder traceLog = new StringBuilder();

            if (searchRequest == null)
                throw new ArgumentNullException("searchRequest");
            if (providerNumberIndex == null)
                throw new ArgumentNullException("providerNumberIndex");
            if (server == null)
                throw new ArgumentNullException("server");
            try
            {
                traceLog.AppendLine("Start: EmailSendHelper, SendMail Method with Params provider: " + provider + " and with Param searchRequest: " + searchRequest + " and with Param server: " + server + " and with Param email: " + email + " and with Param phoneNumberCarrier: " + phoneNumberCarrier + " and with Param providerNumberIndex: " + providerNumberIndex + " and with Param culture: " + culture + " and with Param mailFrom: " + mailFrom); 

                int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);

                ManageContent contentManager = new ManageContent();
                string[] emailAddresses;
                string[] carrier;
                List<string> emailAddressesList = new List<string>();
                List<string> carrierList = new List<string>();
                if (!string.IsNullOrEmpty(email)) emailAddressesList.Add(email);
                if (!string.IsNullOrEmpty(phoneNumberCarrier)) carrierList.Add(phoneNumberCarrier);
                emailAddresses = emailAddressesList.ToArray();
                carrier = carrierList.ToArray();
                RequestHeader requestForProviderDetails = new CommonHelper().GetRequestHeader(culture, networkId);
                provider = contentManager.GetProviderDetails(providerNumberIndex[0], providerNumberIndex[1].Replace("-", "/"), providerNumberIndex[2], searchRequest.ZipCode, requestForProviderDetails, searchRequest.ClientSpecificCode);
                bool emailto = false;
                bool carrierto = false;
                if (carrier.Count() > 0)
                {
                    string body = string.Empty;
                    ArrayList bodyForText = new ArrayList();
                    bodyForText = ReturnProviderInformationForMobile(provider, body, searchRequest, providerNumberIndex);
                    for (int i = 0; i <= bodyForText.Count - 1; i++)
                    {

                        carrierto = contentManager.SendMail(bodyForText[i].ToString(), carrier, VariableConstant.ProviderDetailsHeading);
                        if (carrierto == false)
                            break;
                    }
                }
                if (emailAddresses.Count() > 0)
                {
                    string body = string.Empty;
                    using (StreamReader reader = new StreamReader(server.MapPath("~/Templates/LocateProviderEmail/ProviderDetails.html")))
                    {
                        body = reader.ReadToEnd();
                    }
                    if (searchRequest.ClientSpecificCode != null && searchRequest.ClientSpecificNetwork != null)
                    {
                        body = body.Replace(EmailBodyConstant.NetworkType, searchRequest.ClientSpecificNetwork);
                    }
                    else
                    {
                        body = body.Replace(EmailBodyConstant.NetworkType, searchRequest.NetworkType.NetworkName + " " + EmailBodyConstant.Network);
                    }
                    
                       body = body.Replace(EmailBodyConstant.Label_Details, Resources.lbl_Details);
                       body = body.Replace(EmailBodyConstant.Label_Type, Resources.lbl_Type);
                       body = body.Replace(EmailBodyConstant.Label_Specialty, Resources.lbl_Specialty);
                       body = body.Replace(EmailBodyConstant.Label_Focus, Resources.lbl_Focus);
                       body = body.Replace(EmailBodyConstant.Label_Gender, Resources.lbl_Gender);
                       body = body.Replace(EmailBodyConstant.Label_PracticeName, Resources.lbl_PracticeName);
                       body = body.Replace(EmailBodyConstant.Label_Speaks, Resources.lbl_Speaks);
                       body = body.Replace(EmailBodyConstant.Label_HospitalAffiliation, Resources.lbl_HospitalAffiliation);
                       body = body.Replace(EmailBodyConstant.Label_ProviderNumber, Resources.lbl_ProviderNumber);
                       body = body.Replace(EmailBodyConstant.Label_Location, Resources.lbl_Location);
                       body = body.Replace(EmailBodyConstant.Label_CurrentLocation, Resources.lbl_CurrentLocation);
                       body = body.Replace(EmailBodyConstant.Label_Hospital, Resources.lbl_Hospital);
                       body = body.Replace(EmailBodyConstant.Label_EstimatedDistance, Resources.lbl_EstimatedDistance);
                       body = body.Replace(EmailBodyConstant.Label_Address, Resources.lbl_Address);
                       body = body.Replace(EmailBodyConstant.Label_Dial, Resources.lbl_Dial);
                       body = body.Replace(EmailBodyConstant.Label_Fax, Resources.lbl_Fax);
                       body = body.Replace(EmailBodyConstant.Label_OtherOfficeLocations, Resources.lbl_OtherOfficeLocations);

                   
                    string providerNameDegree = string.Empty;
                    if (provider.ProviderName != null)
                    {
                        providerNameDegree = ReturnProviderName(provider);
                        body = body.Replace(EmailBodyConstant.ProviderName, providerNameDegree);
                    }

                    string addressLine1 = string.Empty;
                    string addressLine2 = string.Empty;
                    string distance = string.Empty;
                    provider.OtherOfficeLocations = GetPrimaryAddress.GetAddressForProvider(provider, providerNumberIndex);
                    if (provider.OtherOfficeLocations != null)
                    {
                        if (provider.OtherOfficeLocations[0].AddressLine1 != null)
                        { addressLine1 += provider.OtherOfficeLocations[0].AddressLine1+" ";}
                         if (provider.OtherOfficeLocations[0].AddressLine2 != null)
                        { addressLine1 += provider.OtherOfficeLocations[0].AddressLine2 + " ";}

                        //if (provider.OtherOfficeLocations[0].AddressLine1 != null && provider.OtherOfficeLocations[0].AddressLine2 != null)
                        //{ addressLine2 += provider.OtherOfficeLocations[0].AddressLine2 + " "; }

                        if (provider.OtherOfficeLocations[0].CITY != null)
                        { addressLine2 += provider.OtherOfficeLocations[0].CITY + " "; }

                        if (provider.OtherOfficeLocations[0].State != null)
                        { addressLine2 += provider.OtherOfficeLocations[0].State + " "; }

                        if (provider.OtherOfficeLocations[0].Zipcode != null)
                        { addressLine2 += provider.OtherOfficeLocations[0].Zipcode; }


                        decimal distanceDecimal = provider.OtherOfficeLocations[0].ProviderDistance;
                        distance = Math.Round(distanceDecimal, 2).ToString(CultureInfo.CurrentCulture) + " " + VariableConstant.Miles;

                    }

                    if (addressLine1 != null)
                    {
                        body = body.Replace(EmailBodyConstant.PrimaryAddressLine1, addressLine1);
                    }
                    if (addressLine2 != null)
                    {
                        body = body.Replace(EmailBodyConstant.PrimaryAddressLine2, addressLine2);
                    }
                    if (searchRequest.State == null || searchRequest.State == "")
                    {

                        body = body.Replace(EmailBodyConstant.Distance, distance);

                    }
                    else
                    {

                        body = body.Replace(EmailBodyConstant.replaceDistance, string.Empty);
                        body = body.Replace(EmailBodyConstant.replace_Distance, string.Empty);
                    }

                    string phoneNumber = string.Empty;
                    if (provider.OtherOfficeLocations[0].PhoneExt != null)
                    { phoneNumber += provider.OtherOfficeLocations[0].PhoneExt; }
                    if (provider.OtherOfficeLocations[0].PhoneNbr != null)
                    { phoneNumber += provider.OtherOfficeLocations[0].PhoneNbr; }

                    body = body.Replace(EmailBodyConstant.PhoneNumber, phoneNumber);

                    if (provider.AcceptNewPatients != null && provider.AcceptNewPatients != "0")
                    {
                       // body = body.Replace(EmailBodyConstant.AcceptingNewPatients, VariableConstant.AcceptingPatients);
                        body = body.Replace(EmailBodyConstant.AcceptingNewPatients, Resources.lbl_AcceptingPatients);
                    }
                    else
                    {
                        //body = body.Replace(EmailBodyConstant.AcceptingNewPatients, VariableConstant.NotAcceptingPatients);
                        body = body.Replace(EmailBodyConstant.AcceptingNewPatients, Resources.lbl_NotAcceptingPatients);
                    }
                    if (provider.ProviderType != null)
                    {
                        body = body.Replace(EmailBodyConstant.Type, provider.ProviderType.ProviderTypeName);
                    }
                    if (provider.Speciality != null)
                    {
                        body = body.Replace(EmailBodyConstant.Specialty, provider.Speciality.SpecialtyName);
                    }
                    if (provider.Focus != null)
                    {
                        body = body.Replace(EmailBodyConstant.Focus, provider.Focus);
                    }
                    if (provider.Gender != null)
                    {
                        body = body.Replace(EmailBodyConstant.Gender, provider.Gender);
                    }

                    if (provider.PracticeName != null)
                    {
                        body = body.Replace(EmailBodyConstant.PracticeName, provider.PracticeName);
                    }

                    if (provider.LanguagesSpoken != null)
                    {
                        body = body.Replace(EmailBodyConstant.SpokenLanguage, provider.LanguagesSpoken);
                    }
                    if (provider.AffiliatedHospitalNames != null)
                    {
                        body = body.Replace(EmailBodyConstant.HospitalAffiliation, provider.AffiliatedHospitalNames);
                    }

                    if (provider.ProvNum != null)
                    {
                        body = body.Replace(EmailBodyConstant.ProviderNumber, provider.ProvNum);
                    }

                    if (provider.CPCID != null)
                    {
                        body = body.Replace(EmailBodyConstant.CpdId, provider.CPCID);

                    }

                    body = body.Replace(EmailBodyConstant.Hospital, string.Empty);
                    if (provider.OtherOfficeLocations != null)
                    {
                        body = body.Replace(EmailBodyConstant.Dial, provider.OtherOfficeLocations[0].PhoneNbr);

                    }
                    if (provider.OtherOfficeLocations != null)
                    {
                        body = body.Replace(EmailBodyConstant.Fax, provider.OtherOfficeLocations[0].FaxNbr);
                    }

                    body = ReturnOtherOfficeAddress(provider, body, searchRequest);
                    //body += "<b style='color:#243e16;'>Hours:</b>";
                    body += " <table style='color:#243e16; width:45%'>";
                    body += "  <tr>";
                    //body += " <td style='padding-right:50px;margin-right:50px;'>Day </td>";
                    //body += "<td style='padding-right:50px;margin-right:50px;'>Hours</td>";
                    body += " <td>" + EmailBodyConstant.Label_Day + ": </td>";
                    body = body.Replace(EmailBodyConstant.Label_Day, Resources.lbl_Day);
                    body += "<td>" + EmailBodyConstant.Label_Day + ":</td>";
                    body = body.Replace(EmailBodyConstant.Label_Day, Resources.lbl_Hours);
                    body += "<td></td>";
                    body += " </tr>";

                    List<Hours> hoursList = new List<Hours>();
                    //int start = 0;
                    //int end = 3;
                    int startAm = 0;
                    int endAm = 1;
                    int startPm = 2;
                    int endPm = 3;
                    string days = AppSettingHelper.GetAppSettingValue(VariableConstant.Weekdays);
                    string[] weekDays = days.Split(',');
                    string html = "";
                    if (provider != null)
                    {
                        if (provider.OfficeHours.Count() > 0)
                        {
                            for (int i = 0; i < 7; i++)
                            {

                                #region commentedArea
                                //Hours hours = new Hours();
                                //hours.Day = weekDays[i];
                                //if (!string.IsNullOrEmpty(provider.OfficeHours[start].OfficeTimeSlot))
                                //{
                                //    if (provider.OfficeHours[start].OfficeTimeSlot.Trim().Length > 0 && provider.OfficeHours[end].OfficeTimeSlot.Length > 0)
                                //    {

                                //        hours.Time = provider.OfficeHours[start].OfficeTimeSlot + VariableConstant.StartTimeInAM + " - " + provider.OfficeHours[end].OfficeTimeSlot + VariableConstant.EndTimeInPM;
                                //    }
                                //    else
                                //    {
                                //        if (provider.OfficeHours[start].OfficeTimeSlot.Trim().Length > 0)
                                //        {
                                //            hours.Time = provider.OfficeHours[start].OfficeTimeSlot + VariableConstant.StartTimeInAM;
                                //        }
                                //        else
                                //        {
                                //            hours.Time = provider.OfficeHours[end].OfficeTimeSlot + VariableConstant.EndTimeInPM;
                                //        }
                                //    }
                                //}
                                //hoursList.Add(hours);
                                //start = start + 4;
                                //end = end + 4;
                                #endregion


                                #region NewChanges

                                Hours hours = new Hours();
                                hours.Day = weekDays[i];

                                if (provider.OfficeHours[startAm].OfficeTimeSlot.Trim().Length > 0 && provider.OfficeHours[endAm].OfficeTimeSlot.Length > 0)
                                {
                                     html = "<table style='width:100%'><tr><td style='width:45%'>" + provider.OfficeHours[startAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + "</td><td style='width:2%'>-</td><td style='width:45%'>" + provider.OfficeHours[endAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + "</td></tr></table>";

                                    hours.Time = html;
                                    html = "";
                                }
                                else
                                {
                                    if (provider.OfficeHours[startAm].OfficeTimeSlot.Trim().Length > 0)
                                    {
                                         html = "<table style='width:100%'><tr><td style='width:45%'>" + provider.OfficeHours[startAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + "</td><td style='width:2%'></td><td style='width:45%'></td></tr></table>";

                                        hours.Time = html;
                                        html = "";
                                    }
                                    else if (provider.OfficeHours[endAm].OfficeTimeSlot.Trim().Length > 0)
                                    {
                                         html = "<table style='width:100%'><tr><td style='width:45%'></td><td style='width:2%'></td><td style='width:45%'>" + provider.OfficeHours[endAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + "</td></tr></table>";

                                        hours.Time = html;
                                        html = "";

                                    }
                                }




                                if (provider.OfficeHours[startPm].OfficeTimeSlot.Trim().Length > 0 && provider.OfficeHours[endPm].OfficeTimeSlot.Length > 0)
                                {
                                    
                                    html = "<table style='width:100%'><tr><td style='width:45%'>" + provider.OfficeHours[startPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td><td style='width:2%'>-</td><td style='width:45%'>" + provider.OfficeHours[endPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td></tr></table>";

                                    hours.TimePM = html;
                                    html = "";
                                }
                                else
                                {
                                    if (provider.OfficeHours[startPm].OfficeTimeSlot.Trim().Length > 0)
                                    {
                                      
                                         html = "<table style='width:100%'><tr><td style='width:45%'>" + provider.OfficeHours[startPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td><td style='width:2%'></td><td style='width:45%'></td></tr></table>";
                                         hours.TimePM = html;
                                        html = "";
                                    }
                                    else if (provider.OfficeHours[endPm].OfficeTimeSlot.Trim().Length > 0)
                                    {
                                        
                                        html = "<table style='width:100%'><tr><td style='width:45%'></td><td style='width:2%'></td><td style='width:45%'>" + provider.OfficeHours[endPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td></tr></table>";
                                        hours.TimePM = html;
                                        html = "";
                                    }
                                }



                                hoursList.Add(hours);
                                startAm = startAm + 4;
                                endAm = endAm + 4;
                                startPm = startPm + 4;
                                endPm = endPm + 4;
                                #endregion

                            }
                        }
                    }
                    LocateProviderSearchResultViewModel searchResultViewModel = new LocateProviderSearchResultViewModel();
                    searchResultViewModel.Hours = hoursList;
                    if (searchResultViewModel.Hours.Count > 0)
                    {
                        foreach (var OfficeHours in searchResultViewModel.Hours)
                        {
                            if (!string.IsNullOrWhiteSpace(OfficeHours.Time) || !string.IsNullOrWhiteSpace(OfficeHours.TimePM))
                            {
                                body += "<tr>";
                                //body += "<td style='padding-right:50px;margin-right:50px;'>" + OfficeHours.Day + "</td>";
                                //body += "<td style='padding-right:50px;margin-right:50px;'>" + OfficeHours.Time + "</td>";
                                //body+="<td style='padding-right:50px;margin-right:50px;'>" + OfficeHours.TimePM + "</td>";

                                body += "<td>" + OfficeHours.Day + "</td>";
                                body += "<td>" + OfficeHours.Time + "</td>";
                                body += "<td>" + OfficeHours.TimePM + "</td>";
                                    body += "</tr>";
                            }
                        }
                    }
                    else
                    {
                        body += "<tr>";
                        body += "<td style='padding-right:50px;margin-right:50px;'>" + VariableConstant.NotAvailable + "</td>";
                        body += "<td></td>";
                        body += "</tr>";
                    }
                    body += " </table>";
                    
                    emailto = contentManager.SendMail(body, emailAddresses, VariableConstant.ProviderDetailsHeading,mailFrom);
                }
                bool value = false;
                if (carrierto || emailto)
                {
                    value = true;
                    traceLog.AppendLine(" & End: EmailSendHelper, SendMail Method");
                    return value;
                }
                traceLog.AppendLine(" & End: EmailSendHelper, SendMail Method");
                return value;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// generate other office location object for mailing
        /// </summary>
        /// <param name="provider"></param>
        /// <param name="body"></param>
        /// <returns></returns>
        private static string ReturnOtherOfficeAddress(Aetna.ProviderContracts.DataContracts.Provider provider, string body, SearchRequestEntity searchRequest)
        {
            StringBuilder traceLog = new StringBuilder();

            if (provider == null)
                throw new ArgumentNullException(VariableConstant.Provider);
            try
            {
                traceLog.AppendLine("Start: EmailSendHelper, ReturnOtherOfficeAddress Method with Params provider: " + provider + " and with Param body: " + body + " and with Param searchRequest: " + searchRequest); 
                if (provider.OtherOfficeLocations.Count > 51)
                {
                    body += "<p style='color:#243e16;margin:0px;padding:0px;'><b>" + Resources.lblMorethan50Location + " </b></p>";
                    if (searchRequest.State == null || searchRequest.State == "")
                    {
                        provider.OtherOfficeLocations = provider.OtherOfficeLocations.OrderBy(a => a.ProviderDistance).ToList();
                    }
                    else
                    {
                        provider.OtherOfficeLocations = provider.OtherOfficeLocations.OrderBy(a => a.CITY).ToList();
                    }
                }
                for (int i = 1; i < provider.OtherOfficeLocations.Count; i++)
                {
                    //Defect #2151
                    var OtherOfficeLocations = provider.OtherOfficeLocations[i];
                    body += "<p style='color:#243e16;margin:0px;padding:0px;'><b>" + EmailBodyConstant.Label_Hospital + ": </b></p>";
                    body = body.Replace(EmailBodyConstant.Label_Hospital, Resources.lbl_Hospital);
                    string otherOfficeDistance = string.Empty;
                    if (searchRequest.State == null || searchRequest.State == "")
                    {
                        otherOfficeDistance += Math.Round(OtherOfficeLocations.ProviderDistance, 2).ToString(CultureInfo.CurrentCulture) + " " + EmailBodyConstant.EmailMileHeading;
                        body += "<p style='color:#243e16;margin:0px;padding:0px;'><b>" + EmailBodyConstant.Label_EstimatedDistance + ":</b>" + otherOfficeDistance + "</p>";
                        body = body.Replace(EmailBodyConstant.Label_EstimatedDistance, Resources.lbl_EstimatedDistance);
                    }
                    string otherAddressLine1 = string.Empty;
                    string otherAddressLine2 = string.Empty;
                    if (OtherOfficeLocations.AddressLine1 != null)
                    { otherAddressLine1 += OtherOfficeLocations.AddressLine1; }
                     if (OtherOfficeLocations.AddressLine2 != null)
                    { otherAddressLine1 += OtherOfficeLocations.AddressLine2 + " "; }

                    //if (OtherOfficeLocations.AddressLine1 != null && OtherOfficeLocations.AddressLine2 != null)
                    //{ otherAddressLine2 += OtherOfficeLocations.AddressLine2 + " "; }
                    if (OtherOfficeLocations.CITY != null)
                    { otherAddressLine2 += OtherOfficeLocations.CITY + " "; }
                    if (OtherOfficeLocations.State != null)
                    { otherAddressLine2 += OtherOfficeLocations.State + " "; }

                    if (OtherOfficeLocations.Zipcode != null)
                    { otherAddressLine2 += OtherOfficeLocations.Zipcode; }

                    if (otherAddressLine1 != null)
                    {
                        body += "<p style='color:#243e16;margin:0px;padding:0px;'> <b>"+EmailBodyConstant.Label_Address+": </b>" + otherAddressLine1 + "</p>";
                        body = body.Replace(EmailBodyConstant.Label_Address, Resources.lbl_Address);
                    }
                    if (otherAddressLine2 != null)
                    {
                        body += "<p style='color:#243e16;margin:0px;padding:0px;'>" + otherAddressLine2 + "</p>";
                    }
                    body += "<br />";
                    if (i == 50)
                    { break; }
                }
                traceLog.AppendLine(" & End: EmailSendHelper, ReturnOtherOfficeAddress Method");
                return body;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// generate other office location object for sending text
        /// </summary>
        /// <param name="provider"></param>
        /// <param name="body"></param>
        /// <returns></returns>
        private static string ReturnOtherOfficeAddressForText(Aetna.ProviderContracts.DataContracts.Provider provider, string body, SearchRequestEntity searchRequest)
        {
            StringBuilder traceLog = new StringBuilder();

            if (provider == null)
                throw new ArgumentNullException(VariableConstant.Provider);
            try
            {
                traceLog.AppendLine("Start: EmailSendHelper, ReturnOtherOfficeAddressForText Method with Params provider: " + provider + " and with Param body: " + body + " and with Param searchRequest: " + searchRequest); 
                for (int i = 1; i < provider.OtherOfficeLocations.Count; i++)
                {
                    var OtherOfficeLocations = provider.OtherOfficeLocations[i];
                    body += "Hospital: <br />";
                    string otherOfficeDistance = string.Empty;
                    if (searchRequest.State == null || searchRequest.State == "")
                    {
                        otherOfficeDistance += Math.Round(OtherOfficeLocations.ProviderDistance, 2).ToString(CultureInfo.CurrentCulture) + " " + EmailBodyConstant.EmailMileHeading;
                        body += "Estimated Distance:" + otherOfficeDistance + "<br />";
                    }
                    string otherAddressLine1 = string.Empty; ;
                    string otherAddressLine2 = string.Empty;
                    if (OtherOfficeLocations.AddressLine1 != null)
                    { otherAddressLine1 += OtherOfficeLocations.AddressLine1; }
                     if (OtherOfficeLocations.AddressLine2 != null)
                    { otherAddressLine1 += OtherOfficeLocations.AddressLine2 + " "; }

                    //if (OtherOfficeLocations.AddressLine1 != null && OtherOfficeLocations.AddressLine2 != null)
                    //{ otherAddressLine2 += OtherOfficeLocations.AddressLine2 + " "; }
                    if (OtherOfficeLocations.CITY != null)
                    { otherAddressLine2 += OtherOfficeLocations.CITY + " "; }
                    if (OtherOfficeLocations.State != null)
                    { otherAddressLine2 += OtherOfficeLocations.State + " "; }

                    if (OtherOfficeLocations.Zipcode != null)
                    { otherAddressLine2 += OtherOfficeLocations.Zipcode; }

                    if (otherAddressLine1 != null)
                    {
                        body += "Address: " + otherAddressLine1 + "<br />";
                    }
                    if (otherAddressLine2 != null)
                    {
                        body += otherAddressLine2 + "<br />";
                    }
                    body += "<br />";
                   

                }
                traceLog.AppendLine(" & End: EmailSendHelper, ReturnOtherOfficeAddressForText Method");
                return body;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// send text for map details
        /// </summary>
        /// <param name="searchRequest"></param>
        /// <param name="direction"></param>
        /// <param name="provider"></param>
        /// <param name="emailAddress"></param>
        /// <param name="carrier"></param>
        /// <param name="providerNumberIndex"></param>
        /// <param name="providerNameDegree"></param>
        /// <param name="address"></param>
        /// <returns></returns>
        public static bool ReturnMapDetailsSendText(SearchRequestEntity searchRequest, Aetna.ProviderContracts.DataContracts.Provider provider, string emailAddress, string carrier, string[] providerNumberIndex, string providerNameDegree, string address, string culture)
        {
            StringBuilder traceLog = new StringBuilder();

            if (searchRequest == null)
                throw new ArgumentNullException("searchRequest");
            if (providerNumberIndex == null)
                throw new ArgumentNullException("providerNumberIndex");
            //if (direction == null)
              //  throw new ArgumentNullException("direction");
            try
            {
                traceLog.AppendLine("Start: EmailSendHelper, ReturnMapDetailsSendText Method with Params searchRequest: " + searchRequest + " and with Param provider: " + provider + " and with Param emailAddress: " + emailAddress + " with Param carrier: " + carrier + " and with Param providerNumberIndex: " + providerNumberIndex + " and with Param providerNameDegree: " + providerNameDegree + " and with Param address: " + address + " and with Param culture: " + culture); 
                int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                ManageContent contentManager = new ManageContent();
                RequestHeader requestForProviderDetails = new CommonHelper().GetRequestHeader(culture, networkId);
                provider = contentManager.GetProviderDetails(providerNumberIndex[0], providerNumberIndex[1].Replace("-", "/"), providerNumberIndex[2], searchRequest.ZipCode, requestForProviderDetails, searchRequest.ClientSpecificCode);

                bool emailto = false;
                bool carrierto = false;


                if (!string.IsNullOrEmpty(carrier))
                {
                    string[] smsGateWay = new string[1];
                    smsGateWay[0] = carrier;
                    string body = string.Empty;
                    ArrayList bodyForText = new ArrayList();
                    bodyForText = ReturnMapInformationForText(provider, body, searchRequest, providerNameDegree, address,providerNumberIndex);
                    for (int i = 0; i <= bodyForText.Count - 1; i++)
                    {

                        carrierto = contentManager.SendMail(bodyForText[i].ToString(), smsGateWay, VariableConstant.ProviderMapDetailsHeading);
                        if (carrierto == false)
                            break;
                    }
                }
                if (!string.IsNullOrEmpty(emailAddress))
                {
                    string[] emailAddresses = new string[1];
                    emailAddresses[0] = emailAddress;
                    string html = string.Empty;
                    html = "<style>table {border-collapse: collapse;}th{background-color: #cccccc;}th,td "
                    + "{text-align:centre;border: 1px solid #999999;padding: 5px;}</style>";
                    html += "<p style='color:#243e16;font-size:medium'>" + EmailBodyConstant.ProviderOnlineSearch + "</p>";
                    if (searchRequest.ClientSpecificCode != null && searchRequest.ClientSpecificNetwork != null)
                    {
                        html += "<p style='color:#243e16;font-size:medium'>" + searchRequest.ClientSpecificNetwork + "</p>";
                    }
                    else
                    {
                        html += "<p style='color:#243e16;font-size:medium'>" + searchRequest.NetworkType.NetworkName + "</p>";
                    }

                    html += "<h2 style='color:#0067a6;font-weight:bold;font-size:medium'>" + providerNameDegree + "</h2>";
                    if (provider.ProviderName != null)
                    {
                        providerNameDegree = EmailSendHelper.ReturnProviderName(provider);
                    }

                    string distance = string.Empty;
                    List<ProviderOffice> provOffice = new List<ProviderOffice>();
                    if (provider.OtherOfficeLocations != null)
                    {

                        provOffice = provider.OtherOfficeLocations.Where(x => x.ProvLocationID == providerNumberIndex[1].Replace("-", "/")
                                                                                && x.ProvTaxId == providerNumberIndex[2]).ToList();

                        distance = Math.Round(provOffice[0].ProviderDistance, 2).ToString(CultureInfo.CurrentCulture) + " " + VariableConstant.Miles;

                    }

                    if (address != null)
                    {
                        html += "<span style='color:#243e16;font-size:medium'>" + address + "</span>";
                        html += "<br />";
                    }

                    string phoneNumber = string.Empty;

                    if (provider.OtherOfficeLocations != null)
                    {

                        if (provOffice[0].PhoneExt != null && provOffice[0].PhoneExt != "")
                        {
                            phoneNumber += provOffice[0].PhoneExt;
                        }


                        if (provOffice[0].PhoneNbr != null && provOffice[0].PhoneNbr != "")
                        {
                            phoneNumber += provOffice[0].PhoneNbr;
                        }
                    }

                    html += "<span style='color:#0067a6;font-size:medium'>" + distance + "</span>";
                    html += "<br />";
                    html += "<span style='color:#0067a6;font-size:medium'>" + phoneNumber + "</span>";
                    html += "<br />";
                    html += "<br />";

                    html += "<table><tr><th colspan=4>Provider Direction</th></tr><tbody>";


                    //foreach (var item in direction)
                    //{
                    //    html += "<tr>";
                    //    html += "<td>&nbsp;";
                    //    html += "<img src='" + item.IconUrl + "'>  ";
                    //    if (item.SignUrl != null)
                    //    {
                    //        foreach (var signs in item.SignUrl)
                    //        {
                    //            html += "<img src='" + signs + "'>";
                    //        }
                    //    }

                    //    html += "</td>";
                    //    html += "<td>" + item.Narrative + "</td>";
                    //    html += "<td>" + item.Distance + " Miles</td>";
                    //    if (!string.IsNullOrEmpty(item.MapUrl))
                    //    {
                    //        html += "<td><img src='" + item.MapUrl + "'></td>";
                    //    }
                    //    else
                    //    {
                    //        html += "&nbsp;";
                    //    }
                    //    html += "</tr>";
                    //}
                    html += "</tbody></table>";
                    emailto = contentManager.SendMail(html, emailAddresses, VariableConstant.ProviderMapDetailsHeading);
                }
                bool value = false;
                if (carrierto || emailto)
                {
                    value = true;
                    traceLog.AppendLine(" & End: EmailSendHelper, ReturnMapDetailsSendText Method");
                    return value;
                }
                traceLog.AppendLine(" & End: EmailSendHelper, ReturnMapDetailsSendText Method");
                return value;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// send mail for map details
        /// </summary>
        /// <param name="searchRequest"></param>
        /// <param name="direction"></param>
        /// <param name="provider"></param>
        /// <param name="emailAddress"></param>
        /// <param name="carrier"></param>
        /// <param name="providerNumberIndex"></param>
        /// <param name="providerNameDegree"></param>
        /// <param name="address"></param>
        /// <returns></returns>
        public static bool ReturnMapDetails(SearchRequestEntity searchRequest, List<ProviderDirectionPath> direction, Aetna.ProviderContracts.DataContracts.Provider provider, string emailAddress, string carrier, string[] providerNumberIndex, string providerNameDegree, string address, string culture, string mailFrom)
        {
            StringBuilder traceLog = new StringBuilder();

            if (searchRequest == null)
                throw new ArgumentNullException("searchRequest");
            if (providerNumberIndex == null)
                throw new ArgumentNullException("providerNumberIndex");
            if (direction == null)
                throw new ArgumentNullException("direction");
            try
            {
                traceLog.AppendLine("Start: EmailSendHelper, ReturnMapDetails Method with Params searchRequest: " + searchRequest + " and with Param direction: " + direction + " and with Param provider: " + provider + " with Param emailAddress: " + emailAddress + " and with Param carrier: " + carrier + " and with Param providerNumberIndex: " + providerNumberIndex + " and with Param providerNameDegree: " + providerNameDegree + " and with Param address: " + address + " and with Param culture: " + culture+" and with Param mailFrom: "+mailFrom); 
                int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                ManageContent contentManager = new ManageContent();
                RequestHeader requestForProviderDetails = new CommonHelper().GetRequestHeader(culture, networkId);
                provider = contentManager.GetProviderDetails(providerNumberIndex[0], providerNumberIndex[1].Replace("-", "/"), providerNumberIndex[2], searchRequest.ZipCode, requestForProviderDetails, searchRequest.ClientSpecificCode);

                bool emailto = false;
                bool carrierto = false;


                if (!string.IsNullOrEmpty(carrier))
                {
                    string[] smsGateWay = new string[1];
                    smsGateWay[0] = carrier;
                    string body = string.Empty;
                    ArrayList bodyForText = new ArrayList();
                    bodyForText = ReturnMapInformationForText(provider, body, searchRequest, providerNameDegree, address,providerNumberIndex);
                    for (int i = 0; i <= bodyForText.Count - 1; i++)
                    {

                        carrierto = contentManager.SendMail(bodyForText[i].ToString(), smsGateWay, VariableConstant.ProviderMapDetailsHeading);
                        if (carrierto == false)
                            break;
                    }
                }
                if (!string.IsNullOrEmpty(emailAddress))
                {
                    string[] emailAddresses = new string[1];
                    emailAddresses[0] = emailAddress;
                    string html = string.Empty;
                    html = "<style>table {border-collapse: collapse;}th{background-color: #cccccc;}th,td "
                    + "{text-align:centre;border: 1px solid #999999;padding: 5px;}</style>";
                    html += "<p style='color:#243e16;font-size:medium'>" + EmailBodyConstant.ProviderOnlineSearch + "</p>";
                    if (searchRequest.ClientSpecificCode != null && searchRequest.ClientSpecificNetwork != null)
                    {
                        html += "<p style='color:#243e16;font-size:medium'>" + searchRequest.ClientSpecificNetwork + "</p>";
                    }
                    else
                    {
                        html += "<p style='color:#243e16;font-size:medium'>" + searchRequest.NetworkType.NetworkName + "</p>";
                    }

                    html += "<h2 style='color:#0067a6;font-weight:bold;font-size:medium'>" + providerNameDegree + "</h2>";
                    if (provider.ProviderName != null)
                    {
                        providerNameDegree = EmailSendHelper.ReturnProviderName(provider);
                    }

                    string distance = string.Empty;
                    List<ProviderOffice> provOffice = new List<ProviderOffice>();
                    if (provider.OtherOfficeLocations != null)
                    {
                        decimal distanceDecimal = provider.OtherOfficeLocations[0].ProviderDistance;
                        distance = Math.Round(distanceDecimal, 2).ToString(CultureInfo.CurrentCulture) + " " + VariableConstant.Miles;

                        provOffice = provider.OtherOfficeLocations.Where(x => x.ProvLocationID == providerNumberIndex[1].Replace("-", "/")
                                                                                && x.ProvTaxId == providerNumberIndex[2]).ToList();
                        
                        distance = Math.Round(provOffice[0].ProviderDistance, 2).ToString(CultureInfo.CurrentCulture) + " " + VariableConstant.Miles;

                    }

                    if (address != null)
                    {
                        html += "<span style='color:#243e16;font-size:medium'>" + address + "</span>";
                        html += "<br />";
                    }

                    string phoneNumber = string.Empty;
                    if (provider.OtherOfficeLocations[0].PhoneExt != null)
                    { phoneNumber += provider.OtherOfficeLocations[0].PhoneExt; }
                    if (provider.OtherOfficeLocations[0].PhoneNbr != null)
                    { phoneNumber += provider.OtherOfficeLocations[0].PhoneNbr; }

                    if (provider.OtherOfficeLocations != null)
                    {

                        if (provOffice[0].PhoneExt != null && provOffice[0].PhoneExt != "")
                        {
                            phoneNumber += provOffice[0].PhoneExt;
                        }


                        if (provOffice[0].PhoneNbr != null && provOffice[0].PhoneNbr != "")
                        {
                            phoneNumber += provOffice[0].PhoneNbr;
                        }
                    }

                    html += "<span style='color:#0067a6;font-size:medium'>" + distance + "</span>";
                    html += "<br />";
                    html += "<span style='color:#0067a6;font-size:medium'>" + phoneNumber + "</span>";
                    html += "<br />";
                    html += "<br />";

                    html += "<table><tr><th colspan=4>Provider Direction</th></tr><tbody>";


                    foreach (var item in direction)
                    {
                        html += "<tr>";
                        html += "<td>&nbsp;";
                        html += "<img src='" + item.IconUrl + "'>  ";
                        if (item.SignUrl != null)
                        {
                            foreach (var signs in item.SignUrl)
                            {
                                html += "<img src='" + signs + "'>";
                            }
                        }

                        html += "</td>";
                        html += "<td>" + item.Narrative + "</td>";
                        html += "<td>" + item.Distance + " Miles</td>";
                        if (!string.IsNullOrEmpty(item.MapUrl))
                        {
                            html += "<td><img src='" + item.MapUrl + "'></td>";
                        }
                        else
                        {
                            html += "&nbsp;";
                        }
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    emailto = contentManager.SendMail(html, emailAddresses, VariableConstant.ProviderMapDetailsHeading, mailFrom);
                }
                bool value = false;
                if (carrierto || emailto)
                {
                    value = true;
                    traceLog.AppendLine(" & End: EmailSendHelper, ReturnMapDetails Method");
                    return value;
                }
                traceLog.AppendLine(" & End: EmailSendHelper, ReturnMapDetails Method");
                return value;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// returns body for sending map details as text message
        /// </summary>
        /// <param name="direction"></param>
        /// <param name="provider"></param>
        /// <param name="html"></param>
        /// <param name="searchRequest"></param>
        /// <param name="providerNameDegree"></param>
        /// <param name="address"></param>
        /// <returns></returns>
        private static ArrayList ReturnMapInformationForText(Aetna.ProviderContracts.DataContracts.Provider provider, string body, SearchRequestEntity searchRequest, string providerNameDegree, string address, string[] providerNumberIndex)
        {
            StringBuilder traceLog = new StringBuilder();

            int addressLoc = 0;
            ArrayList bodyPart = new ArrayList();
            string body2 = " ";
            string checklength = "";
            if (searchRequest == null)
                throw new ArgumentNullException("searchRequest");
            if (provider == null)
                throw new ArgumentNullException("provider");
            try
            {
                traceLog.AppendLine("Start: EmailSendHelper, ReturnMapInformationForText Method with Params provider: " + provider + " and with Param body: " + body + " and with Param searchRequest: " + searchRequest + " with Param providerNameDegree: " + providerNameDegree + " and with Param address: " + address + " and with Param providerNumberIndex: " + providerNumberIndex); 
                //body += EmailBodyConstant.ProviderOnlineSearch + "<br /><br />";
                body += searchRequest.NetworkType.NetworkName.TrimEnd().TrimStart() + " ";



                //string providerNameDegree = string.Empty;
                if (provider.ProviderName != null)
                {
                    providerNameDegree = ReturnProviderName(provider);
                    body += providerNameDegree.TrimEnd().TrimStart() + " ";
                }
                string addressLine1 = string.Empty;
                string addressLine2 = string.Empty;
                string distance = string.Empty;
                if (provider.OtherOfficeLocations != null)
                {
                    for (int i = 0; i < provider.OtherOfficeLocations.Count; i++)
                    {
                        if (provider.OtherOfficeLocations[i].ProvLocationID == providerNumberIndex[1] && provider.OtherOfficeLocations[i].ProvTaxId == providerNumberIndex[2])
                        {
                            addressLoc = i;
                            break;
                        }
                    }
                    if (provider.OtherOfficeLocations[addressLoc].AddressLine1 != null)
                    { addressLine1 += provider.OtherOfficeLocations[addressLoc].AddressLine1 + " "; }
                    else if (provider.OtherOfficeLocations[addressLoc].AddressLine2 != null)
                    { addressLine1 += provider.OtherOfficeLocations[addressLoc].AddressLine2 + " "; }

                    if (provider.OtherOfficeLocations[addressLoc].AddressLine1 != null && provider.OtherOfficeLocations[addressLoc].AddressLine2 != null)
                    { addressLine2 += provider.OtherOfficeLocations[addressLoc].AddressLine2 + " "; }

                    if (provider.OtherOfficeLocations[addressLoc].CITY != null)
                    { addressLine2 += provider.OtherOfficeLocations[addressLoc].CITY + " "; }

                    if (provider.OtherOfficeLocations[addressLoc].State != null)
                    { addressLine2 += provider.OtherOfficeLocations[addressLoc].State + " "; }

                    if (provider.OtherOfficeLocations[addressLoc].Zipcode != null)
                    { addressLine2 += provider.OtherOfficeLocations[addressLoc].Zipcode; }


                    decimal distanceDecimal = provider.OtherOfficeLocations[addressLoc].ProviderDistance;
                    distance = Math.Round(distanceDecimal, 2).ToString(CultureInfo.CurrentCulture) + " " + VariableConstant.Miles;

                }


                if (addressLine1 != null)
                {
                    body2 += addressLine1.TrimEnd().TrimStart();
                    body2 += " ";

                }
                if (addressLine2 != null)
                {

                    body2 += addressLine2.TrimEnd().TrimStart();
                    body2 += " ";
                    //body2 = body2.Replace(EmailBodyConstant.Distance, distance);
                    //body2 += distance.TrimEnd().TrimStart() + " ";
                    //body += "<br />";
                    string phoneNumber = string.Empty;
                    if (provider.OtherOfficeLocations[addressLoc].PhoneExt != null)
                    { phoneNumber += provider.OtherOfficeLocations[0].PhoneExt; }
                    if (provider.OtherOfficeLocations[addressLoc].PhoneNbr != null)
                    { phoneNumber += provider.OtherOfficeLocations[0].PhoneNbr; }

                    body2 += "Ph: " + phoneNumber.TrimEnd().TrimStart() + " ";



                }
                checklength = body + body2;
                if (checklength.Length <= 140)
                    bodyPart.Add(checklength);
                else
                {
                    bodyPart.Add("(1/2) " + body);
                    bodyPart.Add("(2/2)" + body2);

                }
                traceLog.AppendLine(" & End: EmailSendHelper, ReturnMapInformationForText Method");
                return bodyPart;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

    }

}




