﻿//saving the provider selected to session

function ChoosingAcceptingNewPatients(providertypeid,event) {
    //debugger;
   
    if (providertypeid == 1) {
        $('#ProviderAcceptingNewPatient').show();
        $('#Physician label').addClass('active');
        $('#Except_Physician label').removeClass('active');
        $('#All label').removeClass('active');
        event.stopPropagation()
    }
    else {
        $('#AcceptingNewPatients').prop('checked', false);
        $('#ProviderAcceptingNewPatient').hide();
        
    }
    if (providertypeid == 0) {
        $('#ProviderAcceptingNewPatient_All').show();
        $('#All label').addClass('active');
        $('#Physician label').removeClass('active');
        $('#Except_Physician label').removeClass('active');
        event.stopPropagation()
    }
    else {
        $('#AcceptingNewPatients_All').prop('checked', false);
        $('#ProviderAcceptingNewPatient_All').hide();       
    }
   
    
}
function ProviderTypeSelection() {

    // debugger;
    var searchRequest = new Object();
    var providerType = new Object();
    var forgeryId = $("#forgeryToken").val();
    providerType.ProviderTypeID = $('input[name="ProviderType"]:checked').val();
    providerType.ProviderTypeName = $('input[name="ProviderType"]:checked').attr('provider-name');
    searchRequest.ProviderType = providerType;
    searchRequest.AcceptingNewPatients = $('input[name="ProviderAcceptingNewPatient"]:checked').val();
    searchRequest.CustomerType = $('input[name=UserType]:checked').val();
    searchRequest.ClientSpecificCode = $("#txtClientSpcNet").val();
    var NetworkType = new Object();
    NetworkType.NetworkId = $('input[name=NetworkType]:checked').val();
    NetworkType.NetworkName = $('input[name=NetworkType]:checked').attr('networktype-name');
    searchRequest.NetworkType = NetworkType;
    $.ajax({
        type: 'POST',
        url: '/LocateProviderMobile/SaveSearchRequestToSession',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        data: JSON.stringify({ search: searchRequest }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            window.location.href = '/LocateProviderMobile/SearchIndex/';
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });

}
