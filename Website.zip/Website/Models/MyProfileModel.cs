﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using NABWebsite.DTO;

namespace NABWebsite.Models
{
    public class MyProfileModel
    {
        public MyProfile MyProfile { get; set; }
        public string RecaptchaPublicKey { get; set; }
        public string GoogleRecaptchaAPIAddressSingle { get; set; }
        //public List<ImageDetails> SecureImageListRef { get; set; }
        //public int SelectedImageIdRef { get; set; }
        //public ImageDetails SelectedImageRef { get; set; }

       
    }
}