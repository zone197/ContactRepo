﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NABWebsite.Models
{
    public class ClaimAppealForm
    {
        [Required(ErrorMessage = "Please enter Claim Number")]
        public string ClaimNum { get; set; }

        [Required(ErrorMessage = "Reason For Appeal cannot be empty")]       
        public string ReasonForAppeal { get; set; }

        [Required(ErrorMessage = "Please enter Amount")]       
        public string ExpectedAmt { get; set; }

         [Required(ErrorMessage = "Please Select an option")]
        public bool AttempForClaim { get; set; }
       
        public string ReferenceNum { get; set; }       
       
        public string AdditionalDetails { get; set; }

        [Required(ErrorMessage = "Contact Name cannot be empty")]       
        [RegularExpression("[a-zA-Z0-9\\-\\s]+", ErrorMessage = "Please enter a valid Contact Name")]
        public string ContactName { get; set; }
       
        //[RegularExpression("[0-9\\-\\+\\, ]+", ErrorMessage = "Please enter a valid Phone No.")]
         [Required(ErrorMessage = "Please enter Contact Number")]
        public string ContactNum { get; set; }

        [Required(ErrorMessage = "Please enter MailId")]
        [RegularExpression(".+\\@.+\\..+", ErrorMessage = "Please enter a valid Email")]
        public string ContactEmail { get; set; }

    }
}