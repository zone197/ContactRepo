﻿using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Helper;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.Mvc;
using ErrorLogService = Aetna.Service.Contracts;

namespace NABWebsite.Controllers
{
    public class DemographicUpdateController : Controller
    {
        private const string CONST_SUCCESS = "Success";
        // GET: DemographicUpdate
        public ActionResult Index()
        {
            try
            {
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.DemographicUpdateHeader;
                return View();
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult DemographicUpdate(DemographicUpdateForm formDetails)
        {
            try
            {
                DemographicUpdateForm details = new DemographicUpdateForm();
                string body = string.Empty;
                Boolean success;
                string FileName = "";
                byte[] binData = null;

                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }

                Session[Constants.Header] = Constants.DemographicUpdateHeader;
                if (ModelState.IsValid)
                {
                    if (formDetails.Files != null)
                    {
                        if (formDetails.Files.ContentType.Contains("pdf"))
                        {
                            if (formDetails.Files.ContentLength < Convert.ToInt32(ConfigurationManager.AppSettings["pdfFileContentLength"]))
                            {
                                FileName = Path.GetFileName(formDetails.Files.FileName);
                                //Improper Resource Shutdown or release Security Vulnerability issue fix on 14-Mar-2019
                                using (BinaryReader b = new BinaryReader(formDetails.Files.InputStream))
                                {
                                    try
                                    {
                                        binData = b.ReadBytes(formDetails.Files.ContentLength);
                                    }
                                    catch (Exception ex)
                                    {
                                        throw;
                                    }
                                    finally
                                    {
                                        if (b != null)
                                        {
                                            b.Close();
                                            b.Dispose();
                                        }
                                    }
                                }
                            }
                            else
                            {
                                ModelState.AddModelError("Files", "Please upload document of size less than 10MB");
                                return View("Index", formDetails);
                            }
                        }
                        else
                        {
                            ModelState.AddModelError("Files", "Please upload document in pdf format only");
                            return View("Index", formDetails);
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("Files", "The details of this request on your letterhead must be attached");
                        return View("Index", formDetails);
                    }
                    using (StreamReader reader = new StreamReader(Server.MapPath("~/Views/DemographicUpdate/EmailTemplate.html")))
                    {
                        body = reader.ReadToEnd();
                    }
                    body = body.Replace("{ProviderName}", formDetails.ProviderName);
                    body = body.Replace("{TIN}", formDetails.TIN);
                    body = body.Replace("{DemographicChangeType}", formDetails.DemographicChangeType);
                    body = body.Replace("{TeleMedicineService}", formDetails.TeleMedicineService);
                    body = body.Replace("{TeleMedicineLocation}", formDetails.TeleMedicineLocation);
                    body = body.Replace("{ReasonForDemographicChange}", formDetails.ReasonForDemographicChange);
                    body = body.Replace("{NPI}", string.IsNullOrEmpty(formDetails.NPI) ? "N/A" : formDetails.NPI);
                    body = body.Replace("{CAQH}", string.IsNullOrEmpty(formDetails.CAQH) ? "N/A" : formDetails.CAQH);
                    body = body.Replace("{ContactName}", formDetails.ContactName);
                    body = body.Replace("{ContactNum}", string.IsNullOrEmpty(formDetails.ContactNum) ? "N/A" : formDetails.ContactNum);
                    body = body.Replace("{ContactEmail}", string.IsNullOrEmpty(formDetails.ContactEmail) ? "N/A" : formDetails.ContactEmail);


                    ManageContent contentManager = new ManageContent();
                    string[] emailAddresses;
                    var email = ConfigurationManager.AppSettings["FromDemographicUpdateFormInfo"];
                    List<string> emailAddressesList = new List<string>();
                    if (!string.IsNullOrEmpty(email)) emailAddressesList.Add(email);
                    emailAddresses = emailAddressesList.ToArray();
                    string subjectLine = VariableConstant.DemographicUpdateFormInfoSubject + " " + formDetails.TIN + " " + formDetails.ProviderName;
                    success = contentManager.SendMailDemographicUpdateFormInfo(body, emailAddresses, subjectLine, formDetails.concatRequest, binData, FileName);
                    if (success == true)
                    {
                        formDetails.Status = "true";
                        return Content("<script type='text/javascript'>alert('Your form has been submitted.');window.location.href='/DemographicUpdate/Index';</script>");
                    }
                    else
                    {
                        formDetails.Status = "false";
                        return Content("<script type='text/javascript'>alert('Your form cannot be submitted due to some error.');window.location.href='/DemographicUpdate/Index';</script>");
                    }
                }
                else
                {
                    return View("Index");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return View();
        }
    }
}