﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;
namespace NABWebsite.Models
{
    //ViewModel for "Secure Email"
    public class SecureEmailModel
    {
        public SecureEmail Email { get; set; }
        public bool CustomerServiceAccess { get; set; }

    }

    
}