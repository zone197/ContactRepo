﻿$(document).ready(function () {
    $(document).find('.ui-slider-handle').css('border-radius', '15px');
    $(document).find('.ui-slider-handle').css('outline', 'none');
    $(document).find('.ui-slider-horizontal').css('border', '1px solid #8dc641');
    $(document).find('.ui-slider-handle').css('top', '-0.7em');
    $(document).find('.ui-slider-handle').css('width', '1.8em');
    $(document).find('.ui-slider-handle').css('height', '1.8em');

    $('input[name=searchBy]').on('change', function (e) {
        $('#showpanel').slideUp("slow");
        GetResources("lblShowOptions");
    })


})

function functionClear() {
    //debugger;
    $('input[name=ProviderType]').attr('checked', false);
    $("#txtZipCode").val("");
    $("#txtProviderName").val("");
    $("#txtTIN").val("");
    //$("#SearchState option").prop("value", "");

    $('#SearchState option[selected="selected"]').each(function () {
        $(this).removeAttr('selected');
    })

    $("#SearchState option:first").attr('selected', 'selected');
    $("#rbByState").prop('checked', false);
    $("#rbByZip").prop('checked', true);
    $("#zipDiv").show();
    $("#stateDiv").hide();
    //$("#SpecialityOrCondition").attr('checked', false);

    //$("#SearchCounty").val("");
    //$("#SearchCity").val("");
    $("#SelectCondition").val("");
    $("#selectedCondition").val("");
    $("#specialities").val("");
    $("#selectedSpeciality").val("");
    $("#headingErrorMsg").empty();
    $("#errorMsgZipState").empty();
    $("#ErrorMessageForInfo").empty();
    $("#errorMsgProviderType").empty();
    $("#btnAddRemoveError").empty();
    $('#errorMsgTinOrProvider').empty();
    $('#SearchState').dropdown('restore defaults');
    $('#SearchCounty').dropdown('restore defaults');
    $('#SearchCity').dropdown('restore defaults');
        
    $('#specialities').empty();
    $('#SelectCondition').empty();

    $('#txtRadiusValue').val("10");
    $('#RadiusSlider').slider({
        value: $('#txtRadiusValue').val()
    });

    $('#showpanel').slideUp("slow");
    GetResources("lblShowOptions");
}