﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Models;
using System.Globalization;
using System.Text;
using System.Configuration;
using System.Web.Security.AntiXss;
using Utilities;

namespace NABWebsite.Controllers
{
    public class UserAccessVerificationController : BaseController
    {
        UserAccessVerificationBLL objBll = new UserAccessVerificationBLL();
        ProviderVerification bllObject = new ProviderVerification();
        //StringBuilder traceLog = new StringBuilder();
        /// <summary>
        /// get index page for user access verification
        /// </summary>
        /// <returns>ActionResult</returns>
        [CheckAccess(Function = "Verify User Access")]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
           
            try
            {                
                traceLog.AppendLine("Start: UserAccessVerificationController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: UserAccessVerificationController, Index Method");
                    return RedirectToAction("Index", "Home");
                }

                Session[Constants.CurrentController] = Constants.UserAccessVerification;
                Session[Constants.CurrentAction] = Constants.Index;
                Session[Constants.Header] = Constants.UserAccessVerificationSpaceHead;



                if (ConfigurationManager.AppSettings[Constants.Site] == Constants.External)
                {
                    UserAccessVerification userAccessVerificationEntity = new UserAccessVerification();
                    UserVerification modelObject = new UserVerification();
                    modelObject.UserAccess = userAccessVerificationEntity;
                    if (modelObject.UserAccess.PageNo == 0)
                        modelObject.UserAccess.PageNo = 1;

                     SetUserAccess(modelObject);

                    if (modelObject.UserAccess.UserRole == Constants.Provider)
                    {
                        modelObject.UserAccess = objBll.GetUserAccessDetails(modelObject.UserAccess);
                        modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                        traceLog.AppendLine(" & End: UserAccessVerificationController, Index Method");
                        return View("UserAccessResult", modelObject);
                    }
                    else if (modelObject.UserAccess.UserRole == Constants.Payer)
                    {
                        modelObject.UserAccess = objBll.GetUserAccessDetailsForPayer(modelObject.UserAccess);
                        modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                        traceLog.AppendLine(" & End: UserAccessVerificationController, Index Method");
                        return View("UserAccessResultPayer", modelObject);
                    }
                    traceLog.AppendLine(" & End: UserAccessVerificationController, Index Method");
                    return Redirect("/Error/Index");
                }
                else
                {
                    UserAccessVerification userAccessVerificationEntity = new UserAccessVerification();
                    UserVerification modelObject = new UserVerification();
                    modelObject.UserAccess = userAccessVerificationEntity;
                    SetUserAccess(modelObject);
                    if (modelObject.UserAccess.UserRole == Constants.Payer)
                    {
                        modelObject.UserAccess.AllClient = new List<SelectListItem>();
                        modelObject.UserAccess.AllClient = objBll.GetAllClient(modelObject.UserAccess);
                        modelObject.UserAccess.AllSubClient = new List<SelectListItem>() { new SelectListItem() { Text = Constants.SelectSubClient, Value = Constants.SelectSubClient } };
                    }
                    traceLog.AppendLine(" & End: UserAccessVerificationController, Index Method");
                    return View("UserSearch", modelObject);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }
        }

        /// <summary>
        /// Search Result page for user access verfication
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Verify User Access")]
        [HttpPost]
        public ActionResult UserSearch(UserVerification modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserAccessVerificationController, UserSearch Method with Param modelObject: " + modelObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: UserAccessVerificationController, UserSearch Method");
                    return RedirectToAction("Index", "Home");
                }

                if (modelObject != null)
                {
                    if (modelObject.UserAccess.PageNo == Constants.ZeroCount)
                        modelObject.UserAccess.PageNo = Constants.OneCount;

                    SetUserAccess(modelObject);

                    if (modelObject.UserAccess.UserRole == Constants.Provider)
                    {
                        modelObject.UserAccess = objBll.GetUserAccessDetails(modelObject.UserAccess);
                    }
                    else if (modelObject.UserAccess.UserRole == Constants.Payer)
                    {
                        modelObject.UserAccess.AllClient = new List<SelectListItem>();
                        modelObject.UserAccess.AllSubClient = new List<SelectListItem>();
                        modelObject.UserAccess.AllClient = objBll.GetAllClient(modelObject.UserAccess);
                        modelObject.UserAccess.AllSubClient = GetSubClientByClient(modelObject.UserAccess.ClientNumber);
                        modelObject.UserAccess = objBll.GetUserAccessDetailsForPayer(modelObject.UserAccess);
                    }

                    modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                    traceLog.AppendLine(" & End: UserAccessVerificationController, UserSearch Method");
                    return View("UserSearch", modelObject);
                }
                traceLog.AppendLine(" & End: UserAccessVerificationController, UserSearch Method");
                return Redirect("/Error/Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }


        /// <summary>
        /// pagination and sorting logic implementation for result set in user access verification
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult UserDetailsPartial(UserVerification modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserAccessVerificationController, UserDetailsPartial Method with Param modelObject: " + modelObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: UserAccessVerificationController, UserDetailsPartial Method");
                    return Content(Constants.ContentHome);
                }

                if (modelObject != null)
                {
                    if (modelObject.UserAccess.PageNo == Constants.ZeroCount)
                        modelObject.UserAccess.PageNo = Constants.OneCount;

                    SetUserAccess(modelObject);

                    if (modelObject.UserAccess.UserRole == Constants.Provider)
                    {
                        modelObject.UserAccess = objBll.GetUserAccessDetails(modelObject.UserAccess);
                        modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                        traceLog.AppendLine(" & End: UserAccessVerificationController, UserDetailsPartial Method");
                        return PartialView("_SearchTinUser", modelObject);
                    }
                    else if (modelObject.UserAccess.UserRole == Constants.Payer)
                    {
                        modelObject.UserAccess.AllClient = new List<SelectListItem>();
                        modelObject.UserAccess.AllSubClient = new List<SelectListItem>();
                        modelObject.UserAccess.AllClient = objBll.GetAllClient(modelObject.UserAccess);
                        modelObject.UserAccess.AllSubClient = GetSubClientByClient(modelObject.UserAccess.ClientNumber);
                        modelObject.UserAccess = objBll.GetUserAccessDetailsForPayer(modelObject.UserAccess);
                        modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                        traceLog.AppendLine(" & End: UserAccessVerificationController, UserDetailsPartial Method");
                        return PartialView("_SearchTinUserForPayer", modelObject);
                    }

                }
                traceLog.AppendLine(" & End: UserAccessVerificationController, UserDetailsPartial Method");
                return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }
        }

        /// <summary>
        /// load user remove confirmation page with data selected
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Verify User Access")]
        public ActionResult UserRemoveConfirmation(UserVerification modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserAccessVerificationController, UserRemoveConfirmation Method with Param modelObject: " + modelObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: UserAccessVerificationController, UserRemoveConfirmation Method");
                    return RedirectToAction("Index", "Home");
                }

                if (modelObject != null)
                {
                    SetUserAccess(modelObject);
                    User requestor = new User();
                    requestor = objBll.GetUserDetails(modelObject.UserAccess.Userid, modelObject.UserAccess.UserType);

                    if (modelObject.UserAccess.UserRole == Constants.Provider)
                    {
                        modelObject.UserAccess = objBll.GetUserAccessDetails(modelObject.UserAccess);
                        modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                    }
                    else if (modelObject.UserAccess.UserRole == Constants.Payer)
                    {
                        modelObject.UserAccess.AllClient = new List<SelectListItem>();
                        modelObject.UserAccess.AllSubClient = new List<SelectListItem>();
                        modelObject.UserAccess.AllClient = objBll.GetAllClient(modelObject.UserAccess);
                        modelObject.UserAccess.AllSubClient = GetSubClientByClient(modelObject.UserAccess.ClientNumber);
                        modelObject.UserAccess = objBll.GetUserAccessDetailsForPayer(modelObject.UserAccess);
                        modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                    }
                    //modelObject.UserAccess = objBll.GetUserAccessDetails(modelObject.UserAccess);
                    //modelObject.UsersModel = modelObject.UserAccess.Users.ToList();

                    string[] index = modelObject.Indexes.Split('+');

                    modelObject.UsersModel = (from p in modelObject.UsersModel
                                              where index.Contains(p.Id)
                                              select p).ToList<UserClass>();


                    StringBuilder changesText = new StringBuilder();
                    List<UserClass> userList = new List<UserClass>();
                    foreach (var item in modelObject.UsersModel)
                    {
                        UserClass user = new UserClass();
                        user.CheckSelect = item.CheckSelect;
                        user.Company = item.Company;
                        user.EntityNo = item.EntityNo;
                        user.User = item.User;
                        user.UserId = item.UserId;
                        user.Phone = item.Phone;
                        user.Id = item.Id;
                        user.Network = item.Network;
                        user.ProviderId = item.ProviderId;
                        user.ProviderName = item.ProviderName;
                        user.PayerNumber = item.PayerNumber;
                        user.GroupName = item.GroupName;
                        user.GroupNumber = item.GroupNumber;
                        user.TaxId = item.TaxId;

                        changesText.Append(Constants.User);
                        changesText.Append(item.User);
                        changesText.Append(Constants.Company);
                        changesText.Append(item.Company);

                        if (modelObject.UserAccess.UserRole == Constants.Payer)
                        {
                            string payerName = (from list in modelObject.UserAccess.AllClient
                                                where list.Value.ToUpper().Equals(item.PayerNumber.ToUpper())
                                                select list.Text).FirstOrDefault();
                            if (!string.IsNullOrEmpty(payerName))
                            {
                                payerName = payerName.ToUpper().Replace(item.PayerNumber.ToUpper(), "").Replace("(", "").Replace(")", "");                                
                            }
                            else
                            {
                                payerName = string.Empty;
                            }
                            changesText.Append("Payer Number");
                            changesText.Append(item.PayerNumber);
                            changesText.Append("Payer Name");
                            changesText.Append(payerName);
                            changesText.Append("Group Number");
                            changesText.Append(item.GroupNumber);
                            changesText.Append("Group Name");
                            changesText.Append(item.GroupName);
                            user.PayerName = payerName;
                        }
                        else if (modelObject.UserAccess.UserRole == Constants.Provider)
                        {
                            changesText.Append(Constants.TaxId);
                            changesText.Append(item.TaxId);
                            changesText.Append(Constants.EntityNumber);
                            changesText.Append(item.EntityNo);
                        }
                        changesText.Append("~~");
                        userList.Add(user);
                    }
                    modelObject.UsersModel = userList;
                    modelObject.SelectedChange = changesText.ToString();
                    traceLog.AppendLine(" & End: UserAccessVerificationController, UserRemoveConfirmation Method");
                    return View("UserRemoveConfirmation", modelObject);
                }
                traceLog.AppendLine(" & End: UserAccessVerificationController, UserRemoveConfirmation Method");
                return Redirect("/Error/Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }


        /// <summary>
        /// approve termination for data selected and show alert
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Verify User Access")]
        public ActionResult ApproveTermination(UserVerification modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserAccessVerificationController, ApproveTermination Method with Param modelObject: " + modelObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: UserAccessVerificationController, ApproveTermination Method");
                    return RedirectToAction("Index", "Home");
                }
                if (modelObject != null)
                {
                    SetUserAccess(modelObject);

                    User requestor = new User();
                    requestor = objBll.GetUserDetails(modelObject.UserAccess.Userid, modelObject.UserAccess.UserType);

                    if (modelObject.UserAccess.UserRole == Constants.Provider)
                    {
                        modelObject.UserAccess = objBll.GetUserAccessDetails(modelObject.UserAccess);
                        modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                    }
                    else if (modelObject.UserAccess.UserRole == Constants.Payer)
                    {
                        modelObject.UserAccess.AllClient = new List<SelectListItem>();
                        modelObject.UserAccess.AllSubClient = new List<SelectListItem>();
                        modelObject.UserAccess.AllClient = objBll.GetAllClient(modelObject.UserAccess);
                        modelObject.UserAccess.AllSubClient = GetSubClientByClient(modelObject.UserAccess.ClientNumber);
                        modelObject.UserAccess = objBll.GetUserAccessDetailsForPayer(modelObject.UserAccess);
                        modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                    }


                    string[] index = modelObject.Indexes.Split('+');

                    modelObject.UsersModel = (from p in modelObject.UsersModel
                                              where index.Contains(p.Id)
                                              select p).ToList<UserClass>();

                    List<UserAccessDetail> removedUser = new List<UserAccessDetail>();
                    foreach (var item in modelObject.UsersModel)
                    {
                        UserAccessDetail link = new UserAccessDetail();

                        link.CompanyName = item.Company;
                        link.UserName = item.User;
                        link.UserId = item.UserId;
                        link.RequestorCompanyName = requestor.CompanyName;
                        link.RequestorEmail = requestor.Email;
                        link.RequestorId = modelObject.UserAccess.Userid;
                        link.RequestorName = requestor.FirstName + " " + requestor.LastName;
                        link.RequestorPhone = requestor.BusinessPhone;
                        link.RequestorTitle = requestor.Title;
                        link.SubmittedOn = DateTime.Now.ToString();
                        link.Tin = item.TaxId;
                        link.ProviderNumber = item.ProviderId;
                        link.PayorNumber = item.PayerNumber;
                        link.GroupNumber = item.GroupNumber;
                        removedUser.Add(link);
                    }

                    objBll.SendForAdminQueue(removedUser, modelObject.UserAccess.Userid, modelObject.UserAccess.UserType);


                    bllObject.InsertChangedData(modelObject.SelectedChange, modelObject.UserAccess.Userid, modelObject.UserAccess.Userid);

                    string userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    string userType = ConfigurationManager.AppSettings[Constants.Site];


                    string requesterName = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    string toMailUser = requestor.Email;
                    string[] mailIdUser = new string[1];
                    mailIdUser[0] = toMailUser;
                    string toMailProvider = ConfigurationManager.AppSettings[Constants.ProviderRelations];
                    string[] mailIdProvider = new string[1];
                    mailIdProvider[0] = toMailProvider;
                    string[] bccMailId = new string[1];
                    string mailIdBCC = ConfigurationManager.AppSettings[Constants.BCCMailAddress];
                    bccMailId[0] = mailIdBCC;
                    ProviderVerification providerObjBll = new ProviderVerification();
                    providerObjBll.SendMail(GetMailBody(modelObject.SelectedChange), mailIdUser, bccMailId, Constants.UserAccessMessageUser);
                    providerObjBll.SendMail(GetMailBodyInt(modelObject.SelectedChange, userId, requestor), mailIdProvider, bccMailId, Constants.UserAccessMessageAdmin);

                    traceLog.AppendLine(" & End: UserAccessVerificationController, ApproveTermination Method");
                    return Content(Constants.ContentUserAccessVerification);
                }
                traceLog.AppendLine(" & End: UserAccessVerificationController, ApproveTermination Method");
                return Redirect("/Error/Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }
        }


        /// <summary>
        /// load Information is valid page
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Verify User Access")]
        public ActionResult InformationIsValid(UserVerification modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserAccessVerificationController, InformationIsValid Method with Param modelObject: " + modelObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: UserAccessVerificationController, InformationIsValid Method");
                    return RedirectToAction("Index", "Home");
                }

                if (modelObject != null)
                {
                    SetUserAccess(modelObject);
                   
                    if (modelObject.UserAccess.UserRole == Constants.Provider)
                    {
                        modelObject.UserAccess = objBll.GetUserAccessDetails(modelObject.UserAccess);
                        modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                    }
                    else if (modelObject.UserAccess.UserRole == Constants.Payer)
                    {                        
                        modelObject.UserAccess.AllClient = new List<SelectListItem>();
                        modelObject.UserAccess.AllSubClient = new List<SelectListItem>();                        
                        modelObject.UserAccess.AllClient = objBll.GetAllClient(modelObject.UserAccess);                        
                        modelObject.UserAccess.AllSubClient = GetSubClientByClient(modelObject.UserAccess.ClientNumber);                        
                        modelObject.UserAccess = objBll.GetUserAccessDetailsForPayer(modelObject.UserAccess);                        
                        modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                    }
                    //modelObject.UserAccess = objBll.GetUserAccessDetails(modelObject.UserAccess);
                    //modelObject.UsersModel = modelObject.UserAccess.Users.ToList();
                                        
                    string[] index = modelObject.Indexes.Split('+');

                    modelObject.UsersModel = (from p in modelObject.UsersModel
                                              where index.Contains(p.Id)
                                              select p).ToList<UserClass>();


                    StringBuilder changesText = new StringBuilder();
                    List<UserClass> userList = new List<UserClass>();
                    
                    foreach (var item in modelObject.UsersModel)
                    {
                        UserClass user = new UserClass();
                        user.CheckSelect = item.CheckSelect;
                        user.Company = item.Company;
                        user.EntityNo = item.EntityNo;
                        user.User = item.User;
                        user.UserId = item.UserId;
                        user.Phone = item.Phone;
                        user.Id = item.Id;
                        user.Network = item.Network;
                        user.ProviderId = item.ProviderId;
                        user.ProviderName = item.ProviderName;
                        user.PayerNumber = item.PayerNumber;
                        user.GroupName = item.GroupName;
                        user.GroupNumber = item.GroupNumber;
                        user.TaxId = item.TaxId;

                        changesText.Append(Constants.User);
                        changesText.Append(item.User);
                        changesText.Append(Constants.Company);
                        changesText.Append(item.Company);

                        if (modelObject.UserAccess.UserRole == Constants.Payer)
                        {                            
                            string payerName = (from list in modelObject.UserAccess.AllClient
                                                where list.Value.ToUpper().Equals(item.PayerNumber.ToUpper())
                                                select list.Text).FirstOrDefault();
                            if (!string.IsNullOrEmpty(payerName))
                            {
                                payerName = payerName.ToUpper().Replace(item.PayerNumber.ToUpper(), "").Replace("(", "").Replace(")", "");
                            }
                            else
                            {
                                payerName = string.Empty;
                            }
                            changesText.Append("Payer Number");
                            changesText.Append(item.PayerNumber);
                            changesText.Append("Payer Name");
                            changesText.Append(payerName);
                            changesText.Append("Group Number");
                            changesText.Append(item.GroupNumber);
                            changesText.Append("Group Name");
                            changesText.Append(item.GroupName);
                            user.PayerName = payerName;
                        }
                        else if (modelObject.UserAccess.UserRole == Constants.Provider)
                        {
                            changesText.Append(Constants.TaxId);
                            changesText.Append(item.TaxId);
                            changesText.Append(Constants.EntityNumber);
                            changesText.Append(item.EntityNo);
                        }
                        changesText.Append("~~");
                        userList.Add(user);
                    }
                    modelObject.UsersModel = userList;
                    modelObject.SelectedChange = changesText.ToString();                   

                    //StringBuilder changesText = new StringBuilder();
                    //changesText.Append(Constants.NoChangesRequired);
                    //modelObject.SelectedChange = changesText.ToString();
                    traceLog.AppendLine(" & End: UserAccessVerificationController, InformationIsValid Method");
                    return View("InformationIsValid", modelObject);
                }
                traceLog.AppendLine(" & End: UserAccessVerificationController, InformationIsValid Method");
                return Redirect("/Error/Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
               throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// approve validation and show alert
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Verify User Access")]
        public ActionResult ApproveValidation(UserVerification modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserAccessVerificationController, ApproveValidation Method with Param modelObject: " + modelObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: UserAccessVerificationController, ApproveValidation Method");
                    return RedirectToAction("Index", "Home");
                }


                if (modelObject != null)
                {
                    string userId = string.Empty;
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                    {
                        userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    }

                    bllObject.InsertChangedData(modelObject.SelectedChange, userId, userId);

                    string userType = ConfigurationManager.AppSettings[Constants.Site];
                    User requestor = new User();
                    requestor = objBll.GetUserDetails(userId, userType);


                    string requesterName = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    string toMailUser = requestor.Email;
                    string[] mailIdUser = new string[1];
                    mailIdUser[0] = toMailUser;
                    string toMailProvider = ConfigurationManager.AppSettings[Constants.ProviderRelations];
                    string[] mailIdProvider = new string[1];
                    mailIdProvider[0] = toMailProvider;
                    string[] bccMailId = new string[1];
                    string mailIdBCC = ConfigurationManager.AppSettings[Constants.BCCMailAddress];
                    bccMailId[0] = mailIdBCC;
                    ProviderVerification providerObjBll = new ProviderVerification();
                    providerObjBll.SendMail(GetMailBody(Constants.NoChangesRequired), mailIdUser, bccMailId, Constants.UserAccessMessageUser);
                    providerObjBll.SendMail(GetMailBodyInt(Constants.NoChangesRequired, userId, requestor), mailIdProvider, bccMailId, Constants.UserAccessMessageAdmin);

                    traceLog.AppendLine(" & End: UserAccessVerificationController, ApproveValidation Method");
                    return Content(Constants.ContentUserAccessVerification);
                }
                traceLog.AppendLine(" & End: UserAccessVerificationController, ApproveValidation Method");
                return Redirect("/Error/Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch subclient by client
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        private IEnumerable<SelectListItem> GetSubClientByClient(string client)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserAccessVerificationController, GetSubClientByClient Method with Param client: " + client);
                List<SelectListItem> subClient = new List<SelectListItem>();
                SelectListItem startObject = new SelectListItem() { Text = Constants.SelectSubClient, Value = Constants.SelectSubClient };
                subClient.Add(startObject);
                if (client != null)
                {
                    Access access = new Access();
                    List<string> networkList = null;
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                    {
                        access.User = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    }
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole))
                    {
                        access.Role = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                    }
                    if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                    {
                        access.UserType = ConfigurationManager.AppSettings[Constants.Site];
                    }
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                            && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                    {
                        access.IsEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                    }
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                                && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                                && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                    {
                        //get selected role
                        Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                        //get the network for selcted function
                        networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuUserAccess, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                    }

                    if (networkList != null)
                    {
                        access.Network = string.Join(",", networkList);
                    }
                    IEnumerable<SelectListItem> subClientList = objBll.GetSubClientByClient(client, access);
                    if (subClientList != null)
                    {
                        subClient.AddRange(subClientList.Select(x => new SelectListItem { Text = x.Value, Value = x.Value }).ToList());
                    }
                }
                traceLog.AppendLine(" & End: UserAccessVerificationController, GetSubClientByClient Method");
                return subClient;
            }
            catch (Exception )
            {

                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch subclient by client
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns>JsonResult</returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetSubClientByClientByJson(string clientId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserAccessVerificationController, GetSubClientByClientByJson Method with Param clientId: " + clientId);
                clientId = AntiXssEncoder.HtmlEncode(clientId, true);//Added on 17-Jul-18 to fix Reflected XSS
                //if (!string.IsNullOrEmpty(clientId))
                //{
                //    clientId = AntiXssEncoder.HtmlEncode(clientId, true);//Added on 17-Jul-18 to fix Reflected XSS
                //}                 
                var client = GetSubClientByClient(clientId);
                traceLog.AppendLine(" & End: UserAccessVerificationController, GetSubClientByClientByJson Method");
                return Json(client, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private void SetUserAccess(UserVerification userVerification)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserAccessVerificationController, SetUserAccess Method with Param userVerification: " + userVerification);
            UserDetails user = (UserDetails)Session[Constants.UserDetails];
            List<string> networkList = new List<string>();
            if (user != null)
            {
                if (!string.IsNullOrEmpty(user.UserId))
                {
                    userVerification.UserAccess.Userid = user.UserId;
                }
                if (!string.IsNullOrEmpty(user.SelectedRole))
                {
                    userVerification.UserAccess.UserRole = user.SelectedRole;
                }
                if (!string.IsNullOrEmpty(user.SelectedRole)
                                && user.UserRoles != null
                                && user.UserRoles.Count() > 0)
                {
                    userVerification.UserAccess.IsEmployee = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault().IsEmployee;
                }
                if (!string.IsNullOrEmpty(user.SelectedRole)
                                    && user.UserRoles != null
                                    && user.UserRoles.Count() > 0)
                {
                    //get selected role
                    Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault();
                    //get the network for selcted function
                    networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuUserAccess, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                }
            }
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
            {
                userVerification.UserAccess.UserType = ConfigurationManager.AppSettings[Constants.Site];
            }
            if (networkList != null)
            {
                userVerification.UserAccess.Network = string.Join(",", networkList);
            }
                traceLog.AppendLine(" & End: UserAccessVerificationController, SetUserAccess Method");
            }
            catch (Exception )
            {
                
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// Build the mail content for Admin
        /// </summary>
        /// <param name="changeList"></param>
        /// <param name="userId"></param>
        /// <returns>string</returns>
        private string GetMailBodyInt(string changeList, string userId, User objUser)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserAccessVerificationController, GetMailBodyInt Method with Param changeList: " + changeList + " and with Param userId: " + userId + "and with Param objUser: " + objUser);
                StringBuilder mailBody = new StringBuilder();
                if (objUser != null)
                {

                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append("A First Health/Cofinity network provider has reviewed the list of users that can view claims information on the First Health/Cofinity website.  If deletions to web user access were requested they are noted below.");
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.BreakLine);

                    mailBody.Append(Constants.TableHeader);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.StyleStart);
                    mailBody.Append(changeList.Replace("~", "<br/>"));
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.StyleEnd);
                    mailBody.Append(Constants.TableEnd);
                    mailBody.Append(Constants.BreakLine);

                    mailBody.Append(Constants.TableHeader);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.SubmittedBy);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.UserNameLabel + userId);
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.NameLabel + objUser.LastName.ToString().Trim() + Constants.CommaWithSpace + objUser.FirstName.ToString().Trim());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.TitleLabel + objUser.Title.ToString().Trim());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.CompanyNameLabel + objUser.CompanyName.ToString().Trim());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.PhoneLabel + objUser.BusinessPhone.ToString().Trim());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.EmailLabel + objUser.Email.ToString().Trim());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.SubmittedOn + DateTime.Now.ToShortDateString());
                    mailBody.Append(Constants.RowEnd);

                    mailBody.Append(Constants.TableEnd);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.BreakLine);

                    mailBody.Append(Constants.TableHeader);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append("As a First Health/Cofinity website administrator, you are responsible for processing this provider data change if appropriate. ");
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.BreakLine);


                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.MessageAdmin3);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.BreakLine);

                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.MessageAdmin4);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.TableEnd);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.BreakLine);

                    mailBody.Append(Constants.TableHeader);
                    mailBody.Append(Constants.RowStart);
                    mailBody.Append(Constants.CofinityLabel);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.BreakLine);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.RowStyle);
                    mailBody.Append(Constants.DoNotReply);
                    mailBody.Append(Constants.RowEnd);
                    mailBody.Append(Constants.TableEnd);
                }
                traceLog.AppendLine(" & End: UserAccessVerificationController, SetUserAccess Method");
                return mailBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Build mail body for user
        /// </summary>
        /// <param name="changeList"></param>
        /// <returns>string</returns>
        private static string GetMailBody(string changeList)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
               
                StringBuilder mailBody = new StringBuilder();

                traceLog.AppendLine("Start: UserAccessVerificationController, GetMailBody Method with Param changeList: " + changeList);

                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.UserAccessMessageUser3);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);

                mailBody.Append(Constants.TableHeader);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.StyleStart);
                mailBody.Append(changeList.Replace("~", "<br/>"));
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.StyleEnd);
                mailBody.Append(Constants.TableEnd);

                mailBody.Append(Constants.BreakLine);

                mailBody.Append(Constants.TableHeader);
                mailBody.Append(Constants.RowStart);
                mailBody.Append("A message has been submitted to our Provider Services team for review and processing, if appropriate.You will be contacted if there are any questions about your request. ");
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.TableEnd);

                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);

                mailBody.Append(Constants.TableHeader);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.CofinityLabel);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStyle);
                mailBody.Append(Constants.DoNotReply);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.TableEnd);
                traceLog.AppendLine(" & End: UserAccessVerificationController, GetMailBody Method");
                return mailBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

    }
}