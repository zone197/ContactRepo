﻿
$(document).ready(function () {

    //clearing all the messages as soon as user enters the email id
        $('#emailIdForProviderDetails').keyup(function () {
            $('#errorMessage').empty();
            $("#emailSearchResult").empty();
        });
    //clearing all the messages as soon as user enters the phone number
        $('#phoneNumber').keyup(function () {
            $('#errorMessage').empty();
            $("#emailSearchResult").empty();
        });
});

function GetResources(key) {
    var forgeryId = $("#forgeryToken").val();
    var returnValue;
    $.ajax({
        type: 'POST',
        url: '/LocateProviderMobile/GetResources',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        async: false,
        data: JSON.stringify({ key: key }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            ////debugger;
            returnValue = result;

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
    ////debugger;
    return returnValue;
}

function ValidateCaptchaMoreDetailsMObile(event, CaptchaVerify,Visibility) {
    try {
        if (Visibility == 'invisible') {
            if (CaptchaVerify == "false")
                SendProviderDetails(true)
            else {
                event.preventDefault();
                grecaptcha.reset();
                grecaptcha.execute();
            }
        }
        else {          
               SendProviderDetails("");
        }
    }
    catch (ex) {
    }
}

//without captcha validation
function SendProviderDetails(captchaResponse) {
    var ProviderNumber = $("#hdnProviderMoreproviderUIN").val();
    var address1 = $("#hdnProviderMoreAddress1").val();
    var city = $("#hdnProviderMoreCITY").val();
    var state = $("#hdnProviderMoreState").val();
    var zip = $("#hdnProviderMoreZipcode").val();
    var providerNameDegree = $("#hdnProviderMoreLongName").val();

    var forgeryId = $("#forgeryToken").val();
    var ActiveTab = $('.nav-tabs .active').text();
    $('#errorMessage').empty();
    var address = address1 + " " + city + " " + state + " " + zip;
    var providerNumber = ProviderNumber;
    var email = $("#emailIdForProviderDetails").val().trim();
    var phoneNumber = $("#phoneNumber").val().trim();
    
    var phoneNumberCarrier = $('#CarrierData').val();
    var form = $('#FormSendDetailsForMobile' + ProviderNumber);
    $.validator.unobtrusive.parse(form);
    //debugger;
    form.validate();
    if ((phoneNumber != "" && phoneNumberCarrier.length!=0) || email != "") {
        if (form.valid()) {
            //var captchaResponse = $("#g-recaptcha-response").val();
            //if (CaptchaVerify == "false")
            //    captchaResponse = "true";
            if (captchaResponse) {
                if (ActiveTab != "Map") {
                    $.ajax({
                        type: 'POST',
                        url: '/LocateProviderMobile/SendingMailForMobile',
                        contentType: "application/json; charset=utf-8",
                        datatype: 'json',
                        data: JSON.stringify({ email: email, phoneNumberCarrier: phoneNumberCarrier, phoneNumber: phoneNumber, providerNumber: providerNumber, captcha: captchaResponse }),
                        headers: {
                            'VerificationToken': forgeryId
                        },
                        success: function (result) {
                            grecaptcha.reset();
                            if (result == true) {
                                var msgEmailSent = GetResources("lblEmailTextSuccessFul");
                                $("#emailSearchResult").html(msgEmailSent);
                                $("#emailIdForProviderDetails").val("");
                                
                            }
                            else if (result == false) {
                                var msgEmailNotSent = GetResources("lblEmailNotSent");
                                $("#emailSearchResult").html(msgEmailNotSent);
                                $("#emailIdForProviderDetails").val("");
                               
                            }
                            else if (result =="sessionTimeOut") {
                                window.location.href = '/LocateProviderMobile/Index/';
                            }
                            else {
                                var errorCaptchaValidation = GetResources("lblErrorCaptchaValidation");
                                $("#emailSearchResult").html(errorCaptchaValidation);
                                $("#emailIdForProviderDetails").val("");                              
                            }
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            grecaptcha.reset();
                        }
                    });
                }
                else if(ActiveTab == "Map")
                {
                    getLocationMobile(email, phoneNumberCarrier, phoneNumber, address, captchaResponse, ProviderNumber, providerNameDegree,forgeryId);
                    //  ShowPositionTestMobile(email,phoneNumberCarrier,phoneNumber,address,captchaResponse,ProviderNumber,providerNameDegree,forgeryId);
                }
            }
            else {
                var errorFillTheCaptcha = GetResources("lblPleaseFillCaptchaErrorMessage");
                $("#errorMessage").html(errorFillTheCaptcha);
            }
        }
        else {
            var errorProvideValidIdOrPhone = GetResources("lblProvideValidIdOrPhoneNumber");
            $('#errorMessage').html(errorProvideValidIdOrPhone);

        }

    }
    else {
        var errorEnterValidEmailOrPhone = GetResources("lblEnterIdOrPhoneNumber");
        $("#errorMessage").html(errorEnterValidEmailOrPhone);
    }
}




