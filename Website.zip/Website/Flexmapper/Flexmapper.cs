﻿//using System;
//using System.Data;
//using System.Configuration;
//using System.IO;
//using System.Runtime.Serialization;
//using System.ServiceModel;
//using System.Collections.Generic;

//namespace FlexMapper.MapperService
//{
//    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
//    [ServiceContract]
//    public interface IMapperService
//    {
//        [OperationContract]
//        MapResult MapGeneralType(string appId, string templateName, string keyFieldName);
//        [OperationContract]
//        MapClaimList MapClaimList(string appId, string batchNumber);
//        [OperationContract]
//        MapResult MapAClaim(string appId, string claimNumber);
//    }

//    [DataContract]
//    public class MapResult
//    {
//        [DataMember]
//        public bool IsMapCompleted { get; set; }
//        [DataMember]
//        public string Message { get; set; }
//        [DataMember]
//        public byte[] FileContent { get; set; }
//    }

//    [DataContract]
//    public class MapClaimList
//    {
//        [DataMember]
//        public bool IsMapCompleted { get; set; }
//        [DataMember]
//        public string Message { get; set; }
//        [DataMember]
//        public byte[] FileContent { get; set; }
//        [DataMember]
//        public int TotalErrorClaim { get; set; }
//        [DataMember]
//        public string ErrorClaimList { get; set; }
//    }
//}

