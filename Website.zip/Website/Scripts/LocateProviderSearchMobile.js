$(document).ready(function () {

    $("#ErrorMessageForInfo").empty();
    $('#showpanel').slideUp("slow");
    $("#headingErrorMsg").empty();
    $("#errorMsgZipState").empty();

    /* autosuggestions based on search criteria when user keys in two characters */
    $(function () {
        function split(val) {
            return val.split(/,\s*/);
        }
        function extractLast(term) {
            return split(term).pop();
        }
        $("#txtProviderName").bind("keydown", function (event) {
            if (event.keyCode === $.ui.keyCode.TAB && $(this).data("autocomplete").menu.active) {
                event.preventDefault();
            }
        })
        $("#txtProviderName").autocomplete({
            source: function (request, response) {
                var forgeryId = $("#forgeryToken").val();
                var searchRequest = new Object();
                var NetworkType = new Object();
                NetworkType.NetworkId = $('input[name=NetworkType]:checked').val();
                NetworkType.NetworkName = $('input[name=NetworkType]:checked').attr('networktype-name');
                searchRequest.NetworkType = NetworkType;
                searchRequest.ClientSpecificCode = $("#txtClientSpcNet").val();
                var providerType = new Object();

                providerType.ProviderTypeID = $('input[name="ProviderType"]:checked').val();
                providerType.ProviderTypeName = $('input[name="ProviderType"]:checked').attr('provider-name');
                searchRequest.ProviderType = providerType;
                searchRequest.CustomerType = $('input[name=UserType]:checked').val();
                if ($('#txtboxZipCode').val().trim() != "") {
                    searchRequest.Zipcode = $('#txtboxZipCode').val();
                    searchRequest.Radius = $('#txtRadiusValue').val();
                }
                else if ($('#SearchState').val() != "" && $('#SearchState').val() != null) {
                    //
                    searchRequest.State = $('#SearchState').val();
                    var countyList = [];
                    $('#SearchCounty :selected').each(function (i, selected) {
                        if ($(selected).val() != "" && $(selected).val() != null) {
                            countyList[i] = $(selected).val();
                        }
                    });
                    searchRequest.CountyCodes = countyList;
                    var cityList = [];
                    $('#SearchCity :selected').each(function (i, selected) {
                        if ($(selected).val() != "" && $(selected).val() != null) {
                            cityList[i] = $(selected).val();
                        }
                    });
                    searchRequest.CityCodes = cityList;
                }
                if ($('#txtProviderName').val() != undefined && $('#txtProviderName').val() != null && $('#txtProviderName').val().trim() != "") {
                    searchRequest.ProviderName = request.term;
                }
                $.ajax({
                    url: '/LocateProviderMobile/GetProviderNameSearchCriteria',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify({ query: request.term, searchRequest: searchRequest }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    term: extractLast(request.term),
                    success: function (data) {
                        response($.map(data, function (item) {
                            return {
                                label: item.PhysicanName,
                                value: item.PhysicanNum     // EDIT
                            }
                        }));
                    }
                })
            },
            search: function () {
                // custom minLength
                var term = extractLast(this.value);
                if (term.length < 2) {
                    return false;
                }
            },
            focus: function (event, ui) {
                event.preventDefault();
            },
            select: function (event, ui) {
                event.preventDefault();
                $("#txtProviderName").val(ui.item.label);
                $("#ProviderNameHiddenValue").val(ui.item.value);
            }
        });

    });

    /* checking for values entered in radius textbox and displaying appropriate errror messages */
    $('#txtRadiusValue').on('change', function () {
        $("#headingErrorMsg").empty();
        $("#errorMsgZipState").empty();
        $("#ErrorMessageForInfo").empty();
        if (!jQuery.isNumeric($('#txtRadiusValue').val())) {
            var errorNumericRadius = GetResources("lblEnterNumericRadiusErrorMessage");
            $('#errorMsgZipState').html(errorNumericRadius);
            $('#headingErrorMsg').html(errorNumericRadius);
        }
        else {
            $("#errorMsgZipState").empty();
            $("#headingErrorMsg").empty();
            if ($(this).val() > 100 || $(this).val() < 5) {
                $(this).val("10");
            }
            $('#RadiusSlider').slider({
                value: $('#txtRadiusValue').val()
            });
            if (!jQuery.isNumeric($('#txtboxZipCode').val()) && $('#txtboxZipCode').val() != null && $('#txtboxZipCode').val() != "") {
                var errorMsgZipNumeric = GetResources("lblErrorMsgEnterNumericValuesInZip");
                $('#errorMsgZipState').html(errorMsgZipNumeric);
                $('#headingErrorMsg').html(errorMsgZipNumeric);
                $('#showpanel').slideUp("slow");
                var result = GetResources('lblMoreOptions');
                ////debugger;
                var link = $("#open");
                link.html('<a aria-expanded="false" id="seeMoreDetails">' + result + '</a>')
            }
            else {
                $("#errorMsgZipState").empty();
                $("#headingErrorMsg").empty();

            }
        }

    });

    //setting the textbox value of specialty from the option selected from the dropdown
    $(function () {
        $("#specialities").click(function (event) {
            event.preventDefault(); // Stop the browser from redirecting as it normally would
            if ($("#specialities").val() == -1) {
                $("#selectedSpeciality").val("");
            }
            else {
                var selectedid = $(this).find("option:selected").text().trim();
                $("#selectedSpeciality").val(selectedid);
                $("#selectedCondition").val("");
                $("#SelectCondition").val("-1");
                $("#selectedFocus").val("");
                $("#focusTypes").val("-1");
            }
        });
    });

    //setting the textbox value of condition from the option selected from the dropdown
    $(function () {
        $("#SelectCondition").click(function (event) {
            event.preventDefault(); // Stop the browser from redirecting as it normally would
            if ($("#SelectCondition").val() == -1) {
                $("#selectedCondition").val("");
            }
            else {
                var selectedid = $(this).find("option:selected").text().trim();
                $("#selectedCondition").val(selectedid);
                $("#selectedSpeciality").val("");
                $("#specialities").val("-1");
                $("#selectedFocus").val("");
                $("#focusTypes").val("-1");
            }
        });
    });



    //setting the textbox value of condition from the option selected from the dropdown
    $(function () {
        $("#focusTypes").click(function (event) {
            event.preventDefault(); // Stop the browser from redirecting as it normally would
            if ($("#focusTypes").val() == -1) {
                $("#selectedFocus").val("");
            }
            else {
                var selectedid = $(this).find("option:selected").text().trim();
                $("#selectedFocus").val(selectedid);
                $("#selectedCondition").val("");
                $("#SelectCondition").val("-1");
                $("#selectedSpeciality").val("");
                $("#specialities").val("-1");
            }
        });
    });


    //filter the specialty dropdown based on the value enters in the textbox
    jQuery.fn.filterByText1 = function (textbox, selectSingleMatch) {
        return this.each(function () {
            var select = this;
            var options = [];
            $("#specialities").find('option').each(function () {
                options.push({ value: $(this).val(), text: $(this).text(), data_eng: $(this).attr("data-eng"), data_spn: $(this).attr("data-spn") });
            });
            $("#specialities").data('options', options);
            $(textbox).bind('change keyup', function () {
                var options = $("#specialities").empty().data('options');
                var search = $.trim($(this).val());
                var regex = new RegExp(search, "gi");

                $.each(options, function (i) {
                    var option = options[i];
                    if (option.text.match(regex) !== null) {
                        $("#specialities").append(
                        $('<option>').text(option.text).val(option.value).attr("data-spn", option.data_spn).attr("data-eng", option.data_eng)
                        );
                    }
                });
                if (selectSingleMatch === true && $("#specialities").children().length === 1) {
                    $("#specialities").children().get(0).selected = true;
                }
            });
        });
    };
    $(function () {
        $('select[id$=specialities]').filterByText1($('input[id$=selectedSpeciality]'), true);

    });

    //filter the condition dropdown based on the value enters in the textbox
    jQuery.fn.filterByText2 = function (textbox, selectSingleMatch) {
        return this.each(function () {
            var select = this;
            var options = [];
            $("#SelectCondition").find('option').each(function () {
                options.push({ value: $(this).val(), text: $(this).text(), data_eng: $(this).attr("data-eng"), data_spn: $(this).attr("data-spn") });
            });
            $("#SelectCondition").data('options', options);
            $(textbox).bind('change keyup', function () {
                var options = $("#SelectCondition").empty().data('options');
                var search = $.trim($(this).val());
                var regex = new RegExp(search, "gi");

                $.each(options, function (i) {
                    var option = options[i];
                    if (option.text.match(regex) !== null) {
                        $("#SelectCondition").append(
                        $('<option>').text(option.text).val(option.value).attr("data-spn", option.data_spn).attr("data-eng", option.data_eng)
                        );
                    }
                });
                if (selectSingleMatch === true && $("#SelectCondition").children().length === 1) {
                    $("#SelectCondition").children().get(0).selected = true;
                }
            });
        });
    };
    $(function () {
        $('select[id$=SelectCondition]').filterByText2($('input[id$=selectedCondition]'), true);
    });

    //filter the focus dropdown based on the value enters in the textbox
    jQuery.fn.filterByText3 = function (textbox, selectSingleMatch) {
        return this.each(function () {
            var select = this;
            var options = [];
            $("#focusTypes").find('option').each(function () {
                options.push({ value: $(this).val(), text: $(this).text(), data_eng: $(this).attr("data-eng"), data_spn: $(this).attr("data-spn") });
            });
            $("#focusTypes").data('options', options);
            $(textbox).bind('change keyup', function () {
                var options = $("#focusTypes").empty().data('options');
                var search = $.trim($(this).val());
                var regex = new RegExp(search, "gi");

                $.each(options, function (i) {
                    var option = options[i];
                    if (option.text.match(regex) !== null) {
                        $("#focusTypes").append(
                            $('<option>').text(option.text).val(option.value).attr("data-spn", option.data_spn).attr("data-eng", option.data_eng)
                        );
                    }
                });
                if (selectSingleMatch === true && $("#focusTypes").children().length === 1) {
                    $("#focusTypes").children().get(0).selected = true;
                }
            });
        });
    };
    $(function () {
        $('select[id$=focusTypes]').filterByText3($('input[id$=selectedFocus]'), true);

    });

    $('#SearchState').multiselect({
        buttonWidth: '100%',
        enableFiltering: true,
        maxHeight: 200,
        nonSelectedText: GetResources("txtStateRequired"),
        enableCaseInsensitiveFiltering: true,
        enableFullValueFiltering: true,
        enableHTML: false,
        onDropdownShown: function (even) {
            this.$filter.find('.multiselect-search').focus();
        },
    });
    $('#SearchCity').multiselect({
        buttonWidth: '100%',
        nonSelectedText: GetResources("txtEnterCity"),
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        enableFullValueFiltering: true,
        enableHTML: false,
        onDropdownShown: function (even) {
            this.$filter.find('.multiselect-search').focus();
        },
    });
    $('#SearchCounty').multiselect({
        buttonWidth: '100%',
        nonSelectedText: GetResources("txtEnterCounty"),
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        enableFullValueFiltering: true,
        enableHTML: false,
        onDropdownShown: function (even) {
            this.$filter.find('.multiselect-search').focus();
        },
    });

    //setting the county and city dropdown based on the state
    $('#SearchState').change(function () {
        $('#SearchNow').prop('disabled', false);
        var forgeryId = $("#forgeryToken").val();
        $("#ErrorMessageForInfo").empty();
        $("#headingErrorMsg").empty();
        $("#errorMsgZipState").empty();
        var stateCode = $('#SearchState').val();
        if (stateCode != null && stateCode != "") {
            $.ajax({
                type: 'POST',
                url: '/LocateProviderMobile/GetCountiesByState',
                contentType: "application/json; charset=utf-8",
                datatype: 'json',
                async: false,
                data: JSON.stringify({ stateCode: stateCode }),
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {
                    $('#SearchCounty').empty();

                    $('#SearchCounty').append('<option value="" data-hidden="true">' + GetResources("txtEnterCounty") + '</option>');
                    $.each(result, function (index, CountyName) {
                        $('#SearchCounty').append("<option value='" + CountyName.CountyName + "'>" + CountyName.CountyName + "</option>");
                    });
                    $('#SearchCounty').multiselect('rebuild');
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    //
                }
            });

            $.ajax({
                type: 'POST',
                url: '/LocateProviderMobile/GetCitiesByState',
                contentType: "application/json; charset=utf-8",
                datatype: 'json',
                async: false,
                data: JSON.stringify({ stateCode: stateCode }),
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {
                    $('#SearchCity').empty();
                    $('#SearchCity').append('<option value="" data-hidden="true">' + GetResources("txtEnterCity") + '</option>');
                    $.each(result, function (index, CityName) {
                        $('#SearchCity').append("<option value='" + CityName.CityName + "'>" + CityName.CityName + "</option>");
                    });
                    $('#SearchCity').multiselect('rebuild');
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    //
                }
            });
        }

    });
    //resetting the city dropdown based on county and state selection
    $('#SearchCounty').change(function () {
        var forgeryId = $("#forgeryToken").val();
        if ($('#SearchCounty').val() != null && $('#SearchCounty').val() != "") {
            var stateCode = [];
            $('#SearchState :selected').each(function (i, selected) {
                stateCode[i] = $(selected).val();
            });
            var county = [];
            $('#SearchCounty :selected').each(function (i, selected) {
                county[i] = $(selected).val();
            });
            $.ajax({
                type: 'POST',
                url: '/LocateProviderMobile/GetCitiesByStateAndCounty',
                contentType: "application/json; charset=utf-8",
                datatype: 'json',
                data: JSON.stringify({ stateCode: stateCode, county: county}),
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {

                    $('#SearchCity').empty();
                    $('#SearchCity').append('<option value="" data-hidden="true">' + GetResources("txtEnterCity") + '</option>');
                    $.each(result, function (index, CityName) {
                        $('#SearchCity').append("<option value='" + CityName.CityName + "'>" + CityName.CityName + "</option>");
                    });
                    $('#SearchCity').multiselect('rebuild');
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    //
                }
            });
        }
        else {
            var stateCode = $('#SearchState').val();
            if (stateCode != null && stateCode != "") {

                $.ajax({
                    type: 'POST',
                    url: '/LocateProviderMobile/GetCitiesByState',
                    contentType: "application/json; charset=utf-8",
                    datatype: 'json',
                    data: JSON.stringify({ stateCode: stateCode }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    success: function (result) {
                        $('#SearchCity').empty();
                        $('#SearchCity').append('<option value="" data-hidden="true">' + GetResources("txtEnterCity") + '</option>');
                        $.each(result, function (index, CityName) {
                            $('#SearchCity').append("<option value='" + CityName.CityName + "'>" + CityName.CityName + "</option>");
                        });
                        $('#SearchCity').multiselect('rebuild');
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        //
                    }
                });
            }
        }

    });
    //validating the Numeric data entered in physician/facility phone number
    $('#txtProviderPhNo').on('focusout', function () {
        $('#txtProviderPhNo').val($('#txtProviderPhNo').val().trim());
        if ((jQuery.isNumeric($('#txtProviderPhNo').val()) == false) || ($('#txtProviderPhNo').val().length < 10 && $('#txtProviderPhNo').val().trim() != "")) {
            //debugger;
            $('#errorMsgProviderPhNo').html("");
            $('#errorMsgProviderPhNo').html(GetResources("lblEnterValidData"));
            //$('#txtProviderPhNo').focus();
        }
        else {
            $('#errorMsgProviderPhNo').html("");
            if ($('#txtProviderPhNo').val().length == 10)
                $("#txtProviderPhNo").val('(' + $("#txtProviderPhNo").val().substr(0, 3) + ')' + $("#txtProviderPhNo").val().substr(3, 3) + '-' + $("#txtProviderPhNo").val().substr(6, 4));


        }
        if ($('#txtProviderPhNo').val() == "")
            $('#errorMsgProviderPhNo').html("");
    });
    $("#txtProviderPhNo").keydown(function (e) {
        //
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            //allow copy paste
            (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
            (e.keyCode == 86 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    function EditPhoneMode() {

        $("#txtProviderPhNo").val($("#txtProviderPhNo").val().substr(1, 3) + $("#txtProviderPhNo").val().substr(5, 3) + $("#txtProviderPhNo").val().substr(9, 4));

    }
    $("#txtProviderPhNo").focusin(function () {
        if ($("#txtProviderPhNo").val() != "" && $("#txtProviderPhNo").val().length == 13) {
            EditPhoneMode();

        }
    })

    //validating the Numeric data entered in NPI
    $('#txtProviderNPI').on('focusout', function () {
        $('#txtProviderNPI').val($('#txtProviderNPI').val().trim());
        if ((jQuery.isNumeric($('#txtProviderNPI').val()) == false) || ($('#txtProviderNPI').val().length < 10 && $('#txtProviderNPI').val().trim() != "")) {
            //debugger;
            $('#errorMsgProviderNPI').html("");
            $('#errorMsgProviderNPI').html(GetResources("lblEnterValidData"));
            //$('#txtProviderNPI').focus();

        }
        else { $('#errorMsgProviderNPI').html(""); }
        if ($('#txtProviderNPI').val() == "")
            $('#errorMsgProviderNPI').html("");

    });
    $("#txtProviderNPI").keydown(function (e) {
        //
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            //allow copy paste
            (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
            (e.keyCode == 86 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    //validation the Medical license number
    $('#txtMedicalLicNo').alphanumeric({
        ichars: '<>=*&+-/][.,`\\'
    });
    $('#txtMedicalLicNo').on('focusout', function () {
        $('#txtMedicalLicNo').val($('#txtMedicalLicNo').val().trim());
        var RE_NAME = /^[a-zA-Z0-9]+$/i;
        if (!RE_NAME.test($('#txtMedicalLicNo').val())) {

            // 
            $('#errorMsgProviderMedLicNo').html("");
            $('#errorMsgProviderMedLicNo').html(GetResources("lblSpecialCharsNotAllowed"));
            //$('#txtProviderNPI').focus();

        }
        else { $('#errorMsgProviderMedLicNo').html(""); }
        if ($('#txtMedicalLicNo').val() == "")
            $('#errorMsgProviderMedLicNo').html("");
    });
    $('#txtMedicalLicNo').keydown(function (e) {
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
             (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||

            // Allow: home, end, left, right, down, up
             (e.keyCode >= 35 && e.keyCode <= 40) ||
            //allow copy paste
            (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
            (e.keyCode == 86 && (e.ctrlKey === true || e.metaKey === true))) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number or character and stop the keypress
        if ((e.shiftKey && ((e.keyCode > 47 && e.keyCode < 58) || e.keyCode > 105)) || e.keyCode == 32) {
            e.preventDefault();
        }
    });

    $('#txtboxZipCode').on('keyup', function () {
        var txtZip = $('#txtboxZipCode').val();
        if (txtZip.trim() == '') {
            $("#errorMsgZipState").empty();
            $("#headingErrorMsg").empty();
            if ($('#SearchState').val() != null && $('#SearchState').val().trim() != "") {
                $('#SearchNow').prop('disabled', false);
            }
            else {
                $('#SearchNow').prop('disabled', true);
            }

        }
        else {
            if (!jQuery.isNumeric(txtZip)) {
                var errorMsgZipNumeric = GetResources("lblErrorMsgEnterNumericValuesInZip");
                $('#errorMsgZipState').html(errorMsgZipNumeric);
                $('#headingErrorMsg').html(errorMsgZipNumeric);
                $('#showpanel').slideUp("slow");
                var result = GetResources('lblMoreOptions');
                var link = $("#open");
                link.html('<a aria-expanded="false" id="seeMoreDetails">' + result + '</a>')
            }
            $('#SearchNow').prop('disabled', false);
        }

    })
    //validating the zipcode entered in the textbox and clearing the state dropdown 
    $('#txtboxZipCode').on('change', function () {
        var forgeryId = $("#forgeryToken").val();
        var txtZip = $('#txtboxZipCode').val().trim();
        if (txtZip != '') {
            if (!jQuery.isNumeric(txtZip)) {
                var errorMsgZipNumeric = GetResources("lblErrorMsgEnterNumericValuesInZip");
                $('#errorMsgZipState').html(errorMsgZipNumeric);
                $('#headingErrorMsg').html(errorMsgZipNumeric);
                $('#showpanel').slideUp("slow");
                var result = GetResources('lblMoreOptions');
                var link = $("#open");
                link.html('<a aria-expanded="false" id="seeMoreDetails">' + result + '</a>')
            }
            else {
                if (!jQuery.isNumeric($('#txtRadiusValue').val())) {
                    var errorNumericRadius = GetResources("lblEnterNumericRadiusErrorMessage");
                    $('#errorMsgZipState').html(errorNumericRadius);
                    $('#headingErrorMsg').html(errorNumericRadius);
                }
                else {
                    $("#errorMsgZipState").empty();
                    $("#headingErrorMsg").empty();
                    $("#ErrorMessageForInfo").empty();
                    if (txtZip != "") {
                        $.ajax({
                            type: 'POST',
                            url: '/LocateProviderMobile/ZipCodeValues',
                            contentType: "application/json; charset=utf-8",
                            datatype: 'json',
                            data: JSON.stringify({ txtZip: txtZip }),
                            headers: {
                                'VerificationToken': forgeryId
                            },
                            success: function (result) {
                                if (result == "True") {
                                    if ($('#showpanel').is(":visible")) {
                                        var result = GetResources('lblLessOptions');
                                        var link = $("#open");
                                        link.html('<a aria-expanded="true" id="seeMoreDetails">' + result + '</a>')
                                    }
                                }
                                else {
                                    var errorEnterValidZip = GetResources("lblErrorMsgValidZip")
                                    $("#headingErrorMsg").html(errorEnterValidZip);
                                    $('#errorMsgZipState').html(errorEnterValidZip);
                                    $('#showpanel').slideUp("slow");
                                    var result = GetResources('lblMoreOptions');
                                    var link = $("#open");
                                    link.html('<a aria-expanded="false" id="seeMoreDetails">' + result + '</a>')
                                }
                            },
                            error: function (XMLHttpRequest, textStatus, errorThrown) {
                            }
                        });
                    }
                }
            }
        }


    });
    $("#txtboxZipCode").keydown(function (e) {
        //
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }

    });
    $("#txtRadiusValue").keydown(function (e) {
        //
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
    });

    // checking whether TIN entered is a number or alphabet
    $('#txtTIN').on('keyup', function () {
        if ($('#txtTIN').val() != null && $('#txtTIN').val() != "") {
            if (!jQuery.isNumeric($('#txtTIN').val())) {
                var errorTinNumeric = GetResources("lblTinNumericErrorMessage");
                $("#headingErrorMsg").html(errorTinNumeric);
                var errorEnterNumericValuesInTin = GetResources("lblEnterNumericValuesInTin");
                $('#errorMsgTinOrProvider').html(errorEnterNumericValuesInTin);
            }
            else {
                $("#headingErrorMsg").empty();
                $('#errorMsgTinOrProvider').empty();
            }
        }
        else {
            $("#headingErrorMsg").empty();
            $('#errorMsgTinOrProvider').empty();
        }
    });

});
// fetching the information on the basis of criteria entered and displaying in the result page on the click of the button
function SearchNowCheck() {
    $("#headingErrorMsg").find('optionalCriteria').empty();
    $("#ErrorMessageForInfo").empty();
    var forgeryId = $("#forgeryToken").val();
    var location = false;
    if ($('#txtboxZipCode').val() != null && $('#txtboxZipCode').val().trim() != "" && $('#txtboxZipCode').val().length == 5) {
        if (document.getElementById("txtRadiusValue").value > 4 && document.getElementById("txtRadiusValue").value <= 100) {
            if ($('#txtTIN').val() != undefined && $('#txtTIN').val() != null && $('#txtTIN').val().trim() != "") {
                if (jQuery.isNumeric($('#txtTIN').val()) && $('#txtTIN').val().length <= 9) {
                    location = true;
                }
                else
                    location = false;

            }
            else
                location = true;
            //check npi length

            if ($('#txtProviderNPI').val() != undefined && $('#txtProviderNPI').val() != null && $('#txtProviderNPI').val().trim() != "") {
                if (jQuery.isNumeric($('#txtProviderNPI').val()) && $('#txtProviderNPI').val().length == 10) {
                    location = true;
                }
                else {
                    location = false;
                    $('#txtProviderNPI').focus();
                    return;
                }


            }
            if ($('#txtMedicalLicNo').val() != undefined && $('#txtMedicalLicNo').val() != null && $('#txtMedicalLicNo').val().trim() != "") {
                var RE_NAME = /^[a-zA-Z0-9]+$/i;
                if (RE_NAME.test($('#txtMedicalLicNo').val())) {
                    location = true;
                }
                else {
                    location = false;
                    $('#txtMedicalLicNo').focus();
                    return;
                }


            }

            if ($('#txtProviderPhNo').val() != undefined && $('#txtProviderPhNo').val() != null && $('#txtProviderPhNo').val().trim() != "") {
                if (jQuery.isNumeric($("#txtProviderPhNo").val().substr(1, 3) + $("#txtProviderPhNo").val().substr(5, 3) + $("#txtProviderPhNo").val().substr(9, 4))
                && $('#txtProviderPhNo').val().length > 10) {
                    location = true;
                }
                else {
                    location = false;
                    $('#txtProviderPhNo').focus();
                    return;
                }


            }

        }
        else {
            location = false
        }
    }

    if ($('#SearchState').val() != null && $('#SearchState').val().trim() != "") {
        if ($('#txtTIN').val() != undefined && $('#txtTIN').val() != null && $('#txtTIN').val().trim() != "") {
            if (jQuery.isNumeric($('#txtTIN').val()) && $('#txtTIN').val().length <= 9) {
                location = true;
            }
            else
                location = false;

        }
        else
            location = true;
        //check npi length

        if ($('#txtProviderNPI').val() != undefined && $('#txtProviderNPI').val() != null && $('#txtProviderNPI').val().trim() != "") {
            if ($('#txtProviderNPI').val().length == 10) {
                location = true;
            }
            else {
                location = false;
                $('#txtProviderNPI').focus();
                return;
            }


        }


        if ($('#txtProviderPhNo').val() != undefined && $('#txtProviderPhNo').val() != null && $('#txtProviderPhNo').val().trim() != "") {
            if ($('#txtProviderPhNo').val().length > 10) {
                location = true;
            }
            else {
                location = false;
                $('#txtProviderPhNo').focus();
                return;
            }


        }

    }
    if (location) {

        var searchRequest = new Object();

        var providerType = new Object();


        providerType.ProviderTypeID = $('input[name="ProviderType"]:checked').val();
        providerType.ProviderTypeName = $('input[name="ProviderType"]:checked').attr('provider-name');

        searchRequest.ProviderType = providerType;
        searchRequest.CustomerType = $('input[name=UserType]:checked').val();
        searchRequest.AcceptingNewPatients = $('input[name="ProviderAcceptingNewPatient"]:checked').val();
        var NetworkType = new Object();
        NetworkType.NetworkId = $('input[name=NetworkType]:checked').val();
        NetworkType.NetworkName = $('input[name=NetworkType]:checked').attr('networktype-name');
        searchRequest.ClientSpecificCode = $("#txtClientSpcNet").val();
        searchRequest.NetworkType = NetworkType;
        ////debugger;
        if ($('#txtboxZipCode').val().trim() != "") {
            searchRequest.Zipcode = $('#txtboxZipCode').val();
            searchRequest.Radius = $('#txtRadiusValue').val();
        }
        else if ($('#SearchState').val() != "" && $('#SearchState').val() != null) {
            //
            searchRequest.State = $('#SearchState').val();
            var countyList = [];
            $('#SearchCounty :selected').each(function (i, selected) {
                countyList[i] = $(selected).val();
            });
            searchRequest.CountyCodes = countyList;
            var cityList = [];
            $('#SearchCity :selected').each(function (i, selected) {
                cityList[i] = $(selected).val();
            });
            searchRequest.CityCodes = cityList;
        }

        if ($('#txtProviderName').val() != undefined && $('#txtProviderName').val() != null && $('#txtProviderName').val().trim() != "") {
            searchRequest.ProviderName = $('#txtProviderName').val().trim();
        }
        if ($('#txtPracticeName').val() != undefined && $('#txtPracticeName').val() != null && $('#txtPracticeName').val().trim() != "") {
            searchRequest.RefinePracticename = $('#txtPracticeName').val().trim();

        }
        if ($('#txtProviderPhNo').val() != undefined && $('#txtProviderPhNo').val() != null && $('#txtProviderPhNo').val().trim() != "") {
            searchRequest.ProviderPhNo = $('#txtProviderPhNo').val().trim().substr(1, 3) + $('#txtProviderPhNo').val().trim().substr(5, 3) + $('#txtProviderPhNo').val().trim().substr(9, 4);


        }
        if ($('#txtMedicalLicNo').val() != undefined && $('#txtMedicalLicNo').val() != null && $('#txtMedicalLicNo').val().trim() != "") {
            searchRequest.ProviderMedicalLicNo = $('#txtMedicalLicNo').val().trim();
        }
        if ($('#txtProviderNPI').val() != undefined && $('#txtProviderNPI').val() != null && $('#txtProviderNPI').val().trim() != "") {
            searchRequest.ProviderNPI = $('#txtProviderNPI').val().trim();
        }
        if ($('#ProviderNameHiddenValue').val() != undefined && $('#ProviderNameHiddenValue').val() != null && $('#ProviderNameHiddenValue').val().trim() != "") {
            searchRequest.ProviderNumber = $('#ProviderNameHiddenValue').val().trim();
        }
        if ($('#txtTIN').val() != undefined && $('#txtTIN').val() != null && $('#txtTIN').val().trim() != "") {
            searchRequest.Tin = $('#txtTIN').val().trim();
        }

        var SpecialtyCodes = [];

        if ($('#selectedSpeciality').val() != "" || $('#selectedSpeciality').val().trim() != "") {
            $('#specialities :selected').each(function (i, selected) {
                if ($(selected).val() != "-1") {
                    //
                    var SpecialtyEntity = new Object();
                    SpecialtyEntity.SpecialtyCode = $(selected).val();
                    SpecialtyEntity.SpecialtyName = $(selected).attr("data-eng");
                    SpecialtyEntity.SpecialtySpanish = $(selected).attr("data-spn");
                    SpecialtyCodes.push(SpecialtyEntity);


                }
            });
            searchRequest.SpecialtyCodes = SpecialtyCodes;
        }
        var ConditionCodes = [];

        if ($('#selectedCondition').val() != "" || $('#selectedCondition').val().trim() != "") {
            $('#SelectCondition :selected').each(function (i, selected) {
                if ($(selected).val() != "-1") {
                    var Conditions = new Object();
                    Conditions.ConditionCode = $(selected).val();
                    Conditions.ConditionsName = $(selected).attr("data-eng");
                    Conditions.ConditionSpanish = $(selected).attr("data-spn");
                    ConditionCodes.push(Conditions);
                }
            });
            searchRequest.ConditionCodes = ConditionCodes;
        }

        var FocusCodes = [];

        if ($('#selectedFocus').val() != "" || $('#selectedFocus').val().trim() != "") {
            $('#focusTypes :selected').each(function (i, selected) {
                if ($(selected).val() != "-1") {
                    //
                    var FocusEntity = new Object();
                    FocusEntity.FocusCode = $(selected).val();
                    FocusEntity.FocusName = $(selected).attr("data-eng");
                    FocusEntity.FocusSpanish = $(selected).attr("data-spn");
                    FocusCodes.push(FocusEntity);


                }
            });
            searchRequest.FocusCodes = FocusCodes;
        }


        $.ajax({
            type: 'POST',
            url: '/LocateProviderMobile/SaveSearchRequestToSession',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ search: searchRequest }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                $("#spinnerPopup").modal('show');
                window.location.href = '/LocateProviderMobile/ProviderSearchResult/';
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                //
            }
        });
    }
    else {
    }
}


// changing heading of the collapsible panel to espanol and vice versa
function GetResources(key) {
    var forgeryId = $("#forgeryToken").val();
    var returnValue;
    $.ajax({
        type: 'POST',
        url: '/LocateProviderMobile/GetResources',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        async: false,
        data: JSON.stringify({ key: key }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            ////debugger;
            returnValue = result;

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
    ////debugger;
    return returnValue;
}
//validating the zip or state field for null or emptystring
function validateField() {
    var result = 0;
    var txtZip = $('#txtboxZipCode').val();
    var txtState = $('#SearchState').val();
    if ((txtZip == "" || txtZip == null) && (txtState == "" || txtState == null)) {
        var errorZipCodeOrStateMandatory = GetResources("lblZipOrStateMandatory");
        var errorSelectZipOrState = GetResources("lblErrorSelectZipOrState");
        if ($("#headingErrorMsg").find('.zipMandatory').length == 0)
            $("#headingErrorMsg").append("<div class='zipMandatory'>" + errorZipCodeOrStateMandatory + " </div>");

        $("#errorMsgZipState").html(errorSelectZipOrState);
        result = -1;
    }
    else {
        $("#errorMsgZipState").empty();
        $('#headingErrorMsg').find('.zipMandatory').remove();
        result = 0;
    }



    return result;
}

// validating the zipcode entered by the user
function checkZip(id) {
    $("#headingErrorMsg").empty();
    $('#errorMsgZipState').empty();
    var result = validateField();
    var forgeryId = $("#forgeryToken").val();
    var txtZip = $('#txtboxZipCode').val();
    if (txtZip != "") {
        if (!jQuery.isNumeric($('#txtboxZipCode').val())) {
            var errorMsgZipNumeric = GetResources("lblErrorMsgEnterNumericValuesInZip");
            $('#errorMsgZipState').html(errorMsgZipNumeric);
            $('#headingErrorMsg').html(errorMsgZipNumeric);
        }
        else {
            $("#headingErrorMsg").empty();
            $('#errorMsgZipState').empty();
            $.ajax({
                type: 'POST',
                url: '/LocateProviderMobile/ZipCodeValues',
                contentType: "application/json; charset=utf-8",
                datatype: 'json',
                data: JSON.stringify({ txtZip: txtZip }),
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {
                    if (result == "True") {
                        isValid = result;
                        if (id == "open") {
                            ShowDetails();
                        }
                        else
                            SearchNowCheck();
                    }
                    else {
                        var errorMsgValidZip = GetResources("lblErrorMsgValidZip");
                        $("#headingErrorMsg").html(errorMsgValidZip);
                        $('#errorMsgZipState').html(errorMsgValidZip);

                        $('#showpanel').slideUp("slow");
                        var result = GetResources('lblMoreOptions');
                        var link = $("#open");
                        link.html('<a aria-expanded="false" id="seeMoreDetails">' + result + '</a>')

                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                }
            });
        }
    }
    else {
        if (id == "open")
            ShowDetails();
        else
            SearchNowCheck();
    }


}

//for collapsible panel
function ShowDetails() {
    $("#headingErrorMsg").find('.stateMandatory').remove();
    $("#headingErrorMsg").find('.zipMandatory').remove();
    var flag = false;
    var link = $("#open");
    if ($('#txtboxZipCode').val() != null && $('#txtboxZipCode').val().trim() != "" && $('#txtboxZipCode').val().length == 5) {
        if (document.getElementById("txtRadiusValue").value > 4 && document.getElementById("txtRadiusValue").value <= 100) {
            flag = true;
        }
        else {
            flag = false
        }
    }
    if ($('#SearchState').val() != null && $('#SearchState').val().trim() != "") {
        flag = true;
    }
    if (flag) {
        $('#showpanel').slideToggle('slow', function () {
            //
            if ($(this).is(":visible")) {
                var result = GetResources('lblLessOptions');
                var link = $("#open");
                link.html('<a aria-expanded="true" id="seeMoreDetails">' + result + '</a>')
            }
            else {
                var result = GetResources('lblMoreOptions');
                var link = $("#open");
                link.html('<a aria-expanded="false" id="seeMoreDetails">' + result + '</a>')
            }
        });
    }
    else {
        $("#headingErrorMsg").find('.stateMandatory').remove();
        $("#headingErrorMsg").find('.zipMandatory').remove();
        $("#errorMsgZipState").empty();
        $("#errorMsgState").empty();
        var errorOptionalCriteria = GetResources("lblErrorOptionalCriteria");
        var errorOptionalCriteriaSelectZipState = GetResources("lblErrorOptionalCriteriaSelectZipOrState")
        if ($("#headingErrorMsg").find('.optionalCriteria').length == 0)
            $("#headingErrorMsg").append("<div class='optionalCriteria'>" + errorOptionalCriteria + "</div>");

        $("#ErrorMessageForInfo").html(errorOptionalCriteriaSelectZipState);
    }
}

function GoToSpecialtyPage() {
    var forgeryId = $("#forgeryToken").val();
    var searchRequest = new Object();
    var providerType = new Object();

    providerType.ProviderTypeID = $('input[name="ProviderType"]:checked').val();
    providerType.ProviderTypeName = $('input[name="ProviderType"]:checked').attr('provider-name');
    searchRequest.AcceptingNewPatients = $('input[name="ProviderAcceptingNewPatient"]:checked').val();
    searchRequest.ProviderType = providerType;

    var NetworkType = new Object();
    NetworkType.NetworkId = $('input[name=NetworkType]:checked').val();
    NetworkType.NetworkName = $('input[name=NetworkType]:checked').attr('networktype-name');
    searchRequest.NetworkType = NetworkType;
    searchRequest.CustomerType = $('input[name=UserType]:checked').val();
    searchRequest.ClientSpecificCode = $("#txtClientSpcNet").val();
    if ($('#txtboxZipCode').val().trim() != "") {
        searchRequest.Zipcode = $('#txtboxZipCode').val();
        searchRequest.Radius = $('#txtRadiusValue').val();
    }
    else if ($('#SearchState').val() != "" && $('#SearchState').val() != null) {
        //
        searchRequest.State = $('#SearchState').val();
        var countyList = [];
        $('#SearchCounty :selected').each(function (i, selected) {
            countyList[i] = $(selected).val();
        });
        searchRequest.CountyCodes = countyList;
        var cityList = [];
        $('#SearchCity :selected').each(function (i, selected) {
            cityList[i] = $(selected).val();
        });
        searchRequest.CityCodes = cityList;
    }

    if ($('#txtProviderName').val() != undefined && $('#txtProviderName').val() != null && $('#txtProviderName').val().trim() != "") {
        searchRequest.ProviderName = $('#txtProviderName').val().trim();
    }
    if ($('#txtPracticeName').val() != undefined && $('#txtPracticeName').val() != null && $('#txtPracticeName').val().trim() != "") {
        searchRequest.RefinePracticename = $('#txtPracticeName').val().trim();

    }
    if ($('#txtProviderPhNo').val() != undefined && $('#txtProviderPhNo').val() != null && $('#txtProviderPhNo').val().trim() != "") {
        searchRequest.ProviderPhNo = $('#txtProviderPhNo').val().trim().substr(1, 3) + $('#txtProviderPhNo').val().trim().substr(5, 3) + $('#txtProviderPhNo').val().trim().substr(9, 4);


    }
    if ($('#txtMedicalLicNo').val() != undefined && $('#txtMedicalLicNo').val() != null && $('#txtMedicalLicNo').val().trim() != "") {
        searchRequest.ProviderMedicalLicNo = $('#txtMedicalLicNo').val().trim();
    }
    if ($('#txtProviderNPI').val() != undefined && $('#txtProviderNPI').val() != null && $('#txtProviderNPI').val().trim() != "") {
        searchRequest.ProviderNPI = $('#txtProviderNPI').val().trim();
    }
    if ($('#ProviderNameHiddenValue').val() != undefined && $('#ProviderNameHiddenValue').val() != null && $('#ProviderNameHiddenValue').val().trim() != "") {
        searchRequest.ProviderNumber = $('#ProviderNameHiddenValue').val().trim();
    }
    if ($('#txtTIN').val() != undefined && $('#txtTIN').val() != null && $('#txtTIN').val().trim() != "") {
        searchRequest.Tin = $('#txtTIN').val().trim();
    }

    var SpecialtyCodes = [];

    if ($('#selectedSpeciality').val() != "" || $('#selectedSpeciality').val().trim() != "") {
        $('#specialities :selected').each(function (i, selected) {
            if ($(selected).val() != "-1") {
                //
                var SpecialtyEntity = new Object();
                SpecialtyEntity.SpecialtyCode = $(selected).val();
                SpecialtyEntity.SpecialtyName = $(selected).text();

                SpecialtyCodes.push(SpecialtyEntity);


            }
        });
        searchRequest.SpecialtyCodes = SpecialtyCodes;
    }
    var ConditionCodes = [];

    if ($('#selectedCondition').val() != "" || $('#selectedCondition').val().trim() != "") {
        $('#SelectCondition :selected').each(function (i, selected) {
            if ($(selected).val() != "-1") {
                var Conditions = new Object();
                Conditions.ConditionCode = $(selected).val();
                Conditions.ConditionsName = $(selected).text();

                ConditionCodes.push(Conditions);
            }
        });
        searchRequest.ConditionCodes = ConditionCodes;
    }

    var FocusCodes = [];

    if ($('#selectedFocus').val() != "" || $('#selectedFocus').val().trim() != "") {
        $('#focusTypes :selected').each(function (i, selected) {
            if ($(selected).val() != "-1") {
                //
                var FocusEntity = new Object();
                FocusEntity.FocusCode = $(selected).val();
                FocusEntity.FocusName = $(selected).text();

                FocusCodes.push(FocusEntity);


            }
        });
        searchRequest.FocusCodes = FocusCodes;
    }

    $.ajax({
        type: 'POST',
        url: '/LocateProvider/SaveSearchRequestToSession',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        data: JSON.stringify({ search: searchRequest }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            window.location.href = '/LocateProviderSpecialityDefination/Index?providerType=' + providerType.ProviderTypeID;
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            //
        }
    });


}
function keyHandler(event, id) {
    if (event.which === 13) {
        //event.stopPropagation;
        return checkZip(id);
    }
    return true;
}
