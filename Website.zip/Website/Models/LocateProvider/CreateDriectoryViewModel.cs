﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;
using Aetna.ProviderContracts.DataContracts;
using System.ComponentModel.DataAnnotations;
using NABResources;

namespace NABWebsite.Models.LocateProvider
{
    public class CreateDirectoryViewModel
    {
        public UserInfo UserInfo { get; set; }

        [Required(ErrorMessage = " ")]
        [Display(Name = "lblProvidersTobeIncludedInDirectory", ResourceType = typeof(Resources))]    
        public string DirectoryType { get; set; }

        public List<DirectoryType> DirectoryTypeList { get; set; }

        [Required(ErrorMessageResourceType = typeof(Resources),
              ErrorMessageResourceName = "lblDirectoryNameRequired", ErrorMessage = null)]
        [Display(Name = "lblEnterDirectoryName", ResourceType = typeof(Resources))]  
        public string DirectoryName { get; set; }


        [Display(Name = "lblSelectItemsToBeIncludedInDirectory", ResourceType = typeof(Resources))]  
        public List<IncludedItem> IncludedItemsList { get; set; }


        [Display(Name = "lblYourCriteria", ResourceType = typeof(Resources))] 
        public SearchRequestEntity SearchRequest { get; set; }
        [Required(ErrorMessage = " ")]
        [Display(Name = "lblSelectOneDeliveryOption", ResourceType = typeof(Resources))] 
        public string DirectoryCreationType { get; set; }

        public List<DirectoryCreationType> DirectoryCreationTypeList { get; set; }
         
        [EmailAddress]
        [RegularExpression(@"^([\w-\.'-]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,8}|[0-9]{1,3})(\]?)$", ErrorMessageResourceType = typeof(Resources),
              ErrorMessageResourceName = "lblInvalidEmailAddress", ErrorMessage = null)]
        public string EmailId1 { get; set; }
        [EmailAddress]
        [RegularExpression(@"^([\w-\.'-]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,8}|[0-9]{1,3})(\]?)$", ErrorMessageResourceType = typeof(Resources),
              ErrorMessageResourceName = "lblInvalidEmailAddress", ErrorMessage = null)]
        public string EmailId2 { get; set; }
        [EmailAddress]
        [RegularExpression(@"^([\w-\.'-]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,8}|[0-9]{1,3})(\]?)$", ErrorMessageResourceType = typeof(Resources),
              ErrorMessageResourceName = "lblInvalidEmailAddress", ErrorMessage = null)]
        public string EmailId3 { get; set; }

        public string RecaptchaPublicKey { get; set; }
        public string GoogleRecaptchaAPIAddressSingle { get; set; }
        public bool MoreProviders { get; set; }
        public bool IncludeTOC { get; set; }
        public bool IncludeIndex { get; set; }

    }

    public class IncludedItem
    {
        public int Id
        {
            get;
            set;
        }
        public string Name
        {
            get;
            set;
        }
        public bool Checked
        {
            get;
            set;
        }
    }
}