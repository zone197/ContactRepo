﻿using NABWebsite.BLL;
using NABWebsite.DTO;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NABWebsite.Models
{
    public class SearchCriteriaModel
    {
        //public Collection<Section> Sections { get; set; }

        //// <summary>
        //// States
        //// </summary>
        //public List<SelectListItem> States { get; set; }

        /////// <summary>
        /////// County
        /////// </summary>
        //public List<SelectListItem> County { get; set; }

        /////// <summary>
        /////// Cities
        /////// </summary>
        //public List<SelectListItem> Cities { get; set; }

        //public List<SelectListItem> Specialty { get; set; }

        //public List<SelectListItem> Condition { get; set; }

        //  public SearchCriteriaModel GetSearchCriteriaModel(PageViewModel PageViewModel, string providerTypeId)
        //{
        //    SearchCriteriaModel sc = new SearchCriteriaModel();

        //    //sc.Heading = "Enter Zip or State Information :";
        //    sc.Sections = new System.Collections.ObjectModel.Collection<DTO.Section>();
        //    DTO.Section Section = new DTO.Section();
        //    Section.SectionId = 1;
        //    Section.SectionSequence = 1;
        //    //Section.SectionTitle = "Search by Zip Code";
        //    sc.Sections.Add(Section);

        //    sc.Sections[0].SubSections = new System.Collections.ObjectModel.Collection<DTO.SubSection>();
        //    DTO.SubSection SubSection = new DTO.SubSection();
        //    SubSection.SubSectionId = 1;
        //    SubSection.SubSectionSequence = 1;
        //    // SubSection.SubSectionTitle = "ZipCode";
        //    // SubSection.Value = "Enter ZipCode";
        //    sc.Sections[0].SubSections.Add(SubSection);

        //    //sc.Sections[0].SubSections = new System.Collections.ObjectModel.Collection<Entity.SubSection>();
        //    DTO.SubSection SubSection1 = new DTO.SubSection();
        //    SubSection1.SubSectionId = 2;
        //    SubSection1.SubSectionSequence = 2;
        //    //SubSection1.SubSectionTitle = "Radius";
        //    SubSection1.Value = "10";
        //    sc.Sections[0].SubSections.Add(SubSection1);


        //    DTO.Section Section2 = new DTO.Section();
        //    Section2.SectionId = 2;
        //    Section2.SectionSequence = 2;
        //    // Section2.SectionTitle = "OR";
        //    sc.Sections.Add(Section2);

        //    DTO.Section Section3 = new DTO.Section();
        //    Section3.SectionId = 3;
        //    Section3.SectionSequence = 3;
        //    //  Section3.SectionTitle = "Search by State";
        //    sc.Sections.Add(Section3);

        //    sc.Sections[2].SubSections = new System.Collections.ObjectModel.Collection<DTO.SubSection>();
        //    DTO.SubSection SubSection2 = new DTO.SubSection();
        //    SubSection2.SubSectionId = 1;
        //    SubSection2.SubSectionSequence = 1;
        //    //  SubSection2.SubSectionTitle = "State";
        //    sc.Sections[2].SubSections.Add(SubSection2);

        //    DTO.SubSection SubSection3 = new DTO.SubSection();
        //    SubSection3.SubSectionId = 2;
        //    SubSection3.SubSectionSequence = 2;
        //    //  SubSection3.SubSectionTitle = "Narrow By County Or City";
        //    sc.Sections[2].SubSections.Add(SubSection3);

        //    //sc.Sections[2].SubSections = new System.Collections.ObjectModel.Collection<Entity.SubSection>();
        //    DTO.SubSection SubSection4 = new DTO.SubSection();
        //    SubSection4.SubSectionId = 3;
        //    SubSection4.SubSectionSequence = 3;
        //    //   SubSection4.SubSectionTitle = "County";
        //    sc.Sections[2].SubSections.Add(SubSection4);

        //    DTO.SubSection SubSection5 = new DTO.SubSection();
        //    SubSection5.SubSectionId = 4;
        //    SubSection5.SubSectionSequence = 4;
        //    //   SubSection5.SubSectionTitle = "OR";
        //    sc.Sections[2].SubSections.Add(SubSection5);

        //    DTO.SubSection SubSection6 = new DTO.SubSection();
        //    SubSection6.SubSectionId = 5;
        //    SubSection6.SubSectionSequence = 5;
        //    //  SubSection6.SubSectionTitle = "City";
        //    sc.Sections[2].SubSections.Add(SubSection6);

        //    DTO.Section Section4 = new DTO.Section();
        //    Section4.SectionId = 4;
        //    Section4.SectionSequence = 1;
        //    //   Section4.SectionTitle = "Specify Additional Search Criteria :";
        //    sc.Sections.Add(Section4);

        //    DTO.Section Section5 = new DTO.Section();
        //    Section5.SectionId = 5;
        //    Section5.SectionSequence = 1;
        //    //    Section5.SectionTitle = "Additional Search Criteria";
        //    sc.Sections.Add(Section5);

        //    DTO.Section Section6 = new DTO.Section();
        //    Section6.SectionId = 6;
        //    Section6.SectionSequence = 1;
        //    //   Section6.SectionTitle = "Search by Provider/TIN";
        //    sc.Sections.Add(Section6);

        //    sc.Sections[5].SubSections = new System.Collections.ObjectModel.Collection<DTO.SubSection>();
        //    DTO.SubSection SubSection7 = new DTO.SubSection();
        //    SubSection7.SubSectionId = 1;
        //    SubSection7.SubSectionSequence = 1;
        //    //  SubSection7.SubSectionTitle = "Enter Name of Physician/Facility :";
        //    // SubSection7.Value = "Enter Name/Facility";
        //    sc.Sections[5].SubSections.Add(SubSection7);


        //    DTO.SubSection SubSection8 = new DTO.SubSection();
        //    SubSection8.SubSectionId = 1;
        //    SubSection8.SubSectionSequence = 2;
        //    //   SubSection8.SubSectionTitle = "Enter TIN of the Provider :";
        //    //  SubSection8.Value = "TIN";
        //    sc.Sections[5].SubSections.Add(SubSection8);

        //    DTO.Section Section7 = new DTO.Section();
        //    Section7.SectionId = 7;
        //    Section7.SectionSequence = 1;
        //    // Section7.SectionTitle = "Search by Speciality";
        //    sc.Sections.Add(Section7);

        //    sc.Sections[6].SubSections = new System.Collections.ObjectModel.Collection<DTO.SubSection>();
        //    DTO.SubSection SubSection9 = new DTO.SubSection();
        //    SubSection9.SubSectionId = 1;
        //    SubSection9.SubSectionSequence = 1;
        //    //     SubSection9.SubSectionTitle = "Type any Speciality :";
        //    sc.Sections[6].SubSections.Add(SubSection9);

        //    DTO.Section Section8 = new DTO.Section();
        //    Section8.SectionId = 8;
        //    Section8.SectionSequence = 1;
        //    //    Section8.SectionTitle = "Search by Condition";
        //    sc.Sections.Add(Section8);

        //    sc.Sections[7].SubSections = new System.Collections.ObjectModel.Collection<DTO.SubSection>();
        //    DTO.SubSection SubSection10 = new DTO.SubSection();
        //    SubSection10.SubSectionId = 1;
        //    SubSection10.SubSectionSequence = 1;
        //    //    SubSection10.SubSectionTitle = "Type any Condition :";
        //    sc.Sections[7].SubSections.Add(SubSection10);

        //    ManageContent obj = new ManageContent();
            
        //    StateConditionSpecialty objectAll = obj.GetStateConditionSpecialty(4);
        //    sc.States = new List<SelectListItem>();
        //    List<SelectListItem> li = new List<SelectListItem>();

        //    foreach (var item in objectAll.StateList)
        //    {
        //        li.Add(new SelectListItem { Text = item.StateName, Value = item.StateCode });

        //    }
        //    sc.States = li;


        //    sc.Specialty = new List<SelectListItem>();
        //    List<SelectListItem> spc = new List<SelectListItem>();
        //    foreach (var item in objectAll.SpecialtiesList)
        //    {
        //        spc.Add(new SelectListItem { Text = item.SpecialtiesName, Value = item.SpecialtiesName });

        //    }
        //    sc.Specialty = spc;

        //    sc.Condition = new List<SelectListItem>();
        //    List<SelectListItem> con = new List<SelectListItem>();
        //    //li.Add(new SelectListItem { Text = "Select", Value = "0" });
        //    //con.Add(new SelectListItem { Text = "Condition 1", Value = "1" });
        //    //con.Add(new SelectListItem { Text = "Condition 2", Value = "2" });
        //    foreach (var item in objectAll.ConditionList)
        //    {
        //        con.Add(new SelectListItem { Text = item.ConditionsName, Value = item.ConditionsName });

        //    }
        //    sc.Condition = con;

        //    return sc;
        //}
    }
}
