﻿using System.Collections.Generic;
using System.Web.Mvc;
using NABWebsite.DTO;
using System.ComponentModel.DataAnnotations;
using Aetna.ProviderContracts.DataContracts;

namespace NABWebsite.Models
{
    public class LayoutViewModel
    {
        [AllowHtml]
        public Header HeaderComponents { get; set; }
        public List<Menu> Menus { get; set; }
        public Footer FooterInfo { get; set; }
        public string hosturl { get; set; }
        public List<ImageDetails> SecureImageListRef { get; set; }
        public int SelectedImageId { get; set; }
        public string ImageCaption { get; set; }
        //[Required]
        //public string userid { get; set; }
        //[Required]
        //public string pwd { get; set; }
        public List<SelectListItem> userroles { get; set; }
        public string selectedRole { get; set; }

        [AllowHtml]
        public HeaderInfo LocateProviderHeaderInfo { get; set; }

        public List<StateDisclaimerEntity> StateDisclaimerList { get; set; }
        public List<UserManualEntity> UserManualList { get; set; }
        public ImageDetails SecureImage { get; set; }
        public bool RemindMeLater { get; set; }
        public int SkipCount { get; set; }
        public bool SetFirstImage { get; set; }
    }

}