﻿//collect form input and submit
function SubmitForm() {

    var searchRequest = new Object();
    var forgeryId = $("#forgeryToken").val();
    var NetworkType = new Object();
    NetworkType.NetworkId = $('input[name=RadioButtonSelected]:checked').val();
    NetworkType.NetworkName = $('input[name=RadioButtonSelected]:checked').attr('networktype-name');
    searchRequest.NetworkType = NetworkType;
    // This will verify PowerSTEPPSunset is on and cofinity network
    if (powerSTEPP == "true" && $('input[name=RadioButtonSelected]:checked').val() == "3" && $("#rdCofinityType").val() == cofiUser
        && (NetworkType.NetworkName.toLocaleLowerCase() == "cofinity" || (NetworkType.NetworkName.toLocaleLowerCase() == "client specific"
        && $("#txtClientSpcNet").val().toLocaleUpperCase() == cofiUser)))
    {
        searchRequest.ClientSpecificCode = $("#rdCofinityType").val();
        $("#rdFCOMType").val("");
    }
    else if (NetworkType.NetworkName.toLocaleLowerCase() == "first choice of the midwest" || (NetworkType.NetworkName.toLocaleLowerCase() == "la primera elección del medio-oeste")) {
        searchRequest.ClientSpecificCode = $("#rdFCOMType").val();
        $("#rdCofinityType").val("");
    }
    else {
        searchRequest.ClientSpecificCode = $("#txtClientSpcNet").val();
        $("#rdCofinityType").val("");
        $("#rdFCOMType").val("");
    }

    $.ajax({
        type: 'POST',
        url: '/LocateProvider/SaveSearchRequestToSession',
        contentType: "application/json; charset=utf-8",
        data: JSON.stringify({ search: searchRequest }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            $.ajax({
                type: 'POST',
                url: '/LocateProvider/SaveRefineRequestToSession',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({ search: searchRequest }),
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {
                    window.location.href = '/LocateProvider/LocateProviderSearch/';
                },
                error: function (xmlHttpRequest, textStatus, errorThrown) {
                }
            });
            //window.location.href = '/LocateProvider/LocateProviderSearch/';
        },
        error: function (xmlHttpRequest, textStatus, errorThrown) {
            ////debugger;
        }
    });
}


