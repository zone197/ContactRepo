﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;
using Utilities;

namespace NABWebsite.Helper
{
    public static class AppSettingHelper
    {
        public static string GetAppSettingValue(string value)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: AppSettingHelper, GetAppSettingValue Method with Params value: " + value); 

                string returnValue = string.Empty;
                if (value != null)
                {
                    if (ConfigurationManager.AppSettings[value] != null)
                    {
                        traceLog.AppendLine(" & End: AppSettingHelper, GetAppSettingValue Method");
                        returnValue = ConfigurationManager.AppSettings[value].ToString();
                    }
                }
                traceLog.AppendLine(" & End: AppSettingHelper, GetAppSettingValue Method");
                return returnValue;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        public static int ReturnValue(string value)
        {
            try
            {
                int returnValue = 0;
                if (value != null)
                {
                    if (ConfigurationManager.AppSettings[value] != null)
                    {
                        returnValue = Convert.ToInt32(ConfigurationManager.AppSettings[value], CultureInfo.CurrentCulture);
                    }
                }
                return returnValue;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}