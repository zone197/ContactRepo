﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.ComponentModel;

namespace NABWebsite.Models
{
    public class TransplantModel
    {
        public IEnumerable<Transplant> TransplantData { get; set; }
        public string CompanyName { get; set; }
    }

    public class StateDetailsInformation
    {
        public string StateName { get; set; }
        public string Coordinates { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string AreaId { get; set; }
    }

    public class CenterList
    {
        public int ImageHeight { get; set; }
        public int ImageWidth { get; set; }
        public string ImageId { get; set; }
        public string ImagePath { get; set; }
        public string ImageUseMap { get; set; }
        public string ImageMapId { get; set; } 
        public IEnumerable<StateDetailsInformation> CenterInformation { get; set; }
    }
    #region Online Transplant Form
    public class OnlineTransplantFormModel
    {
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientName)]
        [DisplayName(Constants.TransplantClientName + Constants.TransplantColon)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        [DataType(DataType.Text)]
        public string ClientName { get; set; }

        [DisplayName(Constants.TransplantClientIdNumber + Constants.TransplantColon)]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [DataType(DataType.Text)]
        public string ClientIdNumber { get; set; }

        [DisplayName(Constants.TransplantClientCaseManager + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientCaseManager)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        [DataType(DataType.Text)]
        public string ClientCaseManager { get; set; }

        [DisplayName(Constants.TransplantClientTelephoneNumber1 + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientTelephoneNumber1)]
        [Phone]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [StringLength(10, MinimumLength = 10, ErrorMessage = Constants.TransplantLengthError10)]
        [DataType(DataType.PhoneNumber)]
        public string ClientTelephoneNumber1 { get; set; }

        [DisplayName(Constants.TransplantClientTelephoneNumber2 + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientTelephoneNumber2)]
        [Phone]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [StringLength(10, MinimumLength = 10, ErrorMessage = Constants.TransplantLengthError10)]
        [DataType(DataType.PhoneNumber)]
        public string ClientTelephoneNumber2 { get; set; }

        [DisplayName(Constants.TransplantClientPayerEligibilityContact + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientPayerEligibilityContact)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string ClientPayerEligibilityContact { get; set; }

        [DisplayName(Constants.TransplantClientPayerCaseManagerEmailAddress + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientPayerCaseManagerEmailAddress)]
        [EmailAddress(ErrorMessage = Constants.TransplantEmailError)]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(Constants.TransplantEmailValidation, ErrorMessage = Constants.TransplantEmailError)]
        public string ClientPayerCaseManagerEmailAddress { get; set; }

        [DisplayName(Constants.TransplantClientFaxNumber + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientFaxNumber)]
        [Phone]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [StringLength(10, MinimumLength = 10, ErrorMessage = Constants.TransplantLengthError10)]
        public string ClientFaxNumber { get; set; }

        [DisplayName(Constants.TransplantClientPayerStreet + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientPayerStreet)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string ClientPayerStreet { get; set; }

        [DisplayName(Constants.TransplantClientClaimPlatform + Constants.TransplantColon)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string ClientClaimPlatform { get; set; }

        [DisplayName(Constants.TransplantClientCity + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientCity)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string ClientCity { get; set; }

        [DisplayName(Constants.TransplantClientState + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientState)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string ClientState { get; set; }
        public IEnumerable<SelectListItem> ClientStateList { get; set; }
        [DisplayName(Constants.TransplantClientNonUSState + Constants.TransplantColon)]
        [Required]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string ClientNonUSState { get; set; }

        [DisplayName(Constants.TransplantClientCountry + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientCountry)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string ClientCountry { get; set; }
        [DisplayName(Constants.TransplantClientIsUSClient + Constants.TransplantColon)]
        public bool ClientIsUSClient { get; set; }

        [DisplayName(Constants.TransplantClientZipCode + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantClientZipCode)]
        [DataType(DataType.PostalCode)]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [StringLength(5, MinimumLength = 5, ErrorMessage = Constants.TransplantLengthError6)]
        public string ClientZipCode { get; set; }

        [DisplayName(Constants.TransplantFacilityName + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantFacilityName)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string FacilityName { get; set; }

        [DisplayName(Constants.TransplantFacilityProgramType + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantFacilityProgramType)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string FacilityProgramType { get; set; }

        [DisplayName(Constants.TransplantFacilityContact + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantFacilityContact)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string FacilityContact { get; set; }

        [DisplayName(Constants.TransplantFacilityTelephoneNumber + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantFacilityTelephoneNumber)]
        [Phone]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [StringLength(10, MinimumLength = 10, ErrorMessage = Constants.TransplantLengthError10)]
        public string FacilityTelephoneNumber { get; set; }

        [DisplayName(Constants.TransplantFacilityEmailAddress + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantFacilityEmailAddress)]
        [EmailAddress(ErrorMessage = Constants.TransplantEmailError)]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(Constants.TransplantEmailValidation, ErrorMessage = Constants.TransplantEmailError)]
        public string FacilityEmailAddress { get; set; }

        [DisplayName(Constants.TransplantFacilityFax + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantFacilityFax)]
        [Phone]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [StringLength(10, MinimumLength = 10, ErrorMessage = Constants.TransplantLengthError10)]
        public string FacilityFax { get; set; }

        [DisplayName(Constants.TransplantFacilityStreet + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantFacilityStreet)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string FacilityStreet { get; set; }

        [DisplayName(Constants.TransplantFacilityCity + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantFacilityCity)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string FacilityCity { get; set; }

        [DisplayName(Constants.TransplantFacilityState + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantFacilityState)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string FacilityState { get; set; }
        public IEnumerable<SelectListItem> FacilityStateList { get; set; }

        [DisplayName(Constants.TransplantFacilityZipCode + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantFacilityZipCode)]
        [DataType(DataType.PostalCode)]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [StringLength(5, MinimumLength = 5, ErrorMessage = Constants.TransplantLengthError6)]
        public string FacilityZipCode { get; set; }

        [DisplayName(Constants.TransplantPatientName + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientName)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string PatientName { get; set; }

        [DisplayName(Constants.TransplantPatientTelephoneNumber + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientTelephoneNumber)]
        [Phone]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [StringLength(10, MinimumLength = 10, ErrorMessage = Constants.TransplantLengthError10)]
        public string PatientTelephoneNumber { get; set; }

        [DisplayName(Constants.TransplantPatientDateOfBirth + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientDateOfBirth)]
        [RegularExpression(Constants.TransplantDateValidation, ErrorMessage = Constants.TransplantDateError)]
        [DataType(DataType.Date)]
        [DefaultValue(Constants.TransplantDefaultDate)]
        [DisplayFormat(DataFormatString = Constants.TransplantDateFormat, ApplyFormatInEditMode = true)]
        public string PatientDateOfBirth { get; set; }

        [DisplayName(Constants.TransplantPatientGender + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientGender)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        [DataType(DataType.Text)]
        public string PatientGender { get; set; }
        public IEnumerable<string> PatientGenderList { get; set; }

        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientInsuranceIdNumber)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [DisplayName(Constants.TransplantPatientInsuranceIdNumber + Constants.TransplantColon)]
        public string PatientInsuranceIdNumber { get; set; }

        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientCoverageEffectiveDate)]
        [DisplayName(Constants.TransplantPatientCoverageEffectiveDate + Constants.TransplantColon)]
        [RegularExpression(Constants.TransplantDateValidation, ErrorMessage = Constants.TransplantDateError)]
        [DataType(DataType.Date)]
        [DefaultValue(Constants.TransplantDefaultDate)]
        [DisplayFormat(DataFormatString = Constants.TransplantDateFormat, ApplyFormatInEditMode = true)]
        public string PatientCoverageEffectiveDate { get; set; }

        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientInsuredName)]
        [DisplayName(Constants.TransplantPatientInsuredName + Constants.TransplantColon)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string PatientInsuredName { get; set; }

        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientsDiagnosis)]
        [DataType(DataType.Text)]
        [DisplayName(Constants.TransplantPatientsDiagnosis + Constants.TransplantColon)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string PatientsDiagnosis { get; set; }

        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientIcdCode)]
        [DataType(DataType.Text)]
        [DisplayName(Constants.TransplantPatientIcdCode + Constants.TransplantColon)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string PatientIcdCode { get; set; }

        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientStreet)]
        [DataType(DataType.Text)]
        [DisplayName(Constants.TransplantPatientStreet + Constants.TransplantColon)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string PatientStreet { get; set; }

        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientCity)]
        [DataType(DataType.Text)]
        [DisplayName(Constants.TransplantPatientCity + Constants.TransplantColon)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string PatientCity { get; set; }

        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientState)]
        [DataType(DataType.Text)]
        [DisplayName(Constants.TransplantPatientState + Constants.TransplantColon)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string PatientState { get; set; }
        public IEnumerable<SelectListItem> PatientStateList { get; set; }

        [DisplayName(Constants.TransplantPatientZipCode + Constants.TransplantColon)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientZipCode)]
        [DataType(DataType.PostalCode)]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        [StringLength(5, MinimumLength = 5, ErrorMessage = Constants.TransplantLengthError6)]
        public string PatientZipCode { get; set; }

        [DisplayName(Constants.TransplantPatient500KCheck)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatient500KCheck)]
        [DataType(DataType.Text)]
        public string Patient500KCheck { get; set; }
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public IEnumerable<string> Patient500KChecklist { get; set; }

        [DisplayName(Constants.TransplantPatientCoverageDetail + Constants.TransplantColon)]
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public string PatientCoverageDetail { get; set; }

        [DisplayName(Constants.TransplantPatientInsuranceResponsibility)]
        [Required(ErrorMessage = Constants.TransplantEnter + Constants.TransplantPatientInsuranceResponsibility)]
        [DataType(DataType.Currency)]
        [RegularExpression(Constants.TransplantNumberValidation, ErrorMessage = Constants.TransplantNumberError)]
        public string PatientInsuranceResponsibility { get; set; }

        [DisplayName(Constants.TransplantPatientOutOfPocket)]
        public string PatientOutOfPocket { get; set; }
        [DataType(DataType.Text)]
        [RegularExpression(Constants.TransplantContentValidation, ErrorMessage = Constants.TransplantTextError)]
        public IEnumerable<string> PatientOutOfPocketList { get; set; }

    }
    #endregion



    public class DisplayList
    {
        public int FileId { get; set; }
        public string FileName { get; set; }
        public string FileTitle { get; set; }
        public string FileType { get; set; }
        public string Description { get; set; }
        public string CompanyName { get; set; }
        public string CreatedDate { get; set; }
        public string ExpirationDate { get; set; }
        public string LastModifiedDate { get; set; }
        public string OnlineForm { get; set; }
    }

    public class SearchResultFilterValue
    {
        [Display(Name = "Page")]
        public int PageNo { get; set; }
        public int TotalPages { get; set; }
        public string SortBy { get; set; }
        public string SortType { get; set; }
    }

    public class TransplantResultsModel
    {
        public SearchResultFilterValue SearchResultParameter { get; set; }
        public string DisplaySize { get; set; }
        public string CompanyName { get; set; }
        public string Message { get; set; }
        public string Header { get; set; }
        public string DisplaySizeText { get; set; }
        public string FormMenu { get; set; }
        public string FileType { get; set; }
        public string Role { get; set; }
        public IEnumerable<DisplayList> AllDisplayResults { get; set; }
        public IEnumerable<SelectListItem> DisplaySizeList { get; set; }
    }
}