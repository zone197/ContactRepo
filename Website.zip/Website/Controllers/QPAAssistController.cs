﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aetna.ProviderContracts.DataContracts;
using NABWebsite.DTO;
using NABWebsite.BLL;
using NABWebsite.Models;
using System.Configuration;
using System.Globalization;
using System.Text;
using Utilities;
using Aetna.Cofinity.Admin.Entities.Response;
using System.Diagnostics;
using NABWebsite.DataAccess;
using System.Threading.Tasks;

namespace NABWebsite.Controllers
{
    public class QPAAssistController : BaseController
    {

        private readonly DataAccess.Requests.Interface.IAreaCallHelper _areaCallHelper;
        // GET: QPAAssist
        NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
        ManageContent contentManager = new ManageContent();

        [NoCache]
        public ActionResult ClaimSearch()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: QPAAssistController, Index Method");
                var model = new AssistModel();
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                if (((UserDetails)Session[Constants.UserDetails] != null) && (((UserDetails)Session[Constants.UserDetails]).SelectedRole != null)
                    && ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant()
                    && Convert.ToBoolean(Session[Constants.FairCostAccess]) == true)
                {
                    Session[Constants.CurrentController] = Constants.QPAAssistController;
                    Session[Constants.CurrentAction] = "Index";
                    Session[Constants.Header] = Constants.FairCostQPAAssist;
                    Session["ClaimSearch"] = null;
                    return View("ClaimSearch", model);
                }
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {

                LogManager.WriteTraceLog(traceLog);
            }
        }

        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: QPAAssistController, Index Method");
                var model = new AssistModel();
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                if (((UserDetails)Session[Constants.UserDetails] != null) && (((UserDetails)Session[Constants.UserDetails]).SelectedRole != null)
                    && ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant()
                    && Convert.ToBoolean(Session[Constants.FairCostAccess]) == true)
                {
                    Session[Constants.CurrentController] = Constants.QPAAssistController;
                    Session[Constants.CurrentAction] = "Index";
                    Session[Constants.Header] = Constants.FairCostQPAAssist;

                    UserDetails user = (UserDetails)Session[Constants.UserDetails];
                    DiscoveryWebService discoveryService = new DataAccess.DiscoveryWebService();
                    if (Session["ClaimFound"] == null)
                    {
                        //ViewBag.ClaimError = "error";
                        model = new AssistModel();
                        return View("ClaimSearch", model);
                    }
                    else if (Session["ClaimSearch"] != null)
                    {

                        var request = new CTSNegotiationClaimSearchResultsRetrieveRequest
                        {
                            UserID = user.UserId,
                            ClaimID = (string)Session["ClaimSearch"],
                            ProductLineIDs = ConfigurationManager.AppSettings["ProductLineIDs"],
                            SourceSystemID = Convert.ToInt32(ConfigurationManager.AppSettings["SourceSystemID"])
                        };


                        var result = discoveryService.GetCTSClaimSearchResult(request);

                        if (result.ExtClaimNum != null)
                        {
                            // check for duplicate
                            var issueRequest = new CTSHasNegotiationIssuesRetrieveRequest
                            {
                                ClaimNum = result.DW2020_ClaimNum,
                                SrcSystemID = Convert.ToInt32(ConfigurationManager.AppSettings["SourceSystemID"]),
                                NegotiationProductTypeDefnID = Convert.ToInt32(ConfigurationManager.AppSettings["NegotiationProductTypeDefnID"])
                            };

                            var duplicateCheck = discoveryService.CheckNegotiationIssue(issueRequest);
                            if (!duplicateCheck.HasNegotiationIssue)
                            {


                                ////Get Claim Info from CTS
                                model.ClaimIDNumber = (string)Session["ClaimSearch"];
                                model.ClaimDOS = result.DateOfService.HasValue ? result.DateOfService.Value.ToString("MM/dd/yyyy") : string.Empty;
                                model.ClaimQPA = result.PaidAMT;
                                model.PatientFLName = result.PatientName;
                                model.ProviderName = result.ProviderName;
                                model.ProviderNPI = result.ProvNPI;
                                model.ProviderTIN = result.ProvTaxID;
                                model.MemberID = result.MemberID;
                                model.BillingStreet = result.BillingAddr;
                                model.BillingCity = result.BillingCity;
                                model.BillingState = result.BillingState;
                                model.ProviderStreet = result.ServiceAddr;
                                model.ProviderCity = result.ServiceCity;
                                model.ProviderState = result.ServiceState;
                                model.ClientName = result.ClientName;
                                model.ProviderPhoneNumber = result.PhoneNbr;
                                model.DW2020_ClaimNum = result.DW2020_ClaimNum;
                                model.GroupName = result.SubClientName;
                                model.ExtClientID = result.ExtClientID;
                                model.SubClientName = result.SubClientName;
                                model.ProductLineID = result.ProductLineID;
                                model.ExtSubClientID = result.ExtSubClientID;

                                if (!string.IsNullOrWhiteSpace(result.BillingPostalCode.Trim()))
                                {
                                    model.BillingZipCode = result.BillingPostalCode.Length > 5 ? result.BillingPostalCode.Substring(0, 5) : result.BillingPostalCode;
                                }

                                if (!string.IsNullOrWhiteSpace(result.ServicePostalCode.Trim()))
                                {
                                    model.ProviderZipCode = result.ServicePostalCode.Length > 5 ? result.ServicePostalCode.Substring(0, 5) : result.ServicePostalCode;
                                }

                                if (user != null)
                                {
                                    model.RequestorFName = user.UserData.FirstName;
                                    model.RequestorLName = user.UserData.LastName;
                                    model.UserId = user.UserId;
                                    if (!string.IsNullOrEmpty(user.UserData.MiddleInitial))
                                    {
                                        model.RequestorName = user.UserData.FirstName + " " + user.UserData.MiddleInitial + " " + user.UserData.LastName;
                                    }
                                    else
                                    {
                                        model.RequestorName = user.UserData.FirstName + " " + user.UserData.LastName;
                                    }
                                    if (!string.IsNullOrEmpty(user.UserData.Email))
                                    {
                                        model.RequestorEmailAddress = user.UserData.Email;
                                    }
                                    if (!string.IsNullOrEmpty(user.UserData.Phoneno))
                                    {
                                        model.RequesterPhoneNumber = user.UserData.Phoneno;
                                    }
                                }

                                int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);


                                var fundingTypes = discoveryService.GetFundingTypes().ToList();
                                model.FunctionTypeList = fundingTypes.Select(x => new SelectListItem()
                                {
                                    Text = x.FundingTypeName,
                                    Value = x.FundingTypeDefnID.ToString()
                                });

                                var speacilities = discoveryService.GetProviderSpecialtyInfo().Where(x => x.SrcSystemID == 3).ToList();

                                model.Specialities = speacilities.Select(x => new SelectListItem()
                                {
                                    Text = x.SpecialtyName,
                                    Value = x.SpecialtyName
                                });

                                var statesAll = contentManager.GetStatesLocateProvider(helper.GetRequestHeader(string.Empty, defaultSourceId)).ToList();

                                List<SelectListItem> statelist = statesAll.Select(x =>
                                                          new SelectListItem()
                                                          {
                                                              Text = x.StateName.ToString(),
                                                              Value = x.StateCode.ToString()
                                                          }).ToList();

                                model.BillingStateList = statelist;
                                model.ProviderStateList = statelist;
                                model.formDate = DateTime.Now.ToString("MM/dd/yyyy");
                            }
                            else
                            {
                                model.ClaimIDNumber = (string)Session["ClaimSearch"];
                                ViewBag.DuplicateError = "duplicateError";
                                traceLog.AppendLine(" & Duplicate Claim Error : QPAAssistController, Index Method");
                                return View("ClaimSearch", model);
                            }

                        }
                        else
                        {
                            model.ClaimIDNumber = (string)Session["ClaimSearch"];
                            ViewBag.ClaimError = "error";
                            traceLog.AppendLine(" & Claim  Not found Error : QPAAssistController, Index Method");
                            return View("ClaimSearch", model);
                        }
                    }
                    Session["ClaimFound"] = null;
                    traceLog.AppendLine(" & End: QPAAssistController, Index Method");
                    return View(model);
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {

                LogManager.WriteTraceLog(traceLog);
            }
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult SaveClaimInfo(AssistModel model)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: QPAAssistController, SaveClaimInfo Method");
                DiscoveryWebService ds = new DiscoveryWebService();
                long issueId = 0;
                var request = ObjectMap(model);
                var fundingTypes = ds.GetFundingTypes().ToList();
                model.FunctionTypeList = fundingTypes.Select(x => new SelectListItem()
                {
                    Text = x.FundingTypeName,
                    Value = x.FundingTypeDefnID.ToString()
                });
                var speacilities = ds.GetProviderSpecialtyInfo().Where(x => x.SrcSystemID == 3).ToList();

                model.Specialities = speacilities.Select(x => new SelectListItem()
                {
                    Text = x.SpecialtyName,
                    Value = x.SpecialtyName
                });
                int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
                var statesAll = contentManager.GetStatesLocateProvider(helper.GetRequestHeader(string.Empty, defaultSourceId)).ToList();

                List<SelectListItem> statelist = statesAll.Select(x =>
                                          new SelectListItem()
                                          {
                                              Text = x.StateName.ToString(),
                                              Value = x.StateCode.ToString()
                                          }).ToList();

                model.BillingStateList = statelist;
                model.ProviderStateList = statelist;
                if (ModelState.IsValid)
                {

                    var maxFileSize = Convert.ToInt32(ConfigurationManager.AppSettings["MaxFilesize"]);
                    var eobFileSize = model.EobAttachment.ContentLength / 1024;
                    var openFileSize = model.OpenForm.ContentLength / 1024;

                    var expireDate = (DateTime.Now - Convert.ToDateTime(model.CheckDate)).TotalDays;

                    if (expireDate > 40)
                    {
                        ModelState.AddModelError("CheckDate", "The period to initiate the open negotiation period has elapsed. The claim is no longer eligible.");
                        return View("Index", model);
                    }
                    else if (eobFileSize > maxFileSize)
                    {
                        ModelState.AddModelError("EobAttachment", "File is too big - File size exceeds maximum limit of 2MB.");
                        return View("Index", model);
                    }
                    else if (eobFileSize <= 0)
                    {
                        ModelState.AddModelError("EobAttachment", "Invalid file");
                        return View("Index", model);
                    }
                    else if (openFileSize > maxFileSize)
                    {
                        ModelState.AddModelError("OpenForm", "File is too big - File size exceeds maximum limit of 2MB.");
                        return View("Index", model);
                    }
                    else if (openFileSize <= 0)
                    {
                        ModelState.AddModelError("OpenForm", "Invalid file");
                        return View("Index", model);
                    }
                    else if (model.RequiredAttachments.Length != 0)
                    {
                        var maxOtherFiles = Convert.ToInt32(ConfigurationManager.AppSettings["MaxOtherFilesize"]);
                        var otherFileSize = -1;
                        if (model.RequiredAttachments.Length == 1 && model.RequiredAttachments[0] != null)
                        {
                            otherFileSize = model.RequiredAttachments[0].ContentLength;
                        }
                        else
                        {
                            for (var fl = 0; fl < model.RequiredAttachments.Length; fl++)
                            {
                                if (model.RequiredAttachments[fl] != null)
                                    otherFileSize += model.RequiredAttachments[fl].ContentLength;
                            }
                        }
                        if (otherFileSize != -1)
                            otherFileSize = otherFileSize / 1024;
                        if (otherFileSize > maxOtherFiles)
                        {
                            ModelState.AddModelError("RequiredAttachments", "File is too big - File size exceeds maximum limit of 5MB.");
                            return View("Index", model);
                        }
                        else if (otherFileSize == 0)
                        {
                            ModelState.AddModelError("RequiredAttachments", "Invalid file");
                            return View("Index", model);
                        }
                    }

                    var result = ds.AddCTSNegotiationIssueEntry(request);

                    issueId = result.IssueID;
                    if (issueId > 0)
                    {
                        if (model.EobAttachment != null)
                        {
                            var attachmentModel = new AssistAttachmentModel()
                            {
                                AttachmentFile = model.EobAttachment,
                                AttachmentType = "EOB",
                                IssueID = issueId
                            };

                            var uploadFiles = UploadAttachment(attachmentModel);
                        }
                        if (model.OpenForm != null)
                        {
                            var attachmentModel = new AssistAttachmentModel()
                            {
                                AttachmentFile = model.OpenForm,
                                AttachmentType = "ONR", //Open Negotiation Request
                                IssueID = issueId
                            };

                            var uploadFiles = UploadAttachment(attachmentModel);
                        }
                        if (model.RequiredAttachments.Length != 0)
                        {
                            for (var i = 0; i < model.RequiredAttachments.Length; i++)
                            {
                                if (model.RequiredAttachments[i] != null)
                                {
                                    var attachmentModel = new AssistAttachmentModel()
                                    {
                                        AttachmentFile = model.RequiredAttachments[i],
                                        AttachmentType = "Other",
                                        IssueID = issueId,
                                        FileDescription = model.FileDescription[i]
                                    };
                                    var uploadFiles = UploadAttachment(attachmentModel);
                                }
                            }

                        }
                    }
                }
                traceLog.AppendLine(" & End: QPAAssistController, SaveClaimInfo Method");
                ViewBag.IssueId = issueId;
                return View("Index", model);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {

                LogManager.WriteTraceLog(traceLog);
            }
        }

        private CTSCreateNegotiationIssueEntryInsertRequest ObjectMap(AssistModel model)
        {

            var request = new CTSCreateNegotiationIssueEntryInsertRequest
            {
                DebugID = 0,
                FH_SiteLogin = model.UserId,
                FH_UserLastName = model.RequestorLName,
                FH_UserFirstName = model.RequestorFName,
                FH_UserEmailAddr = model.RequestorEmailAddress,
                FH_PhoneNbr = model.RequesterPhoneNumber,
                NegotiationReceivedDate = Convert.ToDateTime(model.NegotiationDate),
                ExtClientID = model.ExtClientID,
                ExtSubClientID = model.ExtSubClientID,
                ProductLineID = model.ProductLineID,
                ExtClaimNum = model.ClaimIDNumber,
                DW2020_ClaimNum = model.DW2020_ClaimNum,
                FundingTypeDefnID = model.FundingType,
                ClientPaidAMT = model.AmountPaid,
                PaidAMT = model.ClaimQPA,
                OfferAMT = model.ProviderOffer,
                PatientAMT = model.PatientAmount,
                Copay_DeductAMT = model.CopayDeductible,
                CoInsAMT = model.Coinsurance,
                RemainCoInsAMT = model.BalancePaid,
                OutOfPocketAMT = model.RemainingPocket,
                CheckDate = Convert.ToDateTime(model.CheckDate),
                ProviderName = model.ProviderName,
                ProvTaxID = model.ProviderTIN,
                ProvNPI = model.ProviderNPI,
                ServiceAddr = model.ProviderStreet,
                ServiceCity = model.ProviderCity,
                ServiceState = model.ProviderState,
                ServicePostalCode = model.ProviderZipCode,
                BillingAddr = model.BillingStreet,
                BillingCity = model.BillingCity,
                BillingState = model.BillingState,
                BillingPostalCode = model.BillingZipCode,
                PhoneNbr = model.ProviderPhoneNumber,
                FaxNbr = model.ProviderFaxNumber,
                EmailAddr = model.ProviderEmailAddress,
                MedicalSpecialtyName = model.ProviderSpecialty,
                Comments = model.AdditionalNotes
            };
            return request;

        }
        private bool UploadAttachment(AssistAttachmentModel model)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: QPAAssistCOntroller, UploadAttachment Method with Param request: ");
                var request = new QpaAttachmentRequest()
                {
                    IssueID = model.IssueID,
                    UserLoginID = Convert.ToInt32(ConfigurationManager.AppSettings["CTSUserLoginId"]),
                    UserGUID = Convert.ToInt32(ConfigurationManager.AppSettings["CTSUserLoginId"]),
                    AttachmentType = model.AttachmentType
                };

                request.AttachmentTypeDefnID = model.AttachmentType == "EOB" ? 20 : 10;
                request.AttachmentFile = model.AttachmentFile;
                if (model.AttachmentType == "Other")
                    request.FileDescription = model.FileDescription;



                var qpaAttachmentService = new QpaAttachmentService();
                var isSuccess = qpaAttachmentService.UploadAttachment(request);
                traceLog.AppendLine(" & End:QPAAssistCOntroller, UploadAttachment Method");
                return isSuccess;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// Claim Result
        /// </summary>
        /// <param name="claimObject"></param>
        /// <returns>ActionResult</returns>
        #region Search Results
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetClaim(string claimId)
        {
            StringBuilder traceLog = new StringBuilder();
            int claimFound = 0;
            Session["ClaimSearch"] = null;
            try
            {
                traceLog.AppendLine("Start: QPAAssistController, ClaimSearch Method with Param claim: " + claimId);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: QPAAssistController, ClaimSearch Method");
                    return Json(claimFound, JsonRequestBehavior.AllowGet);
                }
                if (((UserDetails)Session[Constants.UserDetails] != null) && (((UserDetails)Session[Constants.UserDetails]).SelectedRole != null) && ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                {
                    if (claimId != null)
                    {

                        ClaimInquiry claimObject = new ClaimInquiry();
                        ProcessedClaim processClaim = new ProcessedClaim();
                        claimObject.ClaimSearchCriteria = new ClaimSearchCriteria()
                        {
                            ClaimNo = claimId
                        };
                        ProcessedClaimSearchCriteria processClaimSearchCriteria = new ProcessedClaimSearchCriteria()
                        {
                            Network = "First Health",
                            Role = "Payer",
                            SrcSystemID = ConfigurationManager.AppSettings["SourceSystemID"],
                            session = Session.SessionID,
                            SelectedSearchCriteria = "ClaimNo",
                            ProcessClaim = processClaim,
                            ClaimSearchCriteria = claimObject.ClaimSearchCriteria
                        };

                        SetUserAccess(processClaimSearchCriteria);

                        ClaimInquiryBL claimBL = new ClaimInquiryBL();

                        claimObject.ProcessedClaim = claimBL.GetClaims(processClaimSearchCriteria);

                        claimFound = claimObject.ProcessedClaim.TotalCount;

                        if (claimFound == 1)
                        {
                            var ClaimNumber = claimObject.ProcessedClaim.ClaimResult.Select(x => x.ClaimNumber).FirstOrDefault();
                            Session["ClaimSearch"] = claimId;
                            Session["ClaimFound"] = "1";
                        }


                    }

                }
                traceLog.AppendLine(" & End: QPAAssistController, ClaimSearch Method");
                return Json(claimFound, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        #endregion

        [AjaxValidateAntiForgeryToken]
        public JsonResult RefreshClaim()
        {
            Session["ClaimFound"] = "1";
            return Json(JsonRequestBehavior.AllowGet);
        }

        private void SetUserAccess(ProcessedClaimSearchCriteria ProcessClaimSearchCriteria)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimInquiryController, SetUserAccess Method with Param ProcessClaimSearchCriteria: " + ProcessClaimSearchCriteria);
                UserDetails user = (UserDetails)Session[Constants.UserDetails];
                if (user != null)
                {
                    if (!string.IsNullOrEmpty(user.UserId))
                    {
                        ProcessClaimSearchCriteria.Userid = user.UserId;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole))
                    {
                        ProcessClaimSearchCriteria.Role = user.SelectedRole;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole)
                        && user.UserRoles != null
                        && user.UserRoles.Count() > 0)
                    {
                        ProcessClaimSearchCriteria.IsEmployee = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault().IsEmployee;
                        IEnumerable<CanCheckRestrictedMember> canCheckRestrictedList = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                        if (canCheckRestrictedList != null) ProcessClaimSearchCriteria.CanCheckRestrictedMembers = canCheckRestrictedList.FirstOrDefault().RestrictedCheck == 1 ? true : false;
                        else ProcessClaimSearchCriteria.CanCheckRestrictedMembers = false;
                    }
                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    ProcessClaimSearchCriteria.Site = ConfigurationManager.AppSettings[Constants.Site];
                }
                traceLog.AppendLine(" & End: QPAAssistController, SetUserAccess Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

    }
}

