﻿using Aetna.Cofinity.Admin.Entities.Response;
using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Helper;
using NABWebsite.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Utilities;

namespace NABWebsite.Controllers
{
    public class SecureDocumentsController : Controller
    {        
        private static Dictionary<string, int> _cachePageids;
        // will assign by lang selection
        int langcode = Convert.ToInt32(ConfigurationManager.AppSettings["langCode"], CultureInfo.InvariantCulture);
        
        // GET: NoticesnNews
        public ActionResult Page(string PageId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureDocumentsController, Page Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home", new {PageId = 1000 });
                }

                IndexViewModel indexViewModel = new IndexViewModel();
                // Get page information from service
                ManageContent manageContent = new ManageContent();
                PageInfo pageInfo = new PageInfo();
                string culture = AppSettingHelper.GetAppSettingValue(CookieConstant.InitialCulture);

                //Culture is set to english for content pages bydefault because no language change is for content page
                Session["_culture"] = "en-us";

                Session[Constants.Site] = ConfigurationManager.AppSettings[Constants.Site];
                //ViewBag.Title = "First Health and Confinity ";

                Session[Constants.CurrentController] = "SecureDocuments";
                Session[Constants.CurrentAction] = "Page";

                int pageId = 0;
                PageId = PageId.Replace(" ", "").Replace("/", "").Replace("-", "").Replace("&", "");

                int id;
                if (int.TryParse(PageId, out id))
                {
                    pageId = Convert.ToInt32(id);
                    pageId = GetpageIds("", id);
                    if (id != pageId)
                    { pageId = 1000; }
                }
                else
                {
                    pageId = GetpageIds(PageId, 0);
                    pageId = 1000;  //rediret to home if parsing fail
                }
                pageInfo = manageContent.GetPagContent(pageId, langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());

                ContentViewModel contentViewModel = new ContentViewModel();
                //contentViewModel.Title = Server.HtmlEncode(pageInfo.Content.Heading);
                contentViewModel.Title = pageInfo.Content.Heading;
                contentViewModel.Contents = pageInfo.Content.ContentText;//Encode the html
                contentViewModel.ID = pageInfo.Content.PageId;
                indexViewModel.Content = contentViewModel;
                if (contentViewModel.Title.ToUpper().Contains("NOTICES AND NEWS"))
                {
                    Session[Constants.Header] = Constants.NoticesnNewsHeader;
                }
                else if (contentViewModel.Title.ToUpper().Contains("COVID-19 RESOURCES"))
                {
                    Session[Constants.Header] = Constants.COVIDResourcesHeader;
                }
                else if (contentViewModel.Title.ToUpper().Contains("RESOURCES"))
                {
                    Session[Constants.Header] = Constants.ResourcesHeader;
                }
                else if (contentViewModel.Title.ToUpper().Contains("NETWORK TERMINATION REPORTS"))
                {
                    Session[Constants.Header] = Constants.NetworkTermReports;
                }
                else if (contentViewModel.Title.ToUpper().Contains("COFINITY CLIENT LIST"))
                {
                    Session[Constants.Header] = Constants.CofinityClientList;
                }
               
               
                traceLog.AppendLine(" & End: SecureDocumentsController, Page Method");
                return View("Page", indexViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private int GetpageIds(string keyname, int keyvalue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureDocumentsController, GetpageIds Method with Param keyname: " + keyname + " and with Param keyvalue: " + keyvalue);
                int pageid = 1000;

                ManageContent objManage = new ManageContent();
                Dictionary<string, int> dictionary = new Dictionary<string, int>();
                if (this.HttpContext.Cache["pagesid"] == null)
                {
                    _cachePageids = objManage.GetPageIds(Convert.ToInt32(pageid));
                    this.HttpContext.Cache["pagesid"] = _cachePageids;
                }
                else
                {
                    _cachePageids = (Dictionary<string, int>)this.HttpContext.Cache["pagesid"];
                }
                if (_cachePageids == null)
                {
                    _cachePageids = objManage.GetPageIds(Convert.ToInt32(pageid)); //get All pagesid
                }

                if (Convert.ToInt32(keyvalue) > 0)
                {
                    pageid = _cachePageids.FirstOrDefault(x => x.Value == keyvalue).Value;
                }
                else
                {
                    _cachePageids.TryGetValue(keyname.ToLower(), out pageid);
                }
                traceLog.AppendLine(" & End: SecureDocumentsController, GetpageIds Method");
                return pageid;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
    }
}