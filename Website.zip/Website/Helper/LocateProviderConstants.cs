﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NABWebsite.Helper
{
    public static class ApplicationConstants
    {
        public const char SplitString = '_';
        public const string RadioOtherClientNetwork = "3";
        public const string LocateProviderController = "LocateProvider";
        public const string LocateProviderSpecialtyDefinition = "LocateProviderSpecialityDefination";
        public const string SelectNetworkTypeAction = "SelectNetworkType";
        public const string IndexActionForSpecialtyDefinition = "Index";
        public const string MyList = "1";
        public const string SearchResult = "2";
        public const string Email = "1";
        public const string Pdf = "2";
        public const string LocateProviderMobileController = "LocateProviderMobile";
        public const string LocateProviderSearchResultAction = "LocateProviderSearchResult";
        public const string CompareResultAction = "CompareResult";
        public const string ZipLookupSiteUrl = "ZipLookupSiteUrl";
        public const string SearchIndexActionMobile = "SearchIndex";
        public const string IndexActionMobile = "Index";
        public const string ProviderTypeSelection = "ProviderTypeSelection";
        public const string CustomerTypeSelection = "CustomerTypeSelection";
        public const string SearchIndex = "SearchIndex";
        public const string ProviderMoreDetails = "ProviderMoreDetails";
        public const string ProviderSearchResult = "ProviderSearchResult";
        public const string StateDisclaimersAction = "StateDisclaimers";
        public const string LocateProviderSearchAction = "LocateProviderSearch";
        public const string Error = "Error";
        public const string CustomPage = "CustomPage";
        public const string CreateDirectoryAction = "CreateDirectory";
        public const string SendMailAction = "SendMailPage";
        public const string MyDirectory = "MyDirectory";        
        public const string TaggedProvidersAction = "TaggedProviders";
        public const string GetDetailedProviderInfoAction = "GetDetailedProviderInfo";

        public const string HomeController = "Home";
        public const string IndexAction = "Index";
        public const string ProviderSearchCriteria = "ProviderSearchCriteria";
        public const string QPAAssistController = "QPAAssist";
    }

    public static class SessionConstant
    {
        public const string CookiePlanCode = "_plancode";
        public const string SearchRequest = "searchRequest";
        public const string Role = "Role";
        public const string ComparedProvider = "comparedProvider";
        public const string TaggedComparedProvider = "taggedComparedProvider";
        public const string ExpandedProviders = "expandedProviders";
        public const string SortingPagingInfo = "sortingPagingInfo";
        public const string RefineRequest = "refineRequest";
        public const string TaggedProvider = "taggedProvider";
        public const string TaggedSortingPagingInfo = "taggedSortingPagingInfo";
        public const string CurrentController = "CurrentController";
        public const string CurrentAction = "CurrentAction";
        public const string ProviderNumber = "providerNumber";
        public const string ActiveTab = "activeTab";
        public const string SendMail = "SendMail";
        public const string SessionClientlist = "SessionClientlist";
        public const string PathInfo = "pathInfo";
        public const string CustomHeader = "CustomHeader";
        public const string FullUrl = "FullUrl";
        public const string ClientListDetails = "sortingPagingClientInfo";
        public const string ClientListModel = "ClientListModel";
        public const string HospitalName = "HospitalName";

    }

    public static class CookieConstant
    {
        public const string Culture = "_culture";
        public const string InitialCulture = "en-us";
        public const string CheckCulture = "es";
        public const string NewCulture = "es-CR";

    }

    public static class VariableConstant
    {
        public const string StateDisclaimerKey = "StateDisclaimerKey";
        public const string TermsOfUseKey = "TermsOfUseKey";
        public const string UserManualKey = "UserManualKey";
        public const string LocateProviderFunctionality = "LocateProvider";
        public const string IsCaptchaCheck = "IsCaptchaCheck";
        public const string AcceptedStateForUsers = "AcceptedStateForUsers";
        public const string UserTypeProvider = "Provider";
        public const string ClientCode = "clientCode";
        public const string InvalidClientCode = "Invalid Client Code";
        public const string Weekdays = "WeekDays";
        public const string Header = "Header Id";
        public const string PrivateKey = "RecaptchaPrivateKey";
        public const string PublicKey = "RecaptchaPublicKey";
        public const string GoogleAPIAddress = "GoogleRecaptchaAPIAddressSingle";
        public const string GoogleRecaptchaVerificationURL = "GoogleRecaptchaVerificationURL";
        public const string GoogleApiAddressSingle = "GoogleRecaptchaAPIAddressSingle";
        public const string GoogleApiAddressMultiple = "GoogleRecaptchaAPIAddressMultiple";
        public const string ProviderNumber = "providerNumber";
        public const string StateDisclaimersCode = "stateDisclaimersCode";
        public const string SearchResult = "searchResult";
        public const string DirectoryPath = "DirectoryPath";
        public const string SessionTimeout = "Session timeout";
        public const string Success = "Success";
        

        public const string Cofinity = "Cofinity";
        public const string FirstHealth = "First Health";
        public const string ClientSpecific = "Client Specific";
        public const string ClientSpecificSpanish = "El cliente específico";
        public const string ProviderUser = "Provider";

        public const string StartIndexForRecordDisplay = "StartIndexForRecordDisplay";
        public const string LastIndexForRecordDisplay = "LastIndexForRecordDisplay";
        public const string SortColumn = "SortColumn";
        public const string SortOrder = "SortOrder";
        public const string SortField = "SortField";
        public const string SortDirection = "SortDirection";
        public const string PageSize = "PageSize";
        public const string CurrentPageIndex = "CurrentPageIndex";

        public const string LastIndexForClientList="LastIndexForClientList";
        public const string PageSizeForClientList = "PageSizeForClientList";

        public const int TwentyProviders = 20;
        public const int TenClients = 10;
        public const string FirstName = "FirstName";
        public const string Descending = "Desc";
        public const string SpecialtyName = "SpecialtyName";
        public const string Name = "Name";
        public const string Gender = "Gender";
        public const string StreetName = "StreetName";
        public const string RefinePCP = "RefinePCP";
        public const string HospitalAccrediation = "HospitalAccrediation";
        public const string BoardCetified = "BoardCetified";
        public const string ADAAccessible = "ADAAccessible";
        public const string ECP = "ECP";
        public const string AcceptingNewPatients = "AcceptingNewPatients";
        public const string PracticeName = "PracticeName";
        public const string HospitalAffiliation = "HospitalAffiliation";
        public const string CityName = "City";

        public const string Language = "Language";
        public const string Specialty = "Specialty";
        public const string Condition = "Condition";
        public const string Focus = "Focus";
        public const string Tin = "TIN";
        public const string All = "All";
        public const string Phone = "Phone";
        public const string License = "License";
        public const string NPI = "NPI";

        public const string TwoProviders = "twoProviders";
        public const string ThreeProviders = "threeProviders";
        public const string ProviderCompareHeading = "Provider Compare";
        public const string CompareList = "CompareList";
        public const string MinimumProvidersForComparison = "minimumProvidersCompare";
        public const string MaximumProvidersForComparison = "maximumProvidersCompare";

        public const string LabelHideOptions = "lblHideOptions";
        public const string LabelShowOptions = "lblShowOptions";
        public const string LabelSeeLessDetails = "lblSeeLessDetails";
        public const string LabelSeeMoreDetails = "lblSeeMoreDetails";
        public const string LabelEnterNumericRadiusErrorMessage = "lblEnterNumericRadiusErrorMessage";
        public const string LabelErrorMessageValidZip = "lblErrorMsgValidZip";
        public const string LabelErrorEnterNumericValuesInZip = "lblErrorMsgEnterNumericValuesInZip";
        public const string LabelErrorSpecialtySelectionMandatory = "lblErrorSpecialtySelectionMandatory";
        public const string LabelErrorSelectSpecialtyBeforeAdding = "lblErrorSelectSpecialtyBeforeAdding";
        public const string LabelAddOnlyFiveSpecialties = "lblAddAtmostFiveSpecialties";
        public const string LabelSpecialtySelectionNotPossible = "lblSpecialtySelectionNotPossible";
        public const string LabelSelectFiveSpecialties = "lblSelectFiveSpecialties";
        public const string LabelSpecialtyAdditionMandatoryBeforeRemoving = "lblSpcAdditionMandatoryBeforeRemoving";
        public const string LabelAddSpecialtyBeforeRemoving = "lblAddSpecialtyBeforeRemoving";
        public const string LabelSpecialtySelectionMandatoryBeforeRemoving = "lblSpcSelectionMandatoryBeforeRemoving";
        public const string LabelSelectSpecialtyBeforeRemoving = "lblSelectSpcBeforeRemoving";
        public const string LabelTinNumericErrorMessage = "lblTinNumericErrorMessage";
        public const string LabelEnterNumericValuesInTin = "lblEnterNumericValuesInTin";
        public const string LabelUserTypeMandatory = "lblUserTypeMandatory";
        public const string LabelSelectUserType = "lblSelectUserType";
        public const string LabelProviderTypeIsMandatory = "lblProviderTypeIsMandatory";
        public const string LabelSelectProviderTypeErrorMessage = "lblSelectProviderTypeErrorMessage";
        public const string LabelZipMandatoryOnZipSelection = "lblZipMandatoryOnZipSelection";
        public const string LabelSelectZipBeforeSearchNow = "lblSelectZipBeforeSearchNow";
        public const string LabelStateMandatoryOnStateSelection = "lblStateMandatoryOnStateSelection";
        public const string LabelSelectStateBeforeSearchNow = "lblSelectStateBeforeSearchNow";
        public const string LabelOptionalCriteriaErrorMessage = "lblOptionalCriteriaErrorMessage";
        public const string LabelSelectBeforeExpandingOptionalCriteria = "lblSelectBeforeExpandingOptionalCriteria";
        public const string LabelOptionalCriteriaErrorWithoutUser = "lblOptionalCriteriaErrorWithoutUser";
        public const string LabelSelectBeforeExpandOptionalWithoutUser = "lblSelectBeforeExpandOptWithoutUser";

        public const string LabelProvideValidIdOrPhoneNumber = "lblProvideValidIdOrPhoneNumber";
        public const string LabelEnterIdOrPhoneNumber = "lblEnterIdOrPhoneNumber";
        public const string LabelEmailOrTextNotSent = "lblEmailOrTextNotSent";
        public const string LabelValidatingCaptchaError = "lblValidatingCaptchaError";

        public const string LabelEmailSuccessFull = "lblEmailSuccessFul";
        public const string LabelEmailTextSuccessFull = "lblEmailTextSuccessFul";
        public const string LabelEmailNotSent = "lblEmailNotSent";
        public const string LabelErrorCaptchaValidation = "lblErrorCaptchaValidation";
        public const string LabelErrorEnterEmail = "lblErrorEnterEmail";
        public const string LabelPleaseFillCaptchaErrorMessage = "lblPleaseFillCaptchaErrorMessage";

        //public const string LabelZipOrStateIsMandatory = "lblZipOrStateIsMandatory";
        //public const string LabelCriteriaExpandedAfterZipOrStateSelection = "lblCriteriaExpandedAfterZipOrStateSelection";
        //public const string LabelSelectZipOrStateForOptionalCriteria = "lblSelectZipOrStateForOptionalCriteria";
        //public const string LabelNetworkSelectionMandatory = "lblNetworkSelectionMandatory";

        public const string LabelEnterMinimumOneEmailAddress = "lblEnterAtleastOneEmailAddress";
        public const string LabelEmailAddressMandatory = "lblEmailAddressMandatory";
        public const string LabelFindDirectoryAttachedInMail = "lblFindDirectoryAttachedInMail";
        public const string LabelLinkSentInFiveHours = "lblLinkSentInFiveHours";
        public const string LabelLinkSentInTwentyFourHours = "lblLinkSentInTwentyFourHours";

        public const string LabelDirectoryNameRequired = "lblDirectoryNameRequired";

        public const string LabelNetworkSelectionRequired = "lblNetworkSelectionRequired";
        public const string LabelEnterValidClientCodeBeforeStartNow = "lblEnterValidClientCodeBeforeStartNow";
        public const string LabelClientCodeFieldMandatoryForClientSpecificNetwork = "lblClientCodeFieldMandatoryForClientSpecificNetwork";
        public const string LabelInvalidClientSpecificNetworkCode = "lblInvalidClientSpecificNetworkCode";
        public const string LabelClientCodeIsNotValid = "lblClientCodeIsNotValid";
        public const string LabelSelectOneNetworkType = "lblSelectOneNetworkType";

        public const string LabelSelectMinimumTwoProvidersForComparison = "lblSelectAtleastTwoProvidersForComparison";
        public const string LabelInvalidZipCode = "lblInvalidZipCode";
        public const string LabelEnterValidZipOrState = "lblEnterValidZipOrState";
        public const string LabelNoMoreThanThreeProvidersSelected = "lblNoMoreThanThreeProvidersSelected";
        public const string LabelSelectAnotherSimilarProviderForComparison = "lblSelectAnotherSimilarProviderForComparison";
        public const string LabelMaximumTwoHundredProviders = "lblAtmostTwoHundredProvidersToBeSelected";
        public const string LabelNothingSelected = "lblNothingSelected";
        public const string LabelNoMatchCount = "lblNoMatchCount";
        public const string LabelErrorOptionalCriteria = "lblErrorOptionalCriteria";
        public const string LabelErrorOptionalCriteriaSelectZipOrState = "lblErrorOptionalCriteriaSelectZipOrState";

        public const string LabelZipOrStateMandatory = "lblZipOrStateMandatory";
        public const string LabelErrorSelectZipOrState = "lblErrorSelectZipOrState";

        public const string ModelValue = "model";
        public const string DurationFiveMinutes = "5 minutes";
        public const string DurationSixDays = "6 Days";
        public const string ReturnStringFalse = "false";
        public const string ProviderDirectoryHeading = "Provider Directory";
        public const string MinimumProviders = "minimumProviders";
        public const string MaximumProviders = "maximumProviders";
        public const string DurationTenMinutes = "10 minutes";
        public const string DurationFifteenMinutes = "15 minutes";
        public const string ZeroMyList = "ZeroMyList";
        public const string DurationFiveHours = "5 hours";
        public const string DurationTwentyFourHours = "24 hours";
        public const string Provider = "provider";
        public const string Miles = "mile";
        public const string DateTimeFormat = "dd-MM-yyyy-HH':'mm':'ss";
        public const string Underscore = "_";
        public const string AcceptingPatients = "AcceptingPatients";
        public const string NotAcceptingPatients = "NotAcceptingPatients";
        public const string PatientCount = "0";
        public const string NotAvailable = "NA";
        public const string ProviderDetailsHeading = "Provider Details";
        public const string ProviderMapDetailsHeading = "Provider Map Details";
        public const string NotCompared = "Not compared";
        public const string ReturnTrue = "true";
        public const string Direction = "direction";

        public const string LabelMoreOptions = "lblMoreOptions";
        public const string LabelLessOptions = "lblLessOptions";

        public const string Search = "search";

        public const string CarrierNumber = "number@";
        public const string Character = "@";
        public const string StartTime = ":00 AM";
        public const string StartTimeInAM = " AM";
        public const string EndTime = ":00 PM";
        public const string EndTimeInPM = " PM";
        public const string ReportICInfoSubject = "NAB Contact Us";
        public const string ClaimAppealFormInfoSubject = "Claim Appeal Form";
        public const string ProviderTINRequestFormInfoSubject = "Provider TIN Request Form";
        public const string DemographicUpdateFormInfoSubject = "Demographic Update";
        public const string LabelErrorEnterNumericValuesInPhysicianPhone = "lblEnterValidData";
        public const string LabelErrorEnterAlphanumericOnly = "lblSpecialCharsNotAllowed";

        public const string LabelErrorFocusSelectionMandatory = "lblErrorFocusSelectionMandatory";
        public const string LabelErrorSelectFocusBeforeAdding = "lblErrorSelectFocusBeforeAdding";
        public const string LabelAddOnlyFiveFocus = "lblAddAtmostFiveFocus";
        public const string LabelFocusSelectionNotPossible = "lblFocusSelectionNotPossible";
        public const string LabelSelectFiveFocus = "lblSelectFiveFocus";
        public const string LabelFocusAdditionMandatoryBeforeRemoving = "lblFocusAdditionMandatoryBeforeRemoving";
        public const string LabelAddFocusBeforeRemoving = "lblAddFocusBeforeRemoving";
        public const string LabelFocusSelectionMandatoryBeforeRemoving = "lblFocusSelectionMandatoryBeforeRemoving";
        public const string LabelSelectFocusBeforeRemoving = "lblSelectFocusBeforeRemoving";
    }

    public static class EmailBodyConstant
    {
        public const string ProviderOnlineSearch = "Provider Online Search";
        public const string NetworkType = "{NetworkType}";
        public const string LocateProviderSendFrom = "LocateProviderSendFrom";
        public const string EmailMileHeading = "mile";
        public const string Network = "Network";
        //Defect #2151
        public const string Label_Details = "{lbl_Details}";
        public const string Label_Type = "{lbl_Type}";
        public const string Label_Specialty = "{lbl_Specialty}";
        public const string Label_Focus = "{lbl_Focus}";
        public const string Label_Gender = "{lbl_Gender}";
        public const string Label_PracticeName = "{lbl_PracticeName}";
        public const string Label_Speaks = "{lbl_Speaks}";
        public const string Label_HospitalAffiliation = "{lbl_HospitalAffiliation}";
        public const string Label_ProviderNumber = "{lbl_ProviderNumber}";
        public const string Label_Location = "{lbl_Location}";
        public const string Label_CurrentLocation = "{lbl_CurrentLocation}";
        public const string Label_Hospital = "{lbl_Hospital}";
        public const string Label_EstimatedDistance = "{lbl_EstimatedDistance}";
        public const string Label_Address = "{lbl_Address}";
        public const string Label_Dial = "{lbl_Dial}";
        public const string Label_Fax = "{lbl_Fax}";
        public const string Label_Day = "{lbl_Day}";
        public const string Label_Hours = "{lbl_Hours}";
        public const string Label_OtherOfficeLocations = "{lbl_OtherOfficeLocations}";
       



        //provider details
        public const string ProviderName = "{ProviderName}";
        public const string PrimaryAddressLine1 = "{PrimaryAddressLine1}";
        public const string PrimaryAddressLine2 = "{PrimaryAddressLine2}";
        public const string Distance = "{Distance}";
        public const string PhoneNumber = "{PhoneNumber}";
        public const string AcceptingNewPatients = "{AcceptingNewPatients}";
        public const string Type = "{Type}";
        public const string Specialty = "{Specialty}";
        public const string Focus = "{Focus}";
        public const string Gender = "{Gender}";
        public const string PracticeName = "{PracticeName}";
        public const string SpokenLanguage = "{SpokenLanguage}";
        public const string HospitalAffiliation = "{HospitalAffiliation}";
        public const string CpdId = "{CPDID}";
        public const string Hospital = "{Hospital}";
        public const string Dial = "{Dial}";
        public const string Fax = "{Fax}";
        public const string Day = "{Day}";
        public const string Timings = "{Timings}";
        public const string ProviderNumber = "{ProviderNumber}";
        public const string OtherOfficeHospitalName = "{OtherOfficeHospitalName}";
        public const string OtherLocationDistance = "{OtherLocationDistance}";
        public const string OtherAddressLine1 = "{OtherAddressLine1}";
        public const string OtherAddressLine2 = "{OtherAddressLine2}";
        public const string replaceDistance = "<span style=\"color:#0067a6\"> {Distance}</span><br />";
        public const string replace_Distance = "<b>Estimated Distance:</b> {Distance}<br />";  

        //provider compare
        public const string ProviderName1 = "{ProviderName1}";
        public const string ProviderNumber1 = "{ProviderName1}";
        public const string AcceptNewPatient1 = "{AcceptNewPatient1}";
        public const string ProviderAddress1 = "{ProviderAddress1}";
        public const string ProviderDistance1 = "{ProviderDistance1}";
        public const string ProviderHospitalName1 = "{ProviderHospitalName1}";
        public const string ProviderSpokenLanguage1 = "{ProviderSpokenLanguage1}";
        public const string ProviderPhone1 = "{ProviderPhone1}";
        public const string ProviderSpecialty1 = "{ProviderSpeciality1}";
        public const string ProviderFocus1 = "{ProviderFocus1}";
        public const string ProviderSex1 = "{ProviderSex1}";
        public const string ProviderType1 = "{ProviderType1}";
        public const string GASurprisebillrating1 = "{GASurprisebillrating1}";
        public const string ProviderPracticeName1 = "{ProviderPracticeName1}";

        public const string ProviderName2 = "{ProviderName2}";
        public const string AcceptNewPatient2 = "{AcceptNewPatient2}";
        public const string ProviderAddress2 = "{ProviderAddress2}";
        public const string ProviderDistance2 = "{ProviderDistance2}";
        public const string ProviderHospitalName2 = "{ProviderHospitalName2}";
        public const string ProviderSpokenLanguage2 = "{ProviderSpokenLanguage2}";
        public const string ProviderPhone2 = "{ProviderPhone2}";
        public const string ProviderSpecialty2 = "{ProviderSpeciality2}";
        public const string ProviderFocus2 = "{ProviderFocus2}";
        public const string ProviderSex2 = "{ProviderSex2}";
        public const string ProviderType2 = "{ProviderType2}";
        public const string GASurprisebillrating2 = "{GASurprisebillrating2}";
        public const string ProviderPracticeName2 = "{ProviderPracticeName2}";

        public const string ProviderName3 = "{ProviderName3}";
        public const string AcceptNewPatient3 = "{AcceptNewPatient3}";
        public const string ProviderAddress3 = "{ProviderAddress3}";
        public const string ProviderDistance3 = "{ProviderDistance3}";
        public const string ProviderHospitalName3 = "{ProviderHospitalName3}";
        public const string ProviderSpokenLanguage3 = "{ProviderSpokenLanguage3}";
        public const string ProviderPhone3 = "{ProviderPhone3}";
        public const string ProviderSpecialty3 = "{ProviderSpeciality3}";
        public const string ProviderFocus3 = "{ProviderFocus3}";
        public const string ProviderSex3 = "{ProviderSex3}";
        public const string ProviderType3 = "{ProviderType3}";
        public const string GASurprisebillrating3 = "{GASurprisebillrating3}";
        public const string ProviderPracticeName3 = "{ProviderPracticeName3}";

        public const string Url = "{url}";
        public const string NumberOfProviders = "{NumberOfProviders}";
        public const string Duration = "{duration}";
        public const string DateTime = "{DateTime}";
        public const string DirectoryName = "{DirectoryName}";
        public const string FindYourDirectory = "{FindYourDirectory}";
        public const string CustomPath = "custom path";

        // provider header 
        public const string LabelTypeOfProvider = "{TypeOfProvider}";
        public const string LabelAddress = "{Address}";
        public const string LabelSpecialty = "{Specialty}";
        public const string LabelFocus = "{Focus}";
        public const string LabelGender = "{Gender}";
        public const string LabelSpokenLanguage = "{SpokenLanguage}";
        public const string LabelDistance = "{Distance}";
        public const string LabelPhoneNumber = "{PhoneNumber}";
        public const string LabelAcceptingNewPatients = "{AcceptingNewPatients}";
        public const string LabelPracticeName = "{PracticeName}";
        public const string LabelHospitalAffiliation = "{HospitalAffiliation}";
        public const string LabelSurprisebilling = "{Surprisebilling}";

    }

    public static class ExceptionMessageConstant
    {
        public const string CompareProvider = "Invalid Compare provider list";
        public const string SearchRequest = "Invalid Search Request Object";
        public const string Email = "Invalid Email Address";
        public const string Model = "Invalid Model Email Address";
        public const string ProviderNumber = "ProviderNumber";
        public const string PlanCode = "Not a valid plan code";
        public const string ProviderNumberIndex = "Provider Number Index";
        public const string DetailedProviderInformation = "Detailed Provider Info";
    }
}