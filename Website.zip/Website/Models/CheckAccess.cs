﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Controllers;
using NABWebsite.DTO;
using Aetna.Cofinity.Admin.Entities.Response;

namespace NABWebsite.Controllers
{
    public class CheckAccess : ActionFilterAttribute
    {
        public string Function { get; set; }
        public string HasAccess { get; set; }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string HasAccess = FunctionAcess();
            if (HasAccess.Contains(Function))
            {
                base.OnActionExecuting(filterContext);
            }
            else
            {
                filterContext.Result = (new ErrorController()).NoAccessError();
            }
        }        

        private string FunctionAcess()
        {
            string functions = string.Empty;
            UserDetails user = (UserDetails)HttpContext.Current.Session[Constants.UserDetails];
            if (user != null && user.UserRoles != null && user.UserRoles.Count() > 0)
            {
                foreach (var role in user.UserRoles)
                {
                    if (role.RoleName == user.SelectedRole)
                    {
                        if (role.FunctionSensors != null && role.FunctionSensors.Count() > 0)
                        {
                            foreach (var sensorType in role.FunctionSensors)
                            {
                                /// Edited by NAB-IT to check active pages by sensors

                                if (sensorType.Key.ToUpper().Equals("ATTACHMENT INQUIRY"))
                                {
                                    List<Network> networkList = new List<Network>();
                                    //get selected role
                                    Role selectedRole = ((UserDetails)HttpContext.Current.Session[Constants.UserDetails]).UserRoles.Where(r => r.RoleName.Equals(((UserDetails)HttpContext.Current.Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                                    //get the network for selcted function
                                    networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuAttachment, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList<Network>();
                                    foreach (var item in networkList)
                                    {
                                        if (item.SrcSystemId == 1) //Work only for Cofinity.
                                        {
                                            if (HttpContext.Current.Session["ACTIVEPAGELIST"] != null && ((List<string>)(HttpContext.Current.Session["ACTIVEPAGELIST"])).Contains(sensorType.Key))
                                                functions = functions + "," + sensorType.Key;
                                        }
                                    }
                                }
                                else
                                {
                                    if (HttpContext.Current.Session["ACTIVEPAGELIST"] != null && ((List<string>)(HttpContext.Current.Session["ACTIVEPAGELIST"])).Contains(sensorType.Key))
                                        functions = functions + "," + sensorType.Key;
                                }
                            }
                        }
                    }
                }
            }
            return functions;
        }
    }
}
