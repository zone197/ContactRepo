﻿$(document).ready(function () {
    $('input[name=ContactMeBy]').change(function () {
        if ($('#ContactMeBy:checked').val() == 'Email') {
            $("#PhoneNo").parent().parent().parent().removeClass('has-error');
            $("#PhoneNo").next().hide();
            $("#PhoneNo").parent().next().hide();
        }
        if ($('#ContactMeBy:checked').val() == 'Phone') {
            $("#Email").parent().parent().parent().removeClass('has-error');
            $("#Email").next().hide();
            $("#Email").parent().next().hide();
        }
    })

    $('#showContactUsPage').click(function () {
        $.ajax({
            type: 'POST',
            url: $("#hdnhost").val() + '/Home/Contactuspage',
            success: function (view) {
                $('input[name=FH]').attr('checked', false);
                $('#myContact').modal('hide');
                $('#myContact').on('hidden.bs.modal', function (e) {
                    $('body').removeClass('modal-open');
                });
                $('#myContactUs').find('#modal-hiddenContent').html(view).end();
                $('#myContactUs').modal({
                    show: true,
                    backdrop: 'static'
                });

                /*set focus on first input*/
                $('#fhs').focus();

                /*redirect last tab to first input*/
                 $("#btnSend").on('keydown', function (e) {
                        if ((e.which === 9 && !e.shiftKey)) {
                            e.preventDefault();
                            $("#myContactUs").find(".Modalbox-close").focus();
                        }
                 });

                 $("#myContactUs").find(".Modalbox-close").on('keydown', function (e) {
                     if ((e.which === 9 && !e.shiftKey)) {
                         e.preventDefault();
                         $('#fhs').focus();
                     }

                 });
            }
        });
    });

    /*  
    Menu  Drop down open and close 
    */
    $('.dropdown').on('show.bs.dropdown', function (e) {
        $(this).find('.dropdown-menu').first().stop(true, true).slideDown();
        $(this).find('.dropdown-menu').width($(this).width())
    });

    $('.dropdown').on('hide.bs.dropdown', function (e) {
        $(this).find('.dropdown-menu').first().stop(true, true).slideUp();
    });

});




function getpopup(linkId, linkType, linkUrl, pageId, title)
{
    if (linkType == "popup") {
        $("#partialViewContainerDiv").html($("#ConatinerDiv").html());
        $("#LeftModal").modal({
            backdrop: 'static'
        });
        $('#partialViewContainerDiv').find('#1').focus();
        var AnchorCount=  $('#partialViewContainerDiv').find('a').each(function() {
        }).length;
        var lastElement = $("#partialViewContainerDiv").find('#'+ AnchorCount);

        $(lastElement).on('keydown', function (e) {
            if ((e.which === 9 && !e.shiftKey)) {
                e.preventDefault();
                $(".modal-content").find(".Modalbox-close").focus();
            }
        });
        $(".modal-content").find(".Modalbox-close").on('keydown', function (e) {
            if ((e.which === 9 && !e.shiftKey)) {
                e.preventDefault();
                $('#partialViewContainerDiv').find('#1').focus();
            }

        });
    }
    else
        Navigate(linkId, linkType, linkUrl, pageId, title);
}

(function ($) {
    $.fn.alphanumeric = function (p) {
        var input = $(this),
            az = "abcdefghijklmnopqrstuvwxyz",
            options = $.extend({
                ichars: '!@@#$%^&*()+=[]\\\';,/{}|":<>?~`.- _',
                nchars: '',
                allow: ''
            }, p),
            s = options.allow.split(''),
            i = 0,
            ch,
            regex;

        for (i; i < s.length; i++) {
            if (options.ichars.indexOf(s[i]) != -1) {
                s[i] = '\\' + s[i];
            }
        }

        if (options.nocaps) {
            options.nchars += az.toUpperCase();
        }
        if (options.allcaps) {
            options.nchars += az;
        }

        options.allow = s.join('|');

        regex = new RegExp(options.allow, 'gi');
        ch = (options.ichars + options.nchars).replace(regex, '');

        input.keypress(function (e) {
            var key = String.fromCharCode(!e.charCode ? e.which : e.charCode);

            if (ch.indexOf(key) != -1 && !e.ctrlKey) {
                e.preventDefault();
            }
        });

        input.blur(function () {
            var value = input.val(),
                j = 0;

            for (j; j < value.length; j++) {
                if (ch.indexOf(value[j]) != -1) {
                    input.val('');
                    return false;
                }
            }
            return false;
        });

        return input;
    };

    $.fn.numeric = function (p) {
        var az = 'abcdefghijklmnopqrstuvwxyz',
            aZ = az.toUpperCase();

        return this.each(function () {
            $(this).alphanumeric($.extend({
                nchars: az + aZ
            }, p));
        });
    };

    $.fn.alpha = function (p) {
        var nm = '1234567890';
        return this.each(function () {
            $(this).alphanumeric($.extend({
                nchars: nm
            }, p));
        });
    };
})(jQuery);
