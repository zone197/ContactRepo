﻿//collect form input and submit
function SubmitForm() {
    var searchRequest = new Object();
    var NetworkType = new Object();
    var forgeryId = $("#forgeryToken").val();
    var cofinityClientCode = "COFI";
    var FCOMClientCode = "FCOM";
    NetworkType.NetworkId = $('input[name=RadioButtonSelected]:checked').val();
    NetworkType.NetworkName = $('input[name=RadioButtonSelected]:checked').attr('networktype-name');
    searchRequest.NetworkType = NetworkType;
    searchRequest.ClientSpecificCode = $("#txtClientSpcNet").val();
    if (powerSTEPP == "true" && (NetworkType.NetworkName.toLocaleLowerCase() == "cofinity" || searchRequest.ClientSpecificCode.toLocaleUpperCase() == cofinityClientCode)) // in case of Cofinity network and PowerSTEPP is sunset, take Payer as the customer type //TODO: and 'COFI' as ClientSpecificCode
    {
        NetworkType.NetworkId = "3";
        searchRequest.CustomerType = "Payer";
        if (NetworkType.NetworkName.toLocaleLowerCase() == "cofinity")
        {
            searchRequest.ClientSpecificCode = cofinityClientCode;

        }
    }
    else if (NetworkType.NetworkName.toLocaleLowerCase() == "first choice of the midwest" || NetworkType.NetworkName.toLocaleLowerCase() == "la primera elección del medio-oeste"
        || searchRequest.ClientSpecificCode.toLocaleUpperCase() == FCOMClientCode) 
    {
        NetworkType.NetworkId = "3";
        searchRequest.ClientSpecificCode = FCOMClientCode;  
    }
    $.ajax({
        type: 'POST',
        url: '/LocateProviderMobile/SaveSearchRequestToSession',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        data: JSON.stringify({ search: searchRequest }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            $("#txtClientSpcNet").removeClass("txtBoxColorOnError");
            $("#txtClientSpcNet").addClass("txtBoxColor");
            ////debugger;
            if (powerSTEPP == "true") {
                //if (NetworkType.NetworkName == "Cofinity" || searchRequest.ClientSpecificCode == "COFI") {
                //    window.location.href = '/LocateProviderMobile/ProviderTypeSelection/'; // in case of Cofinity network and PowerSTEPP is sunset, proceed to ProviderTypeSelection screen
                //}
                //else {
                //    window.location.href = '/LocateProviderMobile/CustomerTypeSelection/'; // in case of Cofinity network and PowerSTEPP is not sunset, process to CustomerTypeSelection screen
                //}
                window.location.href = '/LocateProviderMobile/ProviderTypeSelection/'; // in case of Cofinity network and PowerSTEPP is sunset, proceed to ProviderTypeSelection screen
            }
            else {
                if (NetworkType.NetworkName.toLocaleLowerCase() == "cofinity") {
                    window.location.href = '/LocateProviderMobile/CustomerTypeSelection/';
                }
                else {
                    window.location.href = '/LocateProviderMobile/ProviderTypeSelection/';
                }
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
}
$(document).ready(function () {
    //check valid form and submit
    var flag = 0;
    $("#txtClientSpcNet").val("");

    $("#btnSubmit").click(function (evt) {
        flag = $('input[name=RadioButtonSelected]:checked').attr('networktype-name');
        var form = $('#formNetworkTypeMobile');
        var forgeryId = $("#forgeryToken").val();
        var value = $('input[name=RadioButtonSelected]:checked').attr('networktype-name');

        if (value == null || value == "") {
            var errorNetworkSelectionReq = GetResources("lblNetworkSelectionRequired");
            $('#errorMsgNetworkTypes').html(errorNetworkSelectionReq);
        }
        if (value.toLocaleLowerCase().match("client") || value.toLocaleLowerCase().match("cliente")) {
            var clientCode = document.getElementById("txtClientSpcNet").value;
            if ($("#txtClientSpcNet").val() == '' || $("#txtClientSpcNet").val() == null) {
                var errorEnterValidCode = GetResources("lblEnterValidClientCodeBeforeStartNow");
                $("#otherError").html(errorEnterValidCode);
                $("#txtClientSpcNet").addClass("txtBoxColorOnError");
                var errorClientCodeMandatory = GetResources("lblClientCodeFieldMandatoryForClientSpecificNetwork");
                $('#errorMsgNetworkTypes').html(errorClientCodeMandatory);
            }
            else {
                $.ajax({
                    type: 'POST',
                    url: '/LocateProviderMobile/CheckClientCode',
                    contentType: "application/json; charset=utf-8",
                    datatype: 'json',
                    data: JSON.stringify({ clientCode: clientCode }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    success: function (result) {
                        if (result == "True") {
                            SubmitForm();
                        }
                        else {
                            var errorInvalidCode = GetResources("lblInvalidClientSpecificNetworkCode");
                            $("#otherError").html(errorInvalidCode);
                            $("#txtClientSpcNet").addClass("txtBoxColorOnError");
                            var errorClientCodeNotValid = GetResources("lblClientCodeIsNotValid");
                            $('#errorMsgNetworkTypes').html(errorClientCodeNotValid);
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                    }
                });

            }

        }
        else {
            if (flag.toLocaleLowerCase().match("first") || flag.toLocaleLowerCase().match("cofinity") || flag.toLocaleLowerCase().match("first choice of the midwest")
                || flag.toLocaleLowerCase().match("la primera elección del medio-oeste")) {
                SubmitForm();
            }
            else {
                var errorRadioButton = GetResources("lblSelectOneNetworkType");
                $("#errorRadio").html(errorRadioButton);
            }
        }

    })

    $("#txtClientSpcNet").keyup(function (evt) {
        $("#otherError").empty();
        $('#errorMsgNetworkTypes').empty();
        $("#txtClientSpcNet").removeClass("txtBoxColorOnError");
        $("#txtClientSpcNet").addClass("txtBoxColor");
    });

    //remove error messages on radio button change
    $('.indexButtonStyle').on('click', function () {
        $("#termsofuseContent").slideUp("slow");
        var a = $(this).find("input[name=RadioButtonSelected]").attr('networktype-name');
        //alert(a);
        $('#errorRadio').empty();
        $("#otherError").empty();
        ////debugger;
        //flag=$('input[name=RadioButtonSelected]:checked').val();
        if (a.toLocaleLowerCase().match("first") || a.toLocaleLowerCase().match("cofinity")
            || a.toLocaleLowerCase().match("first choice of the midwest") || a.toLocaleLowerCase().match("la primera elección del medio-oeste")) {
            $("#txtClientSpcNet").val("");
            $("#txtClientSpcNet").removeClass("txtBoxColorOnError");
            $("#otherError").empty();
            $('#errorMsgNetworkTypes').empty();
        }
        $('#errorMsgNetworkTypes').empty();
    });

    //terms of use slide
    $(".slider").click(function () {
        if ($("#termsofuseContent").is(":hidden")) {
            $("#termsofuseContent").slideDown("slow");
        }
        else {
            $("#termsofuseContent").slideUp("slow");
        }
    })
    $('i').bind('contextmenu', function (e) {
        return false;
    });


})

function GetResources(key) {
    var forgeryId = $("#forgeryToken").val();
    var returnValue;
    $.ajax({
        type: 'POST',
        url: '/LocateProviderMobile/GetResources',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        async: false,
        data: JSON.stringify({ key: key }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            ////debugger;
            returnValue = result;

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
    ////debugger;
    return returnValue;
}