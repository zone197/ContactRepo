﻿using System.Collections.Generic;

namespace NABWebsite.Models
{
    public class RightSectionViewModel
    {
        public List<RightSectionGenericContainer> lstRightSectionGenericContainer { get; set; }
        public List<RightSectionNewsContainer> lstRightSectionNewsContainer { get; set; }
    }
}