﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using NABWebsite.Models;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System.Globalization;
using System.Reflection;
using System.Configuration;
using Aetna.Cofinity.Admin.Entities.Response;
using System.Text;
using Utilities;

namespace NABWebsite.Controllers
{
    public class MemberInquiryController : BaseController
    {
        StringBuilder traceLog = new StringBuilder();
       // GET: MemberInquiry
        /// <summary>
        /// Member Search Home Page
        /// </summary>
        /// <returns>ActionResult</returns>
        [CheckAccess(Function = "Member Inquiry")]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: MemberInquiryController, Index Method");
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.MemberEnquiryHead;
                traceLog.AppendLine(" & End: MemberInquiryController, Index Method");
                return View("MemberInquiry");
            }
            
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Get Member Results
        /// </summary>
        /// <param name="memberInquiryObject"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Member Inquiry")]
        [HttpPost]
        public ActionResult Index(MemberInquiryModel memberInquiryObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, Index Method with Param memberInquiryObject: " + memberInquiryObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: MemberInquiryController, Index Method");
                    return RedirectToAction("Index", "Home");
                }
                MemberSearch objBll = new MemberSearch();
                List<MemberResult> memberObject = new List<MemberResult>();
                if (memberInquiryObject != null)
                {
                    SetUserAccess(memberInquiryObject);
                    if (ModelInputValidation(memberInquiryObject.Member))
                    {
                        memberObject = objBll.GetMemberContent(memberInquiryObject.Member).ToList();
                        memberInquiryObject.MemberResult = memberObject;
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: MemberInquiryController, Index Method");
                        return Content("<script type='text/javascript'>alert('Input contains invalid content');window.location='/MemberInquiry/Index'</Script>");

                    }
                }
                traceLog.AppendLine(" & End: MemberInquiryController, Index Method");
                return View("MemberInquiry", memberInquiryObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Get Last known payer results
        /// </summary>
        /// <param name="memberInquiryObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult SearchLastKnownPayer(MemberInquiryModel memberInquiryObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, SearchLastKnownPayer Method with Param memberInquiryObject: " + memberInquiryObject);
                MemberSearch objBll = new MemberSearch();
                MemberInquiry memberObject = new MemberInquiry();
                MemberInquiryModel member = new MemberInquiryModel();
                if (memberInquiryObject != null)
                {
                    SetUserAccess(memberInquiryObject);
                    memberObject = objBll.GetSearchLastKnownPayer(memberInquiryObject.Member);
                    if (memberObject.Name != null)
                    {
                        member.Member = memberObject;
                        member.Member.IsPresent = Constants.LastKnown;
                    }
                    else
                    {
                        member.Member = new MemberInquiry();
                        SetUserAccess(member);
                        member.Member.IsPresent = Constants.Not;
                    }
                }
                traceLog.AppendLine(" & End: MemberInquiryController, SearchLastKnownPayer Method");
                return PartialView("_SearchLastKnownPayer", member);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Get Claim Results
        /// </summary>
        /// <param name="memberInquiryObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult ProcessedClaimSearch(MemberInquiryModel memberInquiryObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, ProcessedClaimSearch Method with Param memberInquiryObject: " + memberInquiryObject);
                int page = 0;
                string sortby = string.Empty;
                string sorttype = string.Empty;
                string filtertin = string.Empty;
                string filterdos = string.Empty;
                if (memberInquiryObject != null)
                {
                    if (memberInquiryObject.Claim == null)
                    {

                        memberInquiryObject.Claim = new ClaimInquiry();
                        memberInquiryObject.Claim.ClaimSearchCriteria = new ClaimSearchCriteria();
                        memberInquiryObject.Claim.ProcessedClaim = new ProcessedClaim();
                        SetUserAccess(memberInquiryObject);
                        if (memberInquiryObject.Member != null)
                        {
                            if (memberInquiryObject.Member.UserRole.ToUpperInvariant().Equals(Constants.Provider.ToUpperInvariant()))
                            {
                                SetModelClaim(memberInquiryObject);
                            }
                            else if (memberInquiryObject.Member.UserRole.ToUpperInvariant().Equals(Constants.Payer.ToUpperInvariant()))
                            {
                                if (String.IsNullOrEmpty(memberInquiryObject.Member.PayerSsn))
                                {
                                    SetModelClaim(memberInquiryObject);
                                }
                                else
                                {
                                    memberInquiryObject.Claim.ClaimSearchCriteria.AlternateId = memberInquiryObject.Member.PayerSsn;
                                    memberInquiryObject.Claim.ClaimSearchCriteria.FirstName = memberInquiryObject.Member.PayerFirstName;
                                    memberInquiryObject.Claim.ClaimSearchCriteria.LastName = memberInquiryObject.Member.PayerLastName;
                                    memberInquiryObject.Claim.ClaimSearchCriteria.Dob = memberInquiryObject.Member.PayerDateOfBirth;


                                    memberInquiryObject.Claim.SelectedSearchCriteria = Constants.Ssn;
                                    memberInquiryObject.Claim.ProcessedClaim.SortType = Constants.AscendingText;
                                    memberInquiryObject.Claim.ProcessedClaim.SortBy = Constants.DosBegin;
                                    memberInquiryObject.Claim.ProcessedClaim.PageNo = Constants.PageOne;
                                    memberInquiryObject.Claim.Network = memberInquiryObject.Member.Network;
                                }
                            }
                        }
                    }


                    if (memberInquiryObject.Claim.ProcessedClaim != null)
                    {
                        page = memberInquiryObject.Claim.ProcessedClaim.PageNo;
                        sortby = memberInquiryObject.Claim.ProcessedClaim.SortBy;
                        sorttype = memberInquiryObject.Claim.ProcessedClaim.SortType;
                        filtertin = memberInquiryObject.Claim.ProcessedClaim.ProcessFilterTin;
                        filterdos = memberInquiryObject.Claim.ProcessedClaim.ProcessFilterDos;


                    }
                    ClaimInquiryBL claimBL = new ClaimInquiryBL();

                    if (memberInquiryObject.Claim.ProcessedClaim.PageNo == Constants.PageZero)
                    {
                        memberInquiryObject.Claim.ProcessedClaim.PageNo = Constants.PageOne;
                        memberInquiryObject.Claim.ProcessedClaim.TotalPages = Constants.PageOne;
                        memberInquiryObject.Claim.ProcessedClaim.SortType = Constants.AscendingText;
                        memberInquiryObject.Claim.ProcessedClaim.SortBy = Constants.DosBegin;
                    }

                    ProcessedClaimSearchCriteria ProcessClaimSearchCriteria = new ProcessedClaimSearchCriteria();
                    SetUserAccess(ProcessClaimSearchCriteria);
                    ProcessClaimSearchCriteria.SelectedSearchCriteria = memberInquiryObject.Claim.SelectedSearchCriteria;
                    if (memberInquiryObject.Claim.ProcessedClaim != null)
                    {
                        ProcessClaimSearchCriteria.ProcessClaim = memberInquiryObject.Claim.ProcessedClaim;
                    }
                    if (memberInquiryObject.Claim.ClaimSearchCriteria != null)
                    {
                        ProcessClaimSearchCriteria.ClaimSearchCriteria = memberInquiryObject.Claim.ClaimSearchCriteria;
                    }
                    ProcessClaimSearchCriteria.Network = memberInquiryObject.Claim.Network;

                    if (ModelInputValidation(ProcessClaimSearchCriteria))
                    {
                        memberInquiryObject.Claim.ProcessedClaim = claimBL.GetClaims(ProcessClaimSearchCriteria);
                    }
                    else
                    {

                        throw new ArgumentException("Validation Error");
                    }

                    int pageSize = ConfigurationManager.AppSettings[Constants.RecordsPerPage] != null ? Convert.ToInt32(ConfigurationManager.AppSettings[Constants.RecordsPerPage], CultureInfo.InvariantCulture) : Constants.PageSize;
                    memberInquiryObject.Claim.ProcessedClaim.TotalPages = Convert.ToInt32(System.Math.Ceiling(
                        Convert.ToDouble(memberInquiryObject.Claim.ProcessedClaim.TotalCount) / pageSize));

                    memberInquiryObject.Claim.ProcessedClaim.PageNo = page;
                    memberInquiryObject.Claim.ProcessedClaim.SortBy = sortby;
                    memberInquiryObject.Claim.ProcessedClaim.SortType = sorttype;
                    memberInquiryObject.Claim.ProcessedClaim.ProcessFilterTin = filtertin;
                    memberInquiryObject.Claim.ProcessedClaim.ProcessFilterDos = filterdos;

                    if ((UserDetails)Session[Constants.UserDetails] != null
                        && ((UserDetails)Session[Constants.UserDetails]).SelectedRole != null)
                    {
                        if (((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Provider.ToUpperInvariant())
                        {
                            traceLog.AppendLine(" & End: MemberInquiryController, ProcessedClaimSearch Method");
                            return PartialView("_SearchClaims", memberInquiryObject);
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: MemberInquiryController, ProcessedClaimSearch Method");
                            return PartialView("_PayerSearchClaims", memberInquiryObject);
                        }
                    }
                    traceLog.AppendLine(" & End: MemberInquiryController, ProcessedClaimSearch Method");
                    return View("Error");
                }
                else
                {
                    traceLog.AppendLine(" & End: MemberInquiryController, ProcessedClaimSearch Method");
                    return View("Error");
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Set model value for ClaimSearch
        /// </summary>
        /// <param name="mObject"></param>
        private static void SetModelClaim(MemberInquiryModel mObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, SetModelClaim Method with Param mObject: " + mObject);
                if (mObject != null)
                {
                    if (mObject.Member != null)
                    {
                        if (mObject.Member.Searchby.Equals(Constants.Ssn))
                        {
                            if (mObject.Member.EnteredCriteria.Contains(Constants.EnteredCriteriaSsn))
                            {
                                mObject.Claim.ClaimSearchCriteria.AlternateId = mObject.Member.Ssn;
                            }
                            if (mObject.Member.EnteredCriteria.Contains(Constants.EnteredCriteriaName))
                            {
                                mObject.Claim.ClaimSearchCriteria.FirstName = mObject.Member.FirstName;
                                mObject.Claim.ClaimSearchCriteria.LastName = mObject.Member.LastName;
                            }
                            if (mObject.Member.EnteredCriteria.Contains(Constants.EnteredCriteriaDob))
                            {
                                mObject.Claim.ClaimSearchCriteria.Dob = mObject.Member.DateOfBirth;
                            }
                            mObject.Claim.ClaimSearchCriteria.Dos = mObject.Member.DateOfService;


                            mObject.Claim.SelectedSearchCriteria = Constants.Ssn;
                            mObject.Claim.ProcessedClaim.SortType = Constants.AscendingText;
                            mObject.Claim.ProcessedClaim.SortBy = Constants.DosBegin;
                            mObject.Claim.ProcessedClaim.PageNo = Constants.PageOne;
                            mObject.Claim.SelectedSearchCriteria = mObject.Member.Searchby;
                            mObject.Claim.Network = mObject.Member.Network;
                        }
                        else
                        {
                            if (mObject.Member.EnteredCriteria.Contains(Constants.EnteredCriteriaSsn))
                            {
                                mObject.Claim.ClaimSearchCriteria.MemberAlternateId = mObject.Member.Ssn1;
                            }
                            if (mObject.Member.EnteredCriteria.Contains(Constants.EnteredCriteriaName))
                            {
                                mObject.Claim.ClaimSearchCriteria.MemberFirstName = mObject.Member.FirstName1;
                                mObject.Claim.ClaimSearchCriteria.MemberLastName = mObject.Member.LastName1;
                            }
                            if (mObject.Member.EnteredCriteria.Contains(Constants.EnteredCriteriaDob))
                            {
                                mObject.Claim.ClaimSearchCriteria.MemberDob = mObject.Member.DateOfBirth1;
                            }
                            mObject.Claim.ClaimSearchCriteria.MemberDos = mObject.Member.DateOfService1;

                            mObject.Claim.SelectedSearchCriteria = Constants.Member;
                            mObject.Claim.ProcessedClaim.SortType = Constants.AscendingText;
                            mObject.Claim.ProcessedClaim.SortBy = Constants.DosBegin;
                            mObject.Claim.ProcessedClaim.PageNo = 1;
                            mObject.Claim.SelectedSearchCriteria = mObject.Member.Searchby;
                            mObject.Claim.Network = mObject.Member.Network;
                        }

                    }
                }
                traceLog.AppendLine(" & End: MemberInquiryController, SetModelClaim Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Set user access for member search
        /// </summary>
        /// <param name="memberInquiryObject"></param>

        private void SetUserAccess(MemberInquiryModel memberInquiryObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, SetUserAccess Method with Param memberInquiryObject: " + memberInquiryObject);
                UserDetails user = (UserDetails)Session[Constants.UserDetails];
                if (user != null)
                {
                    if (!string.IsNullOrEmpty(user.UserId))
                    {
                        memberInquiryObject.Member.Userid = user.UserId;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole))
                    {
                        memberInquiryObject.Member.UserRole = user.SelectedRole;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole)
                            && user.UserRoles != null
                            && user.UserRoles.Count() > 0)
                    {
                        memberInquiryObject.Member.IsEmployee = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault().IsEmployee;
                        IEnumerable<CanCheckRestrictedMember> canCheckRestrictedList = user.UserRoles.Where(role => role.RoleName.Equals(user.SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                        if (canCheckRestrictedList != null) memberInquiryObject.Member.CanCheckRestrictedMembers = canCheckRestrictedList.FirstOrDefault().RestrictedCheck == 1 ? true : false;
                        else memberInquiryObject.Member.CanCheckRestrictedMembers = false;
                    }
                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    memberInquiryObject.Member.UserType = ConfigurationManager.AppSettings[Constants.Site];
                }
                traceLog.AppendLine(" & End: MemberInquiryController, SetUserAccess Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Set user access for claim search
        /// </summary>
        /// <param name="ProcessClaimSearchCriteria"></param>
        private void SetUserAccess(ProcessedClaimSearchCriteria ProcessClaimSearchCriteria)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, SetUserAccess Method with Param ProcessClaimSearchCriteria: " + ProcessClaimSearchCriteria);
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                {
                    ProcessClaimSearchCriteria.Userid = ((UserDetails)Session[Constants.UserDetails]).UserId;
                }
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole))
                {
                    ProcessClaimSearchCriteria.Role = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                }
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                {
                    ProcessClaimSearchCriteria.IsEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                    IEnumerable<CanCheckRestrictedMember> canCheckRestrictedList = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                    if (canCheckRestrictedList != null) ProcessClaimSearchCriteria.CanCheckRestrictedMembers = canCheckRestrictedList.FirstOrDefault().RestrictedCheck == 1 ? true : false;
                    else ProcessClaimSearchCriteria.CanCheckRestrictedMembers = false;
                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    ProcessClaimSearchCriteria.Site = ConfigurationManager.AppSettings[Constants.Site];
                }
                traceLog.AppendLine(" & End: MemberInquiryController, SetUserAccess Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// input validation for member inquiry
        /// </summary>
        /// <param name="objInputCriteria"></param>
        /// <returns>bool</returns>
        private static bool ModelInputValidation(MemberInquiry objInputCriteria)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, ModelInputValidation Method with Param objInputCriteria: " + objInputCriteria);
                bool check = false;
                if (!string.IsNullOrEmpty(objInputCriteria.Network))
                {
                    check = Validation.IsValidContent(objInputCriteria.Network);
                }
                if (check && !string.IsNullOrEmpty(objInputCriteria.Searchby))
                {
                    check = Validation.IsValidContent(objInputCriteria.Searchby);
                }

                if (check)
                {
                    Type type = objInputCriteria.GetType();
                    PropertyInfo[] properties = type.GetProperties();

                    foreach (PropertyInfo property in properties)
                    {
                        var propertyValue = property.GetValue(objInputCriteria, null);
                        if (propertyValue != null)
                        {
                            if (Validation.IsValidContent(propertyValue.ToString()))
                            {
                                switch (property.Name)
                                {
                                    case Constants.MemberSsn:
                                    case Constants.MemberSsn1:
                                        if (!Validation.IsValidSsn(propertyValue.ToString()))
                                            check = false;
                                        break;
                                    case Constants.FirstName:
                                    case Constants.FirstName1:
                                        if (!Validation.IsValidFirstInitial(propertyValue.ToString()))
                                            check = false;
                                        break;
                                    case Constants.LastName:
                                    case Constants.LastName1:
                                        if (!Validation.IsAlphaWithSpace(propertyValue.ToString()))
                                            check = false;
                                        break;

                                    case Constants.MemberDateOfService:
                                    case Constants.MemberDateOfService1:
                                        check = IsValidDosDateRange(propertyValue.ToString());
                                        break;

                                    case Constants.MemberDateOfBirth:
                                    case Constants.MemberDateOfBirth1:
                                        check = IsValidDobDateRange(propertyValue.ToString());
                                        break;
                                    default: break;

                                }
                            }
                            else
                            {
                                check = false;
                                break;
                            }
                        }
                    }
                }
                traceLog.AppendLine(" & End: MemberInquiryController, ModelInputValidation Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// validation for check 3 year previous date && validate date
        /// </summary>
        /// <param name="valueDate"></param>
        /// <returns>bool</returns>
        private static bool IsValidDosDateRange(string valueDate)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, IsValidDosDateRange Method with Param valueDate: " + valueDate);
                DateTime dt = Convert.ToDateTime(valueDate, CultureInfo.CurrentCulture);
                DateTime dtToday = DateTime.Now;

                int intValidYr = (dtToday.Year - 3);

                if (dt.Year < intValidYr)
                {
                    traceLog.AppendLine(" & End: MemberInquiryController, IsValidDosDateRange Method");
                    return false;
                }

                if (dt <= dtToday)
                {
                    traceLog.AppendLine(" & End: MemberInquiryController, IsValidDosDateRange Method");
                    return Validation.IsValidDate(valueDate);
                }
                else
                {
                    traceLog.AppendLine(" & End: MemberInquiryController, IsValidDosDateRange Method");
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }


        /// <summary>
        /// validation for check 129 year previous date && validate date
        /// </summary>
        /// <param name="valueDate"></param>
        /// <returns>bool</returns>
        private static bool IsValidDobDateRange(string valueDate)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, IsValidDobDateRange Method with Param valueDate: " + valueDate);
                DateTime dt = Convert.ToDateTime(valueDate, CultureInfo.CurrentCulture);
                DateTime dtToday = DateTime.Now;

                int intValidYr = (dtToday.Year - 129);

                if (dt.Year <= intValidYr)
                {
                    traceLog.AppendLine(" & End: MemberInquiryController, IsValidDobDateRange Method");
                    return false;
                }

                if (dt <= dtToday)
                {
                    traceLog.AppendLine(" & End: MemberInquiryController, IsValidDobDateRange Method");
                    return Validation.IsValidDate(valueDate);
                }
                else
                {
                    traceLog.AppendLine(" & End: MemberInquiryController, IsValidDobDateRange Method");
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }




        /// <summary>
        /// input validation for processed claim
        /// </summary>
        /// <param name="objInputCriteria"></param>
        /// <returns>bool</returns>
        private static bool ModelInputValidation(ProcessedClaimSearchCriteria objInputCriteria)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MemberInquiryController, ModelInputValidation Method with Param objInputCriteria: " + objInputCriteria);
                bool check = false;

                if (!string.IsNullOrEmpty(objInputCriteria.Network))
                {
                    check = Validation.IsValidContent(objInputCriteria.Network);
                }
                if (check && !string.IsNullOrEmpty(objInputCriteria.SelectedSearchCriteria))
                {
                    check = Validation.IsValidContent(objInputCriteria.SelectedSearchCriteria);
                }
                traceLog.AppendLine(" & End: MemberInquiryController, ModelInputValidation Method");
                #region ConditionsCheckStart
                if (check)
                {
                    Type type = objInputCriteria.ClaimSearchCriteria.GetType();
                    PropertyInfo[] properties = type.GetProperties();

                    foreach (PropertyInfo property in properties)
                    {
                        var propertyValue = property.GetValue(objInputCriteria.ClaimSearchCriteria, null);
                        if (propertyValue != null)
                        {
                            if (Validation.IsValidContent(propertyValue.ToString()))
                            {
                                switch (property.Name)
                                {
                                    case Constants.ClaimNumber:
                                    case Constants.ClaimNo1:
                                    case Constants.ClaimNo2:
                                    case Constants.AccountNumber:
                                    case Constants.AccountNo1:
                                    case Constants.AccountNo2:
                                        if (!Validation.IsAlphanumeric(propertyValue.ToString()))
                                            check = false;
                                        break;

                                    case Constants.AlternateId:
                                    case Constants.AlternateId1:
                                    case Constants.AlternateId2:
                                    case Constants.MemberAlternateId:
                                    case Constants.MemberAlternateId1:
                                    case Constants.MemberAlternateId2:
                                        if (!Validation.IsValidSsn(propertyValue.ToString()))
                                            check = false;
                                        break;
                                    case Constants.Tin:
                                    case Constants.Tin1:
                                    case Constants.Tin2:
                                    case Constants.MemberTin:
                                    case Constants.MemberTin1:
                                    case Constants.MemberTin2:
                                        if (!Validation.IsValidTin(propertyValue.ToString()))
                                            check = false;
                                        break;
                                    case Constants.FirstName:
                                    case Constants.FirstName1:
                                    case Constants.FirstName2:
                                    case Constants.MemberFirstName:
                                    case Constants.MemberFirstName1:
                                    case Constants.MemberFirstName2:
                                        if (!Validation.IsValidFirstInitial(propertyValue.ToString()))
                                            check = false;
                                        break;
                                    case Constants.LastName:
                                    case Constants.LastName1:
                                    case Constants.LastName2:
                                    case Constants.MemberLastName2:
                                    case Constants.MemberLastName1:
                                    case Constants.MemberLastName:
                                        if (!Validation.IsAlphaWithSpace(propertyValue.ToString()))
                                            check = false;
                                        break;

                                    case Constants.DateOfService:
                                    case Constants.Dos1:
                                    case Constants.Dos2:
                                    case Constants.MemberDos:
                                    case Constants.MemberDos1:
                                    case Constants.MemberDos2:
                                    case Constants.MemberDob:
                                    case Constants.MemberDob1:
                                    case Constants.MemberDob2:
                                    case Constants.Dob:
                                    case Constants.Dob1:
                                    case Constants.Dob2:
                                        if (!Validation.IsValidDate(propertyValue.ToString()))
                                            check = false;
                                        break;
                                    default: break;
                                }
                            }
                            else
                            {
                                check = false;
                                break;
                            }

                        }
                    }

                }
                return check;
                #endregion
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

    }
}