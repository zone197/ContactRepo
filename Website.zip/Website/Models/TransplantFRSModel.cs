﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;
using System.Web.Mvc;
using System.Data;
using System.Collections.ObjectModel;

namespace NABWebsite.Models
{
    public class TransplantFacilityModel
    {
        public TransplantFacilityRateSummary FacilityRate { get; set; }
        public IEnumerable<FacilityRateSummary> Result { get; set; }
        public IEnumerable<PayerFacilityRateSummary> PayerFacilityRateSummary { get; set; }
        public IEnumerable<ZipSearchResults> ZipSearchResults { get; set; }
        public string ExportOption { get; set; }        
        public string CompareFields { get; set; }
        public string SelectedOptionsCustomize { get; set; }
        public string OptionsAvailable { get; set; }
        public IEnumerable<SelectListItem> SpecificFieldList { get; set; }        
        public IEnumerable<SelectListItem> OptionalFieldList { get; set; }
        public string OrgansSelected { get; set; }
        public string PinSelected { get; set; }
        public IEnumerable<SelectListItem> TransplantType { get; set; }
        public string SelectedTransplantTypeValue { get; set; }
        public string CopyrightsInformation { get; set; }
        public DataTable ResultTable { get; set; }
        public DataTable ChildTable { get; set; }
        public Dictionary<string, List<StateRegion>> StateRegionResult { get; set; }
        public SearchResultFilterValue SearchResultParameter { get; set; }
        public string DisplaySize { get; set; }
        public string Message { get; set; }
    }

    public class CustomizeOnlineList
    {
        public IEnumerable<CustomizeOptions> Data { get; set; }
    }

    public class CustomizeOptions
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
    
    public class ShowDownloadReportsModel
    {
        public int ReportId { get; set; }
        public string FileName { get; set; }
        public string ReportDate { get; set; }

    }
    
}