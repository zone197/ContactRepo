﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using NABWebsite.DTO;

namespace NABWebsite.Models
{
    //ViewModel for "Provider Data Verification"
    public class ProviderDataVerificationModel
    {
        public ProviderDataVerification ProviderModel { get; set; }
        public Access AccessDetails { get; set; }
        public string UserId { get; set; }
        public string Role { get; set; }
        public string UserType { get; set; }
        public bool MailSent { get; set; }
        public string MailSentYes { get; set; }

        //may be implemented
        public string AllLocationPho { get; set; }
        public string AllLocationCorrespondence { get; set; }
        public string AllLocationPayment { get; set; }
        public string AllLocationTiming { get; set; }
        public string AllLocationService { get; set; }
    }


    //ViewModel for the changes made by user
    public class Update
    {
        public string ChangeList { get; set; }
        public string ProviderName { get; set; }
        public string ProviderNPI { get; set; }
        public string ProviderTin { get; set; }
    }

}