﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.DTO;
using Aetna.ProviderContracts.DataContracts;

namespace NABWebsite.Models
{
    //ViewModel for "Provider File Download"
    public class ScheduleFilesModel
    {
        public IEnumerable<ProviderScheduledFiles> ScheduledFilesModel { get; set; }

        public int TotalCount { get; set; }

        public ProviderFileDownloadModel ProviderFileDownloadModelRef { get; set; }

        public ProviderFileCreateScheduleModel ProviderFileCreateScheduleModelRef { get; set; }

        public string DeleteSchedules { get; set; }
    }

    //ViewModel for One time request of "Provider File Download"
    public class ProviderFileDownloadModel
    {
        public string NetworkChosen { get; set; }
        public string FileName { get; set; }
        public IEnumerable<SelectListItem> Networks { get; set; }

        public IEnumerable<SelectListItem> FileType { get; set; }
        public string FileTypeChosen { get; set; }
        public string StateMultipleStateRadio { get; set; }
        public string CountyCityRadio { get; set; }
        public IEnumerable<State> ListStates { get; set; }
        public IEnumerable<StatesAvailable> StatesCheckBoxes { get; set; }
        public IEnumerable<SelectListItem> StatesDropDown { get; set; }
        public string StatesDropDownChosen { get; set; }
        public string SpecifyDateRange { get; set; }
        public string SelectDate { get; set; }
        public int DownloadNowRecordCount { get; set; }
        public ProviderFileDownloadSchedule FileDownloadSchedule { get; set; }
        public string MultipleCheckStatesDownload { get; set; }
        public IEnumerable<ProviderScheduledFiles> ScheduledFilesModel { get; set; }
        public string DeleteSchedules { get; set; }
        public string FieldsIncludedContent { get; set; }
        public IEnumerable<CompFieldsAvailable> CompFieldsIncludedContent { get; set; }
        public IEnumerable<OptionalFieldsAvailable> OptFieldsIncludedContent { get; set; }
        public IEnumerable<SelectListItem> CountyDropDown { get; set; } //for county radio of county dropdown
        public string CountyChosen { get; set; }
        //public List<CompFieldsAvailable> CompFieldsIncludedContent { get; set; }
        public IEnumerable<SelectListItem> CompFields { get; set; }
        //public string[] SelectedCompFields { get; set; }
        //public List<OptionalFieldsAvailable> OptFieldsIncludedContent { get; set; }
        public IEnumerable<SelectListItem> OptFields { get; set; }
        //public string[] SelectedOptFields { get; set; }
        public string AllSelectedFields { get; set; }        
       

        public IEnumerable<CountyAvailable> CountyCheckBox { get; set; }
        public IEnumerable<CityAvailable> CityCheckBox { get; set; }
        public IEnumerable<City> CityList { get; set; }
        public IEnumerable<County> CountyList { get; set; }

        public IEnumerable<SelectListItem> CityDropDown { get; set; }  //for city radio of city dropdown
        public string CityChosen { get; set; }

        public IEnumerable<SelectListItem> OtherCountyDropDown { get; set; } //for county/city radio of county dropdown
        public string OtherCountyDropDownChosen { get; set; }

        public IEnumerable<SelectListItem> OtherCityDropDown { get; set; }  //for county/city radio of city dropdown
        public string OtherCityDropDownChosen { get; set; }
     
        public IEnumerable<SelectListItem> CountyCityDropDown { get; set; }


        public string FilePathToDownload { get; set; }


      
    }

    //ViewModel for states of "Provider File Download"
    public class StatesAvailable
    {
        public bool StateCheckBoxType { get; set; }
        public string StateCheckBoxValue { get; set; }
        public string StateCheckBoxName { get; set; }
    }

    //ViewModel for Counties of "Provider File Download"
    public class CountyAvailable
    {
        public bool CountyCheckBoxType { get; set; }
        public string CountyCheckBoxValue { get; set; }       
    }

    //ViewModel for Cities of "Provider File Download"
    public class CityAvailable
    {
        public bool CityCheckBoxType { get; set; }
        public string CityCheckBoxValue { get; set; }
    }

    //ViewModel for Compulsory fields of "Provider File Download"
    public class CompFieldsAvailable
    {
        public bool CompFieldsAvailableType { get; set; }
        public string CompFieldsAvailableText { get; set; }
        public string CompFieldsAvailableValue { get; set; }
    }

    //ViewModel for Optional fields of "Provider File Download"
    public class OptionalFieldsAvailable
    {
        public bool OptionalFieldsAvailableType { get; set; }
        public string OptionalFieldsAvailableText { get; set; }
        public string OptionalFieldsAvailableValue { get; set; }
    }

    //ViewModel for File scheduling of "Provider File Download"
    public class ProviderFileCreateScheduleModel
    {

        public string NetworksChosenSchedule { get; set; }
        public IEnumerable<SelectListItem> NetworksSchedule { get; set; }
        public string FileNameSchedule { get; set; }
        public IEnumerable<SelectListItem> FileTypeSchedule { get; set; }
        public string FileTypeChosenSchedule { get; set; }
        public IEnumerable<SelectListItem> RequiredFieldsSchedule { get; set; }
        public IEnumerable<SelectListItem> OptionalFieldsSchedule { get; set; }
        public string CountyChosenSchedule { get; set; }
        public string CityChosenSchedule { get; set; }
        public string StateMultipleStateRadioSchedule { get; set; }
        public string CountyCityRadioSchedule { get; set; }
        public IEnumerable<State> ListStatesSchedule { get; set; }
        public IEnumerable<StatesAvailable> StatesCheckBoxesSchedule { get; set; }
        public IEnumerable<SelectListItem> StatesDropDownSchedule { get; set; }
        public string StatesDropDownChosenSchedule { get; set; }
        public string SpecifyDateRangeSchedule { get; set; }
        public string AllSelectedFieldsSchedule { get; set; } 
        public ProviderFileDownloadModel FileDownloadSchedule { get; set; }
        public IEnumerable<ProviderScheduledFiles> ScheduledFilesModelSchedule { get; set; }
        public string MultipleCheckStatesSchedule { get; set; }
        public string FieldsIncludedContentSchedule { get; set; }
        public IEnumerable<CompFieldsAvailable> CompFieldsIncludedContentSchedule { get; set; }
        public IEnumerable<OptionalFieldsAvailable> OptFieldsIncludedContentSchedule { get; set; }

        public string ScheduleTypeRadioSchedule { get; set; }

        public string SelectedDay { get; set; }

        public string SelectedDate { get; set; }

        public IEnumerable<City> CityListSchedule { get; set; }
        public IEnumerable<County> CountyListSchedule { get; set; }

        public IEnumerable<CountyAvailable> CountyCheckBoxSchedule { get; set; } //for county radio of county dropdown

        public IEnumerable<CityAvailable> CityCheckBoxSchedule { get; set; }

        public string CountyDropDownChosenSchedule { get; set; }

        public IEnumerable<SelectListItem> CityDropDownSchedule { get; set; }  //for city radio of city dropdown
       
        public string CityDropDownChosenSchedule { get; set; }

        public IEnumerable<SelectListItem> OtherCountyDropDownSchedule { get; set; } //for county/city radio of county dropdown       
        public string OtherCountyDropDownChosenSchedule { get; set; }

        public IEnumerable<SelectListItem> OtherCityDropDownSchedule { get; set; }  //for county/city radio of city dropdown
        public string OtherCityDropDownChosenSchedule { get; set; }

        public IEnumerable<SelectListItem> CountyCityDropDownSchedule { get; set; }

       


    }

}

