﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.DTO;

namespace NABWebsite.Models
{
    //ViewModel for "Search for Claims"
    public class ClaimInquiry
    {
        public string Network { get; set; }
        //public string ClaimNo { get; set; }
        public string SearchBy { get; set; }

        public IEnumerable<SelectListItem> Day { get; set; }
        public IEnumerable<SelectListItem> Month { get; set; }
        public IEnumerable<SelectListItem> Year { get; set; }

        public string SelectedSearchCriteria { get; set; }

        public IEnumerable<SelectListItem> SearchCriteria { get; set; }

        public ProcessedClaim ProcessedClaim { get; set; }

        public string ProcessedFilter { get; set; }

        

        public string RejectedFilter { get; set; }

        public ClaimSearchCriteria ClaimSearchCriteria { get; set; }

        public int TotalCount { get; set; }

        public AllTins TinList { get; set; }

        public string SrcSystemID { get; set; }
    }
}