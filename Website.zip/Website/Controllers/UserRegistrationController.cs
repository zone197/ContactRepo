﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models;
using NABWebsite.DTO;
using NABWebsite.BLL;
using System.Configuration;
using System.Globalization;
using Aetna.ProviderContracts.DataContracts;
using NABWebsite.Helper;
using System.Net;
using Newtonsoft.Json;
using System.Text;
using CofinityEncryption;
using Utilities;
using Newtonsoft.Json.Linq;


namespace NABWebsite.Controllers
{
    public class UserRegistrationController : Controller
    {
        ManageContent contentManager = new ManageContent();
        UserRegistrationBLL bllObject = new UserRegistrationBLL();
        private static Dictionary<string, string> _cacheHostUrl;
        
        // GET: UserRegistration
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserRegistrationController, Index Method");
                UserRegistration userRegistrationModelObject = new UserRegistration();

                List<RegistrationNetworkList> registrationNetworkTypeList = new List<RegistrationNetworkList>()
            {
                new RegistrationNetworkList{ NetworkChosenDisplay= Constants.FirstHealthNetworkDisplay ,NetworkChosenValue=Constants.NetworkFirstHealthText},
                new RegistrationNetworkList{ NetworkChosenDisplay=Constants.CofinityNetworkDisplay , NetworkChosenValue=Constants.NetworkCofinityText}
               
            };

                userRegistrationModelObject.NetworkListRef = registrationNetworkTypeList;

                List<RegistrationCustomerTypeList> customerTypeRef = new List<RegistrationCustomerTypeList>()
                {
                    new RegistrationCustomerTypeList{CustomerChosenDisplay=Constants.CustomerCustomerDisplay,CustomerChosenValue=Constants.Customer},
                    new RegistrationCustomerTypeList{CustomerChosenDisplay=Constants.CustomerProviderDisplay,CustomerChosenValue=Constants.Provider}
                };

                userRegistrationModelObject.CustomerTypeList = customerTypeRef;


                List<RegistrationNetworkAccessList> registrationNetworkAccessTypeList = new List<RegistrationNetworkAccessList>()
            {
                new RegistrationNetworkAccessList{ NetworkAccessChosenType=false, NetworkAccessChosenValue=Constants.GroupHealth},
                new RegistrationNetworkAccessList{ NetworkAccessChosenType=false, NetworkAccessChosenValue=Constants.Auto},
                new RegistrationNetworkAccessList{ NetworkAccessChosenType=false, NetworkAccessChosenValue=Constants.WorkerCompensation},
            };

                userRegistrationModelObject.NetworkAccessListRef = registrationNetworkAccessTypeList;

                NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
                int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);

                List<State> statesAll = new List<State>();
                statesAll = contentManager.GetStatesLocateProvider(helper.GetRequestHeader(string.Empty, defaultSourceId)).ToList();
               


                List<SelectListItem> dropDownObject = statesAll.Select(x =>
                                          new SelectListItem()
                                          {
                                              Text = x.StateName.ToString(),
                                              Value = x.StateCode.ToString()
                                          }).ToList<SelectListItem>();

                userRegistrationModelObject.CompanyStateDropDown = dropDownObject;
                List<SelectListItem> generalQuestion = new List<SelectListItem>();
                List<SelectListItem> familyQuestion = new List<SelectListItem>();
                List<SelectListItem> favoriteQuestion = new List<SelectListItem>();

                generalQuestion = bllObject.GetSecurityQuestionByCategory(Constants.General).ToList();
                familyQuestion = bllObject.GetSecurityQuestionByCategory(Constants.Family).ToList();
                favoriteQuestion = bllObject.GetSecurityQuestionByCategory(Constants.Favourite).ToList();


                userRegistrationModelObject.SecurityQuestion1List = generalQuestion;
                userRegistrationModelObject.SecurityQuestion2List = familyQuestion;
                userRegistrationModelObject.SecurityQuestion3List = favoriteQuestion;

                userRegistrationModelObject.RecaptchaPublicKey = AppSettingHelper.GetAppSettingValue(VariableConstant.PublicKey);
                userRegistrationModelObject.GoogleRecaptchaAPIAddressSingle = AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleAPIAddress);
                userRegistrationModelObject.Hosturl = GetHostUrl("HOSTURL");
                userRegistrationModelObject.LinkId = ConfigurationManager.AppSettings["UserGuideLinkId"];
                traceLog.AppendLine(" & End: UserRegistrationController, Index Method");
                return View(userRegistrationModelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

       


        [AjaxValidateAntiForgeryToken]
        public JsonResult VerifyTokenValue(string secureToken)
        {
            string errorMessage = string.Empty;
            WebClient client = new WebClient();
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserRegistrationController, VerifyTokenValue Method");
                string response = secureToken;
                string secret = AppSettingHelper.GetAppSettingValue(VariableConstant.PrivateKey);
                bool isSuccess = true;

                string captchaErrorMessage = string.Empty;
               
                var reply = client.DownloadString(string.Format(CultureInfo.CurrentCulture, AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleRecaptchaVerificationURL), secret, response));
                //code change for Deserialization of Untrusted Data on 08/10/2018
                var jobj = JObject.Parse(reply);
                isSuccess = (bool)jobj.SelectToken("success");
                if (!isSuccess)
                {
                    captchaErrorMessage = (string)jobj.SelectToken("error-codes");
                    switch (captchaErrorMessage)
                    {
                        case ("missing-input-secret"):
                            errorMessage = Constants.CaptchaParameterMissing;
                            break;
                        case ("invalid-input-secret"):
                            errorMessage = Constants.CaptchaParameterInvalid;
                            break;

                        case ("missing-input-response"):
                            errorMessage = Constants.ResponseParameterMissing;
                            break;
                        case ("invalid-input-response"):
                            errorMessage = Constants.ResponseParameterInvalid;
                            break;

                        default:
                            errorMessage = Constants.CaptchaError;
                            break;
                    }
                   
                }
                else
                {
                    errorMessage = String.Empty;
                }
                   
            }
            catch (Exception ex)
            {
                
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                client.Dispose();
                LogManager.WriteTraceLog(traceLog);
            }
            traceLog.AppendLine(" & End: UserRegistrationController, VerifyTokenValue Method");
            return Json(errorMessage);
        }
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult Success(UserRegistration modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserRegistrationController, Success Method with Param modelObject: " + modelObject);
                if (modelObject != null)
                {
                    if (modelObject.AgreeCheck && modelObject.Prd == modelObject.ConfirmPrd && modelObject.Signature == modelObject.UserName)
                    {
                        Registration registrationObject = new Registration()
                        {
                            NetworkSelected = modelObject.NetworkSelected.Contains(Constants.CommaWithoutSpace) ? modelObject.NetworkSelected.Substring(0, modelObject.NetworkSelected.Length - 1) : modelObject.NetworkSelected,
                            NetworkAccessSelected = modelObject.NetworkAccessSelected,
                            CustomerTypeChosen = modelObject.CustomerTypeChosen,
                            PayerNames = modelObject.PayerNames != null ? (modelObject.PayerNames.Contains(Constants.CommaWithoutSpace) ? modelObject.PayerNames.Substring(0, modelObject.PayerNames.Length - 1) : modelObject.PayerNames) :  string.Empty ,
                            ProviderTypeSelected = modelObject.ProviderTypeSelected,
                            Tins = modelObject.Tins != null ? (modelObject.Tins.Contains(Constants.CommaWithoutSpace) ? modelObject.Tins.Substring(0, modelObject.Tins.Length - 1) : modelObject.Tins) :  string.Empty ,
                            FirstName = (string.IsNullOrEmpty(modelObject.FirstName)) ? string.Empty : modelObject.FirstName.Trim(),
                            MiddleInitial = (string.IsNullOrEmpty(modelObject.MiddleInitial)) ? string.Empty : modelObject.MiddleInitial.Trim(),
                            LastName = (string.IsNullOrEmpty(modelObject.LastName)) ? string.Empty : modelObject.LastName.Trim(),
                            Title = (string.IsNullOrEmpty(modelObject.Title)) ? string.Empty : modelObject.Title.Trim(),
                            EmailAddress = (string.IsNullOrEmpty(modelObject.EmailAddress)) ? string.Empty : modelObject.EmailAddress.Trim(),
                            PracticeEmailAddress = (string.IsNullOrEmpty(modelObject.PracticeEmailAddress)) ? string.Empty : modelObject.PracticeEmailAddress.Trim(),
                            CompanyName = (string.IsNullOrEmpty(modelObject.CompanyName)) ? string.Empty : modelObject.CompanyName.Trim(),
                            DivisionMailstop = (string.IsNullOrEmpty(modelObject.DivisionMailstop)) ? string.Empty : modelObject.DivisionMailstop.Trim(),
                            CompanyAddress = (string.IsNullOrEmpty(modelObject.CompanyAddress)) ? string.Empty : modelObject.CompanyAddress.Trim(),
                            CompanyCity = (string.IsNullOrEmpty(modelObject.CompanyCity)) ? string.Empty : modelObject.CompanyCity.Trim(),
                            CompanyState = (string.IsNullOrEmpty(modelObject.CompanyState)) ? string.Empty : modelObject.CompanyState.Trim(),
                            ZipCode = (string.IsNullOrEmpty(modelObject.ZipCode)) ? string.Empty : modelObject.ZipCode.Trim(),
                            BusinessPhone = (string.IsNullOrEmpty(modelObject.BusinessPhone)) ? string.Empty : modelObject.BusinessPhone.Trim(),
                            NetworkContactName = (string.IsNullOrEmpty(modelObject.NetworkContactName)) ? string.Empty : modelObject.NetworkContactName.Trim(),
                            Comments = (string.IsNullOrEmpty(modelObject.Comments)) ? string.Empty : modelObject.Comments.Trim(),
                            UserName = (string.IsNullOrEmpty(modelObject.UserName)) ? string.Empty : modelObject.UserName.Trim(),
                            Prd = (string.IsNullOrEmpty(Helper.AESEncrypt.DecryptStringAES(modelObject.Prd))) ? string.Empty : NABEncryption.Encrypt(Helper.AESEncrypt.DecryptStringAES(modelObject.Prd.Trim())),
                            SecurityQuestion1Selected = (string.IsNullOrEmpty(modelObject.SecurityQuestion1Selected)) ? string.Empty : modelObject.SecurityQuestion1Selected.Trim(),
                            SecurityQuestion2Selected = (string.IsNullOrEmpty(modelObject.SecurityQuestion2Selected)) ? string.Empty : modelObject.SecurityQuestion2Selected.Trim(),
                            SecurityQuestion3Selected = (string.IsNullOrEmpty(modelObject.SecurityQuestion3Selected)) ? string.Empty : modelObject.SecurityQuestion3Selected.Trim(),
                            SecurityAnswer1 = (string.IsNullOrEmpty(modelObject.SecurityAnswer1)) ? string.Empty : modelObject.SecurityAnswer1.Trim(),
                            SecurityAnswer2 = (string.IsNullOrEmpty(modelObject.SecurityAnswer2)) ? string.Empty : modelObject.SecurityAnswer2.Trim(),
                            SecurityAnswer3 = (string.IsNullOrEmpty(modelObject.SecurityAnswer3)) ? string.Empty : modelObject.SecurityAnswer3.Trim(),
                            Signature = (string.IsNullOrEmpty(modelObject.Signature)) ? string.Empty : modelObject.Signature.Trim(),
                            NabStatus = (modelObject.NetworkSelected.Contains(Constants.Cofinity) || modelObject.NetworkSelected.Contains(Constants.NetworkFirstHealthText)) ? "P" : null,
                            IoeStatus = modelObject.NetworkSelected.Contains("Transplant") ? "P" : null
                        };

                        int result = 0;
                        result = bllObject.RegisterUser(registrationObject);

                        if (result > 0)
                        {
                            if (SendMailtoUser(registrationObject.EmailAddress))
                                traceLog.AppendLine(" & End: UserRegistrationController, Success Method");
                                return Content("<script type='text/javascript'>alert('Your request has been submitted. \\n It will be reviewed and you will receive a status update by e-mail.');window.location.href='/Home/Index';</script>");

                        }

                        else
                            if (result == -2)
                                traceLog.AppendLine(" & End: UserRegistrationController, Success Method");
                                return Content("<script type='text/javascript'>alert('Email Id already Exists!');window.location.href='/Home/Index';</script>");
                    }
                }
                traceLog.AppendLine(" & End: UserRegistrationController, Success Method");
                return Content("<script type='text/javascript'>alert('New User registration failed!');window.location.href='/Home/Index';</script>");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

       
        public bool SendMailtoUser(string emailId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserRegistrationController, SendMailtoUser Method with Param emailId: " + emailId);
                bool result = false;
                string fromMailAddress = ConfigurationManager.AppSettings[Constants.HelpDeskKey];
                List<string> mailAddress = new List<string>();
                mailAddress.Add(emailId);

                string subject = Constants.UserRegistrationMailSubject;
                string body = GetEmailBodyUser();
                result = bllObject.SendMailtoUser(body, fromMailAddress, mailAddress.ToArray(), subject, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                traceLog.AppendLine(" & End: UserRegistrationController, SendMailtoUser Method");
                return result;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        private string EmailBody;
        private string GetEmailBodyUser()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserRegistrationController, GetEmailBodyUser Method");
                StringBuilder mailBody = new StringBuilder();
                mailBody.Append(Constants.UserRegistartionMailBody);

                EmailBody = mailBody.ToString();
                traceLog.AppendLine(" & End: UserRegistrationController, GetEmailBodyUser Method");
                return EmailBody;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public JsonResult GetUserIds(UserRegistration modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: UserRegistrationController, GetUserIds Method with Param modelObject: " + modelObject);
                List<string> useridList = new List<string>();
                if (modelObject != null)
                {
                    var firstName = modelObject.FirstName;
                    var lastName = modelObject.LastName;
                    if (!string.IsNullOrEmpty(firstName) && !string.IsNullOrEmpty(lastName))
                    {
                        if ((Validation.IsValidContent(firstName) && Validation.IsValidContent(lastName)) && (Validation.IsAlpha(firstName) && (Validation.IsAlpha(lastName))))
                        {
                            useridList = bllObject.GetUsers(firstName, lastName).ToList();
                        }
                    }

                }
                traceLog.AppendLine(" & End: UserRegistrationController, GetUserIds Method");
                return Json(useridList, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [CustomOutputCacheAttribute("CacheDuration1800_linkId")]
        public ActionResult RetrieveFile(int linkId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {

                traceLog.AppendLine("Start: UserRegistrationController, RetrieveFile Method with Param linkId: " + linkId);
                int roleId = 0;
                UserDetails userDetails = (UserDetails)Session[Constants.UserDetails];
                if (userDetails != null && userDetails.UserRoles != null)
                {
                    string selectedRole = userDetails.SelectedRole;
                    var roles = userDetails.UserRoles.Where(role => role.RoleName.Equals(selectedRole)).FirstOrDefault();
                    if (roles != null)
                    {
                        roleId = Convert.ToInt32(roles.RoleId);
                    }

                }
                ManageContent manageContent = new ManageContent();
                //langId = 1 for EN- US only
                var fileDetail = manageContent.GetFileContentByLinkId(linkId, 1, roleId, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                string contentType = "application/pdf";
                Byte[] cover = fileDetail.Content;
                var cd = new System.Net.Mime.ContentDisposition
                {
                    FileName = fileDetail.Name + "." + fileDetail.FileType,
                    Inline = true,
                };
              
                Response.AppendHeader("Content-Disposition", cd.ToString());
                traceLog.AppendLine(" & End: UserRegistrationController, RetrieveFile Method");
                return File(cover, contentType);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        private string GetHostUrl(string keyname)
        {
            StringBuilder traceLog = new StringBuilder();
           
            try
            {
                traceLog.AppendLine("Start: UserRegistrationController, GetHostUrl Method with Param keyname: " + keyname);
                string strhosturl = "";

                Dictionary<string, string> dictionary = new Dictionary<string, string>();
                if (_cacheHostUrl == null)
                {
                    strhosturl = Convert.ToString(ConfigurationManager.AppSettings["HOSTURL"]);
                    dictionary.Add("HOSTURL", strhosturl);
                    _cacheHostUrl = dictionary;
                }
                _cacheHostUrl.TryGetValue(keyname.ToUpper(), out strhosturl);
                traceLog.AppendLine(" & End: UserRegistrationController, GetHostUrl Method");
                return strhosturl;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

    }
}