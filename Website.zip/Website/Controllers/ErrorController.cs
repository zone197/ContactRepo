﻿using NABWebsite.Helper;
using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using Utilities;

namespace NABWebsite
{
    public class ErrorController : Controller
    {
        //
        // GET: /Error/
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ErrorController, Index Method");
                if (Convert.ToBoolean(ConfigurationManager.AppSettings["URl_RedirectTo"]))
                {
                    traceLog.AppendLine(" & End: LocateProviderController, Index Method");
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    traceLog.AppendLine(" & End: ErrorController, Index Method");
                    return View("~/views/error/error.cshtml");
                }
            }
            catch(Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        public ActionResult Custom()
        {

            return View("~/views/error/500.html");
        }
        public ActionResult IndexSession()
        {
            return View("~/views/error/errorsession.cshtml");
        }
        public ActionResult ApplicationAccessError()
        {
            return View();
        }

        public ActionResult NoAccessError()
        {
            return RedirectToAction("Home","Home",new {submitButton="Logout"});
        }
        /// <summary>
        /// Set Culture for the application in cookie
        /// </summary>
        /// <param name="culture"></param>
        /// <returns></returns>
        //[ValidateAntiForgeryToken]
        public ActionResult SetCulture(string culture)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ErrorController, SetCulture Method with Param culture: " + culture);
                // Validate input
                culture = CultureHelper.GetImplementedCulture(culture);
                Session[CookieConstant.Culture] = culture;

                //Set Current culture in other session for persist its value after coming from content pages 
                Session["CurrentCulture"] = culture;
                string CurrentController = string.Empty;
                string CurrentAction = string.Empty;

                if (Session[SessionConstant.CurrentController] != null && Session[SessionConstant.CurrentAction] != null)
                {
                    CurrentController = Session[SessionConstant.CurrentController].ToString();
                    CurrentAction = Session[SessionConstant.CurrentAction].ToString();
                }
                else
                {
                    CurrentController = "Error";
                    CurrentAction = "Index";
                }


                traceLog.AppendLine(" & End: ErrorController, SetCulture Method");
                return Redirect("/" + CurrentController + "/" + CurrentAction);
            }
            catch(Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        
	}
}