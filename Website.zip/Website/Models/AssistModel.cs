﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.DTO;

namespace NABWebsite.Models
{
    public class AssistModel
    {
        [Display(Name = "Date:")]
        public string formDate { get; set; }
        public string UserId { get; set; }
        public bool ClaimSearch { get; set; }

        [Display(Name = "Client Name*")]
        public string ClientName { get; set; }
        [Display(Name = "Requestor Name")]
        public string RequestorName { get; set; }
        public string RequestorFName { get; set; }
        public string RequestorLName { get; set; }

        [Display(Name = "Requestor Email Address")]
        public string RequestorEmailAddress { get; set; }

        [Required(ErrorMessage = "Please enter Phone Number")]
        [RegularExpression("^([0-9]{10})$", ErrorMessage = "Please enter valid Phone number")]
        [Display(Name = "Requester Phone Number*")]
        public string RequesterPhoneNumber { get; set; }


        [Display(Name = "Group Name*")]
        public string GroupName { get; set; }

        [Required(ErrorMessage = "Please enter Funding Type")]
        [Display(Name = "Funding Type*")]
        public long? FundingType { get; set; }

        [Display(Name = "Member Identification(ID)*")]
        public string MemberID { get; set; }


        [Display(Name = "Patient first and last name *")]
        public string PatientFLName { get; set; }

        [Required(ErrorMessage = "Please enter Tax Identification Number (TIN)")]
        [RegularExpression("^([0-9]{9})$", ErrorMessage = "Please enter a valid TIN Number")]
        [Display(Name = "Tax Identification Number (TIN)*")]
        public string ProviderTIN { get; set; }

        [Required(ErrorMessage = "Please enter National Provider Identifier (NPI)")]
        [RegularExpression("^([0-9]{10})$", ErrorMessage = "Please enter valid NPI")]
        [Display(Name = "National Provider Identifier (NPI)*")]

        public string ProviderNPI { get; set; }

        [Required(ErrorMessage = "Please enter Address")]
        [Display(Name = "Servicing  Address*")]
        public string ProviderStreet { get; set; }

        [Required(ErrorMessage = "Please enter Servicing City")]
        [Display(Name = "Servicing City*")]
        public string ProviderCity { get; set; }

        [Required(ErrorMessage = "Please enter Servicing State")]
        [Display(Name = "Servicing State*")]
        public string ProviderState { get; set; }

        [Required(ErrorMessage = "Please enter Servicing Zip code")]
        [RegularExpression(@"^\d{5}(-\d{4})?$", ErrorMessage = "Please enter valid Servicing Zip code")]
        [Display(Name = "Servicing Zip code*")]
        public string ProviderZipCode { get; set; }

        [Required(ErrorMessage = "Please enter Billing Address")]
        [Display(Name = "Billing Address*")]
        public string BillingStreet { get; set; }

        [Required(ErrorMessage = "Please enter Billing City")]
        [Display(Name = "Billing City*")]
        public string BillingCity { get; set; }

        [Required(ErrorMessage = "Please enter Billing State")]
        [Display(Name = "Billing State*")]
        public string BillingState { get; set; }

        [Required(ErrorMessage = "Please enter Billing Zip code")]
        [RegularExpression(@"^\d{5}(-\d{4})?$", ErrorMessage = "Please enter valid Billing Zip code")]
        [Display(Name = "Billing Zip code*")]
        public string BillingZipCode { get; set; }

        [Required(ErrorMessage = "Please enter Phone number")]
        [RegularExpression("^([0-9]{10})$", ErrorMessage = "Please enter valid Phone number")]
        [Display(Name = "Provider Phone Number*")]
        public string ProviderPhoneNumber { get; set; }


        [Required(ErrorMessage = "Please enter Fax number")]
        [Display(Name = "Provider Fax Number*")]
        [RegularExpression("^([0-9]{10})$", ErrorMessage = "Please enter valid Fax number")]
        public string ProviderFaxNumber { get; set; }

        [Required(ErrorMessage = "Please enter E-mail Address")]
        [RegularExpression("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]{2,}", ErrorMessage = "Please enter a valid email")]
        [Display(Name = "Provider E-mail Address*")]
        public string ProviderEmailAddress { get; set; }

        [Required(ErrorMessage = "Please enter Provider Name")]
        [Display(Name = "Provider Name*")]
        public string ProviderName { get; set; }

        [Required(ErrorMessage = "Please enter Provider Specialty")]
        [Display(Name = "Provider Specialty*")]
        public string ProviderSpecialty { get; set; }


        [Display(Name = "First Health Claim Identification Number*")]
        public string ClaimIDNumber { get; set; }


        [Display(Name = "Date of Service*")]
        public string ClaimDOS { get; set; }


        [Display(Name = "Qualifying Payment Amount (QPA)*")]
        public double? ClaimQPA { get; set; }

        [Required(ErrorMessage = "Please enter Copay/Deductible Amount")]
        [RegularExpression("^\\d+(\\.\\d{1,2})?$", ErrorMessage = "Please enter a valid Copay/Deductible Amount")]
        [Display(Name = "Copay/Deductible Amount*")]
        public double? CopayDeductible { get; set; }

        [Required(ErrorMessage = "Patient Responsibility Amount")]
        [RegularExpression("^\\d+(\\.\\d{1,2})?$", ErrorMessage = "Please enter a valid Patient Responsibility Amount")]
        [Display(Name = "Patient Responsibility Amount*")]
        public double? PatientAmount { get; set; }

        [Required(ErrorMessage = "Please enter Coinsurance Amount")]
        [RegularExpression("^\\d+(\\.\\d{1,2})?$", ErrorMessage = "Please enter a valid Coinsurance Amount")]
        [Display(Name = "Coinsurance Amount*")]
        public double? Coinsurance { get; set; }

        [Required(ErrorMessage = "Please enter Balance Paid Amount")]
        [RegularExpression("^\\d+(\\.\\d{1,2})?$", ErrorMessage = "Please enter a valid Balance Paid Amount")]
        [Display(Name = "Balance Paid Amount*")]
        public double? BalancePaid { get; set; }

        [Required(ErrorMessage = "Please enter Remaining Out of Pocket Amount")]
        [RegularExpression("^\\d+(\\.\\d{1,2})?$", ErrorMessage = "Please enter a valid Remaining Out of Pocket Amount")]
        [Display(Name = "Remaining Out of Pocket Amount*")]
        public double? RemainingPocket { get; set; }

        [Required(ErrorMessage = "Please enter Check Date")]
        [RegularExpression(Constants.TransplantDateValidation, ErrorMessage = "Please enter a valid Check Date")]
        [Display(Name = "Check Date*")]
        public string CheckDate { get; set; }

        [Required(ErrorMessage = "Please enter Amount Paid")]
        [RegularExpression("^\\d+(\\.\\d{1,2})?$", ErrorMessage = "Please enter a valid Amount Paid")]
        [Display(Name = "Amount Paid*")]
        public double? AmountPaid { get; set; }

        [Required(ErrorMessage = "Please enter Offer made by Provider")]
        [RegularExpression("^\\d+(\\.\\d{1,2})?$", ErrorMessage = "Please enter a valid Offer made by Provider")]
        [Display(Name = "Offer made by Provider*")]
        public double? ProviderOffer { get; set; }

        [Required(ErrorMessage = "Please enter Date Provider Initiated Negotiation")]
        [RegularExpression(Constants.TransplantDateValidation, ErrorMessage = "Please enter a valid Date Provider Initiated Negotiation")]
        [Display(Name = "Date Provider Initiated Negotiation*")]
        public string NegotiationDate { get; set; }


        [Display(Name = "Additional Notes")]
        public string AdditionalNotes { get; set; }

        [Required(ErrorMessage = "Please attach Explanation of Benefits (EOB) ")]
        [Display(Name = "Explanation of Benefits (EOB)*:")]
        public HttpPostedFileBase EobAttachment { get; set; }

        [Required(ErrorMessage = "Please attach Open Negotiation Form ")]
        [Display(Name = "Open Negotiation Form*:")]
        public HttpPostedFileBase OpenForm { get; set; }


        [Display(Name = "Attachments:")]
        public HttpPostedFileBase[] RequiredAttachments { get; set; }

        public string[] FileDescription { get; set; }

        public string ExtClientID { get; set; }
        public string ExtSubClientID { get; set; }
        public string SubClientName { get; set; }
        public long? ProductLineID { get; set; }
        public string ExtClaimNum { get; set; }
        public long DW2020_ClaimNum { get; set; }

        public IEnumerable<SelectListItem> BillingStateList { get; set; }
        public IEnumerable<SelectListItem> ProviderStateList { get; set; }
        public IEnumerable<SelectListItem> FunctionTypeList { get; set; }
        public IEnumerable<SelectListItem> Specialities { get; set; }


    }

    public class AssistAttachmentModel
    {
        public long IssueID { get; set; }

        public IEnumerable<SelectListItem> ActiveAttachmentTypes { get; set; }
        public int AttachmentTypeDefnID { get; set; }
        public string AttachmentType { get; set; }
        public string FileDescription { get; set; }
        public HttpPostedFileBase AttachmentFile { get; set; }
        public HttpPostedFileBase OpenForm { get; set; }
        public HttpPostedFileBase[] RequiredAttachments { get; set; }

    }

}
