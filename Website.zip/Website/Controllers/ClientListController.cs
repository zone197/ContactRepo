﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NABWebsite.DTO;
using NABWebsite.BLL;
using System.Text;
using Utilities;
using NABWebsite.Models;
using NABWebsite.Helper;
using System.Data;
using System.IO;
using ClosedXML.Excel;
using System.Reflection;
using System.Configuration;
using System.Web.Security.AntiXss;


namespace NABWebsite.Controllers
{
    public class ClientListController : Controller
    {
        // GET: ClientList
        /// <summary>
        /// Returns to Client List Search page
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            Session[SessionConstant.ClientListDetails] = null;
            Session[SessionConstant.SessionClientlist] = null;
            try
            {
                traceLog.AppendLine("Start: ClientListController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }

                ClientList clObj = new ClientList();
                bool isExternal = false;
                Session[Constants.Header] = Constants.ClientListHeader;
                if (System.Configuration.ConfigurationManager.AppSettings[Constants.Site] == "External")
                {

                    isExternal = true;

                    ClientListBLL clientListBL = new ClientListBLL();
                    string userId = ((UserDetails)Session[Constants.UserDetails]).UserId.ToString();
                    string srcSystemIds = Constants.ThreeCount.ToString();
                    var getUserFavProviderTins = clientListBL.GetUserFavProviderTins(userId, srcSystemIds);
                    if (getUserFavProviderTins.Count() <= 0)
                    {
                        return RedirectToAction("FavouriteProviderList");
                    }
                    clObj = FavAction();
                }
                Session["isExternal"] = isExternal;
                traceLog.AppendLine(" & End: ClientListController, Index Method");
                return View(clObj);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Returns data to ClientList Search page
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ClientListSearch(ClientList obj)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClientListController, ClientListSearch Method with param obj: " + obj);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ClientListHeader;
                ClientListBLL clientListBL = new ClientListBLL();
                ClientList cl = null;
               
                var clientListOnlyShow = clientListBL.GetClientListOnlyShow();
                string userId = ((UserDetails)Session[Constants.UserDetails]).UserId.ToString();
                string srcSystemIds = Constants.ThreeCount.ToString();
                //List<SelectListItem> items = new List<SelectListItem>();
                if (System.Configuration.ConfigurationManager.AppSettings[Constants.Site] == "External")
                {
                    cl = new ClientList();
                    string provListTemp = "";
                    if (obj.TaxID != null && obj.TaxID != "" && obj.CPDID != null && obj.CPDID != "")
                    {
                        provListTemp = (obj.TaxID.Trim() + "-" + obj.CPDID.Trim()).Trim();
                    }
                    var getUserFavProviders = clientListBL.GetUserFavProviders(userId, provListTemp, srcSystemIds);
                    cl.isValidProvList = false;
                    if (!(getUserFavProviders == null || getUserFavProviders.Count <= 0))
                    {
                        cl.isValidProvList = true;
                        if (clientListOnlyShow != null)
                        {
                            cl.lstclientListOnlyShow = (from row in clientListOnlyShow
                                                        select new SelectListItem()
                                {
                                    Value = row.OptionDescription,
                                    Text = row.OptionDescription
                                });
                        }

                        if (getUserFavProviders != null)
                        {
                            cl.lstStateList = (from row in getUserFavProviders
                                               select new SelectListItem()
                                               {
                                                   Value = row.StateName,
                                                   Text = row.StateCode
                                               });

                            cl.lstProviderList = (from row in getUserFavProviders
                                                  select new SelectListItem()
                                                  {
                                                      Value = row.ProviderName,
                                                      Text = row.ProviderName
                                                  });
                        }
                        
                        
                        cl.TaxID = obj.TaxID;
                        cl.CPDID = obj.CPDID;
                        
                    }
                   
                    
                }
                else
                {
                    cl = new ClientList();
                    if (obj.TaxID != null && obj.TaxID != "" && obj.CPDID != null && obj.CPDID != "")
                    {
                        var getUserVerifyInternal = clientListBL.GetUserVerifyInternal(userId, obj.TaxID.Trim(), obj.CPDID.Trim(), srcSystemIds);
                        cl.isValidProvList = false;

                        if (!(getUserVerifyInternal == null || getUserVerifyInternal.Count <= 0))
                        {
                            cl.isValidProvList = true;
                            if (clientListOnlyShow != null)
                            {
                                cl.lstclientListOnlyShow = (from row in clientListOnlyShow
                                                            select new SelectListItem()
                                                            {
                                                                Value = row.OptionDescription,
                                                                Text = row.OptionDescription
                                                            });
                            }

                            if (getUserVerifyInternal != null)
                            {
                                cl.lstStateList = (from row in getUserVerifyInternal
                                                   select new SelectListItem()
                                                   {
                                                       Value = row.StateName,
                                                       Text = row.StateID
                                                   });

                                cl.lstProviderList = (from row in getUserVerifyInternal
                                                      select new SelectListItem()
                                                      {
                                                          Value = row.ProvName,
                                                          Text = row.ProvName
                                                      });
                            }
                            cl.TaxID = obj.TaxID;
                            cl.CPDID = obj.CPDID;
                        }
                    }
                   

                }
                
                traceLog.AppendLine(" & End: ClientListController, ClientListSearch Method");
                return Json(cl, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }


        private ClientList FavAction()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClientListController, FavAction Method");

                string userId = null;
                ClientList clObj = new ClientList();
                ClientListBLL clientListBL = new ClientListBLL();
                userId = ((UserDetails)Session[Constants.UserDetails]).UserId.ToString();
                string srcSystemIds = Constants.ThreeCount.ToString();
                var getUserFavProviderTins = clientListBL.GetUserFavProviderTins(userId, srcSystemIds);
                if (getUserFavProviderTins != null && getUserFavProviderTins.Count() > 0)
                {
                    var selectListProvName = new List<SelectListItem>();
                    var selectListProvTAXID = new List<SelectListItem>();
                    clObj.lstTAXDropDown = (from row in getUserFavProviderTins
                                            select new SelectListItem()
                                            {
                                                Value = row.ProviderTAXId,
                                                Text = row.ProviderTAXId
                                            }).GroupBy(o => o.Value)
                                           .Select(o => o.FirstOrDefault());

                    clObj.lstProviderList = (from row in getUserFavProviderTins.Where(m=>m.ProviderTAXId.Equals(clObj.lstTAXDropDown.FirstOrDefault().Text))
                                             select new SelectListItem()
                                             {
                                                 Value = row.ProvNum,
                                                 Text = row.ProviderName
                                             });                    


                }
                traceLog.AppendLine(" & End: ClientListController, FavAction Method");
                return clObj;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// Add/Remove providers from the list
        /// </summary>
        /// <returns></returns>
        public ActionResult FavouriteProviderList()
        {
            try
            {
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ClientListFavProvHeader;
                ClientListBLL clientListBL = new ClientListBLL();
                string userid = null;
                int srcSystemId = Convert.ToInt32(Constants.Three);
                string Product = Constants.Product;
                string Network = Constants.NetworkFirstHealthText;
                string ApplicationName = "";

                StringBuilder traceLog = new StringBuilder();

                try
                {
                    traceLog.AppendLine(" & End: ClientListController, FavouriteProviderList Method");
                    if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                    {
                        traceLog.AppendLine(" & End: ClientListController, FavouriteProviderList Method");
                        return RedirectToAction("Index", "Home");
                    }
                    Session[Constants.Header] = Constants.FavProviderList;
                    userid = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    string ProviderList = clientListBL.GetProviderListForUser(userid, Product, Network, ApplicationName);
                    string ProvList = ProviderList.Replace("'", "");
                    ClientListModel Clientmodel = new ClientListModel();
                    List<FavProviderList> clientlist = new List<FavProviderList>();

                    clientlist = clientListBL.GetFavProviderList(userid, ProvList, srcSystemId);
                    var fav = clientlist.Where(a => a.Selected == 0).ToList();
                    var favR = clientlist.Where(a => a.Selected == 1).ToList();
                    Clientmodel.FavProviderR = favR;
                    Clientmodel.FavProvider = fav;
                    Clientmodel.Total = fav.Count();
                    Clientmodel.TotalR = favR.Count();

                    traceLog.AppendLine(" & End: ClientListController, FavouriteProviderList Method");

                    return View(Clientmodel);
                }
                catch (Exception ex)
                {
                    LogManager.WriteErrorLog(ex);
                    throw;
                }

                finally
                {
                    LogManager.WriteTraceLog(traceLog);
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        /// <summary>
        /// Add Favourite provider into list
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult AddFavProviders(string ProviderList)
        {
            try
            {
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ClientListFavProvHeader;
                ClientListBLL clientListBL = new ClientListBLL();

                FavProviders FavProvList = new FavProviders();
                FavProvList.Userid = ((UserDetails)Session[Constants.UserDetails]).UserId;
                FavProvList.Srcsystemid = Convert.ToInt32(Constants.Three);
                FavProvList.ProviderList = ProviderList;

                StringBuilder traceLog = new StringBuilder();

                try
                {

                    traceLog.AppendLine(" & End: ClientListController, AddFavProviders Method");
                    if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                    {
                        traceLog.AppendLine(" & End: ClientListController, AddFavProviders Method");
                        return RedirectToAction("Index", "Home");
                    }


                    bool status = clientListBL.AddFavProviders(FavProvList);
                    traceLog.AppendLine(" & End: ClientListController, AddFavProviders Method");
                    return Json(status);
                }
                catch (Exception ex)
                {
                    LogManager.WriteErrorLog(ex);
                    throw;
                }

                finally
                {
                    LogManager.WriteTraceLog(traceLog);
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        /// <summary>
        /// Remove Favourite provider into list
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult RemoveFavProviders(string ProviderListR)
        {

            try
            {
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ClientListFavProvHeader;
                ClientListBLL clientListBL = new ClientListBLL();
                FavProviders FavProvList = new FavProviders();
                FavProvList.Userid = ((UserDetails)Session[Constants.UserDetails]).UserId;
                FavProvList.Srcsystemid = Convert.ToInt32(Constants.Three);
                FavProvList.ProviderList = ProviderListR;

                StringBuilder traceLog = new StringBuilder();

                try
                {
                    traceLog.AppendLine(" & End: ClientListController, RemoveFavProviders Method");
                    if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                    {
                        traceLog.AppendLine(" & End: ClientListController, RemoveFavProviders Method");
                        return RedirectToAction("Index", "Home");
                    }



                    bool status = clientListBL.RemoveFavProviders(FavProvList);


                    traceLog.AppendLine(" & End: ClientListController, RemoveFavProviders Method");
                    return Json(status);
                }
                catch (Exception ex)
                {
                    LogManager.WriteErrorLog(ex);
                    throw;
                }

                finally
                {
                    LogManager.WriteTraceLog(traceLog);
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        /// <summary>
        /// Save Sorting Paging Informations To Session
        /// </summary>
        /// <param name="sortingPagingInfo"></param>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public void SaveClientSortingPagingInfoToSession(SortingPagingClientInfo SortingPagingClientInfo, ClientList cl)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClientListController, SaveClientSortingPagingInfoToSession Method with Param SortingPagingClientInfo: " + SortingPagingClientInfo);
                Session[SessionConstant.ClientListDetails] = SortingPagingClientInfo;
                Session[SessionConstant.SessionClientlist] = cl;
                traceLog.AppendLine(" & End: ClientListController, SaveClientSortingPagingInfoToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Client List Details
        /// </summary>
        /// <returns></returns>
        //[NoCache]
        // [HttpPost]
        public ActionResult ClientListSearchResults(ClientList ClientList)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ClientListSearchResultsHeader;
                traceLog.AppendLine("Start: ClientListController, ClientListSearchResults Method with param ClientList:" + ClientList);

                ClientDetailsRequestEntity searchRequest = new ClientDetailsRequestEntity();
                ClientListDetailsRequest Details = new ClientListDetailsRequest();
                ClientListModel searchResultClientModel = new ClientListModel();
                SortingPagingClientInfo info = new SortingPagingClientInfo();
                if (Session[SessionConstant.ClientListDetails] != null)
                {
                    info = Session[SessionConstant.ClientListDetails] as SortingPagingClientInfo;
                    if (info.CurrentPageIndex == 0)
                    {
                        searchRequest.StartIndexForRecordDisplay = info.CurrentPageIndex;
                    }
                    else
                    {
                        searchRequest.StartIndexForRecordDisplay = info.CurrentPageIndex * 10;
                    }

                    searchRequest.LastIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.PageSizeForClientList);
                    searchRequest.SortColumn = info.SortField;
                    searchRequest.SortOrder = info.SortDirection;

                }
                else
                {
                    if (info.CurrentPageIndex == 0)
                    {
                        searchRequest.StartIndexForRecordDisplay = info.CurrentPageIndex;
                    }
                    else
                    {
                        searchRequest.StartIndexForRecordDisplay = info.CurrentPageIndex * 10;
                    }

                    searchRequest.LastIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.PageSizeForClientList);

                    searchRequest.SortColumn = System.Configuration.ConfigurationManager.AppSettings["SortCol"];
                    info.SortField = System.Configuration.ConfigurationManager.AppSettings["SortCol"];

                    searchRequest.SortOrder = AppSettingHelper.GetAppSettingValue(VariableConstant.SortDirection);
                    info.SortDirection = AppSettingHelper.GetAppSettingValue(VariableConstant.SortDirection);
                    info.PageSize = AppSettingHelper.ReturnValue(VariableConstant.PageSizeForClientList);
                    info.CurrentPageIndex = AppSettingHelper.ReturnValue(VariableConstant.CurrentPageIndex);
                }

                if (Session[SessionConstant.SessionClientlist] != null)
                {
                    ClientList = Session[SessionConstant.SessionClientlist] as ClientList;
                }
                int count = 0;

                ClientListDetailsRequest reqobject = new ClientListDetailsRequest();
                var ServiceDate = ClientList.OnlyShow;
                reqobject.ServiceDate = Convert.ToDateTime(ServiceDate.Substring(ServiceDate.IndexOf("(") + 1, 10));
                reqobject.LineOfBUsiness = Constants.GroupHealths;
                
                if (ClientList.ProductName ==null)
                {
                    reqobject.Product = Constants.Products;
                }
                else
                {
                    reqobject.Product = ClientList.ProductName;
                }
                if (System.Configuration.ConfigurationManager.AppSettings[Constants.Site] == "External")
                {
                    reqobject.ProvNum = Convert.ToInt32(ClientList.Provider);
                    reqobject.TinNumber = ClientList.TaxIDDropDown;
                }
                else
                {
                    reqobject.ProvNum = Convert.ToInt32(ClientList.CPDID);
                    reqobject.TinNumber = ClientList.TaxID;
                }

                reqobject.StateCode = ClientList.State;

                reqobject.ProviderName = ClientList.ClientPayorName;
                reqobject.StartRowIndex = Convert.ToInt16(searchRequest.StartIndexForRecordDisplay);
                reqobject.LastRowIndex = Constants.LastIndex;
                reqobject.SortColumn = info.SortField;
                reqobject.SortOrder = info.SortDirection;
                searchResultClientModel.results = new List<ClientListResponse>();
                List<ClientListResponse> GetClientListDetails = new List<ClientListResponse>();

                ClientListBLL clientListBL = new ClientListBLL();
                GetClientListDetails = clientListBL.GetClientListDetails(reqobject);

                if (GetClientListDetails.Count != 0)
                {
                    foreach (var item in GetClientListDetails)
                    {
                        searchResultClientModel.results.Add(item);
                        count = item.TotalRecords;
                    }
                }

                info.PageCount = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(count) / Convert.ToDouble(VariableConstant.TenClients)));
                info.TotalRecords = count;
                ViewBag.SortingPagingClientInfo = info;
                Session[SessionConstant.ClientListDetails] = ViewBag.SortingPagingClientInfo;
                Session[SessionConstant.SessionClientlist] = ClientList;
                searchResultClientModel.Clientrequest = reqobject;
                searchResultClientModel.entity = searchRequest;
                searchResultClientModel.OnlyShow = ClientList.OnlyShow;
                searchResultClientModel.ProductName = ClientList.ProductName;
                searchResultClientModel.ClModel = ClientList;
                traceLog.AppendLine(" & End: ClientListController, ClientListSearchResults Method");
                return View("ClientListSearchResults", searchResultClientModel);

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="provNum"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ClientListSelectedProvDetails(string clientList)
        {
            try
            {
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ClientListSearchResultsHeader;
                ClientListModel searchResultClientModel = new ClientListModel();
                ClientListBLL clientListBL = new ClientListBLL();
                searchResultClientModel.provDetails = new List<ProviderDetailsResponse>();
                searchResultClientModel.provDetails = clientListBL.GetProviderDetailsByProvNum(Convert.ToInt32(clientList));
                return Json(searchResultClientModel.provDetails, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {

                throw;
            }
        }


        /// <summary>
        /// Export the records in excel format
        /// </summary>
        /// <returns></returns>
        public FileResult ExportToExcelClientList()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                ClientList objClientList = null;
                if (Session[SessionConstant.SessionClientlist] != null)
                {
                    objClientList = Session[SessionConstant.SessionClientlist] as ClientList;
                }
                ClientListDetailsRequest reqobject = new ClientListDetailsRequest();
                var ServiceDate = objClientList.OnlyShow;
                reqobject.ServiceDate = Convert.ToDateTime(ServiceDate.Substring(ServiceDate.IndexOf("(") + 1, 10));
                reqobject.LineOfBUsiness = Constants.GroupHealths;
                

                if (objClientList.ProductName == null)
                {
                    reqobject.Product = Constants.Products;
                }
                else
                {
                    reqobject.Product = objClientList.ProductName;
                }
                if (System.Configuration.ConfigurationManager.AppSettings[Constants.Site] == "External")
                {
                    reqobject.ProvNum = Convert.ToInt32(objClientList.Provider);
                    reqobject.TinNumber = objClientList.TaxIDDropDown;
                }
                else
                {
                    reqobject.ProvNum = Convert.ToInt32(objClientList.CPDID);
                    reqobject.TinNumber = objClientList.TaxID;
                }

                reqobject.StateCode = objClientList.State;
                reqobject.ProviderName = objClientList.ClientPayorName;
                reqobject.StartRowIndex = 0;
                reqobject.LastRowIndex = 1000000000;// max  value to get all records in a single hit
                reqobject.SortColumn = "";
                reqobject.SortOrder = "";

                List<ClientListResponse> GetClientListDetails = new List<ClientListResponse>();
                ClientListBLL clientListBL = new ClientListBLL();
                GetClientListDetails = clientListBL.GetClientListDetails(reqobject);

                DataTable dt = ToDataTable(GetClientListDetails);
                dt.Columns.RemoveAt(2);// remove the last column of total records
                dt.Columns.RemoveAt(0);
                dt.Columns["ProviderName"].ColumnName = "Client Name List";
                using (XLWorkbook wb = new XLWorkbook())
                {
                    var ws = wb.Worksheets.Add(dt);
                    ws.Row(1).InsertRowsAbove(2);
                    ws.Cell(1, 1).Value = Convert.ToString(ConfigurationManager.AppSettings["ClientListExcelDisclaimer"]);
                    using (MemoryStream stream = new MemoryStream())
                    {
                        wb.SaveAs(stream);
                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "ClientList.xlsx");
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Method to convert List to DataTable 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="items"></param>
        /// <returns></returns>
        public DataTable ToDataTable<T>(List<T> items)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                DataTable dataTable = new DataTable(typeof(T).Name);
                PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo prop in Props)
                {
                    dataTable.Columns.Add(prop.Name);
                }
                foreach (T item in items)
                {
                    var values = new object[Props.Length];
                    for (int i = 0; i < Props.Length; i++)
                    {

                        values[i] = Props[i].GetValue(item, null);
                    }
                    dataTable.Rows.Add(values);
                }
                return dataTable;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="clientListSelected"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ClientListPopulateProvName(string clientListSelected)
        {
            clientListSelected = AntiXssEncoder.HtmlEncode(clientListSelected,false);//Fix of Reflected XSS
            //ClientList obj = new ClientList();
            ClientList postedObj = new ClientList();
            ClientListBLL clientListBL = new ClientListBLL();
            string userId = null;
            userId = ((UserDetails)Session[Constants.UserDetails]).UserId.ToString();
            string srcSystemIds = Constants.ThreeCount.ToString();
            var getUserFavProviderTins = clientListBL.GetUserFavProviderTins(userId, srcSystemIds);
            if (getUserFavProviderTins != null)
            {               
                postedObj.lstProviderList = (from row in getUserFavProviderTins.Where(m=>m.ProviderTAXId.Equals(clientListSelected))
                                         select new SelectListItem()
                                         {
                                             Value = row.ProvNum,
                                             Text = row.ProviderName,
                                             Selected=false
                                         });
            }
            return Json(postedObj.lstProviderList, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Get product Dropdown
        /// </summary>
        /// <param name="clientListSelected"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ProductDropdown(ClientList clientL)
        {
            ClientList postedObj = new ClientList();
            string flag = Constants.Flag;
            DateTime dos = DateTime.Now;
            int planid = Constants.GroupHealths;
            string lob = Constants.GH;
            string ftin = clientL.TaxID;
            string provid = clientL.CPDID;
            string statecode = clientL.State;
            ClientListBLL clientListBL = new ClientListBLL();
             var productDropdownList = clientListBL.GetProductDropdown(flag, dos, planid, provid, statecode, ftin, lob);
               if (!(productDropdownList == null || productDropdownList.Count <= 0))
                        {
                            
                            postedObj.lstProductList = (from row in productDropdownList
                                                            select new SelectListItem()
                                                            {
                                                                Value = row.ProductGroupName,
                                                                Text = row.ProductGroupDesc
                                                            });
                            
                           
                        }
            
            return Json(postedObj, JsonRequestBehavior.AllowGet);
        }


        

    }
}