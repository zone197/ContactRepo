﻿using Aetna.ProviderContracts.DataContracts;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using NABWebsite.DTO;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABResources;
namespace NABWebsite.Models
{
    public class PageViewModel
    {
        private List<State> listState = new List<State>();
        public List<State> ListState { get { return listState; } }
        public SortingPagingInfo SortingPagingInfo { get; set; }
        [Required(ErrorMessageResourceType = typeof(Resources),
              ErrorMessageResourceName = "lblSelectOneNetworkType", ErrorMessage = null)]
        //[Required(ErrorMessage="Select one network type before clicking Start Now")]
        public string RadioButtonSelected { get; set; }
        //[System.Web.Mvc.Remote("IsOtherClientNetworkValid", "Validation", ErrorMessage = "Not a valid Client")]
        [RegularExpression(@"^[0-9a-zA-Z''-'\s]{1,40}$", ErrorMessageResourceType = typeof(Resources),
              ErrorMessageResourceName = "lblSpecialCharsNotAllowed", ErrorMessage = null)]
        //[RegularExpression(@"^[0-9a-zA-Z''-'\s]{1,40}$", ErrorMessage = "special characters are not allowed.")]
        public string OtherClientNetwork { get; set; }
        public Collection<NetworkTypes> NetworkTypeList { get; set; }
        public Collection<ProviderTypes> ProviderTypeList { get; set; }
        public string SelectedSort { get; set; }
        
        public UserCurrentLocation UserCurrentLocation { get; set; }
        [Display(Name = "I agree to")]
        public bool TermsAndCondition { get; set; }
        public List<DisclaimerSectionEntity> TermsOfUse { get; set; }
        public SearchRequestEntity SearchRequest { get; set; }
        public HeaderInfo ClientLoginInfo { get; set; }
      
    }
   
    //public class ProviderMoreDetailsViewModel
    //{
    //   // public ProviderDetails ProviderSearchResultMoreDetails { get; set; }
    //    public UserEmailAddress UserEmailAddress { get; set; }

    //    public string ActiveTab { get; set; }
    //}

    public class UserEmailAddress
    {
        [EmailAddress]
        [Display(Name = "Email Address1")]
        public string EmailAddress1 { get; set; }
    }
   
}