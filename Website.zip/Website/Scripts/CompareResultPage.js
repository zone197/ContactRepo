﻿$(document).ready(function () {
    $(window).keydown(function (event) {
        if (event.keyCode == 13) {
            event.preventDefault();
            return false;
        }
    });
    $("#emailConfirmation").empty();
    $("#emailId").keyup(function () {
        $("#emailConfirmation").empty();
    })
});
// remove a provider from the compare list
function RemoveProviders(ProviderTypeId, ProviderTypeName, ProviderNum) {
    try {
        var forgeryId = $("#forgeryToken").val();
        var ProviderType = new Object();
        var compareProvider = new Object();
        ProviderType.ProviderTypeID = ProviderTypeId;
        ProviderType.ProviderTypeName = ProviderTypeName;
        compareProvider.ProviderType = ProviderType;
        compareProvider.ProviderNumber = ProviderNum;
        $.ajax({
            type: 'POST',
            url: '/LocateProvider/ManageComparedProviders',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ compareProvider: compareProvider }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                $("#providerSelected").remove();
                window.location.href = '/LocateProvider/CompareResult/';
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                ////debugger;
            }
        });

    }
    catch (ex) {

    }
}
// remove a provider from the compare list
function RemoveProvidersEventHandler(event, ProviderTypeId, ProviderTypeName, ProviderNum) {
    if (event.which === 13) {
        //event.stopPropagation;
        return RemoveProviders(ProviderTypeId, ProviderTypeName, ProviderNum);
    }
    return true;
}

//try
// remove a provider from the compare list
function RemoveProvidersTable(ProviderTypeId, ProviderTypeName, ProviderNum, colToRemove) {
    try {
        var forgeryId = $("#forgeryToken").val();
        var ProviderType = new Object();
        var compareProvider = new Object();
        ProviderType.ProviderTypeID = ProviderTypeId;
        ProviderType.ProviderTypeName = ProviderTypeName;
        compareProvider.ProviderType = ProviderType;
        compareProvider.ProviderNumber = ProviderNum;
        $.ajax({
            type: 'POST',
            url: '/LocateProvider/ManageComparedProviders',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ compareProvider: compareProvider }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                if (colToRemove == 1) $(".compareColumn1").remove();
                else if (colToRemove == 2) $(".compareColumn2").remove();
                else if (colToRemove == 3) $(".compareColumn3").remove();
                window.location.href = '/LocateProvider/CompareResult/';
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                ////debugger;
            }
        });

    }
    catch (ex) {

    }
}
// remove a provider from the compare list
function RemoveProvidersEventHandlerTable(event, ProviderTypeId, ProviderTypeName, ProviderNum, colToRemove) {
    if (event.which === 13) {
        //event.stopPropagation;
        return RemoveProvidersTable(ProviderTypeId, ProviderTypeName, ProviderNum, colToRemove);
    }
    return true;
}

function GetResources(key) {
    var forgeryId = $("#forgeryToken").val();
    var returnValue;
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/GetResources',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        async: false,
        data: JSON.stringify({ key: key }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            ////debugger;
            returnValue = result;

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
    ////debugger;
    return returnValue;
}

function ValidateCaptchaCompare(event, CaptchaVerify, Visibility) {
    //debugger
    try {
        if (Visibility == 'invisible') {
            if (CaptchaVerify == "false")
                SendComparisonDetails(true)
            else
            {
                event.preventDefault();
                grecaptcha.reset();
                grecaptcha.execute();
            }
        }
        else {          
                SendComparisonDetails("");
        }
    }
    catch (ex) {

    }
}

//sending the comparison details of the providers to the user
//without captcha validation
function SendComparisonDetails(captchaResponse) {
    var forgeryId = $("#forgeryToken").val();
    //var providerCount = Count;
    var providerCount = $('#hdnListDataforCompare').val();
    var form = $('#FormSendCompareDetails');
    $.validator.unobtrusive.parse(form);
    form.validate();
    if (form.valid()) {
        var email = $("#emailId").val();
        //var captchaResponse = $("#g-recaptcha-response").val();
        //if (CaptchaVerify == "false")
        //    captchaResponse = "true";
        if (captchaResponse) {
            if (email) {
                $.ajax({
                    type: 'POST',
                    url: '/LocateProvider/EmailComparisonLocateProvider',
                    contentType: "application/json; charset=utf-8",
                    datatype: 'json',
                    data: JSON.stringify({ email: email, providerCount: providerCount, captcha: captchaResponse }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    success: function (result) {
                        //debugger
                        if (result == true) {
                            //var emailSentSuccessfully = GetResources("lblEmailSuccessFul");
                            //$("#emailConfirmation").html(emailSentSuccessfully);
                            $('#success_message_Compare').slideDown({ opacity: "show" }, "slow")
                            setTimeout(function () {
                                $('#success_message_Compare').fadeOut(1500);
                            }, 5000);
                            $("#emailId").val("");
                            grecaptcha.reset();
                        }
                        else if (result == false) {
                            var errorEmailNotSent = GetResources("lblEmailNotSent");
                            $("#emailConfirmation").html(errorEmailNotSent);
                            $("#emailId").val("");
                            grecaptcha.reset();
                        }
                        else if (result == "sessionTimeOut") {
                            window.location.href = '/LocateProvider/SelectNetworkType/';
                        }
                        else {
                            var errorCaptchaValidation = GetResources("lblErrorCaptchaValidation");
                            $("#emailConfirmation").html(errorCaptchaValidation);
                            $("#emailId").val("");
                            grecaptcha.reset();
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        //debugger
                        grecaptcha.reset();
                    }
                });
            }
            else {
                var errorPleaseEnteremail = GetResources("lblErrorEnterEmail");
                $("#emailConfirmation").html(errorPleaseEnteremail);
            }
            var compareProvider = new Object();


        }
        else {
            //var errorPleaseFillCaptcha = GetResources("lblPleaseFillCaptchaErrorMessage");
            //$("#emailConfirmation").html(errorPleaseFillCaptcha);
            $('#error_message').slideDown({ opacity: "show" }, "slow")
            setTimeout(function () {
                $('#error_message').fadeOut(1500);
            }, 5000);
        }

    }
    else {
        $("#emailId").focus();
    }
}



