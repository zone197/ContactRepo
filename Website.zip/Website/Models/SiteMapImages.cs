﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NABWebsite.Models
{
    public class SiteMapImages
    {
        public string BookOpenSiteImage { get; set; }
        public string BookCloseSiteImage { get; set; }
        public string FileSiteImage { get; set; }
        public string TreeSiteImage { get; set; }
        public string TreeLineImage { get; set; }

    }
}