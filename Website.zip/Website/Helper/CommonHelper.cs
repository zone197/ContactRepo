﻿using Aetna.ProviderContracts.DataContracts;
using CofinityEncryption;
using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Models.LocateProvider;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security.AntiXss;
using Utilities;

namespace NABWebsite.Helper
{
    public class CommonHelper
    {
        string relayUserName = HttpContext.Current.Session["RelayUserName"].ToString();
        string relayPrd = HttpContext.Current.Session["RelayPassWord"].ToString();
        string applicationName = ConfigurationManager.AppSettings["ApplicationName"];
        int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
        /// <summary>
        /// Validate search request
        /// </summary>
        /// <param name="searchRequestEntity"></param>
        /// <returns></returns>
        public bool Validate(SearchRequestEntity searchRequestEntity)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, Validate Method with Params searchRequestEntity: " + searchRequestEntity); 

                if (searchRequestEntity != null)
                {
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.ProviderType.ProviderTypeId))
                    {
                        if (!ValidationHelper.IsValidContent(searchRequestEntity.ProviderType.ProviderTypeId.ToString()))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                            return false;
                        }
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                        return false;
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.ProviderType.ProviderTypeName))
                    {
                        if (!ValidationHelper.IsValidContent(searchRequestEntity.ProviderType.ProviderTypeName))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                            return false;
                        }
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                        return false;
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.NetworkType.NetworkId))
                    {
                        if (!ValidationHelper.IsValidContent(searchRequestEntity.NetworkType.NetworkId))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                            return false;
                        }
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                        return false;
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.NetworkType.NetworkName))
                    {
                        if (!ValidationHelper.IsValidContent(searchRequestEntity.NetworkType.NetworkName))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                            return false;
                        }
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                        return false;
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.ClientSpecificCode))
                    {
                        if (!ValidationHelper.IsValidContent(searchRequestEntity.ClientSpecificCode))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                            return false;
                        }
                    }
                    if ((string.IsNullOrEmpty(searchRequestEntity.ZipCode) || !string.IsNullOrEmpty(searchRequestEntity.ZipCode) && string.IsNullOrEmpty(searchRequestEntity.Radius)) &&
                            (string.IsNullOrEmpty(searchRequestEntity.State)))
                    {
                        traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                        return false;
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.ZipCode))
                    {
                        if (!ValidationHelper.IsValidContent(searchRequestEntity.ZipCode))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                            return false;
                        }
                        if (!ValidationHelper.IsEmpty(searchRequestEntity.Radius))
                        {
                            if (!ValidationHelper.IsValidContent(searchRequestEntity.Radius))
                            {
                                traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                                return false;
                            }
                        }
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.State))
                    {
                        if (!ValidationHelper.IsValidContent(searchRequestEntity.State))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                            return false;
                        }
                        if (searchRequestEntity.CityCodes != null)
                        {
                            if (searchRequestEntity.CityCodes.Count > 0)
                            {
                                foreach (var item in searchRequestEntity.CityCodes)
                                {
                                    if (!ValidationHelper.IsEmpty(item))
                                    {
                                        if (!ValidationHelper.IsValidCityCountyContent(item))
                                        {
                                            traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                                            return false;
                                        }
                                    }

                                    else
                                    {
                                        traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                                        return false;
                                    }
                                }
                            }
                        }
                        if (searchRequestEntity.CountyCodes != null)
                        {
                            if (searchRequestEntity.CountyCodes.Count > 0)
                            {
                                foreach (var item in searchRequestEntity.CountyCodes)
                                {
                                    if (!ValidationHelper.IsEmpty(item))
                                    {
                                        if (!ValidationHelper.IsValidCityCountyContent(item))
                                        {
                                            traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                                            return false;
                                        }
                                    }

                                    else
                                    {
                                        traceLog.AppendLine(" & End: CommonHelper, Validate Method");
                                        return false;
                                    }

                                }
                            }
                        }

                    }


                    if (!ValidationHelper.IsEmpty(searchRequestEntity.SpecialtyCodes))
                    {
                        foreach (var item in searchRequestEntity.SpecialtyCodes)
                        {
                            if (!ValidateSpecialtyCode(item.SpecialtyCode))
                            {
                                return false;
                            }
                        }

                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.ProviderName))
                    {
                        if (!ValidationHelper.IsValidContentName(searchRequestEntity.ProviderName))
                        {
                            return false;
                        }
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.Tin))
                    {
                        if (!ValidationHelper.IsValidTin(searchRequestEntity.Tin))
                        {
                            return false;
                        }
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.AcceptingNewPatients))
                    {
                        if (!ValidationHelper.IsValidContent(searchRequestEntity.AcceptingNewPatients))
                        {
                            return false;
                        }
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.Gender))
                    {
                        if (!ValidationHelper.IsValidContent(searchRequestEntity.Gender))
                        {
                            return false;
                        }
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.LastIndexForRecordDisplay))
                    {
                        if (!ValidationHelper.IsNumber(searchRequestEntity.LastIndexForRecordDisplay.ToString()))
                        {
                            return false;
                        }
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.LastIndexForRecordDisplay))
                    {
                        if (!ValidationHelper.IsNumber(searchRequestEntity.StartIndexForRecordDisplay.ToString()))
                        {
                            return false;
                        }
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.SpokenLanguages))
                    {
                        foreach (var item in searchRequestEntity.SpokenLanguages)
                        {
                            if (!ValidationHelper.IsEmpty(item))
                            {
                                if (!ValidationHelper.IsValidContent(item))
                                {
                                    return false;
                                }
                            }

                        }
                    }
                }
                else
                {
                    return false;
                }

                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Added to generate secure random number
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <returns></returns>
        public static int GetSecureRandom(int min = 0, int max = int.MaxValue)
        {
            StringBuilder traceLog = new StringBuilder();
            traceLog.AppendLine("Start: CommonHelper, GetSecureRandom Method "); 
            if (max <= min)
                throw new ArgumentOutOfRangeException("max paramater must be greater than min paramater");

            int result = 0;
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                byte[] data = new byte[4];
                rng.GetBytes(data);
                int value = BitConverter.ToInt32(data, 0);
                result = value;

                var proportion = (max - min + 0d) / int.MaxValue;
                result = Math.Abs((int)Math.Round((result * proportion)));
                result += min;
            }
            traceLog.AppendLine(" & End: CommonHelper, GetSecureRandom Method");
            LogManager.WriteTraceLog(traceLog);
            return result;
        }

        /// <summary>
        /// Encode the list of string
        /// Added by NAB-IT on 05-Aprl-2018
        /// </summary>
        /// <param name="EncodedList"></param>
        /// <returns>List<string></string></returns>
        public static List<string> EncodedList(List<string> EncodedList)
        {
            StringBuilder traceLog = new StringBuilder();
            traceLog.AppendLine("Start: CommonHelper, EncodedList Method with Param EncodedList: " + EncodedList); 
            List<string> EncodedListCode = new List<string>();

            foreach (var item in EncodedList)
            {
                EncodedListCode.Add(item != null ? AntiXssEncoder.HtmlEncode(item, false) : item);
            }
            traceLog.AppendLine(" & End: CommonHelper, EncodedList Method");
            LogManager.WriteTraceLog(traceLog);
            return EncodedListCode;
        } 

        /// <summary>
        /// validate specialty
        /// </summary>
        /// <param name="specialtyCode"></param>
        /// <returns></returns>
        protected static bool ValidateSpecialtyCode(string specialtyCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, ValidateSpecialtyCode Method with Param EncodedList: " + specialtyCode); 
                if (!string.IsNullOrEmpty(specialtyCode))
                {
                    //    if (!ValidationHelper.IsAlphanumeric(specialtyCode))
                    //{
                    //        return false;
                    //    }
                    if (!ValidationHelper.IsValidContent(specialtyCode))
                    {
                        traceLog.AppendLine(" & End: CommonHelper, ValidateSpecialtyCode Method");
                        return false;
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: CommonHelper, ValidateSpecialtyCode Method");
                        return true;
                    }

                }
                else
                {
                    traceLog.AppendLine(" & End: CommonHelper, ValidateSpecialtyCode Method");
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog); 
            }

        }

        /// <summary>
        /// validate compare list object
        /// </summary>
        /// <param name="compareProviderList"></param>
        /// <returns></returns>
        public static bool ValidateCompareList(IEnumerable<CompareProvider> compareProviderList)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, ValidateCompareList Method with Param compareProviderList: " + compareProviderList); 
                if (compareProviderList != null)
                {
                    List<CompareProvider> comparedProviders = compareProviderList.ToList();

                    foreach (var item in comparedProviders)
                    {
                        if (!ValidationHelper.IsEmpty(item.ProviderType.ProviderTypeId))
                        {
                            if (!ValidationHelper.IsValidContent(item.ProviderType.ProviderTypeId.ToString()))
                            {
                                traceLog.AppendLine(" & End: CommonHelper, ValidateCompareList Method");
                                return false;
                            }
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateCompareList Method");
                            return false;
                        }

                        if (!ValidationHelper.IsEmpty(item.ProviderNumber))
                        {
                            if (!ValidationHelper.IsValidContent(item.ProviderNumber))
                            {
                                traceLog.AppendLine(" & End: CommonHelper, ValidateCompareList Method");
                                return false;
                            }
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateCompareList Method");
                            return false;
                        }

                        if (!ValidationHelper.IsEmpty(item.TaxId))
                        {
                            if (!ValidationHelper.IsValidContent(item.TaxId))
                            {
                                traceLog.AppendLine(" & End: CommonHelper, ValidateCompareList Method");
                                return false;
                            }
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateCompareList Method");
                            return false;
                        }
                        if (!ValidationHelper.IsEmpty(item.LocationId))
                        {
                            if (!ValidationHelper.IsValidContent(item.LocationId))
                            {
                                traceLog.AppendLine(" & End: CommonHelper, ValidateCompareList Method");
                                return false;
                            }
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateCompareList Method");
                            return false;
                        }


                    } 
                    traceLog.AppendLine(" & End: CommonHelper, ValidateCompareList Method");
                    return true;
                }
                else
                {
                    traceLog.AppendLine(" & End: CommonHelper, ValidateCompareList Method");
                    return false;
                }

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            
        }
        /// <summary>
        /// validate provider number
        /// </summary>
        /// <param name="providerNumber"></param>
        /// <returns></returns>
        public static bool ValidateProviderNumber(string providerNumber)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, ValidateProviderNumber Method with Param providerNumber: " + providerNumber); 
                if (providerNumber != null)
                {
                    if (!ValidationHelper.IsEmpty(providerNumber))
                    {
                        if (!ValidationHelper.IsValidContent(providerNumber))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateProviderNumber Method");
                            return false;
                        }
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: CommonHelper, ValidateProviderNumber Method");
                        return false;
                    }
                }
                else
                {
                    traceLog.AppendLine(" & End: CommonHelper, ValidateProviderNumber Method");
                    return false;
                } 
                traceLog.AppendLine(" & End: CommonHelper, ValidateProviderNumber Method");
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// validate invalid contents of a string
        /// </summary>
        /// <param name="genericString"></param>
        /// <returns></returns>
        public static bool ValidateGenericValue(string value)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, ValidateGenericValue Method with Param value: " + value); 
                if (value != null)
                {
                    if (!ValidationHelper.IsEmpty(value))
                    {
                        if (!ValidationHelper.IsValidContent(value))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateGenericValue Method");
                            return false;
                        }
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: CommonHelper, ValidateGenericValue Method");
                        return false;
                    }
                }
                else
                {
                    traceLog.AppendLine(" & End: CommonHelper, ValidateGenericValue Method");
                    return false;
                } 
                traceLog.AppendLine(" & End: CommonHelper, ValidateGenericValue Method");
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// validate tagged provider object
        /// </summary>
        /// <param name="taggedList"></param>
        /// <returns></returns>
        public static bool ValidateTaggedProviderList(IEnumerable<string> taggedList)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, ValidateTaggedProviderList Method with Param taggedList: " + taggedList); 
                if (taggedList != null)
                {
                    List<string> listTagged = taggedList.ToList();
                    foreach (var item in listTagged)
                    {
                        if (!ValidationHelper.IsEmpty(item))
                        {
                            if (!ValidationHelper.IsValidContent(item))
                            {
                                traceLog.AppendLine(" & End: CommonHelper, ValidateTaggedProviderList Method");
                                return false;
                            }
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateTaggedProviderList Method");
                            return false;
                        }

                    }
                }
                else
                {
                    traceLog.AppendLine(" & End: CommonHelper, ValidateTaggedProviderList Method");
                    return false;
                }
                traceLog.AppendLine(" & End: CommonHelper, ValidateTaggedProviderList Method");
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Validate SearchRequest
        /// </summary>
        /// <param name="searchRequestEntity"></param>
        /// <returns></returns>
        public static bool ValidateSearchRequestForCriteria(SearchRequestEntity searchRequestEntity)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, ValidateSearchRequestForCriteria Method with Param searchRequestEntity: " + searchRequestEntity); 
                if (searchRequestEntity != null)
                {

                    if (searchRequestEntity.ProviderType != null)
                    {
                        if (!ValidationHelper.IsEmpty(searchRequestEntity.ProviderType.ProviderTypeId))
                        {
                            if (!ValidationHelper.IsValidContent(searchRequestEntity.ProviderType.ProviderTypeId.ToString()))
                            {
                                traceLog.AppendLine(" & End: CommonHelper, ValidateSearchRequestForCriteria Method");
                                return false;
                            }
                        }
                        if (!ValidationHelper.IsEmpty(searchRequestEntity.ProviderType.ProviderTypeName))
                        {
                            if (!ValidationHelper.IsValidContent(searchRequestEntity.ProviderType.ProviderTypeName))
                            {
                                traceLog.AppendLine(" & End: CommonHelper, ValidateSearchRequestForCriteria Method");
                                return false;
                            }
                        }
                    }
                    if (searchRequestEntity.NetworkType != null)
                    {
                        if (!ValidationHelper.IsEmpty(searchRequestEntity.NetworkType.NetworkId))
                        {
                            if (!ValidationHelper.IsValidContent(searchRequestEntity.NetworkType.NetworkId))
                            {
                                traceLog.AppendLine(" & End: CommonHelper, ValidateSearchRequestForCriteria Method");
                                return false;
                            }
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateSearchRequestForCriteria Method");
                            return false;
                        }
                        if (!ValidationHelper.IsEmpty(searchRequestEntity.NetworkType.NetworkName))
                        {
                            if (!ValidationHelper.IsValidContent(searchRequestEntity.NetworkType.NetworkName))
                            {
                                traceLog.AppendLine(" & End: CommonHelper, ValidateSearchRequestForCriteria Method");
                                return false;
                            }
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateSearchRequestForCriteria Method");
                            return false;
                        }
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: CommonHelper, ValidateSearchRequestForCriteria Method");
                        return false;
                    }
                    if (!ValidationHelper.IsEmpty(searchRequestEntity.ClientSpecificCode))
                    {
                        if (!ValidationHelper.IsValidContent(searchRequestEntity.ClientSpecificCode))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateSearchRequestForCriteria Method");
                            return false;
                        }
                    }
                }
                traceLog.AppendLine(" & End: CommonHelper, ValidateSearchRequestForCriteria Method");
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Validate Disclaimers Id
        /// </summary>
        /// <param name="disclaimersId"></param>
        /// <returns></returns>
        public static bool ValidDisclaimersId(string disclaimersId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, ValidDisclaimersId Method with Param disclaimersId: " + disclaimersId); 
                if (disclaimersId != null)
                {
                    if (!ValidationHelper.IsEmpty(disclaimersId))
                    {
                        if (!ValidationHelper.IsValidContent(disclaimersId))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidDisclaimersId Method");
                            return false;
                        }
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: CommonHelper, ValidDisclaimersId Method");
                        return false;
                    }
                }
                traceLog.AppendLine(" & End: CommonHelper, ValidDisclaimersId Method");
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Validate Email ids
        /// </summary>
        /// <param name="emailId"></param>
        /// <returns></returns>
        public static bool ValidateEmail(string emailId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, ValidateEmail Method with Param emailId: " + emailId); 
                if (!string.IsNullOrEmpty(emailId))
                {
                    if (!ValidationHelper.IsEmail(emailId))
                    {
                        traceLog.AppendLine(" & End: CommonHelper, ValidateEmail Method");
                        return false;
                    }

                }
                traceLog.AppendLine(" & End: CommonHelper, ValidateEmail Method");
                return true;
            }
            catch(Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }        
        /// <summary>
        /// Validate Model EmailAddresses
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static bool ValidateModelEmailAddresses(CreateDirectoryViewModel model)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, ValidateModelEmailAddresses Method with Param model: " + model); 
                if (model != null)
                {
                    if (!string.IsNullOrEmpty(model.EmailId1))
                    {
                        if (!ValidationHelper.IsEmail(model.EmailId1))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateModelEmailAddresses Method");
                            return false;
                        }
                    }
                    if (!string.IsNullOrEmpty(model.EmailId2))
                    {
                        if (!ValidationHelper.IsEmail(model.EmailId2))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateModelEmailAddresses Method");
                            return false;
                        }
                    }
                    if (!string.IsNullOrEmpty(model.EmailId3))
                    {
                        if (!ValidationHelper.IsEmail(model.EmailId3))
                        {
                            traceLog.AppendLine(" & End: CommonHelper, ValidateModelEmailAddresses Method");
                            return false;
                        }
                    }
                }
                else
                {
                    traceLog.AppendLine(" & End: CommonHelper, ValidateModelEmailAddresses Method");
                    return false;

                }
                traceLog.AppendLine(" & End: CommonHelper, ValidateModelEmailAddresses Method");
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// generate header request object
        /// </summary>
        /// <param name="culture"></param>
        /// <param name="sourceId"></param>
        /// <returns></returns>
        public RequestHeader GetRequestHeader(string culture, int sourceId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: CommonHelper, GetRequestHeader Method with Param culture: " + culture + " and with Param sourceId: " + sourceId); 
                ManageContent contentManager = new ManageContent();
                RequestHeader requestHeader = new RequestHeader();
                requestHeader.SourceID = sourceId;
                requestHeader.Application = applicationName;
                //get networkproduct id based on source system id               
                List<ProductLine> productLineList = new List<ProductLine>();
                productLineList = contentManager.GetNetworkProductLine(requestHeader).ToList();
                if (productLineList!=null && productLineList.Count>0)
                {
                    requestHeader.NetworkProductId = new List<int>() { productLineList.FirstOrDefault().NetworkProductId };
                }
                //for locate provider audit
                requestHeader.FunctionId = "Locate Provider";
                requestHeader.SessionId = HttpContext.Current.Session.SessionID;
                UserDetails user = (UserDetails)HttpContext.Current.Session[Constants.UserDetails];
                if (user != null)
                {
                    if (!string.IsNullOrEmpty(user.UserId))
                    {
                        requestHeader.UserId = user.UserId;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole))
                    {
                        requestHeader.Role = user.SelectedRole;
                    }
                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    requestHeader.Site = ConfigurationManager.AppSettings[Constants.Site];
                }
                if (!string.IsNullOrEmpty(culture))
                {
                    requestHeader.Culture = culture;
                }
                requestHeader.Password = relayPrd;
                requestHeader.UserName = relayUserName;
                traceLog.AppendLine(" & End: CommonHelper, GetRequestHeader Method");
                return requestHeader;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        public static void WriteToFileAsync(string filePath, string message)
        {
            StringBuilder traceLog = new StringBuilder();
            if (string.IsNullOrEmpty(filePath))
                throw new ArgumentNullException("filePath");

            if (string.IsNullOrEmpty(message))
                throw new ArgumentNullException("text");

            byte[] buffer = Encoding.Unicode.GetBytes(message);
            Int32 offset = 0;
            Int32 sizeOfBuffer = 400096;
            FileStream fileStream = null;

            try
            {
                traceLog.AppendLine("Start: CommonHelper, WriteToFileAsync Method with Param filePath: " + filePath + " and with Param message: " + message); 
                fileStream = new FileStream(filePath, FileMode.Append, FileAccess.Write,
                FileShare.None, bufferSize: sizeOfBuffer, useAsync: true);
                fileStream.Write(buffer, offset, buffer.Length);
                traceLog.AppendLine(" & End: CommonHelper, WriteToFileAsync Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                //Console.WriteLine(ex.Message.ToString());
            }
            finally
            {
                if (fileStream != null)
                    fileStream.Dispose();
                LogManager.WriteTraceLog(traceLog);
            }
        }

        public bool IsMobileDevice()
        {
            StringBuilder traceLog = new StringBuilder();
            //GETS THE CURRENT USER CONTEXT
            HttpContext context = HttpContext.Current;

            //string u = context.Request.ServerVariables["HTTP_USER_AGENT"];
            //Regex b = new Regex(@"(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino", RegexOptions.IgnoreCase | RegexOptions.Multiline);
            //Regex v = new Regex(@"1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-", RegexOptions.IgnoreCase | RegexOptions.Multiline);
            //if ((b.IsMatch(u) || v.IsMatch(u.Substring(0, 4))))
            //{
            //    return true;
            //}


            //FIRST TRY BUILT IN ASP.NT CHECK
            traceLog.AppendLine("Start: CommonHelper, IsMobileDevice Method");
            if (context.Request.Browser.IsMobileDevice && context.Request.Browser.MobileDeviceModel != "IPad")
            {
                traceLog.AppendLine(" & End: CommonHelper, IsMobileDevice Method");
                return true;
            }
            //THEN TRY CHECKING FOR THE HTTP_X_WAP_PROFILE HEADER
            if (context.Request.ServerVariables["HTTP_X_WAP_PROFILE"] != null)
            {
                traceLog.AppendLine(" & End: CommonHelper, IsMobileDevice Method");
                return true;
            }
            //THEN TRY CHECKING THAT HTTP_ACCEPT EXISTS AND CONTAINS WAP
            if (context.Request.ServerVariables["HTTP_ACCEPT"] != null &&
                context.Request.ServerVariables["HTTP_ACCEPT"].ToLower().Contains("wap"))
            {
                traceLog.AppendLine(" & End: CommonHelper, IsMobileDevice Method");
                return true;
            }
            //AND FINALLY CHECK THE HTTP_USER_AGENT 
            //HEADER VARIABLE FOR ANY ONE OF THE FOLLOWING
            if (context.Request.ServerVariables["HTTP_USER_AGENT"] != null)
            {
                //Create a list of all mobile types
                string[] mobiles = ConfigurationManager.AppSettings["MobileDevices"].Split(',');


                //Loop through each item in the list created above 
                //and check if the header contains that text
                foreach (string s in mobiles)
                {
                    if (context.Request.ServerVariables["HTTP_USER_AGENT"].
                                                        ToLower().Contains(s.ToLower()))
                    {
                        traceLog.AppendLine(" & End: CommonHelper, IsMobileDevice Method");
                        return true;
                    }
                }
            }
            traceLog.AppendLine(" & End: CommonHelper, IsMobileDevice Method");
            LogManager.WriteTraceLog(traceLog);
            return false;
        }

        public static void LogErrorInTextFile(Exception actualException)
        {
            StringBuilder traceLog = new StringBuilder();
            string appName = ConfigurationManager.AppSettings["ErrorLogAppName"];
            appName = appName ?? AppDomain.CurrentDomain.BaseDirectory + "\\FH";

            string todayDate = DateTime.Now.ToString("MMddyyyy");
            string fileName = String.Concat(appName, "_", todayDate);
            fileName = String.Concat(fileName, "_ErrLog", ".txt");

            string errorLoggingDir = ConfigurationManager.AppSettings["ErrorLoggingDirectory"];
            errorLoggingDir = errorLoggingDir ?? AppDomain.CurrentDomain.BaseDirectory + "\\ApplicationLogs";

            string filePath = Path.Combine(errorLoggingDir, appName, fileName);
            string directoryName = Path.GetDirectoryName(filePath);

            if (!Directory.Exists(directoryName))
                Directory.CreateDirectory(directoryName);

            //FileStream fileStream;
            if (!File.Exists(filePath))
            { //Fixed on 09 Oct -Improper Resource Shutdown or Release
                using (FileStream fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write))
                {
                    using (TextWriter tw = new StreamWriter(fileStream))
                    {
                        try   //Added on 19-Jul-18 to fix Improper Exception Handling
                        {
                            StringBuilder sb = new StringBuilder();
                            traceLog.AppendLine("Start: CommonHelper, LogErrorInTextFile Method with Param actualException: " + actualException);
                            sb.AppendLine("--------------------------------------------------------------------------");
                            sb.AppendLine(string.Empty);
                            sb.AppendLine(String.Format("[appName={0},todayDate={1},fileName={2},errorLoggingDir={3},filePath={4}]", appName, todayDate, fileName, errorLoggingDir, filePath));
                            sb.AppendLine(string.Empty);
                            sb.AppendLine("Timestamp: " + DateTime.Now);
                            sb.AppendLine("Timezone: " + TimeZone.CurrentTimeZone.StandardName);
                            sb.AppendLine(string.Empty);
                            sb.AppendLine("Details of Exception thrown by " + appName + " service:");

                            if (actualException.Data != null && actualException.Data["Method"] != null)
                                sb.AppendLine("Method: " + actualException.Data["Method"]);

                            Type type = actualException.GetType();
                            System.Reflection.PropertyInfo[] properties = type.GetProperties();
                            foreach (System.Reflection.PropertyInfo property in properties)
                                sb.AppendLine(property.Name + ": " + property.GetValue(actualException, null));
                            sb.AppendLine(string.Empty);

                            tw.Write(sb);
                            //Fixed on 20 Sept -Improper Resource Shutdown or Release
                            // tw.Dispose();
                            tw.Close();
                            traceLog.AppendLine(" & End: CommonHelper, LogErrorInTextFile Method");
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                        finally
                        {
                            if (fileStream != null)
                            {
                                fileStream.Close();
                                fileStream.Dispose();
                            }
                            LogManager.WriteTraceLog(traceLog);
                        }
                    }
                }
            }
            else
            {  
                //Fixed on 09 Oct -Improper Resource Shutdown or Release
                using (FileStream fileStream = new FileStream(filePath, FileMode.Append, FileAccess.Write))
                {
                    using (TextWriter tw = new StreamWriter(fileStream))
                    {
                        try   //Added on 19-Jul-18 to fix Improper Exception Handling
                        {
                            StringBuilder sb = new StringBuilder();
                            traceLog.AppendLine("Start: CommonHelper, LogErrorInTextFile Method with Param actualException: " + actualException);
                            sb.AppendLine("--------------------------------------------------------------------------");
                            sb.AppendLine(string.Empty);
                            sb.AppendLine(String.Format("[appName={0},todayDate={1},fileName={2},errorLoggingDir={3},filePath={4}]", appName, todayDate, fileName, errorLoggingDir, filePath));
                            sb.AppendLine(string.Empty);
                            sb.AppendLine("Timestamp: " + DateTime.Now);
                            sb.AppendLine("Timezone: " + TimeZone.CurrentTimeZone.StandardName);
                            sb.AppendLine(string.Empty);
                            sb.AppendLine("Details of Exception thrown by " + appName + " service:");

                            if (actualException.Data != null && actualException.Data["Method"] != null)
                                sb.AppendLine("Method: " + actualException.Data["Method"]);

                            Type type = actualException.GetType();
                            System.Reflection.PropertyInfo[] properties = type.GetProperties();
                            foreach (System.Reflection.PropertyInfo property in properties)
                                sb.AppendLine(property.Name + ": " + property.GetValue(actualException, null));
                            sb.AppendLine(string.Empty);

                            tw.Write(sb);
                            //Fixed on 20 Sept -Improper Resource Shutdown or Release
                            // tw.Dispose();
                            tw.Close();
                            traceLog.AppendLine(" & End: CommonHelper, LogErrorInTextFile Method");
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                        finally
                        {
                            if (fileStream != null)
                            {
                                fileStream.Close();
                                fileStream.Dispose();
                            }
                            LogManager.WriteTraceLog(traceLog);
                        }
                    }
                }
            }

           
                
        }

        public static void WriteToFileAsync( string message)
        {
            StringBuilder traceLog = new StringBuilder();
            //if logging is not enabled then close the thread immediately
            if (ConfigurationManager.AppSettings["LoggingEnabled"].ToString().Equals("TRUE", StringComparison.OrdinalIgnoreCase))
            {
                byte[] buffer = Encoding.Unicode.GetBytes(message);
                Int32 offset = 0;
                Int32 sizeOfBuffer = 4096;
                FileStream fileStream = null;
                var filPath = ConfigurationManager.AppSettings["LoggingPath"]!=null?ConfigurationManager.AppSettings["LoggingPath"].ToString() :@"C:\";
                try
                {
                    traceLog.AppendLine("Start: CommonHelper, WriteToFileAsync Method with Param message: " + message); 
                    fileStream = new FileStream(filPath+"E1Log.txt", FileMode.Append, FileAccess.Write,
                    FileShare.None, bufferSize: sizeOfBuffer, useAsync: true);
                    fileStream.WriteAsync(buffer, offset, buffer.Length);
                    traceLog.AppendLine(" & End: CommonHelper, WriteToFileAsync Method");
                }
                catch (Exception ex)
                {
                    LogManager.WriteErrorLog(ex);
                }
                finally
                {
                    if (fileStream != null)
                        fileStream.Dispose();
                    LogManager.WriteTraceLog(traceLog);
                }
            }
        }

    }
}
