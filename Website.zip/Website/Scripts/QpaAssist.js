﻿$(document).ready(function () {


    $(".datePicker").attr("autocomplete", "off");
    $('.datePicker').datepicker();

    $(".NegotiationDatePicker").attr("autocomplete", "off");
    $('.NegotiationDatePicker').datepicker({
        maxDate: new Date()
    });

    $("#claimIdNumber").focus();

    $("#claimIdNumber").tooltip({ position: { my: "left+15 center", at: "right center" } });

    $(document).on("keyup", "#claimIdNumber", function (e) {
        $("#claimError").hide();
        $("#claimIDError").empty();
        var k = e.which;
        if (k == 13) {
            ClaimSearch();
            e.preventDefault();
        }
    });

    $(document).on("change", "#NegotiationDate", function (e) {
        $("#DateError").hide();
    });
    $(document).on("input", ".fileDescOther", function (e) {
        $('#errorfileDesc').hide();
    });
    $(document).on("input", ".fileDesc", function (e) {
        $('#errorfileDesc').hide();
    });
    $("#SearchClaimBtn").on('click', function (e) {
        ClaimSearch();
        e.preventDefault();
    });
});

$(document).on("click", ".icon-red", function () {
    var $row = $(this).closest('.form-group');
    $row.find('[name="RequiredAttachments"]');
    $(this).closest('.form-group').find('[name="RequiredAttachments"]').val(null);
    $('#errorfileDesc').hide();
    var fileFound = false;
    //remove file Desc
    var parentDiv = $(this).parents('div.descGroup');
    var nextDiv = parentDiv.next('div.descText');
    nextDiv.children('div.descDiv').find("input").val("");



    $(".extraFiles").each(function () {
        if (this.files.length > 0) {
            fileFound = true;
        }
    });


    if ($(".otherFile")[0].files.length !== 0 || fileFound == true) {
        var totalFile = 0;
        if (($(".otherFile")[0].files.length !== 0)) {
            totalFile = $(".otherFile")[0].files[0].size;
        }
        if (fileFound == true) {
            $(".extraFiles").each(function () {
                for (var i = 0; i < this.files.length; i++) {
                    totalFile += this.files[i].size;
                }
            });
        }
        if (totalFile > 5242880) {
            $('#errorFileSize').show();
            $(".deleteFileExtra").show();
            $('.deleteFile').show();
        }
        else {
            $('#errorFileSize').hide();
        }
    }
    else {
        $('#errorFileSize').hide();
    }

});

$(document).on("change", ".otherFile", function (e) {
    $('#errorFileSize').hide();
    $('.deleteFile').hide();
    $(".deleteFileExtra").hide();
    $('#errorFile').hide();
    $('#errorfileDesc').hide();
    $(this).removeClass('.field-validation-error');
    if ($('#errorId').is(":visible")) {
        $('#errorId').hide();
    }
    if (($(".otherFile")[0].files.length == 0)) {
        $('.fileDescOther').val("");
    }
    if (($(".otherFile")[0].files.length !== 0)) {
        if ($(".otherFile")[0].files[0].size > 5242880) {
            $('#errorFileSize').show();
            $('.deleteFile').show();
        }
    }


    var extraFiles = $('.extraFiles').filter(function () {
        return this.extraFiles === '';
    });

    var fileFound = false;
    $(".extraFiles").each(function () {
        if (this.files.length > 0) {
            fileFound = true;
        }
    });

    if (extraFiles.length == 0 || fileFound == true) {
        var extrafilesize = 0;
        if (($(".otherFile")[0].files.length !== 0)) {
            extrafilesize = $(".otherFile")[0].files[0].size;
        }
        $(".extraFiles").each(function () {
            for (var i = 0; i < this.files.length; i++) {
                extrafilesize += this.files[i].size;
            }

        });
        if (extrafilesize > 5242880) {
            $('#errorFileSize').show();
            $(".deleteFileExtra").show();
            $('.deleteFile').show();
        }

    }

});

$(document).on("change", ".extraFiles", function (e) {
    $('#errorFileSize').hide();
    $(".deleteFileExtra").hide();
    $('.deleteFile').hide();
    $('#errorFile').hide();
    $('#errorfileDesc').hide();
    if ($('#errorId').is(":visible")) {
        $('#errorId').hide();
    }

    if (this.files.length == 0) {
        var parentDiv = $(this).parents('div.descGroup');
        var nextDiv = parentDiv.next('div.descText');
        nextDiv.children('div.descDiv').find("input.fileDesc").val("");
    }
    var fileFound = false;
    $(".extraFiles").each(function () {
        if (this.files.length > 0) {
            fileFound = true;
        }
    });
    if ($(".extraFiles")[0].files.length > 0 || fileFound == true) {
        var totalFile = 0;
        if (($(".otherFile")[0].files.length !== 0)) {
            totalFile = $(".otherFile")[0].files[0].size;
        }
        $(".extraFiles").each(function () {
            for (var i = 0; i < this.files.length; i++) {
                totalFile += this.files[i].size;
            }
        });

        if (totalFile > 5242880) {
            $('#errorFileSize').show();
            $(".deleteFileExtra").show();
            $('.deleteFile').show();
        }
    }

});
$(document).on("click", "#searchNewClaim", function () {
    window.location.href = "/QPAAssist/ClaimSearch";
});

$(document).on('click', "#QpaSubmitBtn", function (e) {
    $('#errorFile').hide();
    $("#AmountError").hide();
    $("#CheckError").hide();
    $('#errorFileSize').hide();
    $("#DateError").hide();
    $('#errorfileDesc').hide();
    if ($('#errorId').is(":visible")) {
        $('#errorId').hide();
    }
    var QpaAmount = $("#ClaimQPA").val().trim();
    var AmountPaid = $("#AmountPaid").val().trim();
    var extraComment = $("#AdditionalNotes").val().trim();
    var CheckDate = $("#CheckDate").val();
    var NegDate = $("#NegotiationDate").val();
    var errorFound = false;
    if (QpaAmount && AmountPaid) {
        if (QpaAmount != AmountPaid) {

            if (!extraComment) {
                $("#AmountError").show();
                errorFound = true;
                e.preventDefault();
            }
        }
    }
    if (CheckDate) {
        var newCheckDate = new Date(CheckDate);
        var today = new Date();
        var dateDiff = Math.abs(today.getTime() - newCheckDate.getTime());

        var totalDays = dateDiff / (24 * 60 * 60 * 1000);
        if (totalDays > 40) {
            $("#CheckError").show();
            errorFound = true;
            e.preventDefault();
        }
    }
    if (NegDate) {
        var userDate = new Date(NegDate);
        if (CheckDate) {
            var chkDate = new Date(CheckDate);
            var timeDiff = Math.abs(chkDate.getTime() - userDate.getTime());
                var dayDiff = timeDiff / (24 * 60 * 60 * 1000);

                if (dayDiff > 40) {
                    $("#DateError").show();
                    errorFound = true;
                    e.preventDefault();
                }
        }
        
    }
    var fileFound = false;
    $(".extraFiles").each(function () {
        if (this.files.length > 0) {
            fileFound = true;
        }
    });
    var fileDescErr = false;
    $(".fileDesc").each(function () {
        if (!$(this).val()) {
            fileDescErr = true;
        }
    });

    if ($(".otherFile")[0].files.length !== 0 || fileFound == true) {
        if (($(".otherFile")[0].files.length !== 0)) {
            var fileSize = $(".otherFile")[0].files[0].size;
        }
        else {
            var fileSize = -1;
        }

        var totalFileSize = 0;
        if (fileFound == true) {
            $(".extraFiles").each(function () {
                for (var i = 0; i < this.files.length; i++) {
                    totalFileSize += this.files[i].size;
                }
            });
            if (fileSize != -1) {
                totalFileSize += fileSize;
            }

        }

        if (fileSize === 0) {
            $('#errorFile').show();
            errorFound = true;
            e.preventDefault();
        }
        else if (fileSize > 5242880 || totalFileSize > 5242880) {
            $('#errorFileSize').show();
            errorFound = true;
            e.preventDefault();
        }
        if (($(".otherFile")[0].files.length !== 0) || fileFound == true) {
            var last;
            if (($(".otherFile")[0].files.length !== 0) && fileFound == false) {
                if (!$(".fileDescOther").val()) {
                    $('#errorfileDesc').show();
                    errorFound = true;
                    e.preventDefault();
                }
            }
            if (fileFound == true) {
                $(".extraFiles").each(function () {
                    var len = this.files.length;
                    last = this.files[len - 1].length;
                });
                if (last != 0) {
                    if (fileDescErr == true) {
                        $('#errorfileDesc').show();
                        errorFound = true;
                        e.preventDefault();
                    }
                }
            }

        }

    }
    if (errorFound === false) {
        $("#CheckError").hide();
        $('#errorFile').hide();
        $("#AmountError").hide();
        $("#DateError").hide();
        $("#QpaSubmitForm").submit();
    }
});

function ClaimSearch() {
    $("#claimError").hide();
    $("#claimIDError").empty();
    var claimNumber = $('#claimIdNumber').val().trim();

    var regx = new RegExp('^[a-zA-Z0-9_]*$');

    if (claimNumber) {
        if (regx.test(claimNumber)) {
            ValidateClaimSearch(claimNumber);
        } else {
            $("#claimError").show();
            $("#claimIdNumber").focus();
            $("#claimIDError").html("Please enter Valid First Health Claim Identification Number");
        }
    }
    else {
        $("#claimError").show();
        $("#claimIdNumber").focus();
        $("#claimIDError").html("Please enter First Health Claim Identification Number");

    }
}

function ValidateClaimSearch(claimId) {
    var errormsg = "Claim number not found. Please call customer service at 800-226- 5116 to continue ";
    var forgeryId = $("#forgeryToken").val();
    $.ajax({
        type: 'POST',
        url: '/QPAAssist/GetClaim',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        async: false,
        data: JSON.stringify({ claimId: claimId }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            if (result == 0) {
                $("#claimError").show();
                $("#claimIDError").html(errormsg);
                $("#claimIdNumber").focus();
            } else {
                $("#claimError").hide();
                $("#claimIDError").empty();
                window.location.href = "/QPAAssist/Index";
            }

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $("#claimError").show();
            $("#claimIDError").html(errormsg);
            $("#claimIdNumber").focus();
        }
    });
}



function clearForm() {
    var forgeryId = $("#forgeryToken").val();
    $.ajax({
        type: "POST",
        url: '/QPAAssist/RefreshClaim',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            window.location.href = "/QPAAssist/Index";
        }
    });
}
