﻿using Aetna.ProviderContracts.DataContracts;
using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Models;
using NABWebsite.Models.LocateProvider;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.IO;
using System.Linq;
using NABResources;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Globalization;
using NABWebsite.Helper;
using System.ServiceModel;
using System.Net;
using System.Web.Security.AntiXss;
using Utilities;
namespace NABWebsite.Controllers
{
    //[NoCache]
    public class LocateProviderMobileController : BaseController
    {
        // GET: LocateProviderMobile
        int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
        //StringBuilder traceLog = new StringBuilder();
        #region ActionResult
        /// <summary>
        /// Network selection page
        /// </summary>
        /// <returns>Index View</returns>
        [NoCache]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, Index Method");

                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, Index Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                Session["ClientLoginName"] = null;
                ManageContent objBll = new ManageContent();
                PageViewModel PageViewModel = new Models.PageViewModel();
                Collection<NetworkTypes> networkType = new Collection<NetworkTypes>();
                string culture = ReturnCultureInfo();
                RequestHeader requestForNetworkTypes = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                requestForNetworkTypes.Functionality = AppSettingHelper.GetAppSettingValue(VariableConstant.TermsOfUseKey);
                networkType = objBll.GetNetworkTypesLocateProviderMobile(requestForNetworkTypes);
                PageViewModel.NetworkTypeList = networkType;


                PageViewModel.TermsOfUse = new ManageContent().GetTermsOfUse(requestForNetworkTypes).ToList();

                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                PageViewModel.SearchRequest = searchRequest;
                SetActiveControllerToSession(ApplicationConstants.LocateProviderMobileController, ApplicationConstants.IndexActionMobile);
                traceLog.AppendLine(" & End: LocateProviderMobileController, Index Method");
                return View(PageViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// landing page for custom urls
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult CustomPageMobile()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, CustomPageMobile Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, CustomPageMobile Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                string id = string.Empty;
                if (Session[SessionConstant.CookiePlanCode] != null)
                {
                    id = Convert.ToString(Session[SessionConstant.CookiePlanCode]);
                    PageViewModel pageViewModel = new Models.PageViewModel();
                    ManageContent contentManager = new ManageContent();
                    string culture = ReturnCultureInfo();
                    RequestHeader requestForNetworkType = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                    //ClientLoginInfo clientCode = new ClientLoginInfo();
                    //clientCode = contentManager.GetClientCodeFromPlanCode(id, requestForNetworkType);
                    HeaderInfo locateProviderHeaderInfo = contentManager.GetHeaderInfoForLocateProvider(id, requestForNetworkType);
                    Collection<NetworkTypes> networkType = new Collection<NetworkTypes>();
                    networkType = contentManager.GetNetworkTypesLocateProviderMobile(requestForNetworkType);
                    pageViewModel.NetworkTypeList = networkType;
                    SearchRequestEntity searchRequest = new SearchRequestEntity();
                    if (locateProviderHeaderInfo != null && !string.IsNullOrWhiteSpace(locateProviderHeaderInfo.ClientLoginCode))
                    {
                        pageViewModel.OtherClientNetwork = locateProviderHeaderInfo.ClientLoginCode;
                        pageViewModel.RadioButtonSelected = ApplicationConstants.RadioOtherClientNetwork;
                    }
                    else
                    {
                        throw new System.Exception(ApplicationConstants.Error);
                    }
                    requestForNetworkType.Functionality = AppSettingHelper.GetAppSettingValue(VariableConstant.TermsOfUseKey);
                    pageViewModel.TermsOfUse = contentManager.GetTermsOfUse(requestForNetworkType).ToList();
                    pageViewModel.ClientLoginInfo = locateProviderHeaderInfo;
                    Session["ClientLoginName"] = locateProviderHeaderInfo.ClientLoginName;
                    traceLog.AppendLine(" & End: LocateProviderMobileController, CustomPageMobile Method");
                    return View(pageViewModel);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, CustomPageMobile Method");
                    return RedirectToAction("Index", "Home", null);
                    //this.Response.Redirect("~/AccessDenied.html", true);
                }
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Provider Type Selection Page
        /// </summary>
        /// <returns>ProviderTypeSelection view</returns>
        [NoCache]
        public ActionResult ProviderTypeSelection()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, ProviderTypeSelection Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, ProviderTypeSelection Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    traceLog.AppendLine(" & End: LocateProviderMobileController, ProviderTypeSelection Method");
                    return RedirectToAction(ApplicationConstants.IndexActionMobile, ApplicationConstants.LocateProviderMobileController, null);
                }

                if (!CommonHelper.ValidateSearchRequestForCriteria(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }
                ManageContent contentManager = new ManageContent();
                LocateProviderSearchViewModel objLocateProviderSearchViewModel = new LocateProviderSearchViewModel();
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));
                objLocateProviderSearchViewModel.ListProviderType = contentManager.GetProviderTypesLocateProvider(request).ToList();
                objLocateProviderSearchViewModel.SearchNetworkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                objLocateProviderSearchViewModel.SearchRequest = searchRequest;
                SetActiveControllerToSession(ApplicationConstants.LocateProviderMobileController, ApplicationConstants.ProviderTypeSelection);
                traceLog.AppendLine(" & End: LocateProviderMobileController, ProviderTypeSelection Method");
                return View(objLocateProviderSearchViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Customer Type Selection Page
        /// </summary>
        /// <returns>CustomerTypeSelection view</returns>
        [NoCache]
        public ActionResult CustomerTypeSelection()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, CustomerTypeSelection Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, CustomerTypeSelection Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    traceLog.AppendLine(" & End: LocateProviderMobileController, CustomerTypeSelection Method");
                    return RedirectToAction(ApplicationConstants.IndexActionMobile, ApplicationConstants.LocateProviderMobileController, null);
                }
                LocateProviderSearchViewModel objLocateProviderSearchViewModel = new LocateProviderSearchViewModel();
                objLocateProviderSearchViewModel.SearchRequest = searchRequest;
                SetActiveControllerToSession(ApplicationConstants.LocateProviderMobileController, ApplicationConstants.CustomerTypeSelection);
                traceLog.AppendLine(" & End: LocateProviderMobileController, CustomerTypeSelection Method");
                return View(objLocateProviderSearchViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Search criteria page
        /// </summary>
        /// <returns>Search criteria page view</returns>
        [NoCache]
        public ActionResult SearchIndex()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, SearchIndex Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, SearchIndex Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    traceLog.AppendLine(" & End: LocateProviderMobileController, SearchIndex Method");
                    return RedirectToAction(ApplicationConstants.IndexActionMobile, ApplicationConstants.LocateProviderMobileController, null);
                }

                if (!CommonHelper.ValidateSearchRequestForCriteria(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }
                ManageContent contentManager = new ManageContent();
                LocateProviderSearchViewModel objLocateProviderSearchViewModel = new LocateProviderSearchViewModel();
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));

                objLocateProviderSearchViewModel.ListState = GetStatesOTMC(searchRequest.NetworkType.NetworkId, searchRequest.CustomerType); ;

                objLocateProviderSearchViewModel.ListCondition = contentManager.GetConditionsLocateProvider(request).ToList();
                if (searchRequest.ProviderType != null)
                {
                    objLocateProviderSearchViewModel.ListSpecialty = contentManager.GetSpecialtiesLocateProvider(searchRequest.ProviderType.ProviderTypeId.ToString(), request).ToList();
                    objLocateProviderSearchViewModel.ListFocus = contentManager.GetFocusLocateProvider(searchRequest.ProviderType.ProviderTypeId.ToString(), request).ToList();
                }
                objLocateProviderSearchViewModel.ProviderType = searchRequest.ProviderType;
                objLocateProviderSearchViewModel.SearchNetworkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                objLocateProviderSearchViewModel.AcceptingNewpatients = searchRequest.AcceptingNewPatients;
                if (searchRequest.State != null)
                {
                    objLocateProviderSearchViewModel.CountyList = contentManager.GetCountiesByStateLocateProvider(searchRequest.State, request).ToList();
                    objLocateProviderSearchViewModel.CityList = contentManager.GetCitiesByStateLocateProvider(searchRequest.State, request).ToList();
                }
                objLocateProviderSearchViewModel.SearchRequest = searchRequest;
                objLocateProviderSearchViewModel.ZipLookupSiteUrl = AppSettingHelper.GetAppSettingValue(ApplicationConstants.ZipLookupSiteUrl);
                SetActiveControllerToSession(ApplicationConstants.LocateProviderMobileController, ApplicationConstants.SearchIndex);
                traceLog.AppendLine(" & End: LocateProviderMobileController, SearchIndex Method");
                return View(ApplicationConstants.ProviderSearchCriteria, objLocateProviderSearchViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Provider Search Result
        /// </summary>
        /// <returns>ProviderSearchResult view</returns>
        [NoCache]
        public ActionResult ProviderSearchResult()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, ProviderSearchResult Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, ProviderSearchResult Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    traceLog.AppendLine(" & End: LocateProviderMobileController, ProviderSearchResult Method");
                    return RedirectToAction(ApplicationConstants.IndexActionMobile, ApplicationConstants.LocateProviderMobileController, null);
                }
                if (!new CommonHelper().Validate(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }
                ManageContent contentManager = new ManageContent();

                LocateProviderSearchResultViewModel searchResultViewModel = new LocateProviderSearchResultViewModel();

                SortingPagingInfo info = new SortingPagingInfo();
                if (Session[SessionConstant.SortingPagingInfo] != null)
                {
                    info = Session[SessionConstant.SortingPagingInfo] as SortingPagingInfo;
                    searchRequest.StartIndexForRecordDisplay = info.CurrentPageIndex + 1;
                    searchRequest.LastIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    searchRequest.SortColumn = info.SortField;
                    searchRequest.SortOrder = info.SortDirection;

                }
                else
                {
                    searchRequest.StartIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.StartIndexForRecordDisplay);
                    searchRequest.LastIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    if (searchRequest.ZipCode != null)
                    {
                        searchRequest.SortColumn = AppSettingHelper.GetAppSettingValue(VariableConstant.SortColumn);
                        info.SortField = AppSettingHelper.GetAppSettingValue(VariableConstant.SortField);
                    }
                    else
                    {
                        searchRequest.SortColumn = System.Configuration.ConfigurationManager.AppSettings["FirstName"];
                        info.SortField = System.Configuration.ConfigurationManager.AppSettings["FirstName"];
                    }
                    searchRequest.SortOrder = AppSettingHelper.GetAppSettingValue(VariableConstant.SortOrder);
                    info.SortDirection = AppSettingHelper.GetAppSettingValue(VariableConstant.SortDirection);
                    info.PageSize = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    info.CurrentPageIndex = AppSettingHelper.ReturnValue(VariableConstant.CurrentPageIndex);
                }
                int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, networkId);
                searchResultViewModel.SearchRequest = searchRequest;
                SearchResult searchResult = contentManager.GetCriteriaBasedProviders(searchRequest, request);
                searchResultViewModel.SearchResult = searchResult;
                info.PageCount = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(searchResultViewModel.SearchResult.ProviderMatchCount) / Convert.ToDouble(VariableConstant.TwentyProviders)));
                info.TotalRecords = searchResultViewModel.SearchResult.ProviderMatchCount;

                ViewBag.SortingPagingInfo = info;
                //Fetch Client Specific network name
                if (!string.IsNullOrEmpty(searchRequest.ClientSpecificCode))
                {
                    var clientNetwork = GetNetworkNameFromCode(searchRequest.ClientSpecificCode);
                    searchRequest.ClientSpecificNetwork = clientNetwork;
                }
                SetActiveControllerToSession(ApplicationConstants.LocateProviderMobileController, ApplicationConstants.ProviderSearchResult);
                traceLog.AppendLine(" & End: LocateProviderMobileController, ProviderSearchResult Method");
                return View(searchResultViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Provider More Details
        /// </summary>
        /// <param name="providerNumber"></param>
        /// <param name="activeTab"></param>
        /// <returns>ProviderMoreDetails view</returns>
        [NoCache]
        public ActionResult ProviderMoreDetails()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, ProviderMoreDetails Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, ProviderMoreDetails Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                string providerNumber = string.Empty;
                string activeTab = string.Empty;

                if (Session[SessionConstant.ProviderNumber] != null && Session[SessionConstant.ActiveTab] != null && Session[SessionConstant.SearchRequest] != null)
                {
                    providerNumber = Session[SessionConstant.ProviderNumber].ToString();
                    activeTab = Session[SessionConstant.ActiveTab].ToString();
                }
                else
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    traceLog.AppendLine(" & End: LocateProviderMobileController, ProviderMoreDetails Method");
                    return RedirectToAction(ApplicationConstants.IndexActionMobile, ApplicationConstants.LocateProviderMobileController, null);
                }
                if (!new CommonHelper().Validate(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }


                ManageContent contentManager = new ManageContent();

                char[] splitchar = { ApplicationConstants.SplitString };
                string[] providerNumberIndex = providerNumber.Split(splitchar);

                ProviderDetailedInfoViewModel ObjProviderDetailedInfoViewModel = new ProviderDetailedInfoViewModel();
                Aetna.ProviderContracts.DataContracts.Provider detailedProviderInfo = new Aetna.ProviderContracts.DataContracts.Provider();
                if (providerNumberIndex.Count() == 3)
                {

                    //string locationid = CommonHelper.Decrypt(WebUtility.UrlDecode(providerNumberIndex[1].Replace("-", "/")));
                    //string taxid = CommonHelper.Decrypt(WebUtility.UrlDecode(providerNumberIndex[2]));

                    string locationid = providerNumberIndex[1].Replace("-", "/");
                    string taxid = WebUtility.UrlDecode(providerNumberIndex[2]);
                    int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                    string culture = ReturnCultureInfo();
                    RequestHeader requestForProviderDetails = new CommonHelper().GetRequestHeader(culture, networkId);
                    detailedProviderInfo = contentManager.GetProviderDetails(providerNumberIndex[0], locationid, taxid, searchRequest.ZipCode, requestForProviderDetails, searchRequest.ClientSpecificCode);
                }
                else
                {
                    throw new ArgumentNullException(AppSettingHelper.GetAppSettingValue(VariableConstant.ProviderNumber));
                }
                //List<Hours> hoursList = new List<Hours>();
                //int start = 0;
                //int end = 3;
                //string days = Resources.Weekdays;
                //string[] weekDays = days.Split(',');
                //if (detailedProviderInfo != null)
                //{
                //    if (detailedProviderInfo.OfficeHours.Count() > 0)
                //    {
                //        for (int i = 0; i < 7; i++)
                //        {
                //            Hours hours = new Hours();
                //            hours.Day = weekDays[i];
                //            if (!string.IsNullOrEmpty(detailedProviderInfo.OfficeHours[start].OfficeTimeSlot))
                //            {
                //                if (detailedProviderInfo.OfficeHours[start].OfficeTimeSlot.Trim().Length > 0 && detailedProviderInfo.OfficeHours[end].OfficeTimeSlot.Length > 0)
                //                {
                //                    hours.Time = detailedProviderInfo.OfficeHours[start].OfficeTimeSlot + VariableConstant.StartTimeInAM + " - " + detailedProviderInfo.OfficeHours[end].OfficeTimeSlot + VariableConstant.EndTimeInPM;
                //                }
                //                else
                //                {
                //                    if (detailedProviderInfo.OfficeHours[start].OfficeTimeSlot.Trim().Length > 0)
                //                    {
                //                        hours.Time = detailedProviderInfo.OfficeHours[start].OfficeTimeSlot + VariableConstant.StartTimeInAM;
                //                    }
                //                    else
                //                    {
                //                        hours.Time = detailedProviderInfo.OfficeHours[end].OfficeTimeSlot + VariableConstant.EndTimeInPM;
                //                    }
                //                }

                //            }
                //            hoursList.Add(hours);
                //            start = start + 4;
                //            end = end + 4;
                //        }
                //    }
                //}

                List<Hours> hoursList = new List<Hours>();
                int startAm = 0;
                int endAm = 1;
                int startPm = 2;
                int endPm = 3;
                string days = Resources.Weekdays;
                string[] weekDays = days.Split(',');
                if (detailedProviderInfo != null)
                {
                    if (detailedProviderInfo.OfficeHours.Count() > 0)
                    {
                        for (int i = 0; i < 7; i++)
                        {
                            Hours hours = new Hours();
                            hours.Day = weekDays[i];

                            if (detailedProviderInfo.OfficeHours[startAm].OfficeTimeSlot.Trim().Length > 0 && detailedProviderInfo.OfficeHours[endAm].OfficeTimeSlot.Trim().Length > 0)
                            {
                                hours.Time = "<td>" + detailedProviderInfo.OfficeHours[startAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + " - " + detailedProviderInfo.OfficeHours[endAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + "</td>";
                            }
                            else
                            {
                                if (detailedProviderInfo.OfficeHours[startAm].OfficeTimeSlot.Trim().Length > 0)
                                {
                                    hours.Time = "<td>" + detailedProviderInfo.OfficeHours[startAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + "</td>" + "<td></td>";
                                }
                                else if (detailedProviderInfo.OfficeHours[endAm].OfficeTimeSlot.Trim().Length > 0)
                                {
                                    hours.Time = "<td></td>" + detailedProviderInfo.OfficeHours[endAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + "</td>";
                                }
                            }




                            if (detailedProviderInfo.OfficeHours[startPm].OfficeTimeSlot.Trim().Length > 0 && detailedProviderInfo.OfficeHours[endPm].OfficeTimeSlot.Trim().Length > 0)
                            {
                                hours.TimePM = "<td>" + detailedProviderInfo.OfficeHours[startPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + " - " + detailedProviderInfo.OfficeHours[endPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td>";
                            }
                            else
                            {
                                if (detailedProviderInfo.OfficeHours[startPm].OfficeTimeSlot.Trim().Length > 0)
                                {
                                    hours.TimePM = "<td>" + detailedProviderInfo.OfficeHours[startPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td>" + "<td></td>";
                                }
                                else if (detailedProviderInfo.OfficeHours[endPm].OfficeTimeSlot.Trim().Length > 0)
                                {
                                    hours.TimePM = "<td></td>" + "<td>" + detailedProviderInfo.OfficeHours[endPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td>";
                                }
                            }



                            hoursList.Add(hours);
                            startAm = startAm + 4;
                            endAm = endAm + 4;
                            startPm = startPm + 4;
                            endPm = endPm + 4;
                        }
                    }
                }
                ObjProviderDetailedInfoViewModel.ProviderDetailedInfo = detailedProviderInfo;
                ObjProviderDetailedInfoViewModel.ProviderDetailedInfo.OtherOfficeLocations = GetPrimaryAddress.GetAddressForProvider(detailedProviderInfo, providerNumberIndex);
                ObjProviderDetailedInfoViewModel.SearchRequest = searchRequest;
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                UserPhoneNumber UserPhoneNumber = new UserPhoneNumber();
                UserPhoneNumber.ListCarrier = contentManager.GetCarrierInfoLocateProvider(request).ToList();
                ObjProviderDetailedInfoViewModel.UserPhoneNumber = UserPhoneNumber;
                ObjProviderDetailedInfoViewModel.Hours = hoursList;
                ViewBag.ActiveTab = activeTab;
                SetActiveControllerToSession(ApplicationConstants.LocateProviderMobileController, ApplicationConstants.ProviderMoreDetails);
                ObjProviderDetailedInfoViewModel.PublicKey = AppSettingHelper.GetAppSettingValue(VariableConstant.PublicKey);
                ObjProviderDetailedInfoViewModel.GoogleRecaptchaAPIAddressSingle = AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleAPIAddress);

                if (detailedProviderInfo.OtherOfficeLocations != null)
                {
                    if ((searchRequest.ProviderType.ProviderTypeName.ToUpper() == "HOSPITAL") && (detailedProviderInfo.OtherOfficeLocations[0].State.ToUpper() == "GA" || detailedProviderInfo.OtherOfficeLocations[0].State.ToUpper() == "TX"))
                    {
                        if (detailedProviderInfo.OtherOfficeLocations[0].State.ToUpper() == "TX")
                        {
                            if (detailedProviderInfo.GATXSpecialty != null || detailedProviderInfo.GATXSpecialty.Count() != 0)
                            {
                                foreach (var i in detailedProviderInfo.GATXSpecialty)
                                {
                                    //get Associate Provider
                                    var facilityProvider = GetTXFacilityProviders(i.SpecilityID,providerNumber);
                                    i.AssociateProvider = facilityProvider.Count() == 0 ? false : true;
                                }
                            }
                        }

                        ObjProviderDetailedInfoViewModel.GATXSpecialty = detailedProviderInfo.GATXSpecialty;
                        Session[SessionConstant.HospitalName] = detailedProviderInfo.PracticeName;
                    }
                }


                traceLog.AppendLine(" & End: LocateProviderMobileController, ProviderMoreDetails Method");
                return View(ObjProviderDetailedInfoViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        private List<TXFacilityProvider> GetTXFacilityProviders(string specialityId, string providerInfo)
        {


            char[] splitchar = { ApplicationConstants.SplitString };
            string[] providerNumberIndex = providerInfo.Split(splitchar);
            var providerNum = providerNumberIndex[0];
            var locationId = providerNumberIndex[1].Replace("-", "/");

            ManageContent contentManager = new ManageContent();
            SearchRequestEntity searchRequest = new SearchRequestEntity();
            var facilityProvider = new List<TXFacilityProvider>();
            searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
            if (!string.IsNullOrEmpty(specialityId))
            {
                var specId = Convert.ToInt32(specialityId);
                int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, networkId);

                facilityProvider = contentManager.GetFacilityProvider(request, providerNum, locationId, specId).ToList();
            }
            return facilityProvider;
        }


        /// <summary>
        /// provider more information partial view
        /// </summary>
        /// <param name="providerNumber"></param>
        /// <returns>provider more information partial view</returns>
        [NoCache]
        public ActionResult GetDetailedProviderInfo(string providerNumber)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, GetDetailedProviderInfo Method with Params: " + providerNumber);
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, GetDetailedProviderInfo Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                Session[SessionConstant.ExpandedProviders] = null;
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    traceLog.AppendLine(" & End: LocateProviderMobileController, GetDetailedProviderInfo Method");
                    return RedirectToAction(ApplicationConstants.IndexActionMobile, ApplicationConstants.LocateProviderMobileController, null);
                }
                if (!new CommonHelper().Validate(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }
                if (providerNumber == null)
                    throw new ArgumentNullException(VariableConstant.ProviderNumber);
                char[] splitchar = { ApplicationConstants.SplitString };
                string[] providerNumberIndex = providerNumber.Split(splitchar);
                ManageContent contentManager = new ManageContent();
                ProviderDetailedInfoViewModel ObjProviderDetailedInfoViewModel = new ProviderDetailedInfoViewModel();
                int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                string culture = ReturnCultureInfo();
                RequestHeader requestForProviderDetails = new CommonHelper().GetRequestHeader(culture, networkId);
                Aetna.ProviderContracts.DataContracts.Provider detailedProviderInfo = contentManager.GetProviderDetails(providerNumberIndex[0], providerNumberIndex[1].Replace("-", "/"), providerNumberIndex[2], searchRequest.ZipCode, requestForProviderDetails, searchRequest.ClientSpecificCode);
                ObjProviderDetailedInfoViewModel.ProviderDetailedInfo = detailedProviderInfo;
                traceLog.AppendLine(" & End: LocateProviderMobileController, GetDetailedProviderInfo Method");
                return PartialView("~/Views/Shared/LocateProvider/_ProviderDetailedInfo.cshtml", ObjProviderDetailedInfoViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// State disclaimers 
        /// </summary>
        /// <returns>State disclaimers view</returns>
        //[CustomOutputCacheAttribute("CacheDuration1800_All")]
        public ActionResult StateDisclaimers()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, StateDisclaimers Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, StateDisclaimers Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                LayoutModel layoutmodel = new LayoutModel();
                ManageContent omngcontent = new ManageContent();
                layoutmodel.StateDisclaimerList = omngcontent.GetStateDisclaimers(request).ToList();
                SetActiveControllerToSession(ApplicationConstants.LocateProviderMobileController, ApplicationConstants.StateDisclaimersAction);
                traceLog.AppendLine(" & End: LocateProviderMobileController, StateDisclaimers Method");
                return View(layoutmodel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [NoCache]
        public ActionResult FirstHealthRoleMobile()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderControllerMobile, FirstHealthRoleMobile Method");
                traceLog.AppendLine(" & End: LocateProviderControllerMobile, FirstHealthRoleMobile Method");
                return View("~/Views/LocateProviderMobile/FirstHealthRoleMobile.cshtml");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion


        #region Session
        /// <summary>
        /// Save Sorting Paging Information To Session 
        /// </summary>
        /// <param name="sortingPagingInfo"></param>
        [AjaxValidateAntiForgeryToken]
        public void SaveSortingPagingInfoToSession(SortingPagingInfo sortingPagingInfo)
        {
            Session[SessionConstant.SortingPagingInfo] = sortingPagingInfo;
        }
        /// <summary>
        /// Save provider more details 
        /// </summary>
        /// <param name="sortingPagingInfo"></param>
        [AjaxValidateAntiForgeryToken]
        public void SaveProviderNumberToSession(string providerNumber, string activeTab)
        {
            Session[SessionConstant.ProviderNumber] = providerNumber;
            Session[SessionConstant.ActiveTab] = activeTab;

        }
        /// <summary>
        /// Save Search Request To Session
        /// </summary>
        /// <param name="search"></param>
        [AjaxValidateAntiForgeryToken]
        public void SaveSearchRequestToSession(SearchRequestEntity search)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, SaveSearchRequestToSession Method with Param search: " + search);
                if (search != null)
                {
                    //remove empty items from city list as third party dropdown-Semantic UI
                    //send blank values when no option selected
                    if (search.CityCodes != null)
                    {
                        if (search.CityCodes.Count == 1 && string.IsNullOrEmpty(search.CityCodes[0]))
                        {
                            search.CityCodes = null;
                        }
                    }
                    //remove empty items from county list as third party dropdown-Semantic UI
                    //send blank values when no option selected
                    if (search.CountyCodes != null)
                    {
                        if (search.CountyCodes.Count == 1 && string.IsNullOrEmpty(search.CountyCodes[0]))
                        {
                            search.CountyCodes = null;
                        }
                    }
                    //remove empty items from language list as third party dropdown-Semantic UI
                    //send blank values when no option selected
                    if (search.SpokenLanguages != null)
                    {
                        if (search.SpokenLanguages.Count == 1 && string.IsNullOrEmpty(search.SpokenLanguages[0]))
                        {
                            search.SpokenLanguages = null;
                        }
                    }
                    //saving customer type to session
                    if ((UserDetails)Session[Constants.UserDetails] != null && ((UserDetails)Session[Constants.UserDetails]).SelectedRole != null)
                    {
                        if (ConfigurationManager.AppSettings[Constants.PowerSTEPPSunset] == Constants.TrueId && (search.NetworkType.NetworkId == "3" && (search.NetworkType.NetworkName == "cofinity")))
                        {
                            search.CustomerType = "Payer";
                        }
                        else
                        {
                            search.CustomerType = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                        }
                    }
                    if (!string.IsNullOrEmpty(search.ZipCode) && !string.IsNullOrEmpty(search.State))
                    {
                        search.State = null;
                        search.CountyCodes = null;
                        search.CityCodes = null;

                    }
                }
                Session[SessionConstant.SortingPagingInfo] = null;
                Session[SessionConstant.SearchRequest] = search;
                traceLog.AppendLine(" & End: LocateProviderMobileController, SaveSearchRequestToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion


        #region HelperMethods


        /// <summary>
        /// set values of current controller and action
        /// </summary>
        /// <param name="controller"></param>
        /// <param name="actionMethod"></param>
        void SetActiveControllerToSession(string controller, string actionMethod)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, SetActiveControllerToSession Method with Param controller: " + controller + ", with Param actionmethod: " + actionMethod);

                if (Session[SessionConstant.CurrentController] != null && Session[SessionConstant.CurrentAction] != null)
                {
                    if (!(Session[SessionConstant.CurrentController].ToString().Equals(controller) && Session[SessionConstant.CurrentAction].ToString().Equals(actionMethod)))
                    {
                        Session[SessionConstant.CurrentController] = controller;
                        Session[SessionConstant.CurrentAction] = actionMethod;
                    }
                }
                else
                {
                    Session[SessionConstant.CurrentController] = controller;
                    Session[SessionConstant.CurrentAction] = actionMethod;
                }
                traceLog.AppendLine(" & End: LocateProviderMobileController, SetActiveControllerToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetches resource values
        /// </summary>
        /// <param name="key"></param>
        /// <returns>resource values</returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetResources(string key)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, GetResources Method with Param key: " + key);
                switch (key)
                {
                    case VariableConstant.LabelMoreOptions:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblMoreOptions);

                    case VariableConstant.LabelLessOptions:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblLessOptions);

                    case VariableConstant.LabelSelectOneNetworkType:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblSelectOneNetworkType);
                    case VariableConstant.LabelNetworkSelectionRequired:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblNetworkSelectionRequired);
                    case VariableConstant.LabelEnterValidClientCodeBeforeStartNow:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblEnterValidClientCodeBeforeStartNow);
                    case VariableConstant.LabelClientCodeFieldMandatoryForClientSpecificNetwork:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblClientCodeFieldMandatoryForClientSpecificNetwork);
                    case VariableConstant.LabelInvalidClientSpecificNetworkCode:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblInvalidClientSpecificNetworkCode);
                    case VariableConstant.LabelClientCodeIsNotValid:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblClientCodeIsNotValid);

                    case VariableConstant.LabelErrorEnterNumericValuesInZip:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblErrorMsgEnterNumericValuesInZip);
                    case VariableConstant.LabelErrorMessageValidZip:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblErrorMsgValidZip);
                    case VariableConstant.LabelEnterNumericRadiusErrorMessage:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblEnterNumericRadiusErrorMessage);
                    case VariableConstant.LabelTinNumericErrorMessage:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblTinNumericErrorMessage);
                    case VariableConstant.LabelEnterNumericValuesInTin:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblEnterNumericValuesInTin);
                    case VariableConstant.LabelErrorOptionalCriteria:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblErrorOptionalCriteria);
                    case VariableConstant.LabelErrorOptionalCriteriaSelectZipOrState:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblErrorOptionalCriteriaSelectZipOrState);
                    case VariableConstant.LabelZipOrStateMandatory:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblZipOrStateMandatory);
                    case VariableConstant.LabelErrorSelectZipOrState:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblErrorSelectZipOrState);

                    case VariableConstant.LabelEmailSuccessFull:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblEmailSuccessFul);
                    case VariableConstant.LabelEmailTextSuccessFull:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblEmailTextSuccessFul);
                    case VariableConstant.LabelEmailNotSent:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblEmailNotSent);
                    case VariableConstant.LabelErrorCaptchaValidation:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblErrorCaptchaValidation);
                    case VariableConstant.LabelPleaseFillCaptchaErrorMessage:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblPleaseFillCaptchaErrorMessage);
                    case VariableConstant.LabelProvideValidIdOrPhoneNumber:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblProvideValidIdOrPhoneNumber);
                    case VariableConstant.LabelEnterIdOrPhoneNumber:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblEnterIdOrPhoneNumber);
                    case "MapQuestConsumerKeySecret":
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(AppSettingHelper.GetAppSettingValue("MapQuestConsumerKeySecret"));
                    case "MapQuestConsumerKeyPublic":
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(AppSettingHelper.GetAppSettingValue("MapQuestConsumerKeyPublic"));
                    case "txtEnterCounty":
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.txtEnterCounty);
                    case "txtEnterCity":
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.txtEnterCity);
                    case "txtStateRequired":
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.txtStateRequired);
                    case VariableConstant.LabelErrorEnterNumericValuesInPhysicianPhone:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblEnterValidData);
                    case VariableConstant.LabelErrorEnterAlphanumericOnly:
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                        return Json(Resources.lblSpecialCharsNotAllowed);
                }
                traceLog.AppendLine(" & End: LocateProviderMobileController, GetResources Method");
                return Json("");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Fetches cities based on selected state
        /// Edited By NAB-IT on 4 march 2018 to encode the paramenters
        /// </summary>
        /// <param name="stateCode"></param>
        /// <returns>list of cities</returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public JsonResult GetCitiesByState(string stateCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, GetCitiesByState Method with Param stateCode: " + stateCode);
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                traceLog.AppendLine(" & End: LocateProviderMobileController, GetCitiesByState Method");
                return Json(contentManager.GetCitiesByStateLocateProvider(AntiXssEncoder.HtmlEncode(stateCode, false), request).ToList());
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Fetches cities based on selected state and county
        /// Edited by NAB-IT on 05Apr2018 to encode the input perameters
        /// </summary>
        /// <param name="stateCode"></param>
        /// <param name="county"></param>
        /// <returns>list of cities</returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public JsonResult GetCitiesByStateAndCounty(List<string> stateCode, List<string> county)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                // AntiXssEncoder.HtmlEncode(strStateCode, false);
                // AntiXssEncoder.HtmlEncode(strCounty, false);

                // RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                // ManageContent contentManager = new ManageContent();
                //// return Json(contentManager.GetCitiesByStateAndCountyLocateProvider(CommonHelper.EncodedList(stateCode), CommonHelper.EncodedList(county), request).ToList());

                // return Json(contentManager.GetCitiesByStateAndCountyLocateProvider(strStateCode.Split(',').ToList(), strCounty.Split(',').ToList(), request).ToList());

                traceLog.AppendLine("Start: LocateProviderMobileController, GetCitiesByStateAndCounty Method with Param stateCode: " + stateCode + "with Param county: " + county);
                string strCounties = string.Join(",", county.ToArray());
                strCounties = AntiXssEncoder.HtmlEncode(strCounties, false);
                List<string> listCounty = new List<string>();
                listCounty = strCounties.Split(',').ToList();

                county = listCounty;

                string strStateCode = string.Join(",", stateCode.ToArray());
                strStateCode = AntiXssEncoder.HtmlEncode(strStateCode, false);
                List<string> listState = new List<string>();
                listState = strStateCode.Split(',').ToList();
                stateCode = listState;

                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                traceLog.AppendLine(" & End: LocateProviderMobileController, GetCitiesByStateAndCounty Method");
                return Json(contentManager.GetCitiesByStateAndCountyLocateProvider(stateCode, county, request).ToList());





            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Fetches counties based on selected state
        /// Edited By NAB-IT on 4 march 2018 to encode the paramenters
        /// </summary>
        /// <param name="stateCode"></param>
        /// <returns>list of counties</returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public JsonResult GetCountiesByState(string stateCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, GetCountiesByState Method with Param stateCode: " + stateCode);
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                traceLog.AppendLine(" & End: LocateProviderMobileController, GetCountiesByState Method");
                return Json(contentManager.GetCountiesByStateLocateProvider(AntiXssEncoder.HtmlEncode(stateCode, false), request).ToList());
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// fethces entered client code validity
        /// </summary>
        /// <param name="clientCode"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public bool CheckClientCode(string clientCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, CheckClientCode Method with Param clientCode: " + clientCode);
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                bool check = false;
                ManageContent contentManager = new ManageContent();
                check = contentManager.ValidateClientCode(clientCode, request);
                traceLog.AppendLine(" & End: LocateProviderMobileController, CheckClientCode Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// get autosuggest providers name
        /// </summary>
        /// <param name="clientCode"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public JsonResult GetProviderNameSearchCriteria(SearchRequestEntity searchRequest)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, GetProviderNameSearchCriteria Method with Param searchRequest: " + searchRequest);
                List<PhysicanFacilityName> searchResult = new List<PhysicanFacilityName>();
                ManageContent contentManager = new ManageContent();

                if (searchRequest != null)
                {
                    if (!new CommonHelper().Validate(searchRequest))
                    {
                        throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                    }
                    string culture = ReturnCultureInfo();
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));
                    searchRequest.StartIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.StartIndexForRecordDisplay);
                    searchRequest.LastIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    searchRequest.SortColumn = AppSettingHelper.GetAppSettingValue("NameSuggestionCol");
                    searchRequest.SortOrder = AppSettingHelper.GetAppSettingValue(VariableConstant.SortOrder);
                    searchResult = contentManager.GetAutoSuggestProvidersName(searchRequest, request);
                    traceLog.AppendLine(" & End: LocateProviderMobileController, GetProviderNameSearchCriteria Method");
                    return Json(searchResult, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, GetProviderNameSearchCriteria Method");
                    return null;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// fetched list of zip codes and checkes validity
        /// </summary>
        /// <param name="txtZip"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public bool ZipCodeValues(string txtZip)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, ZipCodeValues Method with Param txtZip: " + txtZip);
                bool zipVal = false;
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                zipVal = contentManager.GetZipCodeValue(request, txtZip);
                traceLog.AppendLine(" & End: LocateProviderMobileController, ZipCodeValues Method");
                return zipVal;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// sends mail of provider details
        /// </summary>
        /// <param name="email"></param>
        /// <param name="phoneNumberCarrier"></param>
        /// <param name="providerNumber"></param>
        /// <param name="captchaResponse"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public JsonResult SendingMailForMobile(string email, string phoneNumberCarrier, string phoneNumber, string providerNumber, string captcha)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, SendingMailForMobile Method with Param email: " + email + ",with Param phoneNumberCarrier: " + phoneNumberCarrier + ",with Param phoneNumber: " + phoneNumber + ",with Param providerNumber: " + providerNumber + ",with Param captcha: " + captcha);
                string smsGateway = string.Empty;
                if (phoneNumberCarrier != null)
                {
                    if (!(string.IsNullOrEmpty(phoneNumber)))
                    {
                        phoneNumber = phoneNumber.Replace("-", "");
                        smsGateway = phoneNumberCarrier.Replace(VariableConstant.CarrierNumber, phoneNumber + VariableConstant.Character);
                    }
                }
                if (providerNumber == null)
                {
                    throw new ArgumentNullException(VariableConstant.ProviderNumber);
                }
                char[] splitchar = { ApplicationConstants.SplitString };
                string[] providerNumberIndex = providerNumber.Split(splitchar);
                Aetna.ProviderContracts.DataContracts.Provider provider = new Aetna.ProviderContracts.DataContracts.Provider();
                if (!CommonHelper.ValidateEmail(email))
                {
                    throw new System.Exception(ExceptionMessageConstant.Email);
                }
                string errorMessage = string.Empty;
                if (!ValidateCaptcha(captcha, out errorMessage))
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, SendingMailForMobile Method");
                    return Json(errorMessage);
                }
                else
                {
                    SearchRequestEntity searchRequest = new SearchRequestEntity();
                    searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                    if (searchRequest == null)
                    {
                        TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                        if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                        {
                            //Fixed Checkmarx issue of XSHM on dated 24-Sep-2018
                            string consonant = "a0b1c2d3e4f5g6h7i8j9klmnopqrstvuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

                            int length2 = CommonHelper.GetSecureRandom(1, 62);
                            this.Response.Redirect("https://" + AppSettingHelper.GetAppSettingValue("CustomHOSTURL") + "?r=" + consonant.Substring(length2, 1));
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: LocateProviderMobileController, SendingMailForMobile Method");
                            return Json("sessionTimeOut");
                        }
                    }
                    if (!new CommonHelper().Validate(searchRequest))
                    {
                        throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                    }
                    bool send = false;
                    string culture = ReturnCultureInfo();

                    string errorLogSenderEmail;

                    if (Session[NABWebsite.Helper.SessionConstant.SearchRequest] != null)
                    {
                        NABWebsite.DTO.SearchRequestEntity searchRequest1 = new NABWebsite.DTO.SearchRequestEntity();

                        searchRequest = Session[NABWebsite.Helper.SessionConstant.SearchRequest] as NABWebsite.DTO.SearchRequestEntity;
                        //var networktype = searchRequest.NetworkType.NetworkName;


                        if (searchRequest.NetworkType.NetworkId == "1")
                        {
                            errorLogSenderEmail = ConfigurationManager.AppSettings["FromCofinityReportInfo"];
                            send = EmailSendHelper.SendMail(provider, searchRequest, Server, email, smsGateway, providerNumberIndex, culture, errorLogSenderEmail);
                            TempData["SendSuccess"] = VariableConstant.Success;
                            traceLog.AppendLine(" & End: LocateProviderMobileController, SendingMailForMobile Method");
                            return Json(send);

                        }
                        else
                        {
                            errorLogSenderEmail = ConfigurationManager.AppSettings["LocateProviderSendFrom"];
                            send = EmailSendHelper.SendMail(provider, searchRequest, Server, email, smsGateway, providerNumberIndex, culture, errorLogSenderEmail);
                            TempData["SendSuccess"] = VariableConstant.Success;
                            traceLog.AppendLine(" & End: LocateProviderMobileController, SendingMailForMobile Method");
                            return Json(send);
                        }
                    }

                    send = EmailSendHelper.SendMail(provider, searchRequest, Server, email, smsGateway, providerNumberIndex, culture, null);
                    traceLog.AppendLine(" & End: LocateProviderMobileController, SendingMailForMobile Method");
                    return Json(send);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }


        /// <summary>
        /// Get provider direction from javascript MapQuest api call
        /// </summary>
        /// <param name="direction"></param>
        /// <param name="emailAddress"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetDirection(List<ProviderDirectionPath> direction, string emailAddress, string carrier, string phoneNumber, string captcha, string providerNumber, string providerNameDegree, string providerAddress)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, GetDirection Method with Param direction: " + direction + ",with Param emailAddress: " + emailAddress + ",with Param carrier: " + carrier + ",with Param phoneNumber: " + phoneNumber + ",with Param captcha: " + captcha + ",with Param providerNumber: " + providerNumber + ",with Param providerNameDegree: " + providerNameDegree + ",with Param providerAddress: " + providerAddress);
                if (providerNumber == null)
                    throw new ArgumentNullException(VariableConstant.ProviderNumber);
                if (direction == null)
                    throw new ArgumentNullException(VariableConstant.Direction);

                if (!string.IsNullOrWhiteSpace(phoneNumber))
                {
                    phoneNumber = phoneNumber.Replace("-", "");
                }

                string smsGateway = string.Empty;
                if (carrier != null)
                {
                    if (!(string.IsNullOrEmpty(phoneNumber)))
                    {
                        smsGateway = carrier.Replace(VariableConstant.CarrierNumber, phoneNumber + VariableConstant.Character);
                        if (!CommonHelper.ValidateEmail(smsGateway))
                        {
                            throw new System.Exception(ExceptionMessageConstant.Email);
                        }
                    }
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                Aetna.ProviderContracts.DataContracts.Provider provider = new Aetna.ProviderContracts.DataContracts.Provider();
                if (!CommonHelper.ValidateEmail(emailAddress))
                {
                    throw new System.Exception(ExceptionMessageConstant.Email);
                }
                char[] splitchar = { ApplicationConstants.SplitString };
                string[] providerNumberIndex = providerNumber.Split(splitchar);
                string errorMessage = string.Empty;
                if (!ValidateCaptcha(captcha, out errorMessage))
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, GetDirection Method");
                    return Json(errorMessage);
                }
                else
                {
                    bool send = false;
                    string culture = ReturnCultureInfo();

                    string errorLogSenderEmail;

                    if (Session[NABWebsite.Helper.SessionConstant.SearchRequest] != null)
                    {
                        NABWebsite.DTO.SearchRequestEntity searchRequest1 = new NABWebsite.DTO.SearchRequestEntity();

                        searchRequest = Session[NABWebsite.Helper.SessionConstant.SearchRequest] as NABWebsite.DTO.SearchRequestEntity;

                        if (searchRequest.NetworkType.NetworkId == "1")
                        {
                            errorLogSenderEmail = ConfigurationManager.AppSettings["FromCofinityReportInfo"];
                            send = EmailSendHelper.ReturnMapDetails(searchRequest, direction, provider, emailAddress, smsGateway, providerNumberIndex, providerNameDegree, providerAddress, culture, errorLogSenderEmail);
                            TempData["SendSuccess"] = VariableConstant.Success;
                            traceLog.AppendLine(" & End: LocateProviderMobileController, GetDirection Method");
                            return Json(send);

                        }
                        else
                        {
                            errorLogSenderEmail = ConfigurationManager.AppSettings["LocateProviderSendFrom"];
                            send = EmailSendHelper.ReturnMapDetails(searchRequest, direction, provider, emailAddress, smsGateway, providerNumberIndex, providerNameDegree, providerAddress, culture, errorLogSenderEmail);
                            TempData["SendSuccess"] = VariableConstant.Success;
                            traceLog.AppendLine(" & End: LocateProviderMobileController, GetDirection Method");
                            return Json(send);
                        }

                    }
                    traceLog.AppendLine(" & End: LocateProviderMobileController, GetDirection Method");
                    return Json(send);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Sending Text Without MapQuest api call
        /// </summary>
        /// <param name="direction"></param>
        /// <param name="emailAddress"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult MapDetailsSendText(string email, string phoneNumberCarrier, string phoneNumber, string captcha, string providerNumber, string providerNameDegree, string providerAddress)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, MapDetailsSendText Method with Param email: " + email + ",with Param phoneNumberCarrier: " + phoneNumberCarrier + ",with Param phoneNumber: " + phoneNumber + ",with Param captcha: " + captcha + ",with Param providerNumber: " + providerNumber + ",with Param providerNameDegree: " + providerNameDegree + ",with Param providerAddress: " + providerAddress);
                if (providerNumber == null)
                {
                    throw new ArgumentNullException(VariableConstant.ProviderNumber);
                }
                if (!string.IsNullOrWhiteSpace(phoneNumber))
                {
                    phoneNumber = phoneNumber.Replace("-", "");
                }
                string smsGateway = string.Empty;
                if (phoneNumberCarrier != null)
                {
                    if (!(string.IsNullOrEmpty(phoneNumber)))
                    {
                        smsGateway = phoneNumberCarrier.Replace(VariableConstant.CarrierNumber, phoneNumber + VariableConstant.Character);
                    }
                }
                char[] splitchar = { ApplicationConstants.SplitString };
                string[] providerNumberIndex = providerNumber.Split(splitchar);
                Aetna.ProviderContracts.DataContracts.Provider provider = new Aetna.ProviderContracts.DataContracts.Provider();
                if (!CommonHelper.ValidateEmail(email))
                {
                    throw new System.Exception(ExceptionMessageConstant.Email);
                }

                string errorMessage = string.Empty;
                if (!ValidateCaptcha(captcha, out errorMessage))
                {
                    traceLog.AppendLine(" & End: LocateProviderMobileController, MapDetailsSendText Method");
                    return Json(errorMessage);
                }
                else
                {
                    SearchRequestEntity searchRequest = new SearchRequestEntity();
                    searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                    if (searchRequest == null)
                    {
                        TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                        traceLog.AppendLine(" & End: LocateProviderMobileController, MapDetailsSendText Method");
                        return Json("sessionTimeOut");
                    }
                    if (!new CommonHelper().Validate(searchRequest))
                    {
                        throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                    }
                    bool send = false;
                    string culture = ReturnCultureInfo();
                    send = EmailSendHelper.ReturnMapDetailsSendText(searchRequest, provider, email, smsGateway, providerNumberIndex, providerNameDegree, providerAddress, culture);
                    TempData["SendSuccess"] = "Success";
                    traceLog.AppendLine(" & End: LocateProviderMobileController, MapDetailsSendText Method");
                    return Json(send);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// get current culture of the browser form cookie
        /// </summary>
        /// <returns></returns>
        private string ReturnCultureInfo()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, ReturnCultureInfo Method");
                string culture = AppSettingHelper.GetAppSettingValue(CookieConstant.InitialCulture);
                //HttpCookie cookie = Request.Cookies[CookieConstant.Culture];
                var cookie = Session[CookieConstant.Culture];
                if (cookie != null)
                {
                    if (cookie.ToString() == AppSettingHelper.GetAppSettingValue(CookieConstant.CheckCulture))
                    {
                        culture = AppSettingHelper.GetAppSettingValue(CookieConstant.NewCulture);
                    }
                }
                traceLog.AppendLine(" & End: LocateProviderMobileController, ReturnCultureInfo Method");
                return culture;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        private List<State> GetStatesOTMC(string networkId, string userType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, GetStatesOTMC Method with Param networkId: " + networkId + ", with Param userType: " + userType);
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                List<State> allStateList = contentManager.GetStatesLocateProvider(request).ToList();
                if (!string.IsNullOrEmpty(userType) && (userType.Equals("Customer", StringComparison.OrdinalIgnoreCase)
                        || userType.Equals("Vendor", StringComparison.OrdinalIgnoreCase)
                        || userType.Equals("Agent", StringComparison.OrdinalIgnoreCase)
                        || userType.Equals("Payer", StringComparison.OrdinalIgnoreCase)
                        || userType.Equals("Member", StringComparison.OrdinalIgnoreCase)))
                {
                    List<State> stateList = new List<State>();
                    string statesForUsers = AppSettingHelper.GetAppSettingValue(VariableConstant.AcceptedStateForUsers);
                    char[] splitchar = { ApplicationConstants.SplitString };
                    string[] displayState = statesForUsers.Split(splitchar);
                    foreach (var item in allStateList)
                    {
                        if (displayState.Contains(item.StateCode))
                        {
                            State stateVal = new State();
                            stateVal.StateCode = item.StateCode;
                            stateVal.StateName = item.StateName;

                            stateList.Add(stateVal);
                        }
                    }
                    traceLog.AppendLine(" & End: LocateProviderMobileController, GetStatesOTMC Method");
                    return stateList;
                }

                // This code will identify the name os network type
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                // This code will tell powerstepp is on with cofinity network or cofinity client specific code   
                //bool isPowerSteppON =
                //    networkId == "3" && (searchRequest.NetworkType.NetworkName == "Cofinity" || searchRequest.ClientSpecificCode == NABWebsite.DTO.Constants.CofinityClientSpecCode)
                //    && ConfigurationManager.AppSettings[NABWebsite.DTO.Constants.PowerSTEPPSunset] == Constants.TrueId;
                bool isPowerSteppON =
                    networkId == "3" || (ConfigurationManager.AppSettings[NABWebsite.DTO.Constants.PowerSTEPPSunset] == Constants.TrueId &&
                    (searchRequest.NetworkType.NetworkName == "Cofinity" || searchRequest.ClientSpecificCode == NABWebsite.DTO.Constants.CofinityClientSpecCode));

                if (((UserDetails)Session[Constants.UserDetails] != null) && ((UserDetails)Session[Constants.UserDetails]).SelectedRole != null &&
                    (networkId == "1" || isPowerSteppON))
                {
                    string role = ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToString();
                    if (role.Equals("Customer", StringComparison.OrdinalIgnoreCase)
                        || role.Equals("Vendor", StringComparison.OrdinalIgnoreCase)
                        || role.Equals("Agent", StringComparison.OrdinalIgnoreCase)
                        || role.Equals("Payer", StringComparison.OrdinalIgnoreCase)
                        || role.Equals("Member", StringComparison.OrdinalIgnoreCase))
                    {
                        List<State> stateList = new List<State>();
                        string statesForUsers = AppSettingHelper.GetAppSettingValue(VariableConstant.AcceptedStateForUsers);
                        char[] splitchar = { ApplicationConstants.SplitString };
                        string[] displayState = statesForUsers.Split(splitchar);
                        foreach (var item in allStateList)
                        {
                            if (displayState.Contains(item.StateCode))
                            {
                                State stateVal = new State();
                                stateVal.StateCode = item.StateCode;
                                stateVal.StateName = item.StateName;

                                stateList.Add(stateVal);
                            }
                        }
                        traceLog.AppendLine(" & End: LocateProviderMobileController, GetStatesOTMC Method");
                        return stateList;
                    }

                }
                traceLog.AppendLine(" & End: LocateProviderMobileController, GetStatesOTMC Method");
                return allStateList;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Return Custom network name
        /// </summary>
        /// <param name="clientCode"></param>
        /// <returns></returns>
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        private string GetNetworkNameFromCode(string clientCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderMobileController, GetNetworkNameFromCode Method with Param clientCode: " + clientCode);
                if (!CommonHelper.ValidateGenericValue(clientCode))
                    throw new ArgumentNullException(VariableConstant.ClientCode, VariableConstant.InvalidClientCode);
                string network = "";
                ManageContent contentManager = new ManageContent();
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                network = contentManager.GetNetworkNameFromCode(clientCode, request);
                traceLog.AppendLine(" & End: LocateProviderMobileController, GetNetworkNameFromCode Method");
                return network;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion
    }
}