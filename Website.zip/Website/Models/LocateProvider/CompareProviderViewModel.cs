﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;
using Aetna.ProviderContracts.DataContracts;
using System.ComponentModel.DataAnnotations;
using NABResources;
namespace NABWebsite.Models.LocateProvider
{
    public class CompareProviderViewModel
    {
        private List<ProviderDataForComparison> listProviderDataForComparison = new List<ProviderDataForComparison>();

        public List<ProviderDataForComparison> ListProviderDataForComparison { get { return listProviderDataForComparison; } }
        [EmailAddress(ErrorMessageResourceType = typeof(NABResources.Resources),
              ErrorMessageResourceName = "lblInvalidEmailAddress",ErrorMessage=null)]
        [RegularExpression(@"^([\w-\.'-]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,8}|[0-9]{1,3})(\]?)$", ErrorMessageResourceType = typeof(Resources),
              ErrorMessageResourceName = "lblInvalidEmailAddress", ErrorMessage = null)]
        [Required(ErrorMessageResourceType = typeof(Resources),
           ErrorMessageResourceName = "lblEmailAddressRequired",ErrorMessage=null)]
        public string EmailId1 { get; set; }
        public string RecaptchaPublicKey { get; set; }
        public string GoogleRecaptchaAPIAddressSingle { get; set; }
        
    }
}