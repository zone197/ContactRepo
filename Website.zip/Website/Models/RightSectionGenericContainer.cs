﻿
namespace NABWebsite.Models
{
    public class RightSectionGenericContainer
    {
        public int SectionId { get; set; }
        public string Title { get; set; }
        public string GroupType { get; set; }
        public int? LinkId { get; set; }
        public int ImageId { get; set; }
        public string LinkType { get; set; }
        public int TargetPageId { get; set; }
        public string LinkUrl { get; set; }
        public string ImageName { get; set; }
        public string ImageTitle { get; set; }
        public byte[] ImageContent { get; set; }
        public int SectionOrder { get; set; }
    }
}