﻿// display all the tabs for details
    function ShowHideDetails(data, activeTab) {
        var link = $("#open" + data);
        $('.nav-tabs a[href="#' + activeTab + data + '"]').tab('show');
    }

// display detailed information about the provider
    function DetailInfo(seqnumber, moveto) {
        var forgeryId = $("#forgeryToken").val();       

        $.ajax({
            type: 'POST',
            url: '/LocateProviderMobile/SaveProviderNumberToSession',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ providerNumber: seqnumber, ActiveTab: moveto }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                $("#spinnerPopup").modal('show');
                window.location.href = '/LocateProviderMobile/ProviderMoreDetails/';
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            }
        });
    //return false;
}

// display tab for dial information
//function DialInfo(seqnumber,moveto) {
//    window.location.href = "/LocateProviderMobile/SaveProviderNumberToSession?providerNumber=" + seqnumber + "&ActiveTab=" + moveto;
//    return false;
//}

// display tab for map information
//function MapInfo(seqnumber, moveto) {
//    window.location.href = "/LocateProviderMobile/SaveProviderNumberToSession?providerNumber=" + seqnumber + "&ActiveTab=" + moveto;
//    return false;
//}
$(document).ready(function () {
    
    //$('#SelectSortCriteria').dropdown({
    //});
    // sort the result set based on the sort criteria selected by the user
    $("#SelectSortCriteria").change(function (evt) {
        var forgeryId = $("#forgeryToken").val();
        $("#CurrentPageIndex").val(0);
        var sortField = $("#SelectSortCriteria").val();
        var sortDirection = $("#SelectSortCriteria").find(':selected').data('direction')
        var sortingPagingInfo = new Object();
        sortingPagingInfo.SortField = sortField;
        sortingPagingInfo.SortDirection = sortDirection;
        sortingPagingInfo.PageSize = $("#PageSize").val();
        sortingPagingInfo.PageCount = $("#PageCount").val();
        sortingPagingInfo.CurrentPageIndex = $("#CurrentPageIndex").val();

        $.ajax({
            type: 'POST',
            url: '/LocateProviderMobile/SaveSortingPagingInfoToSession',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ sortingPagingInfo: sortingPagingInfo }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                $("#spinnerPopup").modal('show');
                window.location.href = '/LocateProviderMobile/ProviderSearchResult/';
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            }
        });
    });

    
    $("#txtGotoPage").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

    // go the page number selected by the user and the sort thr result accordingly
    $("#txtGotoPage").keydown(function (e) {
        if (e.keyCode == 13) {
            var pageindex = parseInt($("#txtGotoPage").val() - 1);
            if (pageindex+1 > 0 && pageindex+1 <= $("#PageCount").val()) {
                var forgeryId = $("#forgeryToken").val();
                $("#CurrentPageIndex").val(pageindex);
                //evt.preventDefault();
                var sortingPagingInfo = new Object();
                sortingPagingInfo.SortField = $("#SortField").val();
                sortingPagingInfo.SortDirection = $("#SortDirection").val();
                sortingPagingInfo.PageSize = $("#PageSize").val();
                sortingPagingInfo.PageCount = $("#PageCount").val();
                sortingPagingInfo.CurrentPageIndex = $("#CurrentPageIndex").val();


                $.ajax({
                    type: 'POST',
                    url: '/LocateProviderMobile/SaveSortingPagingInfoToSession',
                    contentType: "application/json; charset=utf-8",
                    datatype: 'json',
                    data: JSON.stringify({ sortingPagingInfo: sortingPagingInfo }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    success: function (result) {
                        $("#spinnerPopup").modal('show');
                        window.location.href = '/LocateProviderMobile/ProviderSearchResult/';
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                    }
                });
            } else alert("Invalid Page Number");
        }
    })
    $(".pager").click(function (evt) {
        var forgeryId = $("#forgeryToken").val();
        var pageindex = $(evt.target).data("pageindex");
        $("#CurrentPageIndex").val(pageindex);
        var sortingPagingInfo = new Object();
        sortingPagingInfo.SortField = $("#SortField").val();
        sortingPagingInfo.SortDirection = $("#SortDirection").val();
        sortingPagingInfo.PageSize = $("#PageSize").val();
        sortingPagingInfo.PageCount = $("#PageCount").val();
        sortingPagingInfo.CurrentPageIndex = $("#CurrentPageIndex").val();


        $.ajax({
            type: 'POST',
            url: '/LocateProviderMobile/SaveSortingPagingInfoToSession',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ sortingPagingInfo: sortingPagingInfo }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                $("#spinnerPopup").modal('show');
                window.location.href = '/LocateProviderMobile/ProviderSearchResult/';
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            }
        });
    });
});

 