﻿using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Helper;
using NABWebsite.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security.AntiXss;
using Utilities;


namespace NABWebsite.Controllers
{
    public class SecureEmailController : Controller
    {
        private IEnumerable<HttpPostedFileBase> filesToUpload;
        SecureEmailModel modelObject = new SecureEmailModel();
        SecureEmail entityObject = new SecureEmail();
        SecureEmailBLL objectSecureEmailBll = new SecureEmailBLL();
        //StringBuilder traceLog = new StringBuilder();
        private string fileName;
        /// <summary>
        /// Secure email home page
        /// </summary>
        /// <returns>ActionResult</returns>
        [CheckAccess(Function = "Secured Email")]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, Index Method");
                    return RedirectToAction("Index", "Home");
                }
                //If required can be used
                //Session[Constants.CurrentController] = "SecureEmail";
                //Session[Constants.CurrentAction] = "Index";
                Session[Constants.Header] = Constants.SecureEmailHead;



                SetUserAccess(entityObject);
                entityObject = objectSecureEmailBll.FetchAllEmail(entityObject);
                modelObject.Email = entityObject;
                modelObject.CustomerServiceAccess = entityObject.CustomerServiceAccess;
                traceLog.AppendLine(" & End: SecureEmailController, Index Method");
                return View("SecureEmail", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// View mails in sent item
        /// </summary>
        /// <param name="messageId"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult ViewOutbox(int messageId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ViewOutbox Method with Param messageId: " + messageId);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, ViewOutbox Method");
                    return Content(Constants.ContentHome);
                }
                SetUserAccess(entityObject);
                entityObject = objectSecureEmailBll.FetchOutboxEmailById(entityObject, messageId);

                entityObject.InboxUnread = ViewInboxMailCount(false);
                entityObject.OutboxCount = ViewOutboxMailCount(false);
                modelObject.Email = entityObject;
                traceLog.AppendLine(" & End: SecureEmailController, ViewOutbox Method");
                return PartialView("_Outbox", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// View mails in inbox
        /// </summary>
        /// <param name="messageId"></param>
        /// <param name="originalMessageId"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult ViewInbox(int messageId, int originalMessageId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ViewInbox Method with Param messageId: " + messageId + " and with Param originalMessageId: " + originalMessageId);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, ViewInbox Method");
                    return Content(Constants.ContentHome);
                }

                SetUserAccess(entityObject);
                objectSecureEmailBll.MarkMessageRead(messageId, entityObject.Userid, entityObject.Site);
                entityObject = objectSecureEmailBll.FetchInboxEmailById(entityObject, messageId, originalMessageId);
                modelObject.Email = entityObject;
                traceLog.AppendLine(" & End: SecureEmailController, ViewInbox Method");
                return PartialView("_Inbox", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Compose email page
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult NewMail(SecureEmailModel modelObject1)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, NewMail Method with Param NewMail: " + modelObject1);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, NewMail Method");
                    return Content(Constants.ContentHome);
                }
                if (modelObject1 != null)
                {
                    string alphaConfig = AppSettingHelper.GetAppSettingValue(Constants.Alphabets);
                    string[] alphaConfigArray = alphaConfig.Split(',');
                    List<string> alphatest = alphaConfigArray.ToList();

                    SetUserAccess(entityObject);
                    entityObject.SendToDropDown = new List<SelectListItem>();
                    entityObject = objectSecureEmailBll.GetLookupRoles(entityObject);
                    if (String.IsNullOrEmpty(entityObject.Parameter))
                    {
                        entityObject.Parameter = Constants.AlphabetA;
                    }
                    if (String.IsNullOrEmpty(entityObject.SelectedGroup))
                    {
                        entityObject.SelectedGroup = Constants.Number1200;
                    }
                    entityObject = objectSecureEmailBll.GetUserListByRole(entityObject);

                    entityObject.Alpha = alphatest;
                    modelObject1.Email = entityObject;
                    if (modelObject1.Email.Site == Constants.Internal)
                    {
                        traceLog.AppendLine(" & End: SecureEmailController, NewMail Method");
                        return PartialView("_NewMail", modelObject1);
                    }
                    else if (modelObject1.Email.Site == Constants.External)
                    {
                        traceLog.AppendLine(" & End: SecureEmailController, NewMail Method");
                        return PartialView("_NewMailExternal", modelObject1);
                    }
                }
                traceLog.AppendLine(" & End: SecureEmailController, NewMail Method");
                return Content("<script type='text/javascript'> window.location='/Error/Index'</script>");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Delete single or multiple mail(s)
        /// </summary>
        /// <param name="messageId"></param>
        /// <returns>Boolean</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public Boolean DeleteMail(string messageId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, DeleteMail Method with Param messageId: " + messageId);
                SetUserAccess(entityObject);
                traceLog.AppendLine(" & End: SecureEmailController, DeleteMail Method");
                return (objectSecureEmailBll.DeleteMail(messageId, entityObject.Userid, entityObject.Site));
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Mark single or multiple mail(s) as unread
        /// </summary>
        /// <param name="messageId"></param>
        /// <returns>Boolean</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public Boolean MarkMessageUnread(string messageId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, MarkMessageUnread Method with Param messageId: " + messageId);
                SetUserAccess(entityObject);
                traceLog.AppendLine(" & End: SecureEmailController, MarkMessageUnread Method");
                return (objectSecureEmailBll.MarkMessageUnread(messageId, entityObject.Userid, entityObject.Site));
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// view user's Inbox or Outbox
        /// </summary>
        /// <param name="inbox"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult ViewAllInboxOrOutbox(bool inbox)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ViewAllInboxOrOutbox Method with Param inbox: " + inbox);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, ViewAllInboxOrOutbox Method");
                    return Content(Constants.ContentHome);
                }
                SetUserAccess(entityObject);
                entityObject = objectSecureEmailBll.FetchAllEmail(entityObject);
                modelObject.Email = entityObject;
                if (inbox) return PartialView("_AllInbox", modelObject);
                else
                {
                    traceLog.AppendLine(" & End: SecureEmailController, ViewAllInboxOrOutbox Method");
                    return PartialView("_AllOutbox", modelObject);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Get the total number of mails in inbox
        /// </summary>
        /// <returns>string</returns>
        [AjaxValidateAntiForgeryToken]
        public string ViewInboxMailCount(bool customerService)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ViewInboxMailCount Method with Param customerService: " + customerService);
                SetUserAccess(entityObject);
                string mailCount;
                if (!customerService)
                {
                    mailCount = objectSecureEmailBll.FetchInboxMailCount(entityObject.Userid, entityObject.Site);
                }
                else
                {
                    mailCount = objectSecureEmailBll.FetchInboxMailCount(Constants.CustomerService, entityObject.Site);
                }
                traceLog.AppendLine(" & End: SecureEmailController, ViewInboxMailCount Method");
                return mailCount;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// Get the total number of mails in outbox
        /// </summary>
        /// <returns>string</returns>
        [AjaxValidateAntiForgeryToken]
        public string ViewOutboxMailCount(bool customerService)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ViewOutboxMailCount Method with Param customerService: " + customerService);
                SetUserAccess(entityObject);
                string mailCount;
                if (!customerService)
                {
                    mailCount = objectSecureEmailBll.FetchOutboxMailCount(entityObject.Userid, entityObject.Site);
                }
                else
                {
                    mailCount = objectSecureEmailBll.FetchOutboxMailCount(Constants.CustomerService, entityObject.Site);
                }
                traceLog.AppendLine(" & End: SecureEmailController, ViewOutboxMailCount Method");
                return mailCount;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        public static void WriteToFileAsync(string filePath, string message)
        {
            StringBuilder traceLog = new StringBuilder();

            message = message.Replace("\\", "").Replace("..", "");//Added on 30 July-18 to fix Path Travrsal
            byte[] buffer = Encoding.Unicode.GetBytes(message);
            Int32 offset = 0;
            Int32 sizeOfBuffer = 4096;
            FileStream fileStream = null;

            try
            {
                traceLog.AppendLine("Start: SecureEmailController, WriteToFileAsync Method with Param filePath: " + filePath + " and with Param message: " + message);
                fileStream = new FileStream(filePath, FileMode.Append, FileAccess.Write,
                FileShare.None, bufferSize: sizeOfBuffer, useAsync: true);
                fileStream.Write(buffer, offset, buffer.Length);
                traceLog.AppendLine(" & End: SecureEmailController, WriteToFileAsync Method");
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (fileStream != null)
                    fileStream.Dispose();
                LogManager.WriteTraceLog(traceLog);
            }
            //}
        }

        /// <summary>
        /// Download the mail attachments
        /// </summary>
        /// <param name="submitButton"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult Download(string submitButton)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, Download Method with Param submitButton: " + submitButton);
                submitButton = submitButton.Replace("\\", "").Replace("..", "");//Added on 30 July-18 to fix Path Travrsal
                SecureEmailController.WriteToFileAsync(@"D:\logger\TestLog.txt", "SecureEmail: download start, SubmitButton: " + submitButton + Environment.NewLine);
                submitButton = HttpUtility.UrlEncode(submitButton); //Updated on 26-Sept-18 to fix HTTP Response Splitting 
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, Download Method");
                    return Content(Constants.ContentHome);
                }
                if (!string.IsNullOrEmpty(submitButton))
                {
                    //submitButton = AntiXssEncoder.HtmlEncode(submitButton, true);//Added on 30-Jul-18 to fix Reflected XSS               
                    SecureEmailController.WriteToFileAsync(@"D:\logger\TestLog.txt", "!string.IsNullOrEmpty(submitButton)." + Environment.NewLine);
                    string[] fileNameValue = submitButton.Split('+');

                    SecureEmailController.WriteToFileAsync(@"D:\logger\TestLog.txt", "fileNameValue[0]: " + fileNameValue[0] + "; fileNameValue[1]: " + fileNameValue[1] + Environment.NewLine);

                    if (System.IO.File.Exists(fileNameValue[1]))
                    {
                        SecureEmailController.WriteToFileAsync(@"D:\logger\TestLog.txt", "System.IO.File.Exists(fileNameValue[1])" + Environment.NewLine);
                        if (!submitButton.Contains("\n")) //Added on 27-Jul-18 to fix HTTP Response Splitting 
                        {
                            Response.AddHeader(Constants.ContentDisposition, "attachment; filename=" + fileNameValue[0]);
                        }
                        Response.ContentType = Constants.ApplicationOctetStream;
                        Response.BufferOutput = false;
                        Response.TransmitFile(fileNameValue[1]);
                        Response.End();


                    }
                }
                traceLog.AppendLine(" & End: SecureEmailController, Download Method");
                return View("Download");
            }
            catch (Exception ex)
            {
                SecureEmailController.WriteToFileAsync(@"D:\logger\TestLog.txt", "Exception: " + ex.Message + Environment.NewLine);
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// View reply mail page
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult Reply(SecureEmailModel modelObject1)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, Reply Method with Param modelObject1: " + modelObject1);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, Reply Method");
                    return Content(Constants.ContentHome);
                }
                if (modelObject1 != null)
                {
                    SetUserAccess(modelObject1.Email);
                    modelObject1.Email.ViewMail.Subject = Constants.SubjectReplyAdder + modelObject1.Email.ViewMail.Subject;
                    modelObject1.Email.ViewMail.Content = GetBody(modelObject1);
                }
                traceLog.AppendLine(" & End: SecureEmailController, Reply Method");
                return PartialView("_ReplyMail", modelObject1);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Convert Json to List of SelectListItem
        /// </summary>
        /// <param name="json"></param>
        /// <returns>List<SelectListItem></returns>
        private static List<SelectListItem> JSONParse(string json)
        {
            StringBuilder traceLog = new StringBuilder();

            try
            {
                traceLog.AppendLine("Start: SecureEmailController, JSONParse Method with Param json: " + json);
                List<SelectListItem> list = new List<SelectListItem>();
                json = Constants.StartSquareBracket + json + Constants.EndSquareBracket;
                var objects = JArray.Parse(json);
                foreach (JObject root in objects)
                {
                    foreach (KeyValuePair<String, JToken> app in root)
                    {
                        SelectListItem link = new SelectListItem();
                        link.Text = (String)app.Value[Constants.TextWord];
                        link.Value = (String)app.Value[Constants.ValueWord];
                        list.Add(link);
                    }
                }
                traceLog.AppendLine(" & End: SecureEmailController, JSONParse Method");
                return list;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// validate email id for external user
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public JsonResult ValidateRegMail(string emailIds)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ValidateRegMail Method with Param emailIds: " + emailIds);
                if (!string.IsNullOrEmpty(emailIds))
                {
                    String[] separatedUser = emailIds.TrimEnd(',').Split(new char[] { ',' });
                    StringBuilder invalidEmails = new StringBuilder();
                    foreach (string item in separatedUser)
                    {
                        if (!string.IsNullOrEmpty(item))
                        {
                            CustomerServiceUserList allListItem = new CustomerServiceUserList();
                            if (item.ToUpperInvariant().Contains(Constants.CofinityDomain.ToUpperInvariant()) || item.ToUpperInvariant().Contains(Constants.AetnaDomain.ToUpperInvariant())
                                || item.ToUpperInvariant().Contains(Constants.FirstHealthDomain.ToUpperInvariant()))
                            {
                                String email = item.ToString().ToUpperInvariant();
                                allListItem = objectSecureEmailBll.GetExternalToUser(email);
                                if (allListItem != null)
                                {
                                    if (!((allListItem.CustomerServiceList != null && allListItem.CustomerServiceList.Count() > 0) || (allListItem.User != null && !string.IsNullOrEmpty(allListItem.User.Text))))
                                        invalidEmails.Append(item.ToString() + "\n");
                                }
                                else
                                    invalidEmails.Append(item.ToString() + "\n");
                            }
                            else
                            {
                                traceLog.AppendLine(" & End: SecureEmailController, ValidateRegMail Method");
                                return Json(new { status = false, msg = "Not a valid domain address! \n Valid domain address is \'@aetna.com \' ,\'@Cofinity.net\' and \'@Firsthealth.com\'" }, JsonRequestBehavior.AllowGet);
                            }
                        }
                    }
                    if (!string.IsNullOrEmpty(invalidEmails.ToString()))
                    {
                        traceLog.AppendLine(" & End: SecureEmailController, ValidateRegMail Method");
                        return Json(new { status = false, msg = "Please enter a valid First Health or Cofinity email: \n\n" + invalidEmails.ToString() }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: SecureEmailController, ValidateRegMail Method");
                        return Json(new { status = true }, JsonRequestBehavior.AllowGet);
                    }
                }
                traceLog.AppendLine(" & End: SecureEmailController, ValidateRegMail Method");
                return Json(new { status = true }, JsonRequestBehavior.AllowGet);
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                return Json(new { status = false, msg = "Error Email validation!!!.Try again" }, JsonRequestBehavior.AllowGet);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Send mail to recipient
        /// </summary>
        /// <param name="objSecureEmailModel"></param>
        /// <param name="fileUpload"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult SendMail(SecureEmailModel objSecureEmailModel, IEnumerable<HttpPostedFileBase> fileUpload)
        {
            StringBuilder traceLog = new StringBuilder();

            try
            {
                traceLog.AppendLine("Start: SecureEmailController, SendMail Method with Param objSecureEmailModel: " + objSecureEmailModel + " and with Param fileUpload: " + fileUpload);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SendMail Method");
                    return Content(Constants.ContentHome);
                }
                bool retSendValue = true;
                bool retFileValue = true;
                string network = SetNetwork();
                string sessionId = SetSessionId();

                bool check = true;
                retFileValue = IsValidFile(fileUpload);
                if (objSecureEmailModel != null && objSecureEmailModel.Email != null && retFileValue)
                {
                    SetUserAccess(objSecureEmailModel.Email);
                    if (Validation.IsValidContent(objSecureEmailModel.Email.ViewMail.Subject) && Validation.IsValidEmailBodyContent(objSecureEmailModel.Email.ViewMail.Content))
                    {
                        if (objSecureEmailModel.Email.Site == Constants.Internal)
                        {
                            objSecureEmailModel.Email = objectSecureEmailBll.GetMailUserInternal(objSecureEmailModel.Email);
                            if (objSecureEmailModel.Email.UserSendToList != null && objSecureEmailModel.Email.UserSendToList != Constants.UndefinedText)
                            {
                                objSecureEmailModel.Email.SendToDropDown = JSONParse(objSecureEmailModel.Email.UserSendToList);
                            }
                        }
                        else if (objSecureEmailModel.Email.Site == Constants.External)
                        {
                            objSecureEmailModel.Email = objectSecureEmailBll.GetMailUserExternal(objSecureEmailModel.Email);
                            if (!Validation.IsValidContent(objSecureEmailModel.Email.UserSendToList))
                            {
                                retSendValue = false;
                            }
                            if (retSendValue)
                            {
                                List<SelectListItem> externalSendTo = new List<SelectListItem>();
                                List<SelectListItem> groupEmail = new List<SelectListItem>();
                                String[] separatedUser = objSecureEmailModel.Email.UserSendToList.TrimEnd(',').Split(new char[] { ',' });
                                StringBuilder invalidEmail = new StringBuilder();
                                foreach (var item in separatedUser)
                                {
                                    if (!string.IsNullOrEmpty(item))
                                    {
                                        CustomerServiceUserList allListItem = new CustomerServiceUserList();
                                        if (item.ToUpperInvariant().Contains(Constants.CofinityDomain.ToUpperInvariant()) || item.ToUpperInvariant().Contains(Constants.AetnaDomain.ToUpperInvariant())
                                            || item.ToUpperInvariant().Contains(Constants.FirstHealthDomain.ToUpperInvariant()))
                                        {
                                            String email = item.ToString().ToUpperInvariant();
                                            //Delete it after doing it in functionality
                                            //if (email.Contains(Constants.CofinityDomain.ToUpperInvariant()))
                                            //{
                                            //    email = email.Replace(Constants.CofinityDomain.ToUpperInvariant(), Constants.AetnaDomain.ToUpperInvariant());
                                            //}

                                            allListItem = objectSecureEmailBll.GetExternalToUser(email);
                                            if (allListItem != null)
                                            {
                                                if (allListItem.CustomerServiceList != null && allListItem.CustomerServiceList.Count() > 0)
                                                {
                                                    groupEmail.AddRange(allListItem.CustomerServiceList);
                                                }
                                                if (allListItem.User != null && !string.IsNullOrEmpty(allListItem.User.Text))
                                                {
                                                    externalSendTo.Add(allListItem.User);
                                                }
                                                else
                                                {
                                                    invalidEmail.Append(item.ToString() + "\\n");
                                                }
                                            }
                                            else
                                            {
                                                invalidEmail.Append(item.ToString() + "\\n");
                                            }

                                        }
                                        else
                                        {
                                            traceLog.AppendLine(" & End: SecureEmailController, SendMail Method");
                                            return Content("<script type='text/javascript'>alert('Not a valid domain address! \\n Valid domain address is \" @aetna.com \" ,\"@Cofinity.net\" and \"@Firsthealth.com\" '); window.location='/SecureEmail/Index'</script>");
                                        }
                                    }

                                }

                                if (!string.IsNullOrEmpty(invalidEmail.ToString()))
                                {
                                    return Content("<script type='text/javascript'>alert('Please enter a valid First Health or Cofinity email - \\n " + invalidEmail.ToString() + "'); window.location='/SecureEmail/Index'</script>");

                                }

                                objSecureEmailModel.Email.SendToDropDown = externalSendTo;
                                objSecureEmailModel.Email.SecureGroupEmail = groupEmail;
                            }
                        }

                        if (objSecureEmailModel.Email.MailUser.Email == null)
                        {
                            traceLog.AppendLine(" & End: SecureEmailController, SendMail Method");
                            return Content("<script type='text/javascript'>alert('Error sending mail!!!.Try again'); window.location='/SecureEmail/Index'</script>");
                        }

                        objectSecureEmailBll.DeleteTempAttach(objSecureEmailModel.Email.Userid, sessionId);



                        if (objSecureEmailModel.Email.CustomerServiceMail)
                        {
                            objSecureEmailModel.Email.ViewMail.OwnerEmail = ConfigurationManager.AppSettings[Constants.CustomerServiceMail].ToString();
                            objSecureEmailModel.Email.ViewMail.OwnerUserid = Constants.CustomerService;
                            objSecureEmailModel.Email.ViewMail.UserEmail = ConfigurationManager.AppSettings[Constants.CustomerServiceMail].ToString();
                            objSecureEmailModel.Email.ViewMail.Userid = Constants.CustomerService;
                        }
                        else
                        {
                            objSecureEmailModel.Email.ViewMail.OwnerEmail = objSecureEmailModel.Email.MailUser.Email;
                            objSecureEmailModel.Email.ViewMail.OwnerUserid = objSecureEmailModel.Email.Userid;
                            objSecureEmailModel.Email.ViewMail.UserEmail = objSecureEmailModel.Email.MailUser.Email;
                            objSecureEmailModel.Email.ViewMail.Userid = objSecureEmailModel.Email.Userid;
                        }

                        objSecureEmailModel.Email.ViewMail.Subject = objSecureEmailModel.Email.ViewMail.Subject.TrimEnd();
                        objSecureEmailModel.Email.ViewMail.OriginalMessageId = Constants.Zero;
                        objSecureEmailModel.Email.ViewMail.Outgoing = false;
                        objSecureEmailModel.Email.ViewMail.MessageType = SetMessageType(objSecureEmailModel.Email.MailUser.Email, objSecureEmailModel.Email.Site);
                        objSecureEmailModel.Email.ViewMail.Network = network;

                        int returnMessageId = objectSecureEmailBll.InsertMessage(objSecureEmailModel.Email);
                        objSecureEmailModel.Email.ViewMail.OriginalMessageId = returnMessageId.ToString(CultureInfo.InvariantCulture);

                        FileUpload(objSecureEmailModel, fileUpload, returnMessageId);

                        SendIndividual(objSecureEmailModel, objectSecureEmailBll);

                        if (objSecureEmailModel.Email.SecureGroupEmail != null)
                        {
                            foreach (var item in objSecureEmailModel.Email.SecureGroupEmail)
                            {
                                if (!string.IsNullOrEmpty(item.Value))
                                {
                                    SendEMailSMTP(objSecureEmailModel.Email.MailUser.Email, item.Value, objSecureEmailModel.Email.ViewMail.MessageType, objSecureEmailModel.Email.Site);
                                }
                            }
                        }
                    }
                    else
                    {
                        check = false;
                    }
                }
                if (check)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SendMail Method");
                    return Redirect("/SecureEmail/Index");
                }
                else
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SendMail Method");
                    return View("Error");
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Send mail to Individual recipient
        /// </summary>
        /// <param name="objSecureEmailModel"></param>
        /// <param name="objBll"></param>
        private static void SendIndividual(SecureEmailModel objSecureEmailModel, SecureEmailBLL objBll)
        {
            StringBuilder traceLog = new StringBuilder();

            try
            {
                traceLog.AppendLine("Start: SecureEmailController, SendIndividual Method with Param objSecureEmailModel: " + objSecureEmailModel + " and with Param objBll: " + objBll);
                foreach (SelectListItem li in objSecureEmailModel.Email.SendToDropDown)
                {
                    String[] strAUser = li.Value.ToString().Split(new char[] { '|' });
                    SecureEmail objSecureEmail = new SecureEmail();
                    objSecureEmail = objSecureEmailModel.Email;
                    objSecureEmail.ViewMail.Outgoing = true;
                    if (strAUser != null && strAUser.Length > 1)
                    {
                        objSecureEmail.ViewMail.OwnerUserid = strAUser[0].ToString();
                        objSecureEmail.ViewMail.OwnerEmail = strAUser[1].ToString();
                        objSecureEmail.ViewMail.MessageType = SetMessageType(objSecureEmail.ViewMail.OwnerEmail, objSecureEmailModel.Email.Site);


                        int returnMessageIdTo = objBll.InsertMessage(objSecureEmail);
                        objBll.InsertMessageToList(objSecureEmailModel.Email.ViewMail.OriginalMessageId, objSecureEmail.ViewMail.OwnerUserid, objSecureEmail.ViewMail.OwnerEmail);
                        objBll.InsertMessageToList(returnMessageIdTo.ToString(CultureInfo.InvariantCulture), objSecureEmail.ViewMail.OwnerUserid, objSecureEmail.ViewMail.OwnerEmail);

                        SendEMailSMTP(objSecureEmailModel.Email.MailUser.Email, objSecureEmail.ViewMail.OwnerEmail, objSecureEmail.ViewMail.MessageType, objSecureEmailModel.Email.Site);

                    }
                }
                traceLog.AppendLine(" & End: SecureEmailController, SendMail Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Check the file size and format
        /// </summary>
        /// <param name="fileUploadValue"></param>
        /// <returns>bool</returns>
        private bool IsValidFile(IEnumerable<HttpPostedFileBase> fileUploadValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, IsValidFile Method with Param fileUploadValue: " + fileUploadValue);
                this.filesToUpload = fileUploadValue;
                bool status = true;
                int fileSize = 0;
                List<string> allFile = new List<string>();
                foreach (var file in filesToUpload)
                {
                    if (file != null)
                    {
                        string tempFileName = GetFileName(file.FileName);
                        if (!allFile.Contains(tempFileName))
                        {
                            status = (status && Validation.IsValidExtensionName(Path.GetExtension(tempFileName)));
                            allFile.Add(tempFileName);
                            fileSize += file.ContentLength;
                        }
                        else
                        {
                            status = false;
                        }
                    }
                }
                if (fileSize >= 10485760)
                {
                    status = false;
                }
                traceLog.AppendLine(" & End: SecureEmailController, IsValidFile Method");
                return status;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Upload attachment
        /// </summary>
        /// <param name="objSecureEmailModel"></param>
        /// <param name="fileUploadValue"></param>
        /// <param name="messageId"></param>
        private void FileUpload(SecureEmailModel objSecureEmailModel, IEnumerable<HttpPostedFileBase> fileUploadValue, int messageId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, FileUpload Method with Param objSecureEmailModel: " + objSecureEmailModel + " and with Param fileUploadValue: " + fileUploadValue + " and with Param messageId: " + messageId);
                string sessionId = SetSessionId();
                if (fileUploadValue != null && (!string.IsNullOrEmpty(sessionId)))
                {
                    foreach (var file in fileUploadValue)
                    {
                        if (file != null)
                        {
                            string tempFileName = GetFileName(file.FileName);
                            if (objSecureEmailModel.Email.AllFileName.Contains(tempFileName))
                            {
                                Stream fileStream = file.InputStream;
                                int fileStreamLen = file.ContentLength;
                                Byte[] fileContent = new byte[fileStreamLen];
                                fileStream.Read(fileContent, 0, fileStreamLen);
                                int attachId = objectSecureEmailBll.InsertTempMessageAttachment(objSecureEmailModel.Email.Userid, objSecureEmailModel.Email.Site, sessionId, tempFileName, fileContent);

                                if (objSecureEmailModel.Email.Site == Constants.External)
                                {
                                    String saveLocation = String.Format(CultureInfo.InvariantCulture, @"{0}\{1}~{2}~{3}", ConfigurationManager.AppSettings["CurrentServer"].ToString() + ConfigurationManager.AppSettings["SecureMailFileSavePath"].ToString(), objSecureEmailModel.Email.Userid, objSecureEmailModel.Email.ViewMail.OriginalMessageId, tempFileName);
                                    file.SaveAs(saveLocation);
                                    String serverStored = "";
                                    List<ServerDetails> detailsObject = objectSecureEmailBll.GetAllServerDetails();//Call to dal
                                    serverStored = objectSecureEmailBll.FileCopyToServer(saveLocation, detailsObject);
                                    objectSecureEmailBll.InsertMessageAttachment(messageId, objSecureEmailModel.Email.Userid, objSecureEmailModel.Email.Site, sessionId, serverStored);
                                }
                                else
                                {
                                    objectSecureEmailBll.InsertMessageAttachment(messageId, objSecureEmailModel.Email.Userid, objSecureEmailModel.Email.Site, sessionId);
                                }
                                objectSecureEmailBll.DeleteTempAttach(attachId, objSecureEmailModel.Email.Userid, sessionId, tempFileName);
                            }
                        }
                    }
                }
                traceLog.AppendLine(" & End: SecureEmailController, FileUpload Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Set session id
        /// </summary>
        /// <returns>string</returns>
        private string SetSessionId()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, SetSessionId Method ");

                if (Session[Constants.SessionId] != null)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SetSessionId Method");
                    return Session[Constants.SessionId].ToString();
                }
                traceLog.AppendLine(" & End: SecureEmailController, SetSessionId Method");
                return Constants.Empty;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Set message type
        /// </summary>
        /// <param name="email"></param>
        /// <returns>string</returns>
        private static string SetMessageType(string email, string userType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, SetMessageType Method with Param email: " + email + " and with Param userType: " + userType);
                if (userType != Constants.External)
                {
                    if (Validation.IsValidEmailDomain(email))
                        return Constants.SecureToInternalText;
                    else
                    {
                        traceLog.AppendLine(" & End: SecureEmailController, SetMessageType Method");
                        return Constants.SecureToExternalText;
                    }
                }
                else
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SetMessageType Method");
                    return Constants.SecureToInternalText;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Send Smtp mail
        /// </summary>
        /// <param name="toMailID"></param>
        /// <param name="frmMailID"></param>
        /// <param name="strExtMsgType"></param>
        private static void SendEMailSMTP(string frmMailID, string toMailID, string strExtMsgType, string userType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, SendEMailSMTP Method with Param frmMailID: " + frmMailID + " and with Param toMailID: " + toMailID + " and with Param strExtMsgType: " + strExtMsgType + " and with Param userType: " + userType);
                SecureEmailBLL objectSecureEmailBll1 = new SecureEmailBLL();
                string website = string.Empty;
                if (userType == Constants.Internal)
                {
                    if (strExtMsgType == Constants.SecureToInternalText)
                    {
                        website = ConfigurationManager.AppSettings[Constants.WebAddress];
                    }
                    else
                    {
                        website = ConfigurationManager.AppSettings[Constants.WebAddressExternal];
                    }
                }
                else if (userType == Constants.External)
                {
                    website = ConfigurationManager.AppSettings[Constants.WebAddressInternal];
                }


                string subject = Constants.SecureMailSubject;
                StringBuilder strBody = new StringBuilder();
                strBody.Append(Constants.BreakLine);
                strBody.Append(Constants.SecureMailBodyline1 + Constants.BreakLine);
                strBody.Append(Constants.BreakLine);
                strBody.Append(Constants.SecureMailBodyline2);
                strBody.Append(Constants.SecureMailBodyline3Part1 + website + Constants.SecureMailBodyline3Part2 + website + Constants.SecureMailBodyline3Part3 + Constants.BreakLine);
                strBody.Append(Constants.BreakLine);
                strBody.Append(Constants.BreakLine);
                strBody.Append(Constants.CofinityWebService);

                objectSecureEmailBll1.SendConfirmMail(frmMailID, toMailID, subject, strBody.ToString());
                traceLog.AppendLine(" & End: SecureEmailController, SendEMailSMTP Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Get mail body for forward or reply page
        /// </summary>
        /// <param name="objSecureEmailModel"></param>
        /// <returns>string</returns>
        private static string GetBody(SecureEmailModel objSecureEmailModel)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, GetBody Method with Param objSecureEmailModel: " + objSecureEmailModel);
                DateTime dt = Convert.ToDateTime(objSecureEmailModel.Email.ViewMail.Date, CultureInfo.InvariantCulture);

                string body = string.Empty;
                body = objSecureEmailModel.Email.ViewMail.Content;

                StringBuilder sbBody = new StringBuilder();

                sbBody.Append(Constants.NewLine);
                sbBody.Append(Constants.NewLine);
                sbBody.Append(Constants.NewLine);
                sbBody.Append(Constants.OriginalMessageText + Constants.NewLine);
                sbBody.Append(Constants.NewLine);
                sbBody.Append(Constants.SecureMailFrom + objSecureEmailModel.Email.ViewMail.Name + Constants.NewLine);
                sbBody.Append(Constants.SecureMailSent + dt.ToLongDateString() + " " + dt.ToShortTimeString() + Constants.NewLine);
                sbBody.Append(Constants.ToSecureMail + objSecureEmailModel.Email.ViewMail.OwnerName + Constants.NewLine);
                sbBody.Append(Constants.SecureMailSubjectText + objSecureEmailModel.Email.ViewMail.Subject + Constants.NewLine);
                sbBody.Append(Constants.NewLine);
                sbBody.Append(body);
                traceLog.AppendLine(" & End: SecureEmailController, GetBody Method");
                return sbBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Send reply mail
        /// </summary>
        /// <param name="objSecureEmailModel"></param>
        /// <param name="fileUpload"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult SendReplyMail(SecureEmailModel objSecureEmailModel, IEnumerable<HttpPostedFileBase> fileUpload)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, SendReplyMail Method with Param objSecureEmailModel: " + objSecureEmailModel + " and with Param fileUpload: " + fileUpload);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SendReplyMail Method");
                    return Content(Constants.ContentHome);
                }
                Boolean retFileValue = true;
                string network = SetNetwork();
                string sessionId = SetSessionId();

                bool check = true;
                retFileValue = IsValidFile(fileUpload);
                if (objSecureEmailModel != null && objSecureEmailModel.Email != null && retFileValue)
                {
                    SetUserAccess(objSecureEmailModel.Email);
                    string ownerUserid = objSecureEmailModel.Email.ViewMail.Userid;
                    string ownerEmail = objSecureEmailModel.Email.ViewMail.Email;
                    string strMessageID = objSecureEmailModel.Email.ViewMail.MessageId;
                    if (Validation.IsValidContent(objSecureEmailModel.Email.ViewMail.Subject) && Validation.IsValidEmailBodyContent(objSecureEmailModel.Email.ViewMail.Content))
                    {
                        if (objSecureEmailModel.Email.Site == Constants.Internal)
                        {
                            objSecureEmailModel.Email = objectSecureEmailBll.GetMailUserInternal(objSecureEmailModel.Email);
                        }
                        else if (objSecureEmailModel.Email.Site == Constants.External)
                        {
                            objSecureEmailModel.Email = objectSecureEmailBll.GetMailUserExternal(objSecureEmailModel.Email);
                        }
                        objectSecureEmailBll.DeleteTempAttach(objSecureEmailModel.Email.Userid, sessionId);
                        if (objSecureEmailModel.Email.MailUser.Email == null)
                        {
                            traceLog.AppendLine(" & End: SecureEmailController, SendReplyMail Method");
                            return Content("<script type='text/javascript'>alert('Error sending mail!!!.Try again'); window.location='/SecureEmail/Index'</script>");
                        }


                        objSecureEmailModel.Email.ViewMail.OwnerEmail = objSecureEmailModel.Email.MailUser.Email;
                        objSecureEmailModel.Email.ViewMail.OwnerUserid = objSecureEmailModel.Email.Userid;

                        objSecureEmailModel.Email.ViewMail.UserEmail = objSecureEmailModel.Email.MailUser.Email;
                        objSecureEmailModel.Email.ViewMail.Userid = objSecureEmailModel.Email.Userid;

                        objSecureEmailModel.Email.ViewMail.Subject = objSecureEmailModel.Email.ViewMail.Subject.TrimEnd();
                        objSecureEmailModel.Email.ViewMail.OriginalMessageId = Constants.Zero;
                        objSecureEmailModel.Email.ViewMail.Outgoing = false;
                        objSecureEmailModel.Email.ViewMail.Network = network;


                        objSecureEmailModel.Email.ViewMail.MessageType = SetMessageType(objSecureEmailModel.Email.MailUser.Email, objSecureEmailModel.Email.Site);


                        int returnMessageId = objectSecureEmailBll.InsertMessage(objSecureEmailModel.Email);
                        objSecureEmailModel.Email.ViewMail.OriginalMessageId = returnMessageId.ToString(CultureInfo.InvariantCulture);

                        FileUpload(objSecureEmailModel, fileUpload, returnMessageId);


                        SecureEmail objSecureEmail = new SecureEmail();
                        objSecureEmail = objSecureEmailModel.Email;
                        objSecureEmail.ViewMail.Outgoing = true;
                        objSecureEmail.ViewMail.OwnerUserid = ownerUserid;
                        objSecureEmail.ViewMail.OwnerEmail = ownerEmail;
                        objSecureEmail.ViewMail.MessageType = SetMessageType(objSecureEmail.ViewMail.OwnerEmail, objSecureEmailModel.Email.Site);


                        int returnMessageIdTo = objectSecureEmailBll.InsertMessage(objSecureEmail);
                        objectSecureEmailBll.InsertMessageToList(objSecureEmailModel.Email.ViewMail.OriginalMessageId, objSecureEmail.ViewMail.OwnerUserid, objSecureEmail.ViewMail.OwnerEmail);
                        objectSecureEmailBll.InsertMessageToList(returnMessageIdTo.ToString(CultureInfo.InvariantCulture), objSecureEmail.ViewMail.OwnerUserid, objSecureEmail.ViewMail.OwnerEmail);
                        FileUpload(objSecureEmailModel, fileUpload, returnMessageIdTo);
                        objectSecureEmailBll.InsertReplyLog(Convert.ToInt32(returnMessageId, CultureInfo.InvariantCulture), Convert.ToInt32(strMessageID, CultureInfo.InvariantCulture), objSecureEmail.Userid);
                        SendEMailSMTP(objSecureEmailModel.Email.MailUser.Email, objSecureEmail.ViewMail.OwnerEmail, objSecureEmail.ViewMail.MessageType, objSecureEmail.Site);
                    }
                    else
                    {
                        check = false;
                    }


                }
                if (check)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SendReplyMail Method");
                    return Redirect("/SecureEmail/Index");
                }
                else
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SendReplyMail Method");
                    return View("Error");
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// View forward page
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult Forward(SecureEmailModel modelObject1)
        {
            StringBuilder traceLog = new StringBuilder();

            try
            {
                traceLog.AppendLine("Start: SecureEmailController, Forward Method with Param modelObject1: " + modelObject1);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, Forward Method");
                    return Content(Constants.ContentHome);
                }
                if (modelObject1 != null)
                {
                    if (modelObject1.Email != null)
                    {
                        SecureEmail entityObject1 = new SecureEmail();
                        SecureEmailBLL objectSecureEmailBll1 = new SecureEmailBLL();
                        entityObject1 = modelObject1.Email;
                        string alphaConfig = AppSettingHelper.GetAppSettingValue(Constants.Alphabets);
                        string[] alphaConfigArray = alphaConfig.Split(',');
                        List<string> alphatest = alphaConfigArray.ToList();

                        SetUserAccess(entityObject1);
                        entityObject1.SendToDropDown = new List<SelectListItem>();
                        entityObject1 = objectSecureEmailBll1.GetLookupRoles(entityObject1);
                        if (String.IsNullOrEmpty(entityObject1.Parameter))
                        {
                            entityObject1.Parameter = Constants.AlphabetA;
                        }
                        if (String.IsNullOrEmpty(entityObject1.SelectedGroup))
                        {
                            entityObject1.SelectedGroup = Constants.Number1200;
                        }
                        entityObject1 = objectSecureEmailBll1.GetUserListByRole(entityObject1);

                        if (entityObject1.UserSendToList != null && entityObject1.UserSendToList != Constants.UndefinedText)
                        {
                            modelObject1.Email.SendToDropDown = JSONParse(entityObject1.UserSendToList);
                        }

                        modelObject1.Email.Userid = ((UserDetails)Session[Constants.UserDetails]).UserId;
                        modelObject1.Email.ViewMail.Subject = Constants.SubjectForwardAdder + modelObject1.Email.ViewMail.Subject;
                        modelObject1.Email.ViewMail.Content = GetBody(modelObject1);
                        modelObject1.Email = objectSecureEmailBll1.FetchMailAttachmentById(modelObject1.Email, Convert.ToInt32(modelObject1.Email.ViewMail.OriginalMessageId, CultureInfo.InvariantCulture));
                        entityObject1.Alpha = alphatest;
                        modelObject1.Email = entityObject1;
                        if (modelObject1.Email.Site == Constants.Internal)
                        {
                            traceLog.AppendLine(" & End: SecureEmailController, Forward Method");
                            return PartialView("_ForwardMail", modelObject1);
                        }
                        else if (modelObject1.Email.Site == Constants.External)
                        {
                            traceLog.AppendLine(" & End: SecureEmailController, Forward Method");
                            return PartialView("_ForwardMailExternal", modelObject1);
                        }
                    }

                }
                traceLog.AppendLine(" & End: SecureEmailController, Forward Method");
                return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// Send forward mail
        /// </summary>
        /// <param name="objSecureEmailModel"></param>
        /// <param name="fileUpload"></param>
        /// <returns>ActionResult</returns>
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult SendForwardMail(SecureEmailModel objSecureEmailModel, IEnumerable<HttpPostedFileBase> fileUpload)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, SendForwardMail Method with Param objSecureEmailModel: " + objSecureEmailModel + " and with Param fileUpload: " + fileUpload);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SendForwardMail Method");
                    return Content(Constants.ContentHome);
                }
                Boolean retSendValue = true;
                Boolean retFileValue = true;
                string network = SetNetwork();
                string sessionId = SetSessionId();

                bool check = true;
                retFileValue = IsValidFile(fileUpload);
                if (objSecureEmailModel != null && objSecureEmailModel.Email != null && retFileValue)
                {
                    SetUserAccess(objSecureEmailModel.Email);
                    if (Validation.IsValidContent(objSecureEmailModel.Email.ViewMail.Subject) && Validation.IsValidEmailBodyContent(objSecureEmailModel.Email.ViewMail.Content))
                    {
                        if (objSecureEmailModel.Email.Site == Constants.Internal)
                        {
                            objSecureEmailModel.Email = objectSecureEmailBll.GetMailUserInternal(objSecureEmailModel.Email);
                            if (objSecureEmailModel.Email.UserSendToList != null && objSecureEmailModel.Email.UserSendToList != Constants.UndefinedText)
                            {
                                objSecureEmailModel.Email.SendToDropDown = JSONParse(objSecureEmailModel.Email.UserSendToList);
                            }
                        }
                        else if (objSecureEmailModel.Email.Site == Constants.External)
                        {
                            objSecureEmailModel.Email = objectSecureEmailBll.GetMailUserExternal(objSecureEmailModel.Email);
                            if (!Validation.IsValidContent(objSecureEmailModel.Email.UserSendToList))
                            {
                                retSendValue = false;
                            }
                            if (retSendValue)
                            {
                                List<SelectListItem> externalSendTo = new List<SelectListItem>();
                                List<SelectListItem> groupEmail = new List<SelectListItem>();
                                String[] separatedUser = objSecureEmailModel.Email.UserSendToList.TrimEnd(',').Split(new char[] { ',' });
                                StringBuilder invalidEmail = new StringBuilder();
                                foreach (var item in separatedUser)
                                {
                                    if (!string.IsNullOrEmpty(item))
                                    {
                                        CustomerServiceUserList allListItem = new CustomerServiceUserList();
                                        if (item.ToUpperInvariant().Contains(Constants.CofinityDomain.ToUpperInvariant()) || item.ToUpperInvariant().Contains(Constants.AetnaDomain.ToUpperInvariant())
                                            || item.ToUpperInvariant().Contains(Constants.FirstHealthDomain.ToUpperInvariant()))
                                        {
                                            String email = item.ToString().ToUpperInvariant();

                                            //Delete after doing it in functionality
                                            //if (email.Contains(Constants.CofinityDomain.ToUpperInvariant()))
                                            //{
                                            //    email = email.Replace(Constants.CofinityDomain.ToUpperInvariant(), Constants.AetnaDomain.ToUpperInvariant());
                                            //}

                                            allListItem = objectSecureEmailBll.GetExternalToUser(email);
                                            if (allListItem != null)
                                            {
                                                if (allListItem.CustomerServiceList != null && allListItem.CustomerServiceList.Count() > 0)
                                                {
                                                    groupEmail.AddRange(allListItem.CustomerServiceList);
                                                }
                                                if (allListItem.User != null && !string.IsNullOrEmpty(allListItem.User.Text))
                                                {
                                                    externalSendTo.Add(allListItem.User);
                                                }
                                                else
                                                {
                                                    invalidEmail.Append(item.ToString() + "\\n");
                                                }
                                            }
                                            else
                                            {
                                                invalidEmail.Append(item.ToString() + "\\n");
                                            }
                                        }
                                        else
                                        {
                                            traceLog.AppendLine(" & End: SecureEmailController, SendForwardMail Method");
                                            return Content("<script type='text/javascript'>alert('Not a valid domain address! \\n Valid domain address is \" @aetna.com \" ,\"@cofinity.net\" and \"@firsthealth.com\" '); window.location='/SecureEmail/Index'</script>");
                                        }
                                    }

                                }

                                if (!string.IsNullOrEmpty(invalidEmail.ToString()))
                                {
                                    return Content("<script type='text/javascript'>alert('Please enter a valid First Health or Cofinity email - \\n " + invalidEmail.ToString() + "'); window.location='/SecureEmail/Index'</script>");

                                }

                                objSecureEmailModel.Email.SendToDropDown = externalSendTo;
                                objSecureEmailModel.Email.SecureGroupEmail = groupEmail;
                            }
                        }
                        objSecureEmailModel.Email = objectSecureEmailBll.FetchMailAttachmentById(objSecureEmailModel.Email, Convert.ToInt32(objSecureEmailModel.Email.ViewMail.OriginalMessageId, CultureInfo.InvariantCulture));
                        objectSecureEmailBll.DeleteTempAttach(objSecureEmailModel.Email.Userid, sessionId);
                        if (objSecureEmailModel.Email.MailUser.Email == null)
                        {
                            traceLog.AppendLine(" & End: SecureEmailController, SendForwardMail Method");
                            return Content("<script type='text/javascript'>alert('Error sending mail!!!.Try again'); window.location='/SecureEmail/Index'</script>");
                        }

                        if (objSecureEmailModel.Email.CustomerServiceMail)
                        {
                            objSecureEmailModel.Email.ViewMail.OwnerEmail = ConfigurationManager.AppSettings[Constants.CustomerServiceMail].ToString();
                            objSecureEmailModel.Email.ViewMail.OwnerUserid = Constants.CustomerService;
                            objSecureEmailModel.Email.ViewMail.UserEmail = ConfigurationManager.AppSettings[Constants.CustomerServiceMail].ToString();
                            objSecureEmailModel.Email.ViewMail.Userid = Constants.CustomerService;
                        }
                        else
                        {
                            objSecureEmailModel.Email.ViewMail.OwnerEmail = objSecureEmailModel.Email.MailUser.Email;
                            objSecureEmailModel.Email.ViewMail.OwnerUserid = objSecureEmailModel.Email.Userid;
                            objSecureEmailModel.Email.ViewMail.UserEmail = objSecureEmailModel.Email.MailUser.Email;
                            objSecureEmailModel.Email.ViewMail.Userid = objSecureEmailModel.Email.Userid;
                        }
                        objSecureEmailModel.Email.ViewMail.Subject = objSecureEmailModel.Email.ViewMail.Subject.TrimEnd();
                        objSecureEmailModel.Email.ViewMail.OriginalMessageId = Constants.Zero;
                        objSecureEmailModel.Email.ViewMail.Outgoing = false;
                        objSecureEmailModel.Email.ViewMail.Network = network;



                        objSecureEmailModel.Email.ViewMail.MessageType = SetMessageType(objSecureEmailModel.Email.MailUser.Email, objSecureEmailModel.Email.Site);


                        int returnMessageId = objectSecureEmailBll.InsertMessage(objSecureEmailModel.Email);
                        objSecureEmailModel.Email.ViewMail.OriginalMessageId = returnMessageId.ToString(CultureInfo.InvariantCulture);


                        FileUpload(objSecureEmailModel, fileUpload, returnMessageId);

                        ExistingFileUpload(objSecureEmailModel, objectSecureEmailBll, returnMessageId);

                        SendIndividual(objSecureEmailModel, objectSecureEmailBll);

                        if (objSecureEmailModel.Email.SecureGroupEmail != null)
                        {
                            foreach (var item in objSecureEmailModel.Email.SecureGroupEmail)
                            {
                                if (!string.IsNullOrEmpty(item.Value))
                                {
                                    SendEMailSMTP(objSecureEmailModel.Email.MailUser.Email, item.Value, objSecureEmailModel.Email.ViewMail.MessageType, objSecureEmailModel.Email.Site);
                                }
                            }
                        }
                    }
                    else
                    {
                        check = false;
                    }


                }
                if (check)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SendForwardMail Method");
                    return Redirect("/SecureEmail/Index");
                }
                else
                {
                    traceLog.AppendLine(" & End: SecureEmailController, SendForwardMail Method");
                    return View("Error");
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Upload already attached file in forward mail
        /// </summary>
        /// <param name="objSecureEmailModel"></param>
        /// <param name="objBll"></param>
        /// <param name="returnMessageId"></param>
        private void ExistingFileUpload(SecureEmailModel objSecureEmailModel, SecureEmailBLL objectSecureEmailBll1, int returnMessageId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ExistingFileUpload Method with Param objSecureEmailModel: " + objSecureEmailModel + " and with Param objectSecureEmailBll1: " + objectSecureEmailBll1 + "and  with Param returnMessageId: " + returnMessageId);
                string sessionId = SetSessionId();
                if (objSecureEmailModel.Email.Attachment != null && (!string.IsNullOrEmpty(sessionId)))
                {
                    foreach (var file in objSecureEmailModel.Email.Attachment)
                    {
                        if (file != null)
                        {
                            int attachId = objectSecureEmailBll1.InsertTempMessageAttachment(objSecureEmailModel.Email.Userid, Constants.Internal, sessionId, file.FileName, file.FileContentBody);
                            objectSecureEmailBll1.InsertMessageAttachment(returnMessageId, objSecureEmailModel.Email.Userid, objSecureEmailModel.Email.Site, sessionId);
                            objectSecureEmailBll1.DeleteTempAttach(attachId, objSecureEmailModel.Email.Userid, sessionId, file.FileName);
                        }
                    }
                }
                traceLog.AppendLine(" & End: SecureEmailController, ExistingFileUpload Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Set user access
        /// </summary>
        /// <param name="entityObject"></param>
        private void SetUserAccess(SecureEmail entityObject1)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, SetUserAccess Method with Param entityObject1: " + entityObject1);
                UserDetails user = (UserDetails)Session[Constants.UserDetails];
                if (user != null)
                {
                    if (user.UserId != null)
                    {
                        entityObject1.Userid = user.UserId;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole))
                    {
                        entityObject1.Role = user.SelectedRole;
                    }
                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    entityObject1.Site = ConfigurationManager.AppSettings[Constants.Site];
                }
                traceLog.AppendLine(" & End: SecureEmailController, SetUserAccess Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Get user list 
        /// </summary>
        /// <param name="alphabet"></param>
        /// <param name="selectedGroup"></param>
        /// <returns>JsonResult</returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult ChangeUserList(string alphabet, string selectedGroup)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ChangeUserList Method with Param selectedGroup: " + selectedGroup);

                alphabet = AntiXssEncoder.HtmlEncode(alphabet, true);//Added on 17-Jul-18 to fix Reflected XSS   
                selectedGroup = AntiXssEncoder.HtmlEncode(selectedGroup, true);//Added on 17-Jul-18 to fix Reflected XSS
                //if(!string.IsNullOrEmpty(alphabet))
                //{
                //    alphabet = AntiXssEncoder.HtmlEncode(alphabet, true);//Added on 17-Jul-18 to fix Reflected XSS                
                //}
                //if(!string.IsNullOrEmpty(selectedGroup))
                //{
                //    selectedGroup = AntiXssEncoder.HtmlEncode(selectedGroup, true);//Added on 17-Jul-18 to fix Reflected XSS
                //}               
                SetUserAccess(entityObject);
                var userList = objectSecureEmailBll.GetJsonUserListByRole(alphabet, selectedGroup, entityObject.Userid, entityObject.Site);
                traceLog.AppendLine(" & End: SecureEmailController, ChangeUserList Method");
                return Json(userList, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// View customer service section in Secure mail
        /// </summary>
        /// <returns></returns>
        public ActionResult ViewAllCustomerService()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {

                traceLog.AppendLine("Start: SecureEmailController, ViewAllCustomerService Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return Content(Constants.ContentHome);
                }
                Session[Constants.Header] = Constants.SecureEmail;


                SetUserAccess(entityObject);
                entityObject.Userid = Constants.CustomerService;
                entityObject = objectSecureEmailBll.FetchAllEmail(entityObject);
                modelObject.Email = entityObject;
                traceLog.AppendLine(" & End: SecureEmailController, ViewAllCustomerService Method");
                return PartialView("_AllCustomerService", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// View mail in inbox or outbox of customer service
        /// </summary>
        /// <param name="inbox"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult ViewAllCustomerInboxOrOutbox(bool inbox)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ViewAllCustomerInboxOrOutbox Method with Param inbox: " + inbox);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, ViewAllCustomerInboxOrOutbox Method");
                    return Content(Constants.ContentHome);
                }
                SetUserAccess(entityObject);
                entityObject.Userid = Constants.CustomerService;
                entityObject = objectSecureEmailBll.FetchAllEmail(entityObject);
                modelObject.Email = entityObject;
                if (inbox)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, ViewAllCustomerInboxOrOutbox Method");
                    return PartialView("_AllCustomerInbox", modelObject);
                }
                else
                {
                    traceLog.AppendLine(" & End: SecureEmailController, ViewAllCustomerInboxOrOutbox Method");
                    return PartialView("_AllCustomerOutbox", modelObject);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// View a mail in inbox for customer service
        /// </summary>
        /// <param name="messageId"></param>
        /// <param name="originalMessageId"></param>
        /// <returns></returns>
        public ActionResult ViewCustomerServiceInbox(int messageId, int originalMessageId, string network)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ViewCustomerServiceInbox Method with Param messageId: " + messageId + " and with Param originalMessageId: " + originalMessageId + " and with Param  network: " + network);

                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, ViewCustomerServiceInbox Method");
                    return Content(Constants.ContentHome);
                }
                SetUserAccess(entityObject);
                entityObject.Userid = Constants.CustomerService;
                if (string.IsNullOrEmpty(network))
                {
                    objectSecureEmailBll.MarkMessageRead(messageId, entityObject.Userid, entityObject.Site);
                }
                entityObject = objectSecureEmailBll.FetchInboxEmailById(entityObject, messageId, originalMessageId);
                modelObject.Email = entityObject;
                traceLog.AppendLine(" & End: SecureEmailController, ViewCustomerServiceInbox Method");
                return PartialView("_CustomerService", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// View a mail in sent items for customer service 
        /// </summary>
        /// <param name="messageId"></param>
        /// <returns></returns>
        public ActionResult ViewCustomerServiceOutbox(int messageId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, ViewCustomerServiceOutbox Method with Param messageId: " + messageId);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return Content(Constants.ContentHome);
                }
                SetUserAccess(entityObject);
                entityObject.Userid = Constants.CustomerService;
                entityObject = objectSecureEmailBll.FetchOutboxEmailById(entityObject, messageId);
                modelObject.Email = entityObject;
                traceLog.AppendLine(" & End: SecureEmailController, ViewCustomerServiceOutbox Method");
                return PartialView("_CustomerServiceOutbox", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Load Compose email page for Customer Service
        /// </summary>
        /// <param name="modelObject1"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult CustomerNewMail(SecureEmailModel modelObject1)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, CustomerNewMail Method with Param modelObject1: " + modelObject1);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, CustomerNewMail Method");
                    return Content(Constants.ContentHome);
                }
                if (modelObject1 != null)
                {
                    string alphaConfig = AppSettingHelper.GetAppSettingValue(Constants.Alphabets);
                    string[] alphaConfigArray = alphaConfig.Split(',');
                    List<string> alphatest = alphaConfigArray.ToList();

                    SetUserAccess(entityObject);
                    entityObject.SendToDropDown = new List<SelectListItem>();
                    entityObject = objectSecureEmailBll.GetLookupRoles(entityObject);
                    if (String.IsNullOrEmpty(entityObject.Parameter))
                    {
                        entityObject.Parameter = Constants.AlphabetA;
                    }
                    if (String.IsNullOrEmpty(entityObject.SelectedGroup))
                    {
                        entityObject.SelectedGroup = Constants.Number1200;
                    }
                    entityObject = objectSecureEmailBll.GetUserListByRole(entityObject);

                    entityObject.Alpha = alphatest;
                    modelObject1.Email = entityObject;
                    if (modelObject1.Email.Site == Constants.Internal)
                    {
                        traceLog.AppendLine(" & End: SecureEmailController, CustomerNewMail Method");
                        return PartialView("_CustomerNewMail", modelObject1);
                    }
                }
                traceLog.AppendLine(" & End: SecureEmailController, CustomerNewMail Method");
                return Content("<script type='text/javascript'> window.location='/Error/Index'</script>");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Load Reply page for Customer Service
        /// </summary>
        /// <param name="modelObject1"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult CustomerReply(SecureEmailModel modelObject1)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, CustomerReply Method with Param modelObject1: " + modelObject1);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, CustomerReply Method");
                    return Content(Constants.ContentHome);
                }
                if (modelObject1 != null)
                {
                    SetUserAccess(modelObject1.Email);
                    modelObject1.Email.ViewMail.Subject = Constants.SubjectReplyAdder + modelObject1.Email.ViewMail.Subject;
                    modelObject1.Email.ViewMail.Content = GetBody(modelObject1);
                }
                traceLog.AppendLine(" & End: SecureEmailController, CustomerReply Method");
                return PartialView("_CustomerReplyMail", modelObject1);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Load Forward page for Customer Service
        /// </summary>
        /// <param name="modelObject1"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult CustomerForward(SecureEmailModel modelObject1)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, CustomerForward Method with Param modelObject1: " + modelObject1);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: SecureEmailController, CustomerForward Method");
                    return Content(Constants.ContentHome);
                }
                if (modelObject1 != null)
                {
                    if (modelObject1.Email != null)
                    {
                        SecureEmail entityObject1 = new SecureEmail();
                        SecureEmailBLL objectSecureEmailBll1 = new SecureEmailBLL();
                        entityObject1 = modelObject1.Email;
                        string alphaConfig = AppSettingHelper.GetAppSettingValue(Constants.Alphabets);
                        string[] alphaConfigArray = alphaConfig.Split(',');
                        List<string> alphatest = alphaConfigArray.ToList();

                        SetUserAccess(entityObject1);
                        entityObject1.SendToDropDown = new List<SelectListItem>();
                        entityObject1 = objectSecureEmailBll1.GetLookupRoles(entityObject1);
                        if (String.IsNullOrEmpty(entityObject1.Parameter))
                        {
                            entityObject1.Parameter = Constants.AlphabetA;
                        }
                        if (String.IsNullOrEmpty(entityObject1.SelectedGroup))
                        {
                            entityObject1.SelectedGroup = Constants.Number1200;
                        }
                        entityObject1 = objectSecureEmailBll1.GetUserListByRole(entityObject1);

                        if (entityObject1.UserSendToList != null && entityObject1.UserSendToList != Constants.UndefinedText)
                        {
                            modelObject1.Email.SendToDropDown = JSONParse(entityObject1.UserSendToList);
                        }

                        modelObject1.Email.Userid = ((UserDetails)Session[Constants.UserDetails]).UserId;
                        modelObject1.Email.ViewMail.Subject = Constants.SubjectForwardAdder + modelObject1.Email.ViewMail.Subject;
                        modelObject1.Email.ViewMail.Content = GetBody(modelObject1);
                        modelObject1.Email = objectSecureEmailBll1.FetchMailAttachmentById(modelObject1.Email, Convert.ToInt32(modelObject1.Email.ViewMail.OriginalMessageId, CultureInfo.InvariantCulture));
                        entityObject1.Alpha = alphatest;
                        modelObject1.Email = entityObject1;
                        if (modelObject1.Email.Site == Constants.Internal)
                        {
                            traceLog.AppendLine(" & End: SecureEmailController, CustomerForward Method");
                            return PartialView("_CustomerForwardMail", modelObject1);
                        }
                    }

                }
                traceLog.AppendLine(" & End: SecureEmailController, CustomerForward Method");
                return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// Mark the network flag
        /// </summary>
        /// <param name="messageId"></param>
        /// <param name="network"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public Boolean MarkNetworkStatus(string messageId, string network)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, MarkNetworkStatus Method with Param messageId: " + messageId + " and with Param network: " + network);
                SetUserAccess(entityObject);
                if (!string.IsNullOrEmpty(messageId) && !string.IsNullOrEmpty(network))
                {
                    entityObject = objectSecureEmailBll.GetMailUserInternal(entityObject);
                    traceLog.AppendLine(" & End: SecureEmailController, MarkNetworkStatus Method");
                    return (objectSecureEmailBll.MarkNetworkStatus(messageId, network, entityObject.Userid, entityObject.Site, entityObject.MailUser.Email));
                }
                else
                {
                    traceLog.AppendLine(" & End: SecureEmailController, MarkNetworkStatus Method");
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Set the network
        /// </summary>
        /// <returns></returns>
        private string SetNetwork()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, SetNetwork Method");
                string networkValue = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                                && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                                && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                {
                    //get selected role
                    Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                    //get the network for selcted function
                    List<string> networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuSecureEmail, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                    if (networkList.Count() == 1)
                    {
                        networkValue = networkList[0];
                    }
                }
                traceLog.AppendLine(" & End: SecureEmailController, SetNetwork Method");
                return networkValue;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch the filename from rooted path
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private string GetFileName(string fileNameValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: SecureEmailController, GetFileName Method");
                this.fileName = fileNameValue;
                if (System.IO.Path.IsPathRooted(fileName))
                {
                    traceLog.AppendLine(" & End: SecureEmailController, GetFileName Method");
                    return Path.GetFileName(IsValid(fileName) ? fileName : string.Empty);
                }
                traceLog.AppendLine(" & End: SecureEmailController, GetFileName Method");
                return fileName;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private bool IsValid(string fileName)
        {
            if (fileName.Contains(".."))
                return false;
            else
                return true;
        }
    }
}