﻿using NABWebsite.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading;
using System.Net;
using System.Globalization;
using NABWebsite.Models;
using Newtonsoft.Json;
using System.Text;
using Utilities;
using System.Web.Security.AntiXss;
using Newtonsoft.Json.Linq;

namespace NABWebsite
{
    public class BaseController : Controller
    {       
        protected override IAsyncResult BeginExecuteCore(AsyncCallback callback, object state)
        {
            StringBuilder traceLog = new StringBuilder();
            string cultureName = null;
            try
            {
                // Attempt to read the culture from session
                traceLog.AppendLine("Start: BaseController, BeginExecuteCore Method with Param callback: " + callback + "and with Param state: " + state);
                string cultureCookie = Session["_culture"] as string;
                if (cultureCookie != null)
                    cultureName = cultureCookie.ToString();
                else
                    cultureName = Request.UserLanguages != null && Request.UserLanguages.Length > 0 ? Request.UserLanguages[0] : null; // obtain it from HTTP header AcceptLanguages

                // Validate culture name
                cultureName = CultureHelper.GetImplementedCulture(cultureName); // This is safe

                // Set culture         
                // Modify current thread's cultures            
                Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(cultureName);
                Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentCulture;
                //Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.CreateSpecificCulture(cultureName);

                traceLog.AppendLine(" & End: BaseController, BeginExecuteCore Method");
                return base.BeginExecuteCore(callback, state);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);

                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        #region CaptchaVerify

        public bool ValidateCaptcha(string response, out string errorMessage)
        {
            response = AntiXssEncoder.HtmlEncode(response, true);
            StringBuilder traceLog = new StringBuilder();
            string secret = AppSettingHelper.GetAppSettingValue(VariableConstant.PrivateKey);
            errorMessage = string.Empty;
            try
            {
                traceLog.AppendLine("Start: BaseController, ValidateCaptcha Method with Param response: " + response);
                bool captchaVerify = Convert.ToBoolean(AppSettingHelper.GetAppSettingValue(VariableConstant.IsCaptchaCheck));
                bool isSuccess = true;
                string captchaErrorMessage = string.Empty;
                if (captchaVerify)
                {
                    var client = new WebClient();
                    var reply = client.DownloadString(string.Format(CultureInfo.CurrentCulture, AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleRecaptchaVerificationURL), secret, response));
                    //code change for Deserialization of Untrusted Data on 08/10/2018
                    
                    var jobj = JObject.Parse(reply);
                    isSuccess = (bool)jobj.SelectToken("success");
                    if (!isSuccess)
                    {
                        captchaErrorMessage = (string)jobj.SelectToken("error-codes");//captchaResponse.ErrorCodes[0].ToLower(CultureInfo.CurrentCulture);
                    }
                }

                //when response is false check for the error message
                if (!isSuccess)
                {
                    switch (captchaErrorMessage)
                    {
                        case ("missing-input-secret"):
                            errorMessage = "The secret parameter is missing.";
                            break;
                        case ("invalid-input-secret"):
                            errorMessage = "The secret parameter is invalid or malformed.";
                            break;
                        case ("missing-input-response"):
                            errorMessage = "The response parameter is missing.";
                            break;
                        case ("invalid-input-response"):
                            errorMessage = "The response parameter is invalid or malformed.";
                            break;

                        default:
                            errorMessage = "Error occured. Please try again";
                            break;
                    }
                }
                traceLog.AppendLine(" & End: BaseController, ValidateCaptcha Method");
                return isSuccess;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);

                throw;
            }
            finally
            {
                traceLog.Append(errorMessage.ToString());
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion

    }
}