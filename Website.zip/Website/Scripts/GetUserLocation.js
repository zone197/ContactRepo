﻿var SAMPLE_POST_REVERSE = 'https://www.mapquestapi.com' + '/geocoding/v1/reverse?key=YOUR_KEY_HERE&callback=renderReverse';
var safe = '';
var tempaddress = '';
var tempEmail = '';
var tempGateWay = '';
var tempPhoneNumber = '';
var tempcaptchaResponse = '';
var tempProviderNumber = '';
var tempProviderNameDegree = '';
var tempForgeryId = '';
function getLocation(email, phoneNumberCarrier, phoneNumber, address, captchaResponse, ProviderNumber, providerNameDegree, forgeryId) {
    if (navigator.geolocation) {
        tempaddress = address;
        tempEmail = email;
        tempGateWay = phoneNumberCarrier;
        tempPhoneNumber = phoneNumber;
        tempProviderNumber = ProviderNumber;
        tempcaptchaResponse = captchaResponse;
        tempProviderNameDegree = providerNameDegree;
        tempForgeryId = forgeryId;
        navigator.geolocation.getCurrentPosition(showPosition);
    }
    else {
        alert('Geolocation is not supported');
    }

}
function errorCallback() {
   alert("please enable share location service to send direction")
}
function ShowPositionTest(email, phoneNumberCarrier, phoneNumber, address, captchaResponse, ProviderNumber, providerNameDegree, forgeryId) {
    ////debugger;
    tempaddress = address;
    tempEmail = email;
    tempGateWay = phoneNumberCarrier;
    tempPhoneNumber = phoneNumber;
    tempProviderNumber = ProviderNumber;
    tempcaptchaResponse = captchaResponse;
    tempProviderNameDegree = providerNameDegree;
    tempForgeryId = forgeryId;
    var script = document.createElement('script');
    
    script.type = 'text/javascript';
    //var latitude = position.coords.latitude;
    //var longitude = position.coords.longitude;

    var latitude = 40.053116;
    var longitude = -76.313603;

    safe = SAMPLE_POST_REVERSE;
    safe += '&json={';
    safe += 'location:{latLng:{lat:' + latitude + ',lng:' + longitude + '}}}';
    var MapQuestConsumerKeyPublic = GetResources('MapQuestConsumerKeyPublic');
    var newURL = safe.replace('YOUR_KEY_HERE', MapQuestConsumerKeyPublic);
    script.src = newURL;
    document.body.appendChild(script);
}

function showPosition(position) {
    ////debugger;
    var script = document.createElement('script');
    script.type = 'text/javascript';
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;

    //var latitude = 40.053116;
    //var longitude = -76.313603;

    safe = SAMPLE_POST_REVERSE;
    safe += '&json={';
    safe += 'location:{latLng:{lat:' + latitude + ',lng:' + longitude + '}}}';
    var MapQuestConsumerKeyPublic = GetResources('MapQuestConsumerKeyPublic');
    var newURL = safe.replace('YOUR_KEY_HERE', MapQuestConsumerKeyPublic);
    script.src = newURL;
    document.body.appendChild(script);
}

function SanitizeStr(string) { // Added Sept 26, 2018 - Client Heuristic Poor XSS Validation
    var map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;',
        "/": '&#x2F;',
    };
    //const reg = /[&<>"'/]/ig;
    //return string.replace(reg, (match)=>(map[match]));
    return s.replace(s ? /[&<>'"]/g : /[&<>]/g, function (i) {
        return map[i];
    });
}

function renderReverse(response) {
    ////debugger;
    var location = response.results[0].locations[0];
    // Edited by NAB-IT on 05April2018 for perameter encoding
    var fromAddress = SanitizeStr(location.street) + ',' + SanitizeStr(location.adminArea5) + ',' + SanitizeStr(location.adminArea3) + ',' + SanitizeStr(location.postalCode);// Updated Sept 26, 2018 - Client Heuristic Poor XSS Validation
    var SAMPLE_POST = 'https://www.mapquestapi.com' + '/directions/v2/route?key=YOUR_KEY_HERE&from=' + fromAddress + '&to=' + tempaddress + '&callback=renderNarrative';

    var script = document.createElement('script');
    script.type = 'text/javascript';
    var MapQuestConsumerKeyPublic = GetResources('MapQuestConsumerKeyPublic');
    var newURL = SAMPLE_POST.replace('YOUR_KEY_HERE', MapQuestConsumerKeyPublic);
    script.src = encodeURI(newURL);// Edited by NAB-IT on 05April2018 for ulr encoding
    document.body.appendChild(script);
}

function renderNarrative(response) {
    ////debugger;
    var legs = response.route.legs;
    var unit = response.route.options.unit;
    var ProviderDirectionPath = new Array();
    var i = 0;
    var j = 0;
    var trek;
    var maneuver;

    for (; i < legs.length; i++) {
        for (j = 0; j < legs[i].maneuvers.length; j++) {
            var DirectionPath = new Object();
            var IconUrl;
            var SignUrl = new Array();
            var Narrative;
            var MapUrl;
            var Distance;
            var FormattedTime;
            maneuver = legs[i].maneuvers[j];


            if (maneuver.iconUrl) {
                IconUrl = maneuver.iconUrl;
            }
            for (k = 0; k < maneuver.signs.length; k++) {
                var sign = maneuver.signs[k];
                SignUrl.push(sign.url);
            }


            Narrative = maneuver.narrative;
            if (maneuver.mapUrl) {
                MapUrl = maneuver.mapUrl;
            }

            DirectionPath.IconUrl = IconUrl;
            DirectionPath.Narrative = Narrative;
            DirectionPath.MapUrl = MapUrl;
            DirectionPath.SignUrl = SignUrl;
            DirectionPath.Distance = maneuver.distance.toFixed(2);
            DirectionPath.Unit = unit;
            ProviderDirectionPath.push(DirectionPath);
        }
    }
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/GetDirection',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        data: JSON.stringify({ direction: ProviderDirectionPath, emailAddress: tempEmail, carrier: tempGateWay, phoneNumber: tempPhoneNumber, captcha: tempcaptchaResponse, providerNumber: tempProviderNumber, providerNameDegree: tempProviderNameDegree, providerAddress: tempaddress}),
        headers: {
            'VerificationToken': tempForgeryId
        },
        success: function (result) {
            ////debugger;
            if (result == true) {
                $('#success_message').slideDown({ opacity: "show" }, "slow")
                setTimeout(function () {
                    $('#success_message').fadeOut(1500);
                }, 5000);
                //$("#emailConfirmation").html("Email sent successfully. page will be redirected to search result shortly.");
                $("#btnSendMail").prop("disabled", true);
                window.location.href = '/LocateProvider/LocateProviderSearchResult/';
            }
            else if (result == false) {
                $("#emailConfirmation").html("Email/Text not sent. please try again.");
                //grecaptcha.reset();
            }
            else {
                $("#emailConfirmation").html("Email/Text not sent. please try again.");
                //grecaptcha.reset();
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            
            //grecaptcha.reset();
        }
    });
    
}
