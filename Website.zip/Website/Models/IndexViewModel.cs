﻿using System.Collections.Generic;


namespace NABWebsite.Models
{
    public class IndexViewModel
    {
        public List<RightSectionGenericContainer> ListGenContainer { get; set; }
        public List<RightSectionNewsContainer> ListNewsContainer { get; set; }
        public ContentViewModel Content { get; set; }
        
        
    }
}