﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System.Xml;
using System.Configuration;
using System.Collections.ObjectModel;
using System.Data;
using System.Globalization;
using NABResources;
using System.Text;
using System.ServiceModel;
using System.Web.Security.AntiXss;
using Utilities;

namespace NABWebsite.Controllers
{
    public class TransplantController : Controller
    {
        TransplantBusinessLayer bllObject = null;
        //StringBuilder traceLog = new StringBuilder();

        /// <summary>
        /// Generates the Map to view 
        /// </summary>
        /// <returns></returns>
        public ActionResult Map()
        {
            return View();
        }

        /// <summary>
        /// Code to populate states of map on click
        /// </summary>
        /// <param name="state"></param>
        /// <param name="stateCode"></param>
        /// <param name="height"></param>
        /// <param name="width"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult StateMap(string state, string stateCode, int height, int width)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {                
                    traceLog.AppendLine("Start: TransplantController, StateMap Method with Param state: " + state + " and with Param stateCode: " + stateCode + " and with Param height: " + height + " and with Param width: " + width);
                    state = AntiXssEncoder.HtmlEncode(Request.Form["State"], true);
                    stateCode = AntiXssEncoder.HtmlEncode(Request.Form["StateCode"], true);
                   // height =  //AntiXssEncoder.HtmlEncode(Request.Form["height"], true);
                   // width = //AntiXssEncoder.HtmlEncode(Request.Form["width"], true);

                    CenterList centerList = null;
                    StateDetailsInformation model = null;
                    List<StateDetailsInformation> stateList = null;                   
                        if (!string.IsNullOrEmpty(state))
                        {
                            centerList = new CenterList();
                            stateList = new List<StateDetailsInformation>();
                            var document = new XmlDocument();
                            document.Load(ConfigurationManager.AppSettings.Get(Constants.MapInformation));
                            document.LoadXml(document.InnerXml.ToString());



                            // Sanitize input using custom encoding
                            string sanitizedState = System.Text.RegularExpressions.Regex.Replace(state, @"[^a-z^0-9^ ^-^_]", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                            /*
                            // Alternatively, can validate input by casting to integer
                            string sanitizedUserId = Int32.Parse(userId).ToString();
                            */

                            XmlNodeList stateXmlNodeList = document.SelectNodes(Constants.StateXmlStartRoot + (Validation.IsAlphaWithSpace(sanitizedState) ? sanitizedState : string.Empty) + Constants.StateXmlEndRoot);
                            if (stateXmlNodeList.Count > 0)
                            {
                                foreach (XmlNode node in stateXmlNodeList)
                                {
                                    model = new StateDetailsInformation();
                                    model.StateName = state;
                                    model.Coordinates = node[Constants.Coordinates].InnerText;
                                    model.Title = node[Constants.Title].InnerText;
                                    model.Description = node[Constants.Description].InnerText;
                                    model.AreaId = node[Constants.Coordinates].InnerText.Substring(0, 2);
                                    stateList.Add(model);
                                }
                            }
                            centerList.ImageHeight = height;
                            centerList.ImageWidth = width;
                            centerList.ImageId = stateCode;
                            centerList.ImagePath = string.Concat(Constants.MapImagePath, stateCode, Constants.ConstantJpg);
                            centerList.ImageUseMap = string.Concat(Constants.ConstantHash, stateCode);
                            centerList.ImageMapId = string.Concat(Constants.ConstantUnderScore, stateCode);
                            if (stateList != null)
                                centerList.CenterInformation = stateList;
                        }
                        traceLog.AppendLine(" & End: TransplantController, StateMap Method");                    
                return View(centerList);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        #region Payer-Provider Tools

        /// <summary>
        /// To get the pdf for Tools
        /// </summary>
        /// <returns></returns>
        public ActionResult ToolTransplantFacilityList(string formMenu)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: TransplantController, ToolTransplantFacilityList Method with Param formMenu: " + formMenu);
                bllObject = new TransplantBusinessLayer();
                ClientSecureDocumentFileContent entity = null;
                string fileName = "";
                if (!string.IsNullOrEmpty(formMenu))
                {
                    entity = bllObject.FacilityNetworkList(formMenu);
                    if (formMenu.Equals(Constants.ClientListFormMenu))
                        fileName = Constants.InlineFileName + Constants.ClientListFileName;
                    //Response.AddHeader(Constants.ContentDisposition, Constants.InlineFileName + Constants.ClientListFileName);
                    else if (formMenu.Equals(Constants.FacilityListFormMenu))
                        fileName = Constants.InlineFileName + Constants.FacilityListFileName;
                    //Response.AddHeader(Constants.ContentDisposition, Constants.InlineFileName + Constants.FacilityListFileName);
                }
                if (entity == null)
                    throw new FaultException(Constants.ApplicationError);
                // return File(entity.FileContent, Constants.ResponseContentPdf);
                traceLog.AppendLine(" & End: TransplantController, ToolTransplantFacilityList Method");
                return File(entity.FileContent, "application/octet-stream", fileName);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        #endregion

        #region Payer-Provider Reports

        /// <summary>
        /// Get all Reports
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formMenu"></param>
        /// <returns></returns>
        public ActionResult ClientSpecificAllReports(TransplantResultsModel model, string formMenu)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: TransplantController, ClientSpecificAllReports Method with Param model: " + model + " and with Param formMenu: " + formMenu);
                bllObject = new TransplantBusinessLayer();
                TransplantResultDetails reportEntity = null;
                if (model == null)
                    model = new TransplantResultsModel();
                if (model.SearchResultParameter == null)
                {
                    model.SearchResultParameter = new SearchResultFilterValue();
                    model.SearchResultParameter.PageNo = Constants.OneCount;
                    model.SearchResultParameter.SortBy = Constants.DefaultSortBy;
                    model.SearchResultParameter.SortType = Constants.DefaultSortType;
                    model.DisplaySize = Constants.Ten;
                }
                model.DisplaySizeList = PopulateDisplaySize();
                string roleLogin = ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() != null ? ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant().ToString() : null;
                if (!string.IsNullOrEmpty(roleLogin))
                    model.Role = roleLogin;
                model.FormMenu = formMenu;
                reportEntity = bllObject.ReportList(model.Role, model.FormMenu, model.CompanyName, model.SearchResultParameter.PageNo, Convert.ToInt32(model.DisplaySize, CultureInfo.InvariantCulture), model.SearchResultParameter.SortBy, model.SearchResultParameter.SortType);
                //Provider and Payer reports --adding header according to the requirement
                if (!string.IsNullOrEmpty(model.Role))
                {
                    if (model.Role.Equals(Constants.Payer.ToUpperInvariant()))
                    {
                        if (model.FormMenu.Equals(Constants.All))
                        {
                            model.Header = Constants.ViewClientReportsHeader;
                        }
                        else if (model.FormMenu.Equals(Constants.ClaimFormMenu))
                        {
                            model.Header = Constants.ViewClaimReportsHeader;
                        }
                    }
                    else if (model.Role.Equals(Constants.Provider.ToUpperInvariant()))
                    {
                        string site = System.Configuration.ConfigurationManager.AppSettings[Constants.Site];
                        if (site.Equals(Constants.Internal))
                            model.Header = Constants.ViewFacilityReportsHeader;
                        else
                            model.Header = Constants.ViewReportsHeader;
                    }
                }
                if (reportEntity == null)
                    throw new FaultException(Constants.ApplicationError);
                Collection<DisplayList> loadReportOption = new Collection<DisplayList>();
                if (reportEntity.DisplayResultsList.Count() > 0)
                {
                    foreach (var report in reportEntity.DisplayResultsList)
                    {
                        DisplayList clientReport = new DisplayList();
                        clientReport.FileId = report.FileId;
                        clientReport.FileName = report.FileName;
                        clientReport.FileTitle = report.FileTitle;
                        clientReport.Description = report.Description;
                        clientReport.CompanyName = report.CompanyName;
                        clientReport.CreatedDate = report.CreatedDate;
                        clientReport.ExpirationDate = report.ExpirationDate;
                        clientReport.LastModifiedDate = report.LastModifiedDate;
                        loadReportOption.Add(clientReport);
                    }
                    model.AllDisplayResults = loadReportOption;
                    model.SearchResultParameter.TotalPages = reportEntity.TotalPage == Constants.ZeroCount ? Constants.OneCount : reportEntity.TotalPage;
                }
                else
                {
                    if (!string.IsNullOrEmpty(model.Role))
                    {
                        if (model.Role.Equals(Constants.Payer.ToUpperInvariant()))
                        {
                            if (model.FormMenu.Equals(Constants.All))
                            {
                                model.Message = Resources.lblNoReportsFound;
                            }
                            else if (model.FormMenu.Equals(Constants.ClaimFormMenu))
                            {
                                model.Message = Resources.lblNoClaimsAvailable;
                            }
                        }
                        else if (model.Role.Equals(Constants.Provider.ToUpperInvariant()))
                        {
                            model.Message = Resources.lblNoReportsFound;
                        }
                    }
                }
                traceLog.AppendLine(" & End: TransplantController, ClientSpecificAllReports Method");
                return View(model);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private static Collection<SelectListItem> PopulateDisplaySize()
        {
            Collection<SelectListItem> loadDisplaySizeCollection = new Collection<SelectListItem>();
            loadDisplaySizeCollection.Add(new SelectListItem { Text = Resources.Ten, Value = Resources.Ten, Selected = true });
            loadDisplaySizeCollection.Add(new SelectListItem { Text = Resources.TwentyFive, Value = Resources.TwentyFive });
            loadDisplaySizeCollection.Add(new SelectListItem { Text = Resources.Fifty, Value = Resources.Fifty });
            loadDisplaySizeCollection.Add(new SelectListItem { Text = Resources.Hundred, Value = Resources.Hundred });
            return loadDisplaySizeCollection;
        }

        /// <summary>
        /// Get reports file content
        /// </summary>
        /// <param name="fileId"></param>
        /// <returns></returns>
        public ActionResult ClientSecuredDocFileContent(int fileId, string fileName, string role, string formMenu)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: TransplantController, ClientSecuredDocFileContent Method with Param fileId: " + fileId + " and with Param fileName: " + fileName + " and with Param role: " + role + " and with Param formMenu: " + formMenu);
                bllObject = new TransplantBusinessLayer();
                ClientSecureDocumentFileContent result = null;
                if (!string.IsNullOrEmpty(role) && !String.IsNullOrEmpty(formMenu))
                {
                    result = bllObject.ClientSecuredDocFileContent(role, formMenu, fileId);
                }
                if (result == null)
                    throw new FaultException(Constants.ApplicationError);
                if (!fileName.Contains("\n"))  //Added on 23-Jul-18 to fix HTTP Response Splitting
                {
                    fileName = HttpUtility.UrlEncode(fileName);
                    Response.AddHeader(Constants.ContentDisposition, Constants.InlineFileName + fileName);
                }
                traceLog.AppendLine(" & End: TransplantController, ClientSecuredDocFileContent Method");
                return File(result.FileContent, Constants.ResponseContent + fileName.Substring(fileName.IndexOf('.') + 1));
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
           
        }

        #endregion

        #region Payer-Provider Manual & forms
        /// <summary>
        /// Get all manual information
        /// </summary>
        /// <param name="model"></param>
        /// <param name="fileType"></param>
        /// <returns></returns>
        public ActionResult ViewTransplantManualsAndForms(TransplantResultsModel model, string fileType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: TransplantController, ViewTransplantManualsAndForms Method with Param model: " + model + " and with Param fileType: " + fileType);
                bllObject = new TransplantBusinessLayer();
                TransplantResultDetails resultEntity = null;
                if (model == null)
                    model = new TransplantResultsModel();

                if (model.SearchResultParameter == null)
                {
                    model.SearchResultParameter = new SearchResultFilterValue();
                    model.SearchResultParameter.PageNo = Constants.OneCount;
                    model.SearchResultParameter.SortBy = Constants.DefaultSortBy;
                    model.SearchResultParameter.SortType = Constants.DefaultSortType;

                }
                if (model.DisplaySize == null)
                    model.DisplaySize = Constants.Ten;
                model.DisplaySizeList = PopulateDisplaySize();
                string roleLogin = ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() != null ? ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant().ToString() : null;
                if (!string.IsNullOrEmpty(roleLogin))
                    model.Role = roleLogin;
                model.FileType = fileType;
                resultEntity = bllObject.ManualInformation(model.Role, model.FileType, model.SearchResultParameter.PageNo, Convert.ToInt32(model.DisplaySize, CultureInfo.InvariantCulture), model.SearchResultParameter.SortBy, model.SearchResultParameter.SortType);
                if (model.FileType.Equals(Constants.ManualFormMenu))
                {
                    model.DisplaySizeText = Constants.ViewManualsDisplaySizeHeading;
                    if (model.Role.Equals(Constants.Provider.ToUpperInvariant()))
                        model.Header = Constants.ViewProviderManualHeader;
                    else if (model.Role.Equals(Constants.Payer.ToUpperInvariant()))
                        model.Header = Constants.ViewPayerManualHeader;
                }
                else if (model.FileType.Equals(Constants.FormsMenu))
                {
                    model.DisplaySizeText = Constants.ViewFormsDisplaySizeHeading;
                    model.Header = Constants.ViewFormsHeader;
                }

                if (resultEntity == null)
                    throw new FaultException(Constants.ApplicationError);
                Collection<DisplayList> loadManualOption = new Collection<DisplayList>();
                if (resultEntity.DisplayResultsList.Count() > 0)
                {
                    foreach (var report in resultEntity.DisplayResultsList)
                    {
                        DisplayList displayList = new DisplayList();
                        displayList.FileId = report.FileId;
                        displayList.FileName = report.FileName;
                        displayList.FileType = report.FileType;
                        displayList.FileTitle = report.FileTitle;
                        displayList.Description = report.Description;
                        displayList.CreatedDate = report.CreatedDate;
                        displayList.ExpirationDate = report.ExpirationDate;
                        displayList.LastModifiedDate = report.LastModifiedDate;
                        displayList.OnlineForm = report.OnlineForm;
                        loadManualOption.Add(displayList);
                    }
                    model.AllDisplayResults = loadManualOption;
                    model.SearchResultParameter.TotalPages = resultEntity.TotalPage == Constants.ZeroCount ? Constants.OneCount : resultEntity.TotalPage;
                }
                else
                {
                    if (model.FileType.Equals(Constants.ManualFormMenu))
                    {
                        model.Message = Resources.lblNoManualsAvailable;
                    }
                    else if (model.FileType.Equals(Constants.FormsMenu))
                    {
                        model.Message = Resources.lblNoFormsAvailable;
                    }
                }
                traceLog.AppendLine(" & End: TransplantController, ViewTransplantManualsAndForms Method");
                return View(model);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get manuals file content
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public ActionResult ManualFileContent(int fileId, string fileName)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: TransplantController, ManualFileContent Method with Param fileId: " + fileId + " and with Param fileName: " + fileName);
                bllObject = new TransplantBusinessLayer();
                string roleLogin = ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() != null ? ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant().ToString() : null;
                ClientSecureDocumentFileContent result = null;
                if (fileId > 0 && !string.IsNullOrEmpty(fileName) && !string.IsNullOrEmpty(roleLogin))
                {
                    result = bllObject.SecuredManualDocFileContent(fileId, roleLogin);
                }
                if (result == null)
                    throw new FaultException(Constants.ApplicationError);
                if (!fileName.Contains("\n")) //Added on 23-Jul-18 to fix HTTP Response Splitting
                {
                    fileName = HttpUtility.UrlEncode(fileName);
                    Response.AddHeader(Constants.ContentDisposition, Constants.InlineFileName + fileName);
                }
                traceLog.AppendLine(" & End: TransplantController, ManualFileContent Method");
                return File(result.FileContent, Constants.ResponseContent + fileName.Substring(fileName.IndexOf('.') + 1));
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
          
        }

        #endregion

        /// <summary>
        /// ‘Online Transplant Notification Form’
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns></returns>
        public ActionResult OnlineTransplantForm()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: TransplantController, OnlineTransplantForm Method");
                OnlineTransplantFormModel modelObject = new OnlineTransplantFormModel();
                if (modelObject != null)
                {
                    modelObject.ClientStateList = TransplantBusinessLayer.FetchStateList();
                    modelObject.FacilityStateList = TransplantBusinessLayer.FetchStateList();
                    modelObject.PatientStateList = TransplantBusinessLayer.FetchStateList();
                    modelObject.PatientGenderList = TransplantBusinessLayer.FetchGenderList();
                    modelObject.PatientOutOfPocketList = TransplantBusinessLayer.FetchPatientOutOfPocketList();
                    modelObject.Patient500KChecklist = TransplantBusinessLayer.FetchPatient500KChecklist();
                }

                traceLog.AppendLine(" & End: TransplantController, OnlineTransplantForm Method");
                return View(modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// ‘Online Transplant Notification Form User clicks on submit button’
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineTransplantForm(OnlineTransplantFormModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: TransplantController, OnlineTransplantForm Method with Param modelObject: " + modelObject);
                bllObject = new TransplantBusinessLayer();
                if (modelObject != null)
                {
                    OnlineTransplantForm onlineTransplantForm = new OnlineTransplantForm();
                    onlineTransplantForm.ClientName = modelObject.ClientName;
                    onlineTransplantForm.ClientIdNumber = modelObject.ClientIdNumber;
                    onlineTransplantForm.ClientCaseManager = modelObject.ClientCaseManager;
                    onlineTransplantForm.ClientTelephoneNumber1 = modelObject.ClientTelephoneNumber1;
                    onlineTransplantForm.ClientTelephoneNumber2 = modelObject.ClientTelephoneNumber2;
                    onlineTransplantForm.ClientPayerEligibilityContact = modelObject.ClientPayerEligibilityContact;
                    onlineTransplantForm.ClientPayerCaseManagerEmailAddress = modelObject.ClientPayerCaseManagerEmailAddress;
                    onlineTransplantForm.ClientFaxNumber = modelObject.ClientFaxNumber;
                    onlineTransplantForm.ClientPayerStreet = modelObject.ClientPayerStreet;
                    onlineTransplantForm.ClientClaimPlatform = modelObject.ClientClaimPlatform;
                    onlineTransplantForm.ClientCity = modelObject.ClientCity;


                    if (modelObject.ClientIsUSClient)
                    {
                        onlineTransplantForm.ClientCountry = Constants.TransplantClientUSACountry;
                        onlineTransplantForm.ClientState = modelObject.ClientState;
                    }
                    else
                    {
                        onlineTransplantForm.ClientCountry = modelObject.ClientCountry;
                        onlineTransplantForm.ClientState = modelObject.ClientNonUSState;
                    }
                    onlineTransplantForm.ClientZipCode = modelObject.ClientZipCode;

                    onlineTransplantForm.FacilityName = modelObject.FacilityName;
                    onlineTransplantForm.FacilityContact = modelObject.FacilityContact;
                    onlineTransplantForm.FacilityProgramType = modelObject.FacilityProgramType;
                    onlineTransplantForm.FacilityTelephoneNumber = modelObject.FacilityTelephoneNumber;
                    onlineTransplantForm.FacilityEmailAddress = modelObject.FacilityEmailAddress;
                    onlineTransplantForm.FacilityFax = modelObject.FacilityFax;
                    onlineTransplantForm.FacilityStreet = modelObject.FacilityStreet;
                    onlineTransplantForm.FacilityCity = modelObject.FacilityCity;
                    onlineTransplantForm.FacilityState = modelObject.FacilityState;
                    onlineTransplantForm.FacilityZipCode = modelObject.FacilityZipCode;
                    onlineTransplantForm.PatientName = modelObject.PatientName;
                    onlineTransplantForm.PatientDateOfBirth = Convert.ToString(modelObject.PatientDateOfBirth, CultureInfo.InvariantCulture);

                    onlineTransplantForm.PatientGender = modelObject.PatientGender;
                    onlineTransplantForm.PatientTelephoneNumber = modelObject.PatientTelephoneNumber;
                    onlineTransplantForm.PatientInsuranceIdNumber = modelObject.PatientInsuranceIdNumber;
                    onlineTransplantForm.PatientCoverageEffectiveDate = Convert.ToString(modelObject.PatientCoverageEffectiveDate, CultureInfo.InvariantCulture);
                    onlineTransplantForm.PatientInsuredName = modelObject.PatientInsuredName;
                    onlineTransplantForm.PatientsDiagnosis = modelObject.PatientsDiagnosis;
                    onlineTransplantForm.PatientIcdCode = modelObject.PatientIcdCode;
                    onlineTransplantForm.PatientStreet = modelObject.PatientStreet;
                    onlineTransplantForm.PatientCity = modelObject.PatientCity;
                    onlineTransplantForm.PatientState = modelObject.PatientState;
                    onlineTransplantForm.PatientZipCode = modelObject.PatientZipCode;
                    onlineTransplantForm.Patient500KCheck = modelObject.Patient500KCheck;
                    onlineTransplantForm.PatientCoverageDetail = modelObject.PatientCoverageDetail;
                    onlineTransplantForm.PatientInsuranceResponsibility = modelObject.PatientInsuranceResponsibility;
                    onlineTransplantForm.PatientOutOfPocket = modelObject.PatientOutOfPocket;

                    if (bllObject.InsertTransplantOnlineForm(onlineTransplantForm))
                    {
                        if (SendMailtoUser())
                        {
                            traceLog.AppendLine(" & End: TransplantController, OnlineTransplantForm Method");
                            return Content(Constants.SendEmailUserAlert + Constants.TransplantSuccessMessage + Constants.SendEmailUserAlertEnd);
                        }
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: TransplantController, OnlineTransplantForm Method");
                        return Content(Constants.SendEmailUserAlert + Constants.TransplantFailureMessage + Constants.SendEmailUserAlertEnd);
                    }

                }
                modelObject.ClientStateList = TransplantBusinessLayer.FetchStateList();
                modelObject.FacilityStateList = TransplantBusinessLayer.FetchStateList();
                modelObject.PatientStateList = TransplantBusinessLayer.FetchStateList();
                modelObject.PatientGenderList = TransplantBusinessLayer.FetchGenderList();
                modelObject.PatientOutOfPocketList = TransplantBusinessLayer.FetchPatientOutOfPocketList();
                modelObject.Patient500KChecklist = TransplantBusinessLayer.FetchPatient500KChecklist();
                traceLog.AppendLine(" & End: TransplantController, OnlineTransplantForm Method");
                return View(modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Send Email To user
        /// </summary>
        /// <returns></returns>
        public bool SendMailtoUser()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: TransplantController, SendMailtoUser Method");
                bool result = false;
                string fromMailAddress = Constants.TransplantFromMailAddress;
                List<string> mailAddress = new List<string>();
                mailAddress.Add(Constants.TransplantToMailAddress);
                string subject = Constants.TransplantMailSubject;
                string body = GetEmailBodyUser();
                result = bllObject.SendMailtoUser(body, fromMailAddress, mailAddress.ToArray(), subject);
                traceLog.AppendLine(" & End: TransplantController, SendMailtoUser Method");
                return result;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private static string GetEmailBodyUser()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: TransplantController, GetEmailBodyUser Method");
                StringBuilder mailBody = new StringBuilder();
                mailBody.Append(Constants.TransplantMessageLine1);
                mailBody.Append(Constants.TransplantMessageLine2);
                mailBody.Append(Constants.TransplantMessageLine3);
                mailBody.Append(Constants.TransplantMessageLine4);
                traceLog.AppendLine(" & End: TransplantController, GetEmailBodyUser Method");
                return mailBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

    }
}