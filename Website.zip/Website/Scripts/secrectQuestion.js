﻿

$("#securityAnswer1").bind("focus change keyup input", function () {
    if (this.value) {
        $('#eyeAns1').show();
    } else {
        $('#eyeAns1').hide();
    }
});
$("#securityAnswer2").bind("focus change keyup input", function () {
    if (this.value) {
        $('#eyeAns2').show();
    } else {
        $('#eyeAns2').hide();
    }
});
$("#securityAnswer3").bind(" focus change keyup input", function () {
    if (this.value) {
        $('#eyeAns3').show();
    } else {
        $('#eyeAns3').hide();
    }
});


$('#eyeAns1').hover(function () {
    $('#securityAnswer1').attr('type', 'text');
}, function () {
    $('#securityAnswer1').attr('type', 'password');
});

$('#eyeAns2').hover(function () {
    $('#securityAnswer2').attr('type', 'text');
}, function () {
    $('#securityAnswer2').attr('type', 'password');
});

$('#eyeAns3').hover(function () {
    $('#securityAnswer3').attr('type', 'text');
}, function () {
    $('#securityAnswer3').attr('type', 'password');
});

$("#securityAnswer1").on("blur", function () {
    $('#eyeAns1').hide();
});

$("#securityAnswer2").on("blur", function () {
    $('#eyeAns2').hide();
});
$("#securityAnswer3").on("blur", function () {
    $('#eyeAns3').hide();
});
