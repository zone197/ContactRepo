﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System.Text;
using System.DirectoryServices;
using System.Globalization;
using System.Configuration;
using Utilities;

namespace NABWebsite.Controllers
{
    public class MyProfileController : Controller
    {
        MyProfileBLL bllObj = new MyProfileBLL();
        MyProfile dtoObj = new MyProfile();
        MyProfileModel objMyProfileModel = new MyProfileModel();
        //StringBuilder traceLog = new StringBuilder();
        private string userName;
        /// <summary>
        /// Loads the profile page
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: MyProfileController, Index Method");
                    return RedirectToAction("Index", "Home");
                }
                MyProfileModel modelObj = new MyProfileModel();
                modelObj.MyProfile = dtoObj;
                SetUserAccess(modelObj.MyProfile);
                traceLog.AppendLine(" & End: MyProfileController, Index Method");
                return View(modelObj);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Set the user role,usertype,userid
        /// </summary>
        /// <param name="myProfile"></param>
        private void SetUserAccess(MyProfile myProfileValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, SetUserAccess Method with Param myProfileValue: " + myProfileValue);
                this.dtoObj = myProfileValue;
                UserDetails user = (UserDetails)Session[Constants.UserDetails];
                if (user != null)
                {
                    if (!string.IsNullOrEmpty(user.UserId))
                    {
                        dtoObj.Userid = user.UserId;
                    }
                    if (!string.IsNullOrEmpty(user.SelectedRole))
                    {
                        dtoObj.UserRole = user.SelectedRole;
                    }
                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    dtoObj.UserType = ConfigurationManager.AppSettings[Constants.Site];
                }
                traceLog.AppendLine(" & End: MyProfileController, SetUserAccess Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Loads the change password partial view
        /// </summary>
        /// <param name="modelObj"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult GetPassword(MyProfileModel modelObj)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, GetPassword Method with Param modelObj: " + modelObj);
                if (modelObj != null)
                {
                    modelObj.MyProfile = dtoObj;
                }
                traceLog.AppendLine(" & End: MyProfileController, GetPassword Method");
                return PartialView("_ChangePassword", modelObj);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Update the new password
        /// </summary>
        /// <param name="modelObj"></param>
        /// <returns></returns>
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword(MyProfileModel modelObj)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, ChangePassword Method with Param modelObj: " + modelObj);
                string message = string.Empty;
                string userId = string.Empty;
                modelObj.MyProfile.OldPrd = Helper.AESEncrypt.DecryptStringAES(modelObj.MyProfile.OldPrd); // Updated Sept 21, 2018 - Heap Inspection
                modelObj.MyProfile.NewPrd = Helper.AESEncrypt.DecryptStringAES(modelObj.MyProfile.NewPrd); // Updated Sept 21, 2018 - Heap Inspection
                modelObj.MyProfile.NewPrdAgain = Helper.AESEncrypt.DecryptStringAES(modelObj.MyProfile.NewPrdAgain); // Updated Sept 21, 2018 - Heap Inspection
                Helper.AESEncrypt.RandNum = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                }
                if (((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                        if (modelObj != null)
                        {
                            if (ValidatePassword(modelObj) && checkValidityUserID(modelObj.MyProfile))
                            {
                                modelObj.MyProfile.NewPrd = CofinityEncryption.NABEncryption.Encrypt(modelObj.MyProfile.NewPrd); // Updated Sept 21, 2018 - Heap Inspection
                                modelObj.MyProfile.OldPrd = CofinityEncryption.NABEncryption.Encrypt(modelObj.MyProfile.OldPrd); // Updated Sept 21, 2018 - Heap Inspection

                                if (UpdatePassword(modelObj, out message))
                                {
                                    SendMail(modelObj.MyProfile.Userid, modelObj.MyProfile.UserType);
                                    traceLog.AppendLine(" & End: MyProfileController, ChangePassword Method");
                                    return Content(Constants.ContentPrdChange);
                                }
                                else
                                {
                                    traceLog.AppendLine(" & End: MyProfileController, ChangePassword Method");
                                    return Content("<script type='text/javascript'>alert('"+message+"') window.location='/Home/Index'</script>");
                                }
                            }
                        }
                        traceLog.AppendLine(" & End: MyProfileController, ChangePassword Method");
                        return Content(Constants.ContentError);
                    }
                    traceLog.AppendLine(" & End: MyProfileController, ChangePassword Method");
                    return Content(Constants.ContentInvalidUser);
                
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Loads the change image partial view
        /// </summary>
        /// <param name="modelObj"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult FetchImage(MyProfileModel modelObj)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, FetchImage Method with Param modelObj: " + modelObj);
                dtoObj.SecureImageList = bllObj.FetchImageList().ToList();
                dtoObj.SelectedImageId = 0;
                if (modelObj != null)
                {
                    modelObj.MyProfile = dtoObj;
                }
                traceLog.AppendLine(" & End: MyProfileController, FetchImage Method");
                return PartialView("_ChangeImage", modelObj);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Update the new image
        /// </summary>
        /// <param name="modelObj"></param>
        /// <returns></returns>
        [ValidateAntiForgeryToken]
        public ActionResult ChangeImage(MyProfileModel modelObj)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, ChangeImage Method with Param modelObj: " + modelObj);
                if (modelObj != null)
                {
                    if (ValidateSecurityImage(modelObj.MyProfile) && checkValidityUserID(modelObj.MyProfile))
                    {
                        if (bllObj.UpdateSecurityImageDetails(modelObj.MyProfile, Constants.Yes))
                        {
                            SendMail(modelObj.MyProfile.Userid, modelObj.MyProfile.UserType);
                            traceLog.AppendLine(" & End: MyProfileController, ChangeImage Method");
                            return Content(Constants.ContentImageChanged);
                        }
                    }
                    traceLog.AppendLine(" & End: MyProfileController, ChangeImage Method");
                    return Content(Constants.ContentError);
                }
                traceLog.AppendLine(" & End: MyProfileController, ChangeImage Method");
                return View("Error");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Checking User Id validity
        /// </summary>
        /// <returns></returns>
        public bool checkValidityUserID(MyProfile profile)
        {
            if(profile.Userid == ((UserDetails)Session[Constants.UserDetails]).UserId)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }

        /// <summary>
        /// check the validity of image
        /// </summary>
        /// <param name="myProfile"></param>
        /// <returns></returns>
        private bool ValidateSecurityImage(MyProfile myProfile)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, ValidateSecurityImage Method with Param myProfile: " + myProfile);
                this.dtoObj = myProfile;
                if (Validation.IsValidContent(dtoObj.ImageCaption) && Validation.IsValidContent(dtoObj.SelectedImageId.ToString(CultureInfo.CurrentCulture)))
                {
                    traceLog.AppendLine(" & End: MyProfileController, ValidateSecurityImage Method");
                    return true;
                }
                traceLog.AppendLine(" & End: MyProfileController, ValidateSecurityImage Method");
                return false;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
                
        /// <summary>
        /// Loads the change security question partial view
        /// </summary>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult FetchSecurityQuestion()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, FetchSecurityQuestion Method");
                MyProfileModel modelObj = new MyProfileModel();
                List<SelectListItem> generalQuestion = new List<SelectListItem>();
                List<SelectListItem> familyQuestion = new List<SelectListItem>();
                List<SelectListItem> favoriteQuestion = new List<SelectListItem>();
                SelectListItem selectOne = new SelectListItem() { Text = Constants.SelectOne, Value = Constants.SelectOne };

                generalQuestion.Add(selectOne);
                familyQuestion.Add(selectOne);
                favoriteQuestion.Add(selectOne);

                generalQuestion.AddRange(bllObj.GetSecurityQuestionByCategory(Constants.General).ToList());
                familyQuestion.AddRange(bllObj.GetSecurityQuestionByCategory(Constants.Family).ToList());
                favoriteQuestion.AddRange(bllObj.GetSecurityQuestionByCategory(Constants.Favourite).ToList());

                //Get Security Question
                string userId = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                }
                List<string> question = new List<string>();
                question = bllObj.GetSecurityQuestionByUserid(userId, Constants.General).ToList();
                dtoObj.SecurityQuestion1 = question.Count != 0 ? question.ElementAt(0) : string.Empty;
                dtoObj.OldSecurityAnswer1 = question.Count != 0 ? question.ElementAt(1) : string.Empty;
                question = bllObj.GetSecurityQuestionByUserid(userId, Constants.Family).ToList();
                dtoObj.SecurityQuestion2 = question.Count != 0 ? question.ElementAt(0) : string.Empty;
                dtoObj.OldSecurityAnswer2 = question.Count != 0 ? question.ElementAt(1) : string.Empty;
                question = bllObj.GetSecurityQuestionByUserid(userId, Constants.Favourite).ToList();
                dtoObj.SecurityQuestion3 = question.Count != 0 ? question.ElementAt(0) : string.Empty;
                dtoObj.OldSecurityAnswer3 = question.Count != 0 ? question.ElementAt(1) : string.Empty;



                dtoObj.AllSecurityQuestionGeneral = generalQuestion.Select(x => x).Where(x => x.Text != dtoObj.SecurityQuestion1);
                dtoObj.AllSecurityQuestionFamily = familyQuestion.Select(x => x).Where(x => x.Text != dtoObj.SecurityQuestion2);
                dtoObj.AllSecurityQuestionFavorite = favoriteQuestion.Select(x => x).Where(x => x.Text != dtoObj.SecurityQuestion3);


                modelObj.MyProfile = dtoObj;
                SetUserAccess(modelObj.MyProfile);
                traceLog.AppendLine(" & End: MyProfileController, FetchSecurityQuestion Method");
                return PartialView("_ChangeSecurity", modelObj);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Updates the security question
        /// </summary>
        /// <param name="modelObj"></param>
        /// <returns></returns>
        [ValidateAntiForgeryToken]
        public ActionResult ChangeSecurityQuestions(MyProfileModel modelObj)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, ChangeSecurityQuestions Method  with Params modelObj: " + modelObj);
                string userId = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                }

                if (((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    if (modelObj != null)
                    {
                        if (modelObj.MyProfile.UserType == Constants.External && ValidateSecurityQuestion(modelObj.MyProfile) && checkValidityUserID(modelObj.MyProfile))
                        {
                            if (bllObj.UpdateSecurityQuestion(modelObj.MyProfile))
                            {
                                SendMail(modelObj.MyProfile.Userid, modelObj.MyProfile.UserType);
                                traceLog.AppendLine(" & End: MyProfileController, ChangeSecurityQuestions Method");
                                return Content(Constants.ContentQuestionChanged);
                            }
                        }
                        traceLog.AppendLine(" & End: MyProfileController, ChangeSecurityQuestions Method");
                        return Content(Constants.ContentError);

                    }
                    traceLog.AppendLine(" & End: MyProfileController, ChangeSecurityQuestions Method");
                    return View("Error");
                }
                traceLog.AppendLine(" & End: MyProfileController, ChangeSecurityQuestions Method");
                return Content(Constants.ContentInvalidUser);
                
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Validates the security question
        /// </summary>
        /// <param name="dtoObj"></param>
        /// <returns></returns>
        private bool ValidateSecurityQuestion(MyProfile objMyProfile)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, ValidateSecurityQuestion Method  with Params objMyProfile: " + objMyProfile);
                this.dtoObj = objMyProfile;
                if (dtoObj.SecurityQuestion1 == Constants.SelectOne || dtoObj.SecurityQuestion2 == Constants.SelectOne || dtoObj.SecurityQuestion3 == Constants.SelectOne
                     || string.IsNullOrEmpty(dtoObj.SecurityAnswer1) || string.IsNullOrEmpty(dtoObj.SecurityAnswer2) || string.IsNullOrEmpty(dtoObj.SecurityAnswer3))
                {
                    traceLog.AppendLine(" & End: MyProfileController, ValidateSecurityQuestion Method");
                    return false;
                }
                else
                {
                    if (Validation.IsValidContent(dtoObj.SecurityAnswer1) && Validation.IsValidContent(dtoObj.SecurityAnswer2) && Validation.IsValidContent(dtoObj.SecurityAnswer3))
                    {
                        traceLog.AppendLine(" & End: MyProfileController, ValidateSecurityQuestion Method");
                        return true;
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: MyProfileController, ValidateSecurityQuestion Method");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Generate email message content
        /// </summary>
        /// <param name="UserName"></param>
        /// <returns></returns>
        private string GetEmailBody(string userNameValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, GetEmailBody Method  with Params userNameValue: " + userNameValue);
                this.userName = userNameValue;
                StringBuilder mailBody = new StringBuilder();
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.TableHeader);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.EmailProfileHeader);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.ContactImmediatelyText);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.SubmittedBy);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.EmailProfileName + userName);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.EmailProfileDate + System.DateTime.Now.Date.ToShortDateString());
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.TableEnd);

                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);

                mailBody.Append(Constants.TableHeader);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.EmailProfileThankYou);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.CofinityLabel);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.EmailProfileFooter);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.TableEnd);
                traceLog.AppendLine(" & End: MyProfileController, GetEmailBody Method");
                return mailBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// send mail to user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userType"></param>
        private void SendMail(string userId, string userType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, SendMail Method  with Params userId: " + userId + " and with Param userType: " + userType);
                User objUser = new User();
                objUser = bllObj.GetUserDetails(userId, userType);
                if (objUser != null)
                {
                    string profileUserName = objUser.FirstName + " " + objUser.LastName;
                    string[] email = new string[1];
                    email[0] = objUser.Email;
                    string subject = Constants.EmailProfileSubject;
                    string body = GetEmailBody(profileUserName);
                    bllObj.SendMail(email, subject, body);
                }
                traceLog.AppendLine(" & End: MyProfileController, SendMail Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// update password
        /// </summary>
        /// <param name="modelObj"></param>
        /// <returns></returns>
        private bool UpdatePassword(MyProfileModel modelObj,out string message)
        {
            StringBuilder traceLog = new StringBuilder();
            message = string.Empty;
            bool check = false;
            try
            {
                traceLog.AppendLine("Start: MyProfileController, UpdatePassword Method  with Params modelObj: " + modelObj + " and with Param message: " + message);
                LogOnBLL objBll = new LogOnBLL();
                if (ConfigurationManager.AppSettings[Constants.Site].ToUpperInvariant()==Constants.External.ToUpperInvariant())
                {
                    check = objBll.UpdateExternalUserPassword(modelObj.MyProfile.Userid, modelObj.MyProfile.OldPrd, modelObj.MyProfile.NewPrd, out message); // Updated Sept 21, 2018 - Heap Inspection
                }
                else if (ConfigurationManager.AppSettings[Constants.Site].ToUpperInvariant() == Constants.Internal.ToUpperInvariant())
                {
                    check = objBll.UpdateInternalUserPassword(modelObj.MyProfile.Userid, modelObj.MyProfile.OldPrd, modelObj.MyProfile.NewPrd, out message); // Updated Sept 21, 2018 - Heap Inspection
                }
                if (check)
                {
                    check = check && bllObj.UpdateSecurityPassword(modelObj.MyProfile);
                }
                traceLog.AppendLine(" & End: MyProfileController, UpdatePassword Method");
            }
            catch (Exception ex)
            {
                check = false;
                LogManager.WriteErrorLog(ex);
                //throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return check;
            
        }
        /// <summary>
        /// validates th password
        /// </summary>
        /// <param name="modelObj"></param>
        /// <returns></returns>
        private bool ValidatePassword(MyProfileModel modelObj)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: MyProfileController, ValidatePassword Method  with Params modelObj: " + modelObj);
                this.objMyProfileModel = modelObj;
                if (string.IsNullOrEmpty(objMyProfileModel.MyProfile.OldPrd) || objMyProfileModel.MyProfile.NewPrd != objMyProfileModel.MyProfile.NewPrdAgain
                    || objMyProfileModel.MyProfile.NewPrd.Length < 8 || !objMyProfileModel.MyProfile.NewPrd.Any(char.IsLower)
                    || !objMyProfileModel.MyProfile.NewPrd.Any(char.IsUpper) || !objMyProfileModel.MyProfile.NewPrd.Any(char.IsNumber)) // Updated Sept 21, 2018 - Heap Inspection
                {
                    traceLog.AppendLine(" & End: MyProfileController, ValidatePassword Method");
                    return false;
                }
                traceLog.AppendLine(" & End: MyProfileController, ValidatePassword Method");
                return true;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

    }
}