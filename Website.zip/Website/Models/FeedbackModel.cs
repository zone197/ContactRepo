﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace NABWebsite.Models
{
    public class FeedbackModel
    {
     
        public string Comments { get; set; }

        
        public Int16 ContentRating { get; set; }

        
        public Int16 DesignRating { get; set; }

        
        public Int16 EaseOfUserRating { get; set; }

     
        public Int16 OverallRating { get; set; }

        
        public bool IsValidInfo { get; set; }

        public string JustificationComment { get; set; }
    }
}