﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;

namespace NABWebsite.Models
{
    //ViewModel for "File Download"
    public class FileDownloadModel
    {
        public IEnumerable<FileDownload> FileDetails { get; set; }
        public string FilePathChosen { get; set; }
    }
}