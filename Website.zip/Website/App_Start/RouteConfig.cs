﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace NABWebsite
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.MapMvcAttributeRoutes();

            routes.MapRoute(name: "CustomUrl",
                url: "{PageId}",
                defaults: new
                {
                    controller = "Home",
                    action = "Index",
                    PageId = UrlParameter.Optional
                });

            routes.MapRoute(name: "Error",
                url: "Error/{action}",
                defaults: new
                {
                    controller = "Error",
                    action = "Index",
                    PageId = UrlParameter.Optional
                });

            routes.MapRoute(name: "DownloadFiles",
                url: "LocateProvider/{action}/{id}",
                defaults: new
                {
                    controller = "LocateProvider",
                    action = "ProviderFileDownload",
                    id=UrlParameter.Optional
                });
            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{PageId}",
                defaults: new { controller = "Home", action = "Index", PageId = 1000 },
                //defaults: new { controller = "TransplantController", action = "OnlineTransplantForm", PageId = 1000 }, 
                constraints:  new {PageId = @"^[A-Za-z0-9 ]+$" }
                
            );
            
            
        }
    }
}
