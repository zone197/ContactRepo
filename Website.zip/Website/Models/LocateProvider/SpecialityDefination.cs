﻿using Aetna.ProviderContracts.DataContracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using NABResources;

namespace NABWebsite.Models.LocateProvider
{
    public class SpecialityDefination
    {
        public List<Specialty> ListSpecialty { get; set; }

        public List<string> AlphaTest{get;set;}

        public string Alphabet { get; set; }
        [Display(Name = "lblSearchAllSpecialties", ResourceType = typeof(Resources))] 
        public string SearchSpecialty { get; set; }

        public string TextSpecialty { get; set; }

        public string ProviderDetails { get; set; }

        private List<AlphaCount> alphaCount = new List<AlphaCount>();
        public List<AlphaCount> AlphaCount
        {
            get { return alphaCount; }
            set { alphaCount = value; }
        }
        public string ProviderType { get; set; }
         
    } 
    public class AlphaCount
    {
        public string Word;
        public int Count;
    }
    
}