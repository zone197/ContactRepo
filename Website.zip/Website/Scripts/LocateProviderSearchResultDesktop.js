﻿$(document).ready(function () {
    $('#ErrorMessageForRefineResults').empty();

    $('#btnCompare').click(function () {
        var forgeryId = $("#forgeryToken").val();
        $.ajax({
            type: 'POST',
            url: '/LocateProvider/GetComparedProvidersCount',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                if (result >= 2) {
                    $('#errrorMessageForProviders').empty();
                    window.location.href = '/LocateProvider/CompareResult/';
                }
                else {
                    var errorSelectTwoProviders = GetResources("lblSelectAtleastTwoProvidersForComparison");
                    $('#errrorMessageForProviders').html(errorSelectTwoProviders);
                    $('input[name^=compareProviders]')[0].focus();
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            }
        });

    });
    //change the radius value based on the slider
    $(function () {
        if ($("#RefinetxtRadius").val != null) {
            $("#RefineRadiusSliderValue").slider({
                orientation: "horizontal",
                range: "min",
                min: 5,
                max: 100,
                value: $("#RefinetxtRadius").val(),
                step: 5,
                slide: function (event, ui) {
                    $("#RefinetxtRadius").val(ui.value);
                    $('#ErrorMessageForRefineResults').empty();
                }
            });
        }
    });
    $('#RefinetxtRadius').on('change', function (e) {
        if (jQuery.isNumeric($('#RefinetxtRadius').val())) {
            if ($('#RefinetxtRadius').val() > 100 || $('#RefinetxtRadius').val() < 5) {
                $('#RefinetxtRadius').val("10");
            }

            $("#RefineRadiusSliderValue").slider({
                value: $("#RefinetxtRadius").val()
            })

        }
    });

    // remove error message as soon as user starts entering in the zip text box
    $("#RefinetxtZip").keyup(function () {
        $('#ErrorMessageForRefineResults').empty();
    });
    // remove error message as soon as user starts entering in the radius text box
    $("#RefinetxtRadius").keyup(function () {
        $('#ErrorMessageForRefineResults').empty();
    });

    //$('#RefineSpecialty').select2({
    //    enablesearching: true,
    //    width: '100%',
    //    placeholder: "Enter Specialty",
    //    allowClear: true,
    //    maximumSelectionLength: 5,
    //    closeOnSelect: false
    //});

    //$('#RefineSpecialty').on('select2:selecting', function (evt) {
    //    if ($(this).select2('data').length >= 5) return false;  //limit no of selection in dropdown
    //});

    //$('#RefineStateSearch').select2({
    //    enablesearching: false,
    //    width: '100%'
    //});
    //$('#RefineCitySearch').select2({
    //    enablesearching: true,
    //    width: '100%',
    //    placeholder: "Enter City",
    //    allowClear: true,
    //    maximumSelectionLength: 7,
    //    closeOnSelect: false
    //});
    //$('#RefineCountySearch').select2({
    //    enablesearching: true,
    //    width: '100%',
    //    placeholder: "Enter County",
    //    allowClear: true,
    //    maximumSelectionLength: 7,
    //    closeOnSelect: false
    //});
    //$('#RefineCitySearch').on('select2:selecting', function (evt) {
    //    if ($(this).select2('data').length >= 7)
    //        return false;  //limit no of selection in dropdown
    //});
    //$('#RefineCountySearch').on('select2:selecting', function (evt) {
    //    if ($(this).select2('data').length >= 7) return false;  //limit no of selection in dropdown
    //});
    $('#RefineSpecialty').multiselect({

        numberDisplayed: 4,
        buttonWidth: '100%',
        nonSelectedText: GetResources("lblEnterSpecialty"),
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        enableFullValueFiltering: true,
        enableHTML: false,
        onDropdownShown: function (even) {
            this.$filter.find('.multiselect-search').focus();
            $(document).find(".multiselect-container li a").on("keydown", function (e) {
                if (e.keyCode == 9 && e.shiftKey) {
                    $(this).parent().parent().find('.multiselect-search')[0].focus();
                    e.preventDefault();
                }
            })
        }
    });
    $('#RefineSpecialty').change(function () {
        //debugger;
        // Get selected options.
        var selectedOptions = $('#RefineSpecialty option:selected');
        if (selectedOptions.length >= 0) {
            AddItemsToDiv(selectedOptions, "RefineSpecialty", "selectedSpecialty");
        }

        if (selectedOptions.length >= 5) {
            // Disable all other checkboxes.
            var nonSelectedOptions = $('#RefineSpecialty option').filter(function () {
                return !$(this).is(':selected');
            });

            nonSelectedOptions.each(function () {
                var input = $('input[value="' + $(this).val() + '"]');
                input.prop('disabled', true);
                input.parent('li').addClass('disabled');
            });
        }
        else {
            // Enable all checkboxes.
            //debugger;
            $('#RefineSpecialty option').each(function () {
                var input = $('input[value="' + $(this).val() + '"]');
                input.prop('disabled', false);
                input.parent('li').addClass('disabled');
            });
        }
    });

    $('#RefineFocus').multiselect({

        numberDisplayed: 4,
        buttonWidth: '100%',
        nonSelectedText: GetResources("lblEnterFocus"),
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        enableFullValueFiltering: true,
        enableHTML: false,
        onDropdownShown: function (even) {
            this.$filter.find('.multiselect-search').focus();
            $(document).find(".multiselect-container li a").on("keydown", function (e) {
                if (e.keyCode == 9 && e.shiftKey) {
                    $(this).parent().parent().find('.multiselect-search')[0].focus();
                    e.preventDefault();
                }
            })
        }
    });
    $('#RefineFocus').change(function () {
        //debugger;
        // Get selected options.
        var selectedOptions = $('#RefineFocus option:selected');
        if (selectedOptions.length >= 0) {
            AddItemsToDiv(selectedOptions, "RefineFocus", "selectFocus");
        }

        if (selectedOptions.length >= 5) {
            // Disable all other checkboxes.
            var nonSelectedOptions = $('#RefineFocus option').filter(function () {
                return !$(this).is(':selected');
            });

            nonSelectedOptions.each(function () {
                var input = $('input[value="' + $(this).val() + '"]');
                input.prop('disabled', true);
                input.parent('li').addClass('disabled');
            });
        }
        else {
            // Enable all checkboxes.
            //debugger;
            $('#RefineFocus option').each(function () {
                var input = $('input[value="' + $(this).val() + '"]');
                input.prop('disabled', false);
                input.parent('li').addClass('disabled');
            });
        }
    });
    $('#RefineECP').multiselect({

        numberDisplayed: 4,
        buttonWidth: '100%',
        nonSelectedText: GetResources("lblEnterECP"),
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        enableFullValueFiltering: true,
        enableHTML: false,
        onDropdownShown: function (even) {
            this.$filter.find('.multiselect-search').focus();
            $(document).find(".multiselect-container li a").on("keydown", function (e) {
                if (e.keyCode == 9 && e.shiftKey) {
                    $(this).parent().parent().find('.multiselect-search')[0].focus();
                    e.preventDefault();
                }
            })
        }
    });
    $('#RefineECP').change(function () {
        
        // Get selected options.
        var selectedOptions = $('#RefineECP option:selected');
        if (selectedOptions.length >= 0) {
            AddItemsToDiv(selectedOptions, "RefineECP", "selectedECP");
        }

        
       
            // Enable all checkboxes.
            //debugger;
            $('#RefineECP option').each(function () {
                var input = $('input[value="' + $(this).val() + '"]');
                input.prop('disabled', false);
                input.parent('li').addClass('disabled');
            });
        
    });
    ////selecting only one state from the drop down   
    //$('#RefineStateSearch').multiselect({
    //    enableFiltering: true,
    //    maxHeight: 150,
    //    buttonWidth: '100%',
    //    nonSelectedText: GetResources("txtStateRequired"),
    //    enableCaseInsensitiveFiltering: true,
    //    enableFullValueFiltering: true,
    //    enableHTML: false,
    //    onDropdownShown: function (even) {
    //        this.$filter.find('.multiselect-search').focus();
    //        $(document).find(".multiselect-container li a").on("keydown", function (e) {
    //            if (e.keyCode == 9 && e.shiftKey) {
    //                $(this).parent().parent().find('.multiselect-search')[0].focus();
    //                e.preventDefault();
    //            }
    //        })
    //    },
    //});


    //$('#RefineCitySearch').multiselect({
    //    numberDisplayed: 7,
    //    buttonWidth: '100%',
    //    nonSelectedText: GetResources("txtEnterCity"),
    //    enableFiltering: true,
    //    enableCaseInsensitiveFiltering: true,
    //    maxHeight: 150,
    //    enableFullValueFiltering: true,
    //    enableHTML: false,
    //    dropUp: true,
    //    onDropdownShown: function (even) {
    //        this.$filter.find('.multiselect-search').focus();
    //        $(document).find(".multiselect-container li a").on("keydown", function (e) {
    //            if (e.keyCode == 9 && e.shiftKey) {
    //                $(this).parent().parent().find('.multiselect-search')[0].focus();
    //                e.preventDefault();
    //            }
    //        })
    //    },
    //});
    //// selecting maximum of 7 counties from the dropdown

    //$('#RefineCountySearch').multiselect({
    //    numberDisplayed: 7,
    //    buttonWidth: '100%',
    //    nonSelectedText: GetResources("txtEnterCounty"),
    //    enableFiltering: true,
    //    enableCaseInsensitiveFiltering: true,
    //    maxHeight: 150,
    //    enableFullValueFiltering: true,
    //    enableHTML: false,
    //    dropUp: true,
    //    onDropdownShown: function (even) {
    //        this.$filter.find('.multiselect-search').focus();
    //        $(document).find(".multiselect-container li a").on("keydown", function (e) {
    //            if (e.keyCode == 9 && e.shiftKey) {
    //                $(this).parent().parent().find('.multiselect-search')[0].focus();
    //                e.preventDefault();
    //            }
    //        })
    //    },
    //});
    //refining the county and city dropdown on changing the state
    //$('#RefineStateSearch').change(function () {
    //    var forgeryId = $("#forgeryToken").val();
    //    $('#ErrorMessageForRefineResults').empty();
    //    $("#selectedCounty").empty();
    //    $("#selectedCity").empty();
    //    var stateCode = $('#RefineStateSearch').val();
    //    $.ajax({
    //        type: 'POST',
    //        url: '/LocateProvider/GetCountiesByState',
    //        contentType: "application/json; charset=utf-8",
    //        datatype: 'json',
    //        data: JSON.stringify({ stateCode: stateCode }),
    //        headers: {
    //            'VerificationToken': forgeryId
    //        },
    //        success: function (result) {
    //            $('#RefineCountySearch').empty();
    //            $.each(result, function (index, CountyName) {
    //                $('#RefineCountySearch').append("<option value='" + CountyName.CountyName + "'>" + CountyName.CountyName + "</option>");
    //            });
    //            //$("#RefineCountySearch").trigger("change");
    //            $('#RefineCountySearch').multiselect('rebuild');
    //        },
    //        error: function (XMLHttpRequest, textStatus, errorThrown) {
    //        }
    //    });

    //    $.ajax({
    //        type: 'POST',
    //        url: '/LocateProvider/GetCitiesByState',
    //        contentType: "application/json; charset=utf-8",
    //        datatype: 'json',
    //        data: JSON.stringify({ stateCode: stateCode }),
    //        headers: {
    //            'VerificationToken': forgeryId
    //        },
    //        success: function (result) {
    //            $('#RefineCitySearch').empty();
    //            $.each(result, function (index, CityName) {
    //                $('#RefineCitySearch').append("<option value='" + CityName.CityName + "'>" + CityName.CityName + "</option>");
    //            });
    //            //$("#RefineCitySearch").trigger("change");
    //            $('#RefineCitySearch').multiselect('rebuild');
    //        },
    //        error: function (XMLHttpRequest, textStatus, errorThrown) {
    //        }
    //    });

    //});
    ////clear input text from city
    //$('#RefineCitySearch').change(function () {
    //    DisableCheckboxes('RefineCitySearch', 'selectedCity');
    //});
    ////refining the city based on the state and county combination
    //$('#RefineCountySearch').change(function () {
    //    DisableCheckboxes('RefineCountySearch', 'selectedCounty');

    //    var city = [];
    //    var selectCity = [];
    //    $('#RefineCitySearch :selected').each(function (i, selected) {
    //        city[i] = $(selected).val();
    //    });
    //    var forgeryId = $("#forgeryToken").val();
    //    $('.valid').val('');
    //    if ($('#RefineCountySearch').val() != null) {
    //        var stateCode = [];
    //        $('#RefineStateSearch :selected').each(function (i, selected) {
    //            stateCode[i] = $(selected).val();
    //        });
    //        var county = [];
    //        $('#RefineCountySearch :selected').each(function (i, selected) {
    //            county[i] = $(selected).val();
    //        });
    //        //$('#RefineCitySearch').dropdown('clear');
    //        $.ajax({
    //            type: 'POST',
    //            url: '/LocateProvider/GetCitiesByStateAndCounty',
    //            contentType: "application/json; charset=utf-8",
    //            datatype: 'json',
    //            data: JSON.stringify({ stateCode: stateCode, county: county }),
    //            headers: {
    //                'VerificationToken': forgeryId
    //            },
    //            success: function (result) {
    //                $('#RefineCitySearch').empty();
    //                $.each(result, function (index, CityName) {
    //                    $('#RefineCitySearch').append("<option value='" + CityName.CityName + "'>" + CityName.CityName + "</option>");
    //                    for (var i in city) {
    //                        if (city[i] == CityName.CityName) {
    //                            selectCity.push(city[i]);
    //                        }
    //                    }
    //                });
    //                //$("#RefineCitySearch").trigger("change");   
    //                $('#RefineCitySearch').multiselect('rebuild');
    //                $("#RefineCitySearch").multiselect('select', selectCity);
    //                DisableCheckboxes('RefineCitySearch', 'selectedCity');
    //                $('#selectedCity').empty();
    //                $.each(selectCity, function (index, city) { $("#selectedCity").append('<span class="tab">' + city + '</span>'); });

    //            },
    //            error: function (XMLHttpRequest, textStatus, errorThrown) {
    //            }
    //        });
    //    }
    //    else {
    //        var stateCode = $('#RefineStateSearch').val();

    //        $.ajax({
    //            type: 'POST',
    //            url: '/LocateProvider/GetCitiesByState',
    //            contentType: "application/json; charset=utf-8",
    //            datatype: 'json',
    //            data: JSON.stringify({ stateCode: stateCode }),
    //            headers: {
    //                'VerificationToken': forgeryId
    //            },
    //            success: function (result) {
    //                $('#RefineCitySearch').empty();
    //                $.each(result, function (index, CityName) {
    //                    $('#RefineCitySearch').append("<option value='" + CityName.CityName + "'>" + CityName.CityName + "</option>");
    //                    for (var i in city) {
    //                        if (city[i] == CityName.CityName) {
    //                            selectCity.push(city[i]);
    //                        }
    //                    }
    //                });
    //                // $("#RefineCitySearch").trigger("change");   
    //                $('#RefineCitySearch').multiselect('rebuild');
    //                $("#RefineCitySearch").multiselect('select', selectCity);
    //                DisableCheckboxes('RefineCitySearch', 'selectedCity');
    //                $('#selectedCity').empty();
    //                $.each(selectCity, function (index, city) { $("#selectedCity").append('<span class="tab">' + city + '</span>'); });
    //            },
    //            error: function (XMLHttpRequest, textStatus, errorThrown) {
    //            }
    //        });
    //    }

    //});    


    $("#errrorMessageForProviders").empty();
    //sorting the result set on the basis of the sort criteria selected by the user
    $("#SelectSortCriteria").change(function () {
        //debugger;
        var forgeryId = $("#forgeryToken").val();
        $("#CurrentPageIndex").val(0);
        var sortField = $("#SelectSortCriteria").val();
        var sortDirection = $("#SelectSortCriteria").find(':selected').data('direction')
        var sortingPagingInfo = new Object();
        sortingPagingInfo.SortField = sortField;
        sortingPagingInfo.SortDirection = sortDirection;
        sortingPagingInfo.PageSize = $("#PageSize").val();
        sortingPagingInfo.PageCount = $("#PageCount").val();
        sortingPagingInfo.CurrentPageIndex = $("#CurrentPageIndex").val();
        sortingPagingInfo.TotalRecords = $("#ProviderCount").val();

        $.ajax({
            type: 'POST',
            url: '/LocateProvider/SaveSortingPagingInfoToSession',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ sortingPagingInfo: sortingPagingInfo }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                //$("div#spinner").fadeIn("fast");
                $("#spinnerPopup").modal('show');
                window.location.href = '/LocateProvider/LocateProviderSearchResult/';
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            }
        });
    })

    $("#txtGotoPage").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    // go the particular page selected by the user and sort the result set accordingly
    $("#txtGotoPage").on('keydown', function (e) {
        var forgeryId = $("#forgeryToken").val();
        if (e.keyCode == 13) {
            var pageindex = parseInt($("#txtGotoPage").val() - 1);

            if (pageindex + 1 > 0 && pageindex + 1 <= $("#PageCount").val()) {
                $("#CurrentPageIndex").val(pageindex);
                var sortingPagingInfo = new Object();
                sortingPagingInfo.SortField = $("#SortField").val();
                sortingPagingInfo.SortDirection = $("#SortDirection").val();
                sortingPagingInfo.PageSize = $("#PageSize").val();
                sortingPagingInfo.PageCount = $("#PageCount").val();
                sortingPagingInfo.CurrentPageIndex = $("#CurrentPageIndex").val();
                sortingPagingInfo.TotalRecords = $("#ProviderCount").val();

                $.ajax({
                    type: 'POST',
                    url: '/LocateProvider/SaveSortingPagingInfoToSession',
                    contentType: "application/json; charset=utf-8",
                    datatype: 'json',
                    data: JSON.stringify({ sortingPagingInfo: sortingPagingInfo }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    success: function (result) {
                        //$("div#spinner").fadeIn("fast");
                        $("#spinnerPopup").modal('show');
                        window.location.href = '/LocateProvider/LocateProviderSearchResult/';
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                    }
                });
            } else alert("Invalid Page Number");
        }
    })

    $(".pager").click(function (evt) {
        var forgeryId = $("#forgeryToken").val();
        var pageindex = $(evt.target).data("pageindex");
        $("#CurrentPageIndex").val(pageindex);
        var sortingPagingInfo = new Object();
        sortingPagingInfo.SortField = $("#SortField").val();
        sortingPagingInfo.SortDirection = $("#SortDirection").val();
        sortingPagingInfo.PageSize = $("#PageSize").val();
        sortingPagingInfo.PageCount = $("#PageCount").val();
        sortingPagingInfo.CurrentPageIndex = $("#CurrentPageIndex").val();
        sortingPagingInfo.TotalRecords = $("#ProviderCount").val();

        $.ajax({
            type: 'POST',
            url: '/LocateProvider/SaveSortingPagingInfoToSession',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ sortingPagingInfo: sortingPagingInfo }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                //$("div#spinner").fadeIn("fast");
                $("#spinnerPopup").modal('show');
                window.location.href = '/LocateProvider/LocateProviderSearchResult/';
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            }
        });
    });

});



function GetResources(key) {
    var forgeryId = $("#forgeryToken").val();
    var returnValue;
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/GetResources',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        async: false,
        data: JSON.stringify({ key: key }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            ////debugger;
            returnValue = result;

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
    ////debugger;
    return returnValue;
}

function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
function phonenumber(inputtxt) {
    var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    return phoneno.test(inputtxt);
}
//without captcha validation
function SendProviderDetails(event, ProviderNumber, address1, city, state, zip, providerNameDegree) {
    //debugger;
    event.preventDefault();
    var forgeryId = $("#forgeryToken").val();
    $("#errorMessage_" + ProviderNumber).html("");
    var providerNumber = ProviderNumber;
    var email = $("#emailIdForDetails" + ProviderNumber).val().trim();
    var phoneNumber = $("#phoneNumberId" + ProviderNumber).val().trim();
    var phoneNumberCarrierValue = $('#CarrierData_' + ProviderNumber + ' option:selected').val();
    var phoneNumberCarrier = $('#CarrierData_' + ProviderNumber + ' option:selected').text();
    var ProviderMapDeatails = $('input[name="ProviderMapDeatails' + ProviderNumber + '"]:checked').val();
    var checkEmail = false;
    var checkPhone = false;
    var form = $('#FormSendProviderDetails' + ProviderNumber);

    
    if (email == "" && phoneNumber != "") {
        checkPhone = true;
    }
    if (email != "" && phoneNumber == "") {
        checkEmail = true;
    }
    if (email != "" && phoneNumber != "") {
        checkEmail = true;
        checkPhone = true;
    }
    if (email == "" && phoneNumber == "") {
        checkEmail = true;
    }
    if (checkEmail) {
        $("#emailIdForDetails" + ProviderNumber).focus();
        if (email == "") {            
            var errorEnterEmailOrPhone = GetResources("lblEnterIdOrPhoneNumber");
            $("#errorMessage_" + ProviderNumber).html(errorEnterEmailOrPhone);
        }
        else if (!validateEmail(email)) {
            var errrorValidEmailIdAndPhone = GetResources("lblProvideValidIdOrPhoneNumber");
            $("#errorMessage_" + ProviderNumber).html(errrorValidEmailIdAndPhone);
        }
    }
    
    if (checkPhone) {
        if (phoneNumberCarrierValue == "") {
            var errorSelectCarrier = GetResources("errorSelectCarrier");
            $("#errorMessage_" + ProviderNumber).html(errorSelectCarrier);
            $('#CarrierData_' + ProviderNumber).focus();
        }
        if (!phonenumber(phoneNumber.replace('-',''))) {
            var errorEnterPhone = GetResources("errorEnterPhone");
            $("#errorMessage_" + ProviderNumber).html(errorEnterPhone);
            $("#phoneNumberId" + ProviderNumber).focus();
        }
    }

    $.validator.unobtrusive.parse(form);
    form.validate();
    if ((phoneNumberCarrierValue != "" && phoneNumber != "") || validateEmail(email)) {
        if (form.valid()) {

            $("#errorMessage_" + ProviderNumber).empty();
            var sendProviderDetails = new Object();
            var UserEmailAddress = new Object();
            var UserPhoneNumber = new Object();
            sendProviderDetails.SelectedCarrier = phoneNumberCarrierValue;
            sendProviderDetails.SelectedCarrierName = phoneNumberCarrier;
            sendProviderDetails.ProviderUIN = ProviderNumber;
            sendProviderDetails.AddressLine1 = address1;
            sendProviderDetails.City = city;
            sendProviderDetails.State = state;
            sendProviderDetails.ZipCode = zip;
            sendProviderDetails.SelectedMailOption = ProviderMapDeatails;
            //sendProviderDetails.SelectedMailOptionMapDetails = ProviderMapDetails;
            sendProviderDetails.LongName = providerNameDegree;
            UserEmailAddress.EmailAddress1 = email;
            UserPhoneNumber.PhoneNumber = phoneNumber;
            sendProviderDetails.UserEmailAddress = UserEmailAddress;
            sendProviderDetails.UserPhoneNumber = UserPhoneNumber;
            var forgeryId = $("#forgeryToken").val();
            $.ajax({
                type: 'POST',
                url: '/LocateProvider/SendMailPageSession',
                contentType: "application/json; charset=utf-8",
                datatype: 'json',
                data: JSON.stringify({ sendProviderDetails: sendProviderDetails }),
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {
                    window.location.href = '/LocateProvider/SendMailPage';
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    //alert(XMLHttpRequest);
                }
            });

        }
    }
}



//remove the search request from the session 
function CallRemoveSearchRequest(action) {
    var forgeryId = $("#forgeryToken").val();
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/RemoveSaveSearchRequestToSession',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        data: JSON.stringify({ action: action }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            $("#spinnerPopup").modal('show');
            window.location.href = '/LocateProvider/LocateProviderSearchResult/';
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            ////debugger;
        }
    });
}

// remove all the providers selected for comparison
function RemoveAllProviders(action) {
    var forgeryId = $("#forgeryToken").val();
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/RemoveCompareProvidersFromSession',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        data: JSON.stringify({ action: action }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            $("#spinnerPopup").modal('show');
            window.location.href = '/LocateProvider/LocateProviderSearchResult/';
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
    $("#ProvidersSelectedForComparision").empty();
    $('input[name="compareProviders"]').prop('checked', false);
    $('#errrorMessageForProviders').empty();
}

// get the number of taggged providers and go to the tagged providers page
function NavigateToMyList() {
    var forgeryId = $("#forgeryToken").val();
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/GetTaggedProviderCount',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            if (result <= 0) {
                var errrorMsgNoProviderSelected = GetResources("lblNothingSelected");
                alert(errrorMsgNoProviderSelected);
            }
            else {
                window.location.href = '/LocateProvider/TaggedProviders/';
            }

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
}
//get the number of provider to create directory.
function NavigateToCreateDirectory(MatchCount) {
     
    if (MatchCount <= 0) {
                var errrorMsgNoProviderSelected = GetResources("lblNoMatchCount");
                alert(errrorMsgNoProviderSelected);
            }
            else {
        window.location.href = '/LocateProvider/CreateDirectory';
            }

       
}
function CompareImageKeyHandler(event, NumberLocationIdTaxId, NameAndSpecialty, ProviderId, ProviderName) {
    if (event.which === 13) {
        //event.stopPropagation;
        return CompareProviders(NumberLocationIdTaxId, NameAndSpecialty, ProviderId, ProviderName);
    }
    return true;
}
function ShowMoreDetailsHandler(event, data, activeTab, visibility) {
    if (event.which === 13) {
        //event.stopPropagation;
        return ShowHideDetails(data, activeTab, visibility);
    }
    return true;
}
function ShowHideDetailsForOtherAddressHandler(event, data, activeTab, city, state, address, zip, urlPath) {
    if (event.which === 13) {
        //event.stopPropagation;
        return ShowHideDetailsForOtherAddress(data, activeTab, city, state, address, zip, urlPath);
    }
    return true;
}
function ShowHideDetailsForCurrentAddressHandler(event, data, activeTab, visibility, city, state, address, zip, urlPath) {
    if (event.which === 13) {
        //event.stopPropagation;
        return ShowHideDetailsForCurrentAddress(data, activeTab, visibility, city, state, address, zip, urlPath);
    }
    return true;
}
function TagProviderHandler(event, providerUIN) {
    //debugger;
    if (event.which === 13) {
        if ($("#chkTag" + providerUIN).prop('checked') == true) {
            $("#chkTag" + providerUIN).prop('checked', false);
        }
        else {
            $("#chkTag" + providerUIN).prop('checked', true);
        }
        //event.stopPropagation;
        return TagProviders(providerUIN);
    }

    return true;
}

function RemoveCriteriaHandler(event, dataToRemove) {
    ////debugger;
    if (event.which === 13) {
        //event.stopPropagation;
        return CallRemoveSearchRequest(dataToRemove);
    }
    return true;
}
// for getting the autosuggestions based on the search criteria
$(function () {
    function split(val) {
        return val.split(/,\s*/);
    }
    function extractLast(term) {
        return split(term).pop();
    }
    $("#RefinedProviderName").bind("keydown", function (event) {
        if (event.keyCode === $.ui.keyCode.TAB && $(this).data("autocomplete").menu.active) {
            event.preventDefault();
        }
    })
    $("#RefinedProviderName").autocomplete({
        source: function (request, response) {
            var forgeryId = $("#forgeryToken").val();
            $.ajax({
                url: '/LocateProvider/GetProviderName',
                type: "GET",
                dataType: "json",
                data: { query: request.term },
                headers: {
                    'VerificationToken': forgeryId
                },
                term: extractLast(request.term),
                success: function (data) {
                    //debugger;
                    response($.map(data, function (item) {
                        return {
                            label: item,
                            value: item     // EDIT
                        }
                    }));
                }
            })
        },
        search: function () {
            // custom minLength
            var term = extractLast(this.value);
            if (term.length < 2) {
                return false;
            }
        },
        //focus: function (event, ui) {
        //    event.preventDefault();
        //    $("#RefinedProviderName").val(ui.item.label);
        //},
        select: function (event, ui) {
            event.preventDefault();
            $("#RefinedProviderName").val(ui.item.label);
            //$("#RefinedProviderNameHiddenValue").val(ui.item.value);
        }
    });
});



