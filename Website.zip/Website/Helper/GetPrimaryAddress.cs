﻿using Aetna.ProviderContracts.DataContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Utilities;

namespace NABWebsite.Helper
{
    public static class GetPrimaryAddress
    {
        public static List<ProviderOffice> GetAddressForProvider(Aetna.ProviderContracts.DataContracts.Provider detailedProviderInfo, string[] providerNumberIndex)
        {
            StringBuilder traceLog = new StringBuilder();
            if (providerNumberIndex == null)
            {
                throw new ArgumentNullException(ExceptionMessageConstant.ProviderNumberIndex);
            }
            if (detailedProviderInfo == null)
            {
                throw new ArgumentNullException(ExceptionMessageConstant.DetailedProviderInformation);
            }
            try
            {
                traceLog.AppendLine("Start: GetPrimaryAddress, GetAddressForProvider Method with Params detailedProviderInfo: " + detailedProviderInfo + " and with Param providerNumberIndex: " + providerNumberIndex); 


                string primaryLocationId = providerNumberIndex[1].Replace("-", "/");
                string primaryTaxId = providerNumberIndex[2];

                var primaryLocation = detailedProviderInfo.OtherOfficeLocations.Where(m => m.ProvTaxId.Equals(primaryTaxId) && m.ProvLocationID.Equals(primaryLocationId)).ToList();
                var otherLocations = detailedProviderInfo.OtherOfficeLocations.Where(m => !m.ProvTaxId.Equals(primaryTaxId) || !m.ProvLocationID.Equals(primaryLocationId)).ToList();
                var finalList = primaryLocation.Concat(otherLocations).ToList();
                traceLog.AppendLine(" & End: GetPrimaryAddress, GetAddressForProvider Method");
                return finalList;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
    }
}