﻿var SAMPLE_POST_REVERSE = 'https://www.mapquestapi.com' + '/geocoding/v1/reverse?key=YOUR_KEY_HERE&callback=renderReverse';
var safe = '';

function getLocation() {
    if (navigator.geolocation) {        
        navigator.geolocation.getCurrentPosition(showPosition,errorCallback);
    }
    else {
        alert('Geolocation is not supported');
    }

}
function errorCallback() {
    ////debugger
}
function ShowPositionTest() {
    ////debugger;    
    var script = document.createElement('script');

    script.type = 'text/javascript';
    //var latitude = position.coords.latitude;
    //var longitude = position.coords.longitude;

    var latitude = 40.053116;
    var longitude = -76.313603;

    safe = SAMPLE_POST_REVERSE;
    safe += '&json={';
    safe += 'location:{latLng:{lat:' + latitude + ',lng:' + longitude + '}}}';
    var MapQuestConsumerKeyPublic = GetResources('MapQuestConsumerKeyPublic');
    var newURL = safe.replace('YOUR_KEY_HERE', MapQuestConsumerKeyPublic);
    script.src = newURL;
    document.body.appendChild(script);
}

function showPosition(position) {
    ////debugger;
    var script = document.createElement('script');
    script.type = 'text/javascript';
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;

    //var latitude = 40.053116;
    //var longitude = -76.313603;

    safe = SAMPLE_POST_REVERSE;
    safe += '&json={';
    safe += 'location:{latLng:{lat:' + latitude + ',lng:' + longitude + '}}}';
    var MapQuestConsumerKeyPublic = GetResources('MapQuestConsumerKeyPublic');
    var newURL = safe.replace('YOUR_KEY_HERE', MapQuestConsumerKeyPublic);
    script.src = newURL;
    document.body.appendChild(script);
}


function renderReverse(response) {
    ////debugger;
    $('#SearchNow').prop('disabled', false);
    var location = response.results[0].locations[0];
    var ZIP = location.postalCode;
    var splitZIP;
    var ZIPFive;
    var ZIPPlusFour;
    if (ZIP != "" && typeof ZIP !== "undefined") {
        splitZIP = ZIP.split("-");
        ZIPFive = splitZIP[0];
        ZIPPlusFour = splitZIP[0] + splitZIP[1];
    }
    $("#zipPlusFour").val(ZIPPlusFour);
    $("#txtboxZipCode").val(ZIPFive);
}