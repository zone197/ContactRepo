﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models;
using NABWebsite.DTO;
using NABWebsite.BLL;
using System.IO;
using System.Data;
using System.ComponentModel;
using Ionic.Zip;
using System.Globalization;
using System.Configuration;
using System.Threading;
using Aetna.Cofinity.Admin.Entities.Response;
using System.Text;
using Utilities;

namespace NABWebsite.Controllers
{
    public class ProviderFileDownloadController : BaseController
    {
        
        ManageContent contentManager = new ManageContent();
        ProviderFileDownloadBLL ProviderFileDownloadBLLObject = new ProviderFileDownloadBLL();
        //StringBuilder traceLog = new StringBuilder();
        #region Page Load

        /// <summary>
        /// index page load 
        /// </summary>
        /// <returns>ActionResult</returns>
        [CheckAccess(Function = "Provider File Download")]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                    return Content(Constants.ContentHome);

                Session[Constants.CurrentController] = Constants.ProviderFileDownload;
                Session[Constants.CurrentAction] = Constants.Index;
                Session[Constants.Header] = Constants.ProviderFileDownloadHeader;
                traceLog.AppendLine(" & End: ProviderFileDownloadController, Index Method");
                return View("ProviderFileDownload");
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        #endregion

        #region  One Time Request Tab

        
        /// <summary>
        /// Load One Time Request Tab 
        /// </summary>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult AccordionPanel()
        {
            StringBuilder traceLog = new StringBuilder();
            //Thread.Sleep(3000);
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, AccordionPanel Method");
            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                return Content(Constants.ContentHome);

            ScheduleFilesModel modelObject = new ScheduleFilesModel();
            ProviderFileDownloadModel ProviderFileDownloadModelObject = new ProviderFileDownloadModel();
            modelObject.ProviderFileDownloadModelRef = loadSelectFields(ProviderFileDownloadModelObject);
            traceLog.AppendLine(" & End: ProviderFileDownloadController, AccordionPanel Method");
            return PartialView("_DownloadNow", modelObject);
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
                
        /// <summary>
        /// fetch select field to include in report values
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult GetSelectFieldValues(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, GetSelectFieldValues Method with Param modelObject:" + modelObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ProviderFileDownloadController, GetSelectFieldValues Method");
                    return Content(Constants.ContentHome);
                }


            if (modelObject != null)
            {
                var networkSelected = modelObject.ProviderFileDownloadModelRef.NetworkChosen;
                List<SelectListItem> compFieldsSelect = new List<SelectListItem>();
                List<SelectListItem> optFieldsSelect = new List<SelectListItem>();
                FileDownloadColumns objFieldValues = new FileDownloadColumns();
                if (!string.IsNullOrEmpty(networkSelected))
                {
                    objFieldValues = ProviderFileDownloadBLLObject.GetSelectFieldValues(networkSelected);
                    compFieldsSelect = objFieldValues.Mandatory;
                    optFieldsSelect = objFieldValues.Optional;

                    if (compFieldsSelect.Count > 0)
                        compFieldsSelect.ForEach(x => x.Text += '*');

                    if (optFieldsSelect.Count > 0)
                        optFieldsSelect = optFieldsSelect.Select(t =>
                                 new SelectListItem
                                 {
                                     Text = t.Text.Contains('*') ? t.Text.Replace("*", "") : t.Text,
                                     Value = t.Value
                                 }).ToList<SelectListItem>();
                   
                }
                modelObject.ProviderFileDownloadModelRef.CompFields = compFieldsSelect;
                modelObject.ProviderFileDownloadModelRef.OptFields = optFieldsSelect;
                traceLog.AppendLine(" & End: ProviderFileDownloadController, GetSelectFieldValues Method");
                return PartialView("_SelectFieldContnetOneTimeRequest", modelObject);
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, GetSelectFieldValues Method");
            return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

           
        }

        /// <summary>
        /// fetch  state values and append with drop down
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult GetStateDropDown(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, GetStateDropDown Method with Param modelObject:" + modelObject);
            NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
            int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
            {
                traceLog.AppendLine(" & End: ProviderFileDownloadController, GetStateDropDown Method");
                return Content(Constants.ContentHome);
            }

            if (modelObject != null)
            {
                modelObject.ProviderFileDownloadModelRef.ListStates = contentManager.GetStatesLocateProvider(helper.GetRequestHeader(string.Empty, defaultSourceId));
               

                List<SelectListItem> dropDownObject = modelObject.ProviderFileDownloadModelRef.ListStates.Select(x =>
                                      new SelectListItem()
                                      {
                                          Text = x.StateName.ToString(),
                                          Value = x.StateCode.ToString()
                                      }).ToList<SelectListItem>();

                dropDownObject.Insert(0, (new SelectListItem { Text = Constants.AllStates, Value = "" }));


                modelObject.ProviderFileDownloadModelRef.StatesDropDown = dropDownObject;
                traceLog.AppendLine(" & End: ProviderFileDownloadController, GetStateDropDown Method");
                 return PartialView("_StateRadioViewChoosen", modelObject);
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, GetStateDropDown Method");
             return Content(Constants.ContentError);
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// fetch state values and append with checkbox
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult GetMultipleStateCheckBoxes(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, GetMultipleStateCheckBoxes Method with Param modelObject:" + modelObject);
            NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
            int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                return Content(Constants.ContentHome);

            if (modelObject != null)
            {
                modelObject.ProviderFileDownloadModelRef.StatesDropDownChosen = string.Empty;
            


                modelObject.ProviderFileDownloadModelRef.ListStates = contentManager.GetStatesLocateProvider(helper.GetRequestHeader(string.Empty, defaultSourceId));

                modelObject.ProviderFileDownloadModelRef.StatesCheckBoxes = modelObject.ProviderFileDownloadModelRef.ListStates.Select(x =>
                                      new StatesAvailable()
                                      {
                                          StateCheckBoxName = x.StateName.ToString(),
                                          StateCheckBoxValue = x.StateCode.ToString()
                                      }).ToList<StatesAvailable>();
                traceLog.AppendLine(" & End: ProviderFileDownloadController, GetMultipleStateCheckBoxes Method");
                   return PartialView("_MultiStateRadioViewChoosen", modelObject);
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, GetMultipleStateCheckBoxes Method");
         return Content(Constants.ContentError);
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// fetch county/city values based on selection 
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult CountyCitySelector(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, CountyCitySelector Method with Param modelObject:" + modelObject);
            NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
            int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                return Content(Constants.ContentHome);
         
            if (modelObject != null)
            {
                string selector = modelObject.ProviderFileDownloadModelRef.CountyCityRadio;

                if (selector.ToUpperInvariant() == Constants.County.ToUpperInvariant())
                {
                    modelObject.ProviderFileDownloadModelRef.CountyList = contentManager.GetCountiesByStateLocateProvider(modelObject.ProviderFileDownloadModelRef.StatesDropDownChosen, helper.GetRequestHeader(string.Empty, defaultSourceId));
                    modelObject.ProviderFileDownloadModelRef.CountyCheckBox = modelObject.ProviderFileDownloadModelRef.CountyList.Select(x =>
                                            new CountyAvailable()
                                            {
                                                CountyCheckBoxValue = x.CountyName.ToString(),
                                            }).ToList<CountyAvailable>();

                }
                else
                    if (selector.ToUpperInvariant() == Constants.City.ToUpperInvariant())
                    {
                        modelObject.ProviderFileDownloadModelRef.CityList = contentManager.GetCitiesByStateLocateProvider(modelObject.ProviderFileDownloadModelRef.StatesDropDownChosen, helper.GetRequestHeader(string.Empty, defaultSourceId));
                        modelObject.ProviderFileDownloadModelRef.CityCheckBox = modelObject.ProviderFileDownloadModelRef.CityList.Select(x =>
                                                new CityAvailable()
                                                {
                                                    CityCheckBoxValue = x.CityName.ToString()
                                                }).ToList<CityAvailable>();

                    }
                    else
                    {
                        modelObject.ProviderFileDownloadModelRef.CountyList = contentManager.GetCountiesByStateLocateProvider(modelObject.ProviderFileDownloadModelRef.StatesDropDownChosen, helper.GetRequestHeader(string.Empty, defaultSourceId));
                        modelObject.ProviderFileDownloadModelRef.OtherCountyDropDown = modelObject.ProviderFileDownloadModelRef.CountyList.Select(x =>
                                                new SelectListItem()
                                                {
                                                    Text = x.CountyName.ToString(),
                                                    Value = x.CountyName.ToString()
                                                }).ToList<SelectListItem>();


                        List<SelectListItem> OtherCityDropDownObject = new List<SelectListItem>();
                        modelObject.ProviderFileDownloadModelRef.OtherCityDropDown = OtherCityDropDownObject;


                    }
                traceLog.AppendLine(" & End: ProviderFileDownloadController, CountyCitySelector Method");
                 return PartialView("_CountyCityDropDownView", modelObject);
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, CountyCitySelector Method");
             return Content(Constants.ContentError);
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

      
        /// <summary>
        /// show Download Panel based on search criteria
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult ShowDownloadPanel(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, ShowDownloadPanel Method with Param modelObject:" + modelObject);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ProviderFileDownloadController, ShowDownloadPanel Method");
                    return Content(Constants.ContentHome);
                }

            if (modelObject != null)
            {
                string networkSelected = modelObject.ProviderFileDownloadModelRef.NetworkChosen;
                string fileTypeChoosen = modelObject.ProviderFileDownloadModelRef.FileTypeChosen;
                string fileNameUserGiven = modelObject.ProviderFileDownloadModelRef.FileName;
                //string filePathName = string.Empty;
                string selectStatementValue = modelObject.ProviderFileDownloadModelRef.AllSelectedFields;
                string stateOrMultistate = modelObject.ProviderFileDownloadModelRef.StateMultipleStateRadio;
                
                string stateChosen = null;
                string countyCityRadio = string.Empty;
                string countyChosen = null;
                string cityChosen = null;
                string dateLastUpdate = null;
                string GHEffDate = string.Empty;
                string userId = string.Empty;
                string userType = string.Empty;
                var email = string.Empty; 
                if (Session[Constants.UserDetails] != null)
                {
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                    {
                        userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    }
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserData.Email))
                    {
                        email = ((UserDetails)Session[Constants.UserDetails]).UserData.Email;
                    }
                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    userType = ConfigurationManager.AppSettings[Constants.Site];
                }
                string applicationName = ConfigurationManager.AppSettings["ApplicationName"].ToString();
                if (stateOrMultistate.ToUpperInvariant() == Constants.MultipleState.ToUpperInvariant())
                    stateChosen = modelObject.ProviderFileDownloadModelRef.MultipleCheckStatesDownload;
                else
                {
                    stateChosen = modelObject.ProviderFileDownloadModelRef.StatesDropDownChosen;
                    if (stateChosen.ToUpperInvariant() != "AllState".ToUpperInvariant())
                    {
                        countyCityRadio = modelObject.ProviderFileDownloadModelRef.CountyCityRadio;
                        if (countyCityRadio.ToUpperInvariant() == Constants.County.ToUpperInvariant())
                        {
                            countyChosen = modelObject.ProviderFileDownloadModelRef.CountyChosen;
                        }
                        else
                            if (countyCityRadio.ToUpperInvariant() == Constants.City.ToUpperInvariant())
                            {
                                cityChosen = modelObject.ProviderFileDownloadModelRef.CityChosen;
                            }
                            else
                            {
                                countyChosen = modelObject.ProviderFileDownloadModelRef.OtherCountyDropDownChosen;
                                cityChosen = modelObject.ProviderFileDownloadModelRef.OtherCityDropDownChosen;
                            }
                    }
                }

                string fullOrUpdate = modelObject.ProviderFileDownloadModelRef.SpecifyDateRange;
                if (fullOrUpdate.ToUpperInvariant() != Constants.AllRange.ToUpperInvariant())
                    dateLastUpdate = modelObject.ProviderFileDownloadModelRef.SelectDate;

                if (string.IsNullOrEmpty(dateLastUpdate))
                {
                    GHEffDate = DateTime.Now.ToShortDateString();
                    dateLastUpdate = Constants.ValidDate;
                }
                else
                {
                    GHEffDate = Constants.ValidDate;
                }
                   

                //--------------------removing trailing commas-------------//

                if (!string.IsNullOrEmpty(stateChosen) && stateChosen.Substring(stateChosen.Length - 1, 1) == ",")
                    stateChosen = stateChosen.Substring(0, stateChosen.LastIndexOf(Constants.CommaWithoutSpace, StringComparison.Ordinal));
                if (!string.IsNullOrEmpty(countyChosen) && countyChosen.Substring(countyChosen.Length - 1, 1) == ",")
                    countyChosen = countyChosen.Substring(0, countyChosen.LastIndexOf(Constants.CommaWithoutSpace, StringComparison.Ordinal));
                if (!string.IsNullOrEmpty(cityChosen) && cityChosen.Substring(stateChosen.Length - 1, 1) == ",")
                    cityChosen = cityChosen.Substring(0, cityChosen.LastIndexOf(Constants.CommaWithoutSpace, StringComparison.Ordinal));

                //---------------------------------------------------------//

              
                //string whereStatement = MakeWhereStatement(stateChosen, cityChosen, countyChosen, dateLastUpdate, GHEffDate, fullOrUpdate);

                InputDownloadProvider inputDownloadProviderObject = new InputDownloadProvider();
               
                //inputDownloadProviderObject.WhereStatement = whereStatement;
                inputDownloadProviderObject.StateChosen = stateChosen;
                inputDownloadProviderObject.CityChosen = cityChosen;
                inputDownloadProviderObject.CountyChosen = countyChosen;
                inputDownloadProviderObject.DateLastUpdate = dateLastUpdate;
                inputDownloadProviderObject.GHEffDate = GHEffDate;
                inputDownloadProviderObject.FullOrUpdate = fullOrUpdate == Constants.AllRange ? Constants.FullRange : Constants.UpdateRange;

                inputDownloadProviderObject.ProductCode = networkSelected;
                inputDownloadProviderObject.ApplicationName = applicationName;
                               
                if (Session[Constants.UserDetails] != null)
                {
                    List<string> networkList = new List<string>();
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                    {
                        inputDownloadProviderObject.UserId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    }
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole))
                    {
                        inputDownloadProviderObject.UserRole = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                    }
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                    {
                        inputDownloadProviderObject.IsEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                        //inputDownloadProviderObject.CanCheckRestrictedMembers = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                        IEnumerable<CanCheckRestrictedMember> canCheckRestrictedList = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                        if (canCheckRestrictedList != null) inputDownloadProviderObject.CanCheckRestrictedMembers = canCheckRestrictedList.FirstOrDefault().RestrictedCheck == 1 ? true : false;
                        else inputDownloadProviderObject.CanCheckRestrictedMembers = false;

                        ////get selected role
                        Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                        ////get the network for selcted function
                        networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuProviderFile, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();

                    }

                    if (networkList != null)
                    {
                        inputDownloadProviderObject.Network = string.Join(",", networkList);
                    }
                }
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    inputDownloadProviderObject.UserType = ConfigurationManager.AppSettings[Constants.Site];
                }
          

                int recordCount = ProviderFileDownloadBLLObject.GetProviderFileRecordCount(inputDownloadProviderObject);

                modelObject.ProviderFileDownloadModelRef.DownloadNowRecordCount = recordCount;
                

                 if (recordCount > 0)
                 {
                     
                    CreateSchedule createScheduleObject = new CreateSchedule();
                    createScheduleObject.Userid = userId;
                    createScheduleObject.NetworkValue = networkSelected;
                    createScheduleObject.Email = email;
                    createScheduleObject.FileName = fileNameUserGiven;
                    createScheduleObject.FileTypeChosen = fileTypeChoosen;
                    createScheduleObject.FieldsIncludedContent = selectStatementValue;
                    createScheduleObject.StateChosen = stateChosen;
                    createScheduleObject.CountyChosen = countyChosen;
                    createScheduleObject.CityChosen = cityChosen;
                    createScheduleObject.SpecifyDateRange = fullOrUpdate == Constants.AllRange ? Constants.FullRange : Constants.UpdateRange;
                    createScheduleObject.SelectedDay = null;
                    createScheduleObject.SelectedDate = null;
                    createScheduleObject.LastChange = dateLastUpdate;
                    createScheduleObject.EffectiveDate = GHEffDate;
                    createScheduleObject.UserType = userType;
                    createScheduleObject.ApplicationName = applicationName;

                    int result = -1;
                    result = InsertSchedule(createScheduleObject);

                    if (result != @Constants.OneCount)
                        return Content(Constants.ContentError);
                }
                
                
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, ShowDownloadPanel Method");
            return PartialView("_DownloadRecordDisplay", modelObject);
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// add schedule from one time request based on input provided
        /// </summary>
        /// <param name="createScheduleObject"></param>
        /// <returns>int</returns>
        private int InsertSchedule(CreateSchedule createScheduleObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, InsertSchedule Method with Param createScheduleObject:" + createScheduleObject);
            int result = 0;
            result = ProviderFileDownloadBLLObject.SaveSchedule(createScheduleObject);
            traceLog.AppendLine(" & End: ProviderFileDownloadController, InsertSchedule Method");
            return result;
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

          #endregion
     
        #region Schedule Files Tab

        /// <summary>
        /// Get Schedule count
        /// </summary>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult ScheduleCount()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, ScheduleCount Method");
            var result = -1;

            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
            {
                result = 0;
            }

            string userId = string.Empty;
            if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
            {
                userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
            }
            ScheduleFilesModel modelObject = new ScheduleFilesModel();
            if (!string.IsNullOrEmpty(userId))
            {
                modelObject.ScheduledFilesModel = ProviderFileDownloadBLLObject.GetScheduledFiles(userId).ToList();
                result = modelObject.ScheduledFilesModel.Count();
            }

            //Thread.Sleep(3000);
            traceLog.AppendLine(" & End: ProviderFileDownloadController, ScheduleCount Method");
                return Json(result, JsonRequestBehavior.AllowGet);
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
       /// Get Schedule Tabel page
       /// </summary>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult ScheduledFiles()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, ScheduledFiles Method");
            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
            {
                return Content(Constants.ContentHome);
            }

            string userId = string.Empty;
            if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
            {
                userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
            }
            ScheduleFilesModel modelObject = new ScheduleFilesModel();
            if (userId != null)
            {
                modelObject.ScheduledFilesModel = ProviderFileDownloadBLLObject.GetScheduledFiles(userId).ToList();
                modelObject.TotalCount = modelObject.ScheduledFilesModel.Count();
                traceLog.AppendLine(" & End: ProviderFileDownloadController, ScheduledFiles Method");
                return PartialView("_ScheduledFiles", modelObject);
            }
            else
            {
                traceLog.AppendLine(" & End: ProviderFileDownloadController, ScheduledFiles Method");
                return Content(Constants.ContentError);
            }
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        #endregion

        #region Create Download Schedule 

       /// <summary>
       /// Get Create schedule accordion panel
       /// </summary>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult CreateNewSchedule()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, CreateNewSchedule Method");
            ScheduleFilesModel modelObject = new ScheduleFilesModel();
            ProviderFileCreateScheduleModel ProviderFileCreateScheduleModelObject = new ProviderFileCreateScheduleModel();
            modelObject.ProviderFileCreateScheduleModelRef = LoadScheduleSelectFields(ProviderFileCreateScheduleModelObject);
            traceLog.AppendLine(" & End: ProviderFileDownloadController, CreateNewSchedule Method");
            return PartialView("_CreateSchedule", modelObject);
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get select fields to include in report
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult GetSelectFieldValuesForSchedule(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, GetSelectFieldValuesForSchedule Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ProviderFileDownloadController, GetSelectFieldValuesForSchedule Method");
                    return Content(Constants.ContentHome);
                }


            if (modelObject != null)
            {
                var networkSelected = modelObject.ProviderFileCreateScheduleModelRef.NetworksChosenSchedule;
                List<SelectListItem> compFieldsSelect = new List<SelectListItem>();
                List<SelectListItem> optFieldsSelect = new List<SelectListItem>();
                FileDownloadColumns objFieldValues = new FileDownloadColumns();
                if (!string.IsNullOrEmpty(networkSelected))
                {
                    objFieldValues = ProviderFileDownloadBLLObject.GetSelectFieldValues(networkSelected);
                    compFieldsSelect = objFieldValues.Mandatory;
                    optFieldsSelect = objFieldValues.Optional;


                        if (compFieldsSelect.Count > 0)
                        compFieldsSelect.ForEach(x => x.Text += '*');

                    if (optFieldsSelect.Count > 0)
                            optFieldsSelect = optFieldsSelect.Select(t =>
                        new SelectListItem
                        {
                                     Text = t.Text.Contains('*') ? t.Text.Replace("*", "") : t.Text,
                            Value = t.Value
                        }).ToList<SelectListItem>();
                                     
                }
                modelObject.ProviderFileCreateScheduleModelRef.RequiredFieldsSchedule = compFieldsSelect;
                modelObject.ProviderFileCreateScheduleModelRef.OptionalFieldsSchedule = optFieldsSelect;
                traceLog.AppendLine(" & End: ProviderFileDownloadController, GetSelectFieldValuesForSchedule Method");
                return PartialView("_SelectFieldContnetSchedule", modelObject);
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, GetSelectFieldValuesForSchedule Method");
            return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            

        }

        /// <summary>
        /// fetch states and bind to dropdown
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult GetStateDropDownCreateSchedule(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, GetStateDropDownCreateSchedule Method with Param modelObject: " + modelObject);
            NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
            int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
            {
                traceLog.AppendLine(" & End: ProviderFileDownloadController, GetStateDropDownCreateSchedule Method");
                return Content(Constants.ContentHome);
            }

            if (modelObject != null)
            {
                modelObject.ProviderFileCreateScheduleModelRef.ListStatesSchedule = contentManager.GetStatesLocateProvider(helper.GetRequestHeader(string.Empty, defaultSourceId));


                List<SelectListItem> dropDownObject = modelObject.ProviderFileCreateScheduleModelRef.ListStatesSchedule.Select(x =>
                                      new SelectListItem()
                                      {
                                          Text = x.StateName.ToString(),
                                          Value = x.StateCode.ToString()
                                      }).ToList<SelectListItem>();

                dropDownObject.Insert(0, (new SelectListItem { Text = Constants.AllStates, Value = "" }));


                modelObject.ProviderFileCreateScheduleModelRef.StatesDropDownSchedule = dropDownObject;
                traceLog.AppendLine(" & End: ProviderFileDownloadController, GetStateDropDownCreateSchedule Method");
                   return PartialView("_StateRadioViewChoosenCreateSchedule", modelObject);
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, GetStateDropDownCreateSchedule Method");
            return Content(Constants.ContentError);

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

         /// <summary>
        /// fetch states and bind with checkboxes
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult GetMultipleStateCheckBoxesCreateSchedule(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, GetMultipleStateCheckBoxesCreateSchedule Method with Param modelObject: " + modelObject);
            NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
            int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
            {
                traceLog.AppendLine(" & End: ProviderFileDownloadController, GetMultipleStateCheckBoxesCreateSchedule Method");
                return Content(Constants.ContentHome);
            }
          
            if (modelObject != null)
            {
                //modelObject.ProviderFileCreateScheduleModelRef.StatesDropDownChosenSchedule = string.Empty;
                //modelObject.ProviderFileCreateScheduleModelRef.CountyCityRadioSchedule = string.Empty;


                modelObject.ProviderFileCreateScheduleModelRef.ListStatesSchedule = contentManager.GetStatesLocateProvider(helper.GetRequestHeader(string.Empty, defaultSourceId));

                modelObject.ProviderFileCreateScheduleModelRef.StatesCheckBoxesSchedule = modelObject.ProviderFileCreateScheduleModelRef.ListStatesSchedule.Select(x =>
                                      new StatesAvailable()
                                      {
                                          StateCheckBoxName = x.StateName.ToString(),
                                          StateCheckBoxValue = x.StateCode.ToString()
                                      }).ToList<StatesAvailable>();
                traceLog.AppendLine(" & End: ProviderFileDownloadController, GetMultipleStateCheckBoxesCreateSchedule Method");
                   return PartialView("_MultiStateRadioViewChoosenCreateSchedule", modelObject);
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, GetMultipleStateCheckBoxesCreateSchedule Method");
            return Content(Constants.ContentError);         
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// fetch county/city values based on selection
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult CountyCitySelectorCreateSchedule(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, CountyCitySelectorCreateSchedule Method with Param modelObject: " + modelObject);
            NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
            int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                  return Content(Constants.ContentHome);

            if (modelObject != null)
            {
                string selector = modelObject.ProviderFileCreateScheduleModelRef.CountyCityRadioSchedule;

                if (selector.ToUpperInvariant() == Constants.County.ToUpperInvariant())
                {
                    modelObject.ProviderFileCreateScheduleModelRef.CountyListSchedule = contentManager.GetCountiesByStateLocateProvider(modelObject.ProviderFileCreateScheduleModelRef.StatesDropDownChosenSchedule, helper.GetRequestHeader(string.Empty, defaultSourceId));
                    modelObject.ProviderFileCreateScheduleModelRef.CountyCheckBoxSchedule = modelObject.ProviderFileCreateScheduleModelRef.CountyListSchedule.Select(x =>
                                            new CountyAvailable()
                                            {
                                                CountyCheckBoxValue = x.CountyName.ToString(),
                                            }).ToList<CountyAvailable>();

                }
                else
                    if (selector.ToUpperInvariant() == Constants.City.ToUpperInvariant())
                    {
                        modelObject.ProviderFileCreateScheduleModelRef.CityListSchedule = contentManager.GetCitiesByStateLocateProvider(modelObject.ProviderFileCreateScheduleModelRef.StatesDropDownChosenSchedule, helper.GetRequestHeader(string.Empty, defaultSourceId));
                        modelObject.ProviderFileCreateScheduleModelRef.CityCheckBoxSchedule = modelObject.ProviderFileCreateScheduleModelRef.CityListSchedule.Select(x =>
                                                new CityAvailable()
                                                {
                                                    CityCheckBoxValue = x.CityName.ToString()
                                                }).ToList<CityAvailable>();

                    }
                    else
                    {
                        modelObject.ProviderFileCreateScheduleModelRef.CountyListSchedule = contentManager.GetCountiesByStateLocateProvider(modelObject.ProviderFileCreateScheduleModelRef.StatesDropDownChosenSchedule, helper.GetRequestHeader(string.Empty, defaultSourceId));
                        modelObject.ProviderFileCreateScheduleModelRef.OtherCountyDropDownSchedule = modelObject.ProviderFileCreateScheduleModelRef.CountyListSchedule.Select(x =>
                                                new SelectListItem()
                                                {
                                                    Text = x.CountyName.ToString(),
                                                    Value = x.CountyName.ToString()
                                                }).ToList<SelectListItem>();


                        List<SelectListItem> OtherCityDropDownObject = new List<SelectListItem>();
                        modelObject.ProviderFileCreateScheduleModelRef.OtherCityDropDownSchedule = OtherCityDropDownObject;


                    }
                traceLog.AppendLine(" & End: ProviderFileDownloadController, CountyCitySelectorCreateSchedule Method");
                  return PartialView("_CountyCityDropDownViewCreateSchedule", modelObject);
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, CountyCitySelectorCreateSchedule Method");
            return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
          
        }


        /// <summary>
        /// add schedule from create download schedule based on input provided
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult AddNewSchedule(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, AddNewSchedule Method with Param modelObject: " + modelObject);
             int result = 0;
            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
            {
                traceLog.AppendLine(" & End: ProviderFileDownloadController, AddNewSchedule Method");
                return Content(Constants.ContentHome);
            }
            
               if (modelObject != null)
               {
                   string fileTypeChoosen = modelObject.ProviderFileCreateScheduleModelRef.FileTypeChosenSchedule;
                   string fileNameUserGiven = modelObject.ProviderFileCreateScheduleModelRef.FileNameSchedule;

                   string selectStatementValue = modelObject.ProviderFileCreateScheduleModelRef.AllSelectedFieldsSchedule;
                   string stateOrMultistate = modelObject.ProviderFileCreateScheduleModelRef.StateMultipleStateRadioSchedule;

                   string stateChosen = null;
                   string countyCityRadio = string.Empty;
                   string countyChosen = null;
                   string cityChosen = null;
                   string selectedDate = null;
                   string selectedDay = null;
                   string userId = string.Empty;
                   string userType = string.Empty;
                   if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                   {
                       userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                   }
                   if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                   {
                       userType = ConfigurationManager.AppSettings[Constants.Site];
                   }
                   string applicationName = ConfigurationManager.AppSettings["ApplicationName"].ToString();
                   if (stateOrMultistate.ToUpperInvariant() == Constants.MultipleState.ToUpperInvariant())
                       stateChosen = modelObject.ProviderFileCreateScheduleModelRef.MultipleCheckStatesSchedule;
                   else
                   {
                       stateChosen = modelObject.ProviderFileCreateScheduleModelRef.StatesDropDownChosenSchedule;
                       if (stateChosen.ToUpperInvariant() != "AllState".ToUpperInvariant())
                       {
                           countyCityRadio = modelObject.ProviderFileCreateScheduleModelRef.CountyCityRadioSchedule;
                           if (countyCityRadio.ToUpperInvariant() == Constants.County.ToUpperInvariant())
                           {
                               countyChosen = modelObject.ProviderFileCreateScheduleModelRef.CountyChosenSchedule;
                           }
                           else
                               if (countyCityRadio.ToUpperInvariant() == Constants.City.ToUpperInvariant())
                               {
                                   cityChosen = modelObject.ProviderFileCreateScheduleModelRef.CityChosenSchedule;
                               }
                               else
                               {
                                   countyChosen = modelObject.ProviderFileCreateScheduleModelRef.OtherCountyDropDownChosenSchedule;
                                   cityChosen = modelObject.ProviderFileCreateScheduleModelRef.OtherCityDropDownChosenSchedule;
                               }
                       }
                   }

                   string fullOrUpdate = modelObject.ProviderFileCreateScheduleModelRef.SpecifyDateRangeSchedule;
                   string dayOrMonth = modelObject.ProviderFileCreateScheduleModelRef.ScheduleTypeRadioSchedule;
                 
                   if (dayOrMonth.ToUpperInvariant() == Constants.Weekly.ToUpperInvariant())
                   {
                       selectedDay = modelObject.ProviderFileCreateScheduleModelRef.SelectedDay;
                   }

                   else
                   {
                       selectedDate = modelObject.ProviderFileCreateScheduleModelRef.SelectedDate;
                   }
                  

                   //--------------------removing trailing commas-------------//
                  
                    if (!string.IsNullOrEmpty(stateChosen) && stateChosen.Substring(stateChosen.Length - 1, 1) == ",")
                       stateChosen = stateChosen.Substring(0, stateChosen.LastIndexOf(Constants.CommaWithoutSpace, StringComparison.Ordinal));
                   if (!string.IsNullOrEmpty(countyChosen) && countyChosen.Substring(countyChosen.Length - 1, 1) == ",")
                       countyChosen = countyChosen.Substring(0, countyChosen.LastIndexOf(Constants.CommaWithoutSpace, StringComparison.Ordinal));
                   if (!string.IsNullOrEmpty(cityChosen) && cityChosen.Substring(stateChosen.Length - 1, 1) == ",")
                        cityChosen = cityChosen.Substring(0, cityChosen.LastIndexOf(Constants.CommaWithoutSpace, StringComparison.Ordinal));

                   //---------------------------------------------------------//

                    var networkSelected = modelObject.ProviderFileCreateScheduleModelRef.NetworksChosenSchedule;
                   
                   var email = ((UserDetails)Session[Constants.UserDetails]).UserData.Email;
                   
                   CreateSchedule createScheduleObject = new CreateSchedule();
                   createScheduleObject.Userid = userId;
                   createScheduleObject.Email = email;
                   createScheduleObject.NetworkValue = networkSelected;
                   createScheduleObject.FileName = fileNameUserGiven;
                   createScheduleObject.FileTypeChosen = fileTypeChoosen;
                   createScheduleObject.FieldsIncludedContent = selectStatementValue;
                   createScheduleObject.StateChosen = stateChosen;
                   createScheduleObject.CountyChosen = countyChosen;
                   createScheduleObject.CityChosen = cityChosen;
                   createScheduleObject.SpecifyDateRange = fullOrUpdate == Constants.AllRange ? Constants.FullRange : Constants.UpdateRange;
                   createScheduleObject.SelectedDay = selectedDay;
                   createScheduleObject.SelectedDate = selectedDate;
                   createScheduleObject.LastChange = Constants.ValidDate;
                   createScheduleObject.EffectiveDate = Constants.ValidDate;
                   createScheduleObject.UserType = userType;
                   createScheduleObject.ApplicationName = applicationName;
                   
                   result = InsertSchedule(createScheduleObject);
               }
               else
               {
                   result = 0;

               }
               traceLog.AppendLine(" & End: ProviderFileDownloadController, AddNewSchedule Method");
            return Json(result, JsonRequestBehavior.AllowGet);
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        [AjaxValidateAntiForgeryToken]
        public JsonResult CheckFileExists(string fileName)
        {
            StringBuilder traceLog = new StringBuilder();
            int response = 0;
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, CheckFileExists Method with Param fileName: " + fileName);
                string userId = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                }

            response = ProviderFileDownloadBLLObject.CheckFileExists(userId, fileName);
            traceLog.AppendLine(" & End: ProviderFileDownloadController, CheckFileExists Method");
        }
            catch (Exception ex)
            {
                response = -1;
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return Json(response, JsonRequestBehavior.AllowGet);
        }

        [AjaxValidateAntiForgeryToken]
        public ActionResult ModifyCheckedSchedule(string fileName)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {

                traceLog.AppendLine("Start: ProviderFileDownloadController, ModifyCheckedSchedule Method with Param fileName: " + fileName);
                string userId = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                }
            

            ModifySchedule OutputObject = new ModifySchedule();


            ScheduleFilesModel inputObject = new ScheduleFilesModel();
            ProviderFileCreateScheduleModel createScheduleObject = new ProviderFileCreateScheduleModel();

            OutputObject = ProviderFileDownloadBLLObject.ModifyCheckedSchedule(userId, fileName);

            
            MakeModifyScheduleObject(createScheduleObject, OutputObject);
            createScheduleObject = LoadScheduleSelectFields(createScheduleObject);
            createScheduleObject.NetworksChosenSchedule = OutputObject.NetworkValue;
            createScheduleObject.FileNameSchedule = fileName;
            createScheduleObject.AllSelectedFieldsSchedule = OutputObject.FieldsIncludedContent;
            LoadIncludeReportField(createScheduleObject);


            createScheduleObject.SelectedDate = OutputObject.SelectedDate;
            createScheduleObject.SelectedDay = OutputObject.SelectedDay;
            if (!string.IsNullOrEmpty(createScheduleObject.SelectedDate))
                createScheduleObject.ScheduleTypeRadioSchedule = "Monthly";
            else
                createScheduleObject.ScheduleTypeRadioSchedule = "Weekly";

            var fullOrUpdate = OutputObject.SpecifyDateRange;
            if (fullOrUpdate.Equals(Constants.FullRange))
                createScheduleObject.SpecifyDateRangeSchedule = "all";
            else
                createScheduleObject.SpecifyDateRangeSchedule = "updateList";



            inputObject.ProviderFileCreateScheduleModelRef = createScheduleObject;

            traceLog.AppendLine(" & End: ProviderFileDownloadController, ModifyCheckedSchedule Method");
            return PartialView("_CreateSchedule", inputObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        [AjaxValidateAntiForgeryToken]
        public ActionResult DeleteCheckedSchedules(ScheduleFilesModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, DeleteCheckedSchedules Method with Param modelObject: " + modelObject);
            if (modelObject != null)
            {
                var deleteSelections = modelObject.DeleteSchedules;
                string userId = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                }
                int confirmDelete = ProviderFileDownloadBLLObject.DeleteCheckedSchedules(userId, deleteSelections);
                if (confirmDelete > 0)
                {
                    traceLog.AppendLine(" & End: ProviderFileDownloadController, DeleteCheckedSchedules Method");
                    return RedirectToAction("ScheduledFiles", "ProviderFileDownload", null);
                }
                else
                {
                    if (confirmDelete == -1)
                    {
                        traceLog.AppendLine(" & End: ProviderFileDownloadController, DeleteCheckedSchedules Method");
                        return Content(Constants.ContentError);
                    }


                    traceLog.AppendLine(" & End: ProviderFileDownloadController, DeleteCheckedSchedules Method");
                    return Content(Constants.Index);
                }
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, DeleteCheckedSchedules Method");
            return Content(Constants.ContentError);
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private void LoadIncludeReportField(ProviderFileCreateScheduleModel createScheduleObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, LoadIncludeReportField Method with Param createScheduleObject: " + createScheduleObject);
                var networkSelected = createScheduleObject.NetworksChosenSchedule;
                List<SelectListItem> compFieldsSelect = new List<SelectListItem>();
                List<SelectListItem> optFieldsSelect = new List<SelectListItem>();
                FileDownloadColumns objFieldValues = new FileDownloadColumns();
                if (!string.IsNullOrEmpty(networkSelected))
                {
                    objFieldValues = ProviderFileDownloadBLLObject.GetSelectFieldValues(networkSelected);
                    compFieldsSelect = objFieldValues.Mandatory;
                    optFieldsSelect = objFieldValues.Optional;                  

                }
                   

                if (compFieldsSelect.Count > 0)
                compFieldsSelect.ForEach(x => x.Text += '*');

                if (optFieldsSelect.Count > 0)
                optFieldsSelect = optFieldsSelect.Select(t =>
                         new SelectListItem
                         {
                             Text = t.Text.Contains('*') ? t.Text.Replace("*", "") : t.Text,
                             Value = t.Value
                         }).ToList<SelectListItem>();
                                     

            var includedReportValues = createScheduleObject.AllSelectedFieldsSchedule;
                var eachValue = includedReportValues.Split(',');
            List<SelectListItem> compFieldsActual = new List<SelectListItem>();

            for (int i = 0; i < eachValue.Length; i++)
            {
                SelectListItem itemObject = new SelectListItem();
               itemObject = compFieldsSelect.Where(x => x.Value == eachValue[i]).Select(x => x).FirstOrDefault();

                    if (itemObject == null)
                itemObject = optFieldsSelect.Where(x => x.Value == eachValue[i]).Select(x => x).FirstOrDefault();

                 compFieldsActual.Add(itemObject);   
             }

          optFieldsSelect.RemoveAll(p1 => eachValue.Any(p2 => p1.Value == p2));

                //for (int i = 0; i < eachValue.Length; i++)
                //{
                //    for (int j = 0; j < optFieldsSelect.Count; j++)
        //    {
                //       if( eachValue[i].Equals(optFieldsSelect[j].Value))
                //       {
                //           optFieldsSelect.Remove(optFieldsSelect.Where(x => x.Value == eachValue[i]).First());
                //       }
        //    }
                //}
                createScheduleObject.RequiredFieldsSchedule = compFieldsActual;
            createScheduleObject.OptionalFieldsSchedule = optFieldsSelect;
            traceLog.AppendLine(" & End: ProviderFileDownloadController, LoadIncludeReportField Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
          
        }

        private void MakeModifyScheduleObject(ProviderFileCreateScheduleModel inputObject, ModifySchedule OutputObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, MakeModifyScheduleObject Method with Param inputObject: " + inputObject + " and with Param OutputObject: " + OutputObject);
            inputObject.FileNameSchedule = OutputObject.FileName;
            inputObject.FileTypeChosenSchedule = OutputObject.FileTypeChosen.TrimEnd(' ');
            inputObject.FieldsIncludedContentSchedule = OutputObject.FieldsIncludedContent;
            inputObject.NetworksChosenSchedule = OutputObject.NetworkValue;
            var stateChosen = OutputObject.StateChosen;
                if ((stateChosen.Equals(FirstCharToUpper(Constants.AllState)) &&
                    string.IsNullOrEmpty(OutputObject.CountyChosen) && 
                    string.IsNullOrEmpty(OutputObject.CityChosen)))
            {
                inputObject.StateMultipleStateRadioSchedule = Constants.State;
                inputObject.StatesDropDownChosenSchedule = "";
                inputObject.StatesDropDownSchedule = BindStateValuesToDropDown();
            }
            else
                    if ((stateChosen.Equals(FirstCharToUpper(Constants.AllMultiState)) &&
                    string.IsNullOrEmpty(OutputObject.CountyChosen) && 
                    string.IsNullOrEmpty(OutputObject.CityChosen)) 
                    ||
                    (!string.IsNullOrEmpty(stateChosen) && 
                    string.IsNullOrEmpty(OutputObject.CountyChosen) &&
                    string.IsNullOrEmpty(OutputObject.CityChosen)))
                {
                    inputObject.StateMultipleStateRadioSchedule = Constants.MultipleState;
                    inputObject.MultipleCheckStatesSchedule = stateChosen;
                    inputObject.StatesCheckBoxesSchedule = BindStateValuesToCheckBox();
                }
            else
                        if ((!stateChosen.Contains(',') &&
                    !string.IsNullOrEmpty(OutputObject.CountyChosen)) 
                    || 
                        (!stateChosen.Contains(',') && 
                    !string.IsNullOrEmpty(OutputObject.CityChosen)))
                {
                    inputObject.StateMultipleStateRadioSchedule = Constants.State;
                    inputObject.StatesDropDownChosenSchedule = stateChosen;
                    inputObject.StatesDropDownSchedule = BindStateValuesToDropDown();
                            var countyChosen = !string.IsNullOrEmpty(OutputObject.CountyChosen) ? OutputObject.CountyChosen : null;
                    var cityChosen = !string.IsNullOrEmpty(OutputObject.CityChosen) ? OutputObject.CityChosen : null;
                    BindCountyCity(countyChosen, cityChosen, inputObject);
                    traceLog.AppendLine(" & End: ProviderFileDownloadController, MakeModifyScheduleObject Method");
                }
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private IEnumerable<StatesAvailable> BindStateValuesToCheckBox()
        {
            StringBuilder traceLog = new StringBuilder();
            //ManageContent obj = new ManageContent();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, BindStateValuesToCheckBox Method ");
            NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
            int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);

            IEnumerable<Aetna.ProviderContracts.DataContracts.State> ListStates = contentManager.GetStatesLocateProvider(helper.GetRequestHeader(string.Empty, defaultSourceId));
            List<StatesAvailable> objectStatesCheckboxes = new List<StatesAvailable>();


            objectStatesCheckboxes = ListStates.Select(x =>
                                      new StatesAvailable()
                                      {
                                          StateCheckBoxName = x.StateName.ToString(),
                                          StateCheckBoxValue = x.StateCode.ToString()
                                      }).ToList<StatesAvailable>();
            traceLog.AppendLine(" & End: ProviderFileDownloadController, BindStateValuesToCheckBox Method");
            return objectStatesCheckboxes;
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private void BindCountyCity(string countyChosen, string cityChosen, ProviderFileCreateScheduleModel inputObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, BindCountyCity Method with Param countyChosen: " + countyChosen + " and with Param cityChosen: " + cityChosen + " and with Param inputObject: " + inputObject);
            bool checkMultipleCounty = false;
            bool checkMultipleCity = false;
            if (!string.IsNullOrEmpty(countyChosen))
            {
                if (countyChosen.Contains(Constants.CommaWithoutSpace) || countyChosen.Equals(Constants.All) || string.IsNullOrEmpty(cityChosen))
                {
                    checkMultipleCounty = true;
                    inputObject.CountyChosenSchedule = countyChosen;          
                }
            }

            if (!string.IsNullOrEmpty(cityChosen))
            {
                if (cityChosen.Contains(Constants.CommaWithoutSpace) || cityChosen.Equals(Constants.All) || string.IsNullOrEmpty(countyChosen))
                {
                    checkMultipleCity = true;
                    inputObject.CityChosenSchedule = cityChosen;
                }
            }


            if (checkMultipleCounty && !checkMultipleCity)
                inputObject.CountyCityRadioSchedule = FirstCharToUpper(Constants.County);
            else
                if (checkMultipleCity && !checkMultipleCounty)
                    inputObject.CountyCityRadioSchedule = FirstCharToUpper(Constants.City);
                else
                    if (!checkMultipleCounty && !checkMultipleCity)
                    {
                        inputObject.CountyCityRadioSchedule = FirstCharToUpper(Constants.County) + '/' + FirstCharToUpper(Constants.City);
                        inputObject.OtherCountyDropDownChosenSchedule = countyChosen;
                        inputObject.OtherCityDropDownChosenSchedule = cityChosen;
                    }
                    
           
           
            BindCountyCityDiv(countyChosen, inputObject);
            traceLog.AppendLine(" & End: ProviderFileDownloadController, BindCountyCity Method");
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private void BindCountyCityDiv(string countyChosen, ProviderFileCreateScheduleModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, BindCountyCityDiv Method with Param countyChosen: " + countyChosen + " and with Param modelObject: " + modelObject);

            NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
            int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);


            if (modelObject != null)
            {
                string selector = modelObject.CountyCityRadioSchedule;

                if (selector.ToUpperInvariant() == Constants.County.ToUpperInvariant())
                {
                    modelObject.CountyListSchedule = contentManager.GetCountiesByStateLocateProvider(modelObject.StatesDropDownChosenSchedule, helper.GetRequestHeader(string.Empty, defaultSourceId));
                    modelObject.CountyCheckBoxSchedule = modelObject.CountyListSchedule.Select(x =>
                                            new CountyAvailable()
                                            {
                                                CountyCheckBoxValue = x.CountyName.ToString(),
                                            }).ToList<CountyAvailable>();

                }
                else
                    if (selector.ToUpperInvariant() == Constants.City.ToUpperInvariant())
                    {
                        modelObject.CityListSchedule = contentManager.GetCitiesByStateLocateProvider(modelObject.StatesDropDownChosenSchedule, helper.GetRequestHeader(string.Empty, defaultSourceId));
                        modelObject.CityCheckBoxSchedule = modelObject.CityListSchedule.Select(x =>
                                                new CityAvailable()
                                                {
                                                    CityCheckBoxValue = x.CityName.ToString()
                                                }).ToList<CityAvailable>();

                    }
                    else
                        if (selector.ToUpperInvariant() == Constants.County.ToUpperInvariant() + '/' + Constants.City.ToUpperInvariant())
                    {
                        modelObject.CountyListSchedule = contentManager.GetCountiesByStateLocateProvider(modelObject.StatesDropDownChosenSchedule, helper.GetRequestHeader(string.Empty, defaultSourceId));
                        modelObject.OtherCountyDropDownSchedule = modelObject.CountyListSchedule.Select(x =>
                                                new SelectListItem()
                                                {
                                                    Text = x.CountyName.ToString(),
                                                    Value = x.CountyName.ToString()
                                                }).ToList<SelectListItem>();


                        List<string> states = new List<string>() { modelObject.StatesDropDownChosenSchedule };
                        List<string> counties = new List<string>() { countyChosen };
                        List<SelectListItem> cityDropDownObject = new List<SelectListItem>();
                        var cities = contentManager.GetCitiesByStateAndCountyLocateProvider(states, counties, helper.GetRequestHeader(string.Empty, defaultSourceId));

                        if (cities != null)
                        {
                            cityDropDownObject = cities.Select(x =>
                           new SelectListItem
                           {
                               Text = x.CityName.ToString(),
                               Value = x.CityName.ToString()
                           }).ToList<SelectListItem>();
                        }
                        modelObject.OtherCityDropDownSchedule = cityDropDownObject;


                    }
                }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, BindCountyCityDiv Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private  IEnumerable<SelectListItem> BindStateValuesToDropDown()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, BindStateValuesToDropDown Method");
            NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
            int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);

            IEnumerable<Aetna.ProviderContracts.DataContracts.State> ListStates = contentManager.GetStatesLocateProvider(helper.GetRequestHeader(string.Empty, defaultSourceId));
            List<SelectListItem> dropDownObject = new List<SelectListItem>();
            dropDownObject = ListStates.Select(x =>
                                      new SelectListItem()
                                      {
                                          Text = x.StateName.ToString(),
                                          Value = x.StateCode.ToString()
                                      }).ToList<SelectListItem>();

            dropDownObject.Insert(0, (new SelectListItem { Text = Constants.AllStates, Value = "" }));
            traceLog.AppendLine(" & End: ProviderFileDownloadController, BindStateValuesToDropDown Method");

            return dropDownObject;
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private static string FirstCharToUpper(string input)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, FirstCharToUpper Method with Param input: " + input);
                if (String.IsNullOrEmpty(input))
                {
                    traceLog.AppendLine(" & End: ProviderFileDownloadController, FirstCharToUpper Method");
                    return string.Empty;
                }
                else
                {
                    traceLog.AppendLine(" & End: ProviderFileDownloadController, FirstCharToUpper Method");
                    return input.First().ToString().ToUpper(CultureInfo.InvariantCulture) + input.Substring(1);
                }
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

      #endregion
        
        #region private methods

        /// <summary>
        /// set various fields of one time request tab
        /// </summary>
        /// <param name="ProviderFileDownloadModelObject"></param>
        /// <returns>ProviderFileDownloadModel</returns>
        private ProviderFileDownloadModel loadSelectFields(ProviderFileDownloadModel ProviderFileDownloadModelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, loadSelectFields Method with Param ProviderFileDownloadModelObject: " + ProviderFileDownloadModelObject);
            List<SelectListItem> networks = new List<SelectListItem>();
            networks = FetchAllNetworks();

            ProviderFileDownloadModelObject.Networks = networks;

            List<SelectListItem> fileTypes = new List<SelectListItem>(){
                new SelectListItem{Text=Constants.Text,Value=Constants.ExtensionTxt},
                new SelectListItem{Text=Constants.DelimitedText,Value=Constants.ExtensionDText},
                new SelectListItem{Text=Constants.Csv,Value=Constants.ExtensionCsv}
            };

            ProviderFileDownloadModelObject.FileType = fileTypes;


            List<SelectListItem> compFieldsSelect = null;
            List<SelectListItem> optFieldsSelect = null;
            ProviderFileDownloadModelObject.CompFields = compFieldsSelect;
            ProviderFileDownloadModelObject.OptFields = optFieldsSelect;


            traceLog.AppendLine(" & End: ProviderFileDownloadController, loadSelectFields Method");
            return ProviderFileDownloadModelObject;
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        public List<SelectListItem> FetchAllNetworks()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, FetchAllNetworks Method");
             List<SelectListItem> networks = new List<SelectListItem>();
                
             InputNetwork networkObject = new InputNetwork();

             List<string> networkList = new List<string>();
             string network = string.Empty;
                
             if (Session[Constants.UserDetails] != null)
             {
                 if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                 {
                    networkObject.Userid = ((UserDetails)Session[Constants.UserDetails]).UserId;
                 }
                 if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole))
                 {
                     networkObject.UserRole = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                 }
                 if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                     && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                     && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                 {
                     networkObject.IsEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                      //get selected role
                     Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                     //get the network for selcted function
                     networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.ProviderFileDownloadHeader, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList().NetworksStringList();
                 }

                  if (networkList != null)
                 {
                     network = string.Join(",", networkList);
                 }
                  networkObject.Network = network;
             }
             if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
             {
                 networkObject.UserType = ConfigurationManager.AppSettings[Constants.Site];
             }


            string appName = ConfigurationManager.AppSettings["ApplicationName"].ToString();
            
            networkObject.ApplicationName = appName;
           

            IEnumerable<SelectListItem> networkInput = ProviderFileDownloadBLLObject.GetNetworks(networkObject);

            if (networkInput!=null)
            networks = networkInput.ToList();
            traceLog.AppendLine(" & End: ProviderFileDownloadController, FetchAllNetworks Method");
            return networks;
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        

        /// <summary>
        /// set various fields of create download schedule tab
        /// </summary>
        /// <param name="ProviderFileDownloadModelObject"></param>
        /// <returns></returns>
        private ProviderFileCreateScheduleModel LoadScheduleSelectFields(ProviderFileCreateScheduleModel ProviderFileCreateScheduleModelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, LoadScheduleSelectFields Method with Param ProviderFileCreateScheduleModelObject: " + ProviderFileCreateScheduleModelObject);
            List<SelectListItem> networks = FetchAllNetworks();

            ProviderFileCreateScheduleModelObject.NetworksSchedule = networks;

            List<SelectListItem> fileTypes = new List<SelectListItem>(){
                new SelectListItem{Text=Constants.Text,Value=Constants.ExtensionTxt},
                new SelectListItem{Text=Constants.DelimitedText,Value=Constants.ExtensionDText},
                new SelectListItem{Text=Constants.Csv,Value=Constants.ExtensionCsv}
            };

            ProviderFileCreateScheduleModelObject.FileTypeSchedule = fileTypes;


            List<SelectListItem> compulsoryFieldsSelect = null;
            List<SelectListItem> optionalFieldsSelect = null;
            ProviderFileCreateScheduleModelObject.RequiredFieldsSchedule = compulsoryFieldsSelect;
            ProviderFileCreateScheduleModelObject.OptionalFieldsSchedule = optionalFieldsSelect;

            traceLog.AppendLine(" & End: ProviderFileDownloadController, LoadScheduleSelectFields Method");

            return ProviderFileCreateScheduleModelObject;
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        #endregion

        #region common method to use in both create schedule and one time request
        /// <summary>
        /// get city based on county and state json call
        /// </summary>
        /// <param name="county"></param>
        /// <param name="state"></param>
        /// <returns>ActionResult</returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult GetCityBasedOnCounty(string county, string state)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ProviderFileDownloadController, GetCityBasedOnCounty Method with Param county: " + county + " and with Param state: " + state);
            NABWebsite.Helper.CommonHelper helper = new Helper.CommonHelper();
            int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
            List<SelectListItem> cityDropDownObject = null;
            if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
            {
                return Content(Constants.ContentHome);
            }
            if (!string.IsNullOrEmpty(county) && !string.IsNullOrEmpty(state))
            {
                List<string> states = new List<string>() { state };
                List<string> counties = new List<string>() { county };
                var cities = contentManager.GetCitiesByStateAndCountyLocateProvider(states, counties, helper.GetRequestHeader(string.Empty, defaultSourceId));
                if (cities != null)
                {
                    cityDropDownObject = cities.Select(x =>
                   new SelectListItem
                   {
                       Text = x.CityName.ToString(),
                       Value = x.CityName.ToString()
                   }).ToList<SelectListItem>();
                }
                else
                    cityDropDownObject = null;
                traceLog.AppendLine(" & End: ProviderFileDownloadController, GetCityBasedOnCounty Method");
                return Json(cityDropDownObject, JsonRequestBehavior.AllowGet);
            }
            traceLog.AppendLine(" & End: ProviderFileDownloadController, GetCityBasedOnCounty Method");
            return Content(Constants.ContentError);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }



        /// <summary>
        /// data field description view page load
        /// </summary>
        /// <returns>ActionResult</returns>
        [CheckAccess(Function = "Provider File Download")]
        public ActionResult DataFieldDescription()
        {
            try
            {
            return View();
        }
            catch (Exception)
            {
                
                throw;
            }
        }

        #endregion

    }

}


