﻿
namespace NABWebsite.Models
{
    public class NewsAndEvents
    {
        public int NewsOrEventId { get; set; }
        public string NewsHeading { get; set; }
        public string NewsDetails { get; set; }
        public bool IsClickable { get; set; }
        public bool IsActive { get; set; }
        public bool IsNews { get; set; }
        public int Sequence { get; set; }
        public byte[] Image { get; set; }
        public string DateTime { get; set; }
        
    }
}