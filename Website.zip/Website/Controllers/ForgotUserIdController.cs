﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System.Configuration;
using System.DirectoryServices;
using System.Text;
using System.Net;
using NABWebsite.Helper;
using System.Globalization;
using Newtonsoft.Json;
using Utilities;
using System.Xml.Serialization;
using Newtonsoft.Json.Linq;

namespace NABWebsite.Controllers
{
    public class ForgotUserIdController : Controller
    {
        MyProfileBLL bllObj = new MyProfileBLL();
        LogOnBLL objBll = new LogOnBLL();
        MyProfile dtoObj = new MyProfile();
        MyProfileModel objMyProfileModel = new MyProfileModel();
        StringBuilder traceLog = new StringBuilder();
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotUserIdController, Index Method");
                
                objMyProfileModel.RecaptchaPublicKey = AppSettingHelper.GetAppSettingValue(VariableConstant.PublicKey);
                objMyProfileModel.GoogleRecaptchaAPIAddressSingle = AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleAPIAddress);
                traceLog.AppendLine(" & End: ForgotUserIdController, Index Method");
                return View(objMyProfileModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        [AjaxValidateAntiForgeryToken]
        public bool CheckUserValidity(string firstName, string lastName, string email)
        {
            try
            {
                traceLog.AppendLine("Start: ForgotUserIdController, CheckUserValidity Method with Param firstName: " + firstName + "with Param lastName: " + lastName + "with Param email: " + email);
                bool check = false;
                string userId = "";
                userId = bllObj.CheckUserValidity(firstName, lastName, email);
                if (!string.IsNullOrEmpty(userId))
                {
                    Session[Constants.Userid] = userId;
                    check = true;
                }
                traceLog.AppendLine(" & End: ForgotUserIdController, CheckUserValidity Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [AjaxValidateAntiForgeryToken]
        public ActionResult FetchQuestions()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotUserIdController, FetchQuestions Method");
                string userId = Session[Constants.Userid] != null ? Session[Constants.Userid].ToString() : string.Empty;
                userId = Microsoft.Security.Application.Encoder.LdapFilterEncode(userId);
                if (userId != null)
                {
                    if (objBll.IsAdValidated(userId))
                    {
                        Session[Constants.Userid] = userId;
                        List<string> question = new List<string>();
                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.General).ToList();
                        dtoObj.SecurityQuestion1 = question.Count != 0 ? question.ElementAt(0) : string.Empty;
                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.Family).ToList();
                        dtoObj.SecurityQuestion2 = question.Count != 0 ? question.ElementAt(0) : string.Empty;
                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.Favourite).ToList();
                        dtoObj.SecurityQuestion3 = question.Count != 0 ? question.ElementAt(0) : string.Empty;
                        objMyProfileModel.MyProfile = dtoObj;
                    }
                    else
                    {
                        List<SelectListItem> generalQuestion = new List<SelectListItem>();
                        List<SelectListItem> familyQuestion = new List<SelectListItem>();
                        List<SelectListItem> favoriteQuestion = new List<SelectListItem>();
                        SelectListItem selectOne = new SelectListItem() { Text = Constants.SelectOne, Value = Constants.SelectOne };

                        generalQuestion.AddRange(bllObj.GetSecurityQuestionByCategory(Constants.General).ToList());
                        familyQuestion.AddRange(bllObj.GetSecurityQuestionByCategory(Constants.Family).ToList());
                        favoriteQuestion.AddRange(bllObj.GetSecurityQuestionByCategory(Constants.Favourite).ToList());

                        List<int> location = new List<int>();
                        location = GetRandomNumber(1, generalQuestion.Count, 1);
                        dtoObj.SecurityQuestion1 = generalQuestion.ElementAt(location[0]).Text;
                        location = GetRandomNumber(1, familyQuestion.Count, 1);
                        dtoObj.SecurityQuestion2 = familyQuestion.ElementAt(location[0]).Text;
                        location = GetRandomNumber(1, favoriteQuestion.Count, 1);
                        dtoObj.SecurityQuestion3 = favoriteQuestion.ElementAt(location[0]).Text;
                        objMyProfileModel.MyProfile = dtoObj;
                    }
                }
                traceLog.AppendLine(" & End: ForgotUserIdController, FetchQuestions Method");
                return PartialView("_QuestionPanel", objMyProfileModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }        

        private List<int> GetRandomNumber(int fromNumber, int toNumber, int numberOfRandomNumbersRequired)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotUserIdController, GetRandomNumber Method with Param fromNumber: " + fromNumber + "with Param toNumber: " + toNumber + "with Param numberOfRandomNumbersRequired: " + numberOfRandomNumbersRequired);
                List<int> randomNumbers = new List<int>();
                //Random random = new Random(System.DateTime.Now.Millisecond);
                for (int i = 0; i < numberOfRandomNumbersRequired; i++)
                {
                    //int rnumber = random.Next(fromNumber, toNumber);
                    int rnumber = CommonHelper.GetSecureRandom(fromNumber, toNumber);//Added on 27-Jul-2018 to generate secure number and to fix Weak PRNG
                    if (!randomNumbers.Contains(rnumber))
                    {
                        randomNumbers.Add(rnumber);
                    }
                    else
                    {
                        numberOfRandomNumbersRequired = numberOfRandomNumbersRequired + 1;
                    }
                }
                traceLog.AppendLine(" & End: ForgotUserIdController, GetRandomNumber Method");
                return randomNumbers;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [AjaxValidateAntiForgeryToken]
        public bool CheckQuestion(string question1, string question2, string question3, string answer1, string answer2, string answer3)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotUserIdController, CheckQuestion Method with Param answer1: " + answer1 + "with Param answer2: " + answer2 + "with Param answer3: " + answer3);
                string userId = Session[Constants.Userid] != null ? Session[Constants.Userid].ToString() : string.Empty;
                userId = Microsoft.Security.Application.Encoder.LdapFilterEncode(userId);
                bool checkValidity = false;
                if (userId != null)
                {
                    if (objBll.IsAdValidated(userId))
                    {
                        Session[Constants.Userid] = userId;
                        List<string> question = new List<string>();
                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.General).ToList();
                        string modelAnswer1 = question != null ? question.ElementAt(1) : string.Empty;
                        string modelQuestion1 = question != null ? question.ElementAt(0) : string.Empty;

                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.Family).ToList();
                        string modelAnswer2 = question != null ? question.ElementAt(1) : string.Empty;
                        string modelQuestion2 = question != null ? question.ElementAt(0) : string.Empty;

                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.Favourite).ToList();
                        string modelAnswer3 = question != null ? question.ElementAt(1) : string.Empty;
                        string modelQuestion3 = question != null ? question.ElementAt(0) : string.Empty;

                        if (modelQuestion1.ToLower() == question1.ToLower() && modelQuestion2.ToLower() == question2.ToLower() && modelQuestion3.ToLower() == question3.ToLower() && modelAnswer1.ToLower() == answer1.ToLower() && modelAnswer2.ToLower() == answer2.ToLower() && modelAnswer3.ToLower() == answer3.ToLower())
                        {
                            checkValidity = true;
                        }

                    }
                }
                traceLog.AppendLine(" & End: ForgotUserIdController, CheckQuestion Method");
                return checkValidity;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private void SendMailToUser()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotUserIdController, SendMailToUser Method");
                string userId = Session[Constants.Userid] != null ? Session[Constants.Userid].ToString() : string.Empty;
                string userType = string.Empty;
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    userType = ConfigurationManager.AppSettings[Constants.Site];
                }
                string subject = Constants.CofinityLabel;
                string body = GetEmailBody(userId);

                User temp = new User();
                temp = bllObj.GetUserDetails(userId, userType);
                List<string> toEmail = new List<string>();
                toEmail.Add(temp.Email);
                bllObj.SendMail(toEmail.ToArray(), subject, body);
                traceLog.AppendLine(" & End: ForgotUserIdController, SendMailToUser Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        private string GetEmailBody(string userId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotUserIdController, GetEmailBody Method with Param userId: " + userId);
                StringBuilder mailBody = new StringBuilder();
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ForgotUserIdMailLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ForgotUserIdMailLine2);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ForgotPrdMailLine3 + ConfigurationManager.AppSettings[Constants.WebAddress] + Constants.SecureMailBodyline3Part2);
                mailBody.Append(Constants.Bold + ConfigurationManager.AppSettings[Constants.WebAddress] + Constants.MessageEnd);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ForgotUserIdMailLine4);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ForgotUserIdMailLine5);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.UserMailLabel + userId);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.RequestMailLabel + DateTime.Now.ToString());
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.CofinityWebService);
                mailBody.Append(Constants.DoNotReply);
                traceLog.AppendLine(" & End: ForgotUserIdController, GetEmailBody Method");
                return mailBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [AjaxValidateAntiForgeryToken]
        public bool SendUserId()
        {
            StringBuilder traceLog = new StringBuilder();
            bool check = false;
            try
            {
                traceLog.AppendLine("Start: ForgotUserIdController, SendUserId Method");
                SendMailToUser();
                check = true;
                traceLog.AppendLine(" & End: ForgotUserIdController, SendUserId Method");
                
            }
            catch(Exception ex)
            {
                
                check = false;
                LogManager.WriteErrorLog(ex);
                throw;
               
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return check;
        }

        [AjaxValidateAntiForgeryToken]
        public JsonResult VerifyTokenValue(string captcha)
        {
            StringBuilder traceLog = new StringBuilder();
            string errorMessage = string.Empty;
            WebClient client = null;
            try
            {
                traceLog.AppendLine("Start: ForgotUserIdController, VerifyTokenValue Method with Param captcha: " + captcha);
                bool isSuccess = true;
                string captchaErrorMessage = string.Empty;
                string response = captcha;
                string secret = AppSettingHelper.GetAppSettingValue(VariableConstant.PrivateKey);

                client = new WebClient();
                var reply = client.DownloadString(string.Format(CultureInfo.CurrentCulture, AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleRecaptchaVerificationURL), secret, response));
               
                //var captchaResponse = JsonConvert.DeserializeObject<CaptchaResponse>(reply);
                //code change for Deserialization of Untrusted Data on 08/10/2018
                var jobj = JObject.Parse(reply);
                isSuccess = (bool)jobj.SelectToken("success");
                if (!isSuccess)
                {
                    captchaErrorMessage = (string)jobj.SelectToken("error-codes");//captchaResponse.ErrorCodes[0].ToLower(CultureInfo.CurrentCulture);                
                    //var error = captchaResponse.ErrorCodes[0].ToLower(CultureInfo.CurrentCulture);
                    switch (captchaErrorMessage)
                    {
                        case ("missing-input-secret"):
                            errorMessage = "The secret parameter is missing.";
                            break;
                        case ("invalid-input-secret"):
                            errorMessage = "The secret parameter is invalid or malformed.";
                            break;

                        case ("missing-input-response"):
                            errorMessage = "The response parameter is missing.";
                            break;
                        case ("invalid-input-response"):
                            errorMessage = "The response parameter is invalid or malformed.";
                            break;

                        default:
                            errorMessage = "Error occured. Please try again";
                            break;
                    }

                }
                else
                {
                    errorMessage = "";
                }
                traceLog.AppendLine(" & End: ForgotUserIdController, VerifyTokenValue Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return Json(errorMessage);
        }
    }
}