﻿$(document).ready(function () {
    //-----------------------copy paste prevent code ---------------------------------------//

    var keyDown = false, ctrl = 17, vKey = 86, Vkey = 118, slashKey = 47;

    //--------date range--------------------------------------//


    $(".date input:text").on('keypress', function (e) {
        if (e.keyCode == ctrl) keyDown = true;
    }).on('keyup', function (e) {
        if (e.keyCode == ctrl) keyDown = false;
    });

    $(".date input:text").on('keypress', function (e) {
        if (!e) var e = window.event;
        if (e.keyCode == 8 && e.which == 8) return true;
        if (e.keyCode > 0 && e.which == 0) return true;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
        if (character == '\b' || character == ' ' || character == '\t' || code == slashKey) return true;
        if (keyDown && (code == vKey || code == Vkey)) return (character);
        else return (/[0-9]$/.test(character));
    }).on('focusout', function (e) {
        var $this = $(this);
        $this.val($this.val().replace(/[^0-9^/]/g, ''));
    }).on('paste', function (e) {

        var $this = $(this);
        setTimeout(function () {
            $this.val($this.val().replace(/[^0-9^/]/g, ''));
        }, 5);

    });
    //-----------------------------------------------------------------//

    //--------Numeric--------------------------------------//
    $(".numeric input:text").on('keypress', function (e) {

        if (e.keyCode == ctrl) keyDown = true;
    }).on('keyup', function (e) {

        if (e.keyCode == ctrl) keyDown = false;
    });

    $(".numeric input:text").on('keypress', function (e) {
        if (!e) var e = window.event;
        if (e.keyCode == 8 && e.which == 8) return true;
        if (e.keyCode > 0 && e.which == 0) return true;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
        if (character == '\b' || character == ' ' || character == '\t') return true;
        if (keyDown && (code == vKey || code == Vkey)) return (character);
        else return (/[0-9]$/.test(character));
    }).on('focusout', function (e) {
        var $this = $(this);
        $this.val($this.val().replace(/[^0-9]/g, ''));
    }).on('paste', function (e) {

        var $this = $(this);
        setTimeout(function () {
            $this.val($this.val().replace(/[^0-9]/g, ''));
        }, 5);

    });
    //-----------------------------------------------------------------//

    //--------Alphabet--------------------------------------//
    $(".alphabet input:text").on('keypress', function (e) {

        if (e.keyCode == ctrl) keyDown = true;
    }).on('keyup', function (e) {

        if (e.keyCode == ctrl) keyDown = false;
    });

    $(".alphabet input:text").on('keypress', function (e) {
        if (!e) var e = window.event;
        if (e.keyCode == 8 && e.which == 8) return true;
        if (e.keyCode > 0 && e.which == 0) return true;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
        if (character == '\b' || character == ' ' || character == '\t') return true;
        if (keyDown && (code == vKey || code == Vkey)) return (character);
        else return (/[a-zA-Z]$/.test(character));
    }).on('focusout', function (e) {
        var $this = $(this);
        $this.val($this.val().replace(/[^a-zA-Z]/g, ''));
    }).on('paste', function (e) {

        var $this = $(this);
        setTimeout(function () {
            $this.val($this.val().replace(/[^a-zA-Z]/g, ''));
        }, 5);

    });
    //-----------------------------------------------------------------//

    //--------AlphaNumeric with few special characters-----------------//
  $(".alphanum-account input:text").on('keypress', function (e) {

        if (e.keyCode == ctrl) keyDown = true;
    }).on('keyup', function (e) {

        if (e.keyCode == ctrl) keyDown = false;
    });

    $(".alphanum-account input:text").on('keypress', function (e) {
        if (!e) var e = window.event;
        if (e.keyCode == 8 && e.which == 8) return true;
        if (e.keyCode > 0 && e.which == 0) return true;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
        if (character == '\b' || character == ' ' || character == '\t') return true;
        if (keyDown && (code == vKey || code == Vkey)) return (character);
        else return (/[a-zA-Z0-9\  ,./'()&-]$/.test(character));
    }).on('focusout', function (e) {
        var $this = $(this);
        $this.val($this.val().replace(/[^a-zA-Z0-9\  ,./'()&-]$/g, ''));
    }).on('paste', function (e) {

        var $this = $(this);
        setTimeout(function () {
            $this.val($this.val().replace(/[^a-zA-Z0-9\  ,./'()&-]$/g, ''));
        }, 5);

    });
    //-----------------------------------------------------------------//

    //--------AlphaNumeric--------------------------------------//
    $(".alphanum input:text").on('keypress', function (e) {

        if (e.keyCode == ctrl) keyDown = true;
    }).on('keyup', function (e) {

        if (e.keyCode == ctrl) keyDown = false;
    });

    $(".alphanum input:text").on('keypress', function (e) {
        if (!e) var e = window.event;
        if (e.keyCode == 8 && e.which == 8) return true;
        if (e.keyCode > 0 && e.which == 0) return true;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
        if (character == '\b' || character == ' ' || character == '\t') return true;
        if (keyDown && (code == vKey || code == Vkey)) return (character);
        else return (/[a-zA-Z0-9]$/.test(character));
    }).on('focusout', function (e) {
        var $this = $(this);
        $this.val($this.val().replace(/[^a-zA-Z0-9]/g, ''));
    }).on('paste', function (e) {

        var $this = $(this);
        setTimeout(function () {
            $this.val($this.val().replace(/[^a-zA-Z0-9]/g, ''));
        }, 5);

    });
    //-----------------------------------------------------------------//
    //--------Alphabet with space--------------------------------------//
    $(".alphaspace input:text").on('keypress', function (e) {

        if (e.keyCode == ctrl) keyDown = true;
    }).on('keyup', function (e) {

        if (e.keyCode == ctrl) keyDown = false;
    });

    $(".alphaspace input:text").on('keypress', function (e) {
        if (!e) var e = window.event;
        if (e.keyCode == 8 && e.which == 8) return true;
        if (e.keyCode > 0 && e.which == 0) return true;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
        if (character == '\b' || character == ' ' || character == '\t') return true;
        if (keyDown && (code == vKey || code == Vkey)) return (character);
        else return (/[a-zA-Z ]$/.test(character));
    }).on('focusout', function (e) {
        var $this = $(this);
        $this.val($this.val().replace(/[^a-zA-Z ]/g, ''));
    }).on('paste', function (e) {

        var $this = $(this);
        setTimeout(function () {
            $this.val($this.val().replace(/[^a-zA-Z ]/g, ''));
        }, 5);

    });
    //-----------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
})


function dateCheckDob(value, id) {
    
        var flagLeap = 0;
        var correctDateFlag = 0;
        var countSlash = value;
        countSlash = countSlash.replace(/[^/]/g, "").length;

        if (value.indexOf("/") > 0 && value.lastIndexOf("/") <= 5 && countSlash == 2) {
            var arrDate = value.split('/');
            var value1 = arrDate[0];
            var value2 = arrDate[1];
            var value3 = arrDate[2];

            if (value1 == "" || value2 == "" || value3 == "") {

                correctDateFlag = -1;
            }
            if (value1 == "00" || value1 == "0")
                correctDateFlag = -1;
            if (value2 == "00" || value2 == "0")
                correctDateFlag = -1;
            if (value3 == "0000")
                correctDateFlag = -1;

            if (correctDateFlag == 0) {
                if (value3.length == 4)
                    correctDateFlag = 1;
            }

        }

        if (correctDateFlag == 1) {

            if (value1 > 12 || value2 > 31) {
                addError(id);
                flagLeap = -1;
            }
            else {
                var futureFlag = checkFutureDate(value1, value2, value3);
                var pastFlag = checkPastDateDob(value1, value2, value3);
                if (futureFlag == -1 || pastFlag == -1) {
                    addError(id);
                    flagLeap = -1;
                }
                else
                    if (value1 == 4 || value1 == 6 || value1 == 9 || value1 == 11) {
                        if (value2 > 30) {
                            addError(id);
                            flagLeap = -1;
                        }
                        else
                            removeError(id);

                    }

                    else if (value1 == 2) {
                        var leapCheck = checkFeb(value1, value2, value3, id);
                        if (leapCheck == -1)
                            flagLeap = -1;

                    }
                    else
                        removeError(id);
            }
        }
        else {
            addError(id);
            flagLeap = -1;
        }



        return flagLeap;
    }

    function dateCheckDos(value, id) {
       // debugger;
        var flagLeap = 0;
        var correctDateFlag = 0;
        var countSlash = value;
        countSlash = countSlash.replace(/[^/]/g, "").length;

        if (value.indexOf("/") > 0 && value.lastIndexOf("/") <= 5 && countSlash == 2) {
            var arrDate = value.split('/');
            var value1 = arrDate[0];
            var value2 = arrDate[1];
            var value3 = arrDate[2];

            if (value1 == "" || value2 == "" || value3 == "") {

                correctDateFlag = -1;
            }
            if (value1 == "00" || value1 == "0")
                correctDateFlag = -1;
            if (value2 == "00" || value2 == "0")
                correctDateFlag = -1;
            if (value3 == "0000")
                correctDateFlag = -1;

            if (correctDateFlag == 0) {
                if (value3.length == 4)
                    correctDateFlag = 1;
            }

        }

        if (correctDateFlag == 1) {

            if (value1 > 12 || value2 > 31) {
                addError(id);
                flagLeap = -1;
            }
            else {
                var futureFlag = checkFutureDate(value1, value2, value3);
                var pastFlag = checkPastDateDos(value1, value2, value3);
                if (futureFlag == -1 || pastFlag == -1) {
                    addError(id);
                    flagLeap = -1;
                }
                else
                    if (value1 == 4 || value1 == 6 || value1 == 9 || value1 == 11) {
                        if (value2 > 30) {
                            addError(id);
                            flagLeap = -1;
                        }
                        else
                            removeError(id);

                    }

                    else if (value1 == 2) {
                        var leapCheck = checkFeb(value1, value2, value3, id);
                        if (leapCheck == -1)
                            flagLeap = -1;

                    }
                    else
                        removeError(id);
            }
        }
        else {
            addError(id);
            flagLeap = -1;
        }



        return flagLeap;
    }

    function checkFutureDate(value1, value2, value3) {
        var futureFlag = 0;
        var currentYear = (new Date).getFullYear();
        var currentMonth = (new Date).getMonth() + 1;
        var currentDate = (new Date).getDate();

        if (value3 > currentYear)
            futureFlag = -1;
        else
            if (value3 == currentYear) {
                if (value1 > currentMonth)
                    futureFlag = -1;
                else
                    if (value1 == currentMonth) {
                        if (value2 > currentDate)
                            futureFlag = -1;
                    }
            }

        return futureFlag;
    }

    function checkPastDateDob(value1, value2, value3) {
        var pastFlag = 0;
        var targetYear = (new Date).getFullYear() - 129;

        if (value3 < targetYear)
            pastFlag = -1;

        return pastFlag;
    }

    function checkPastDateDos(value1, value2, value3) {
       // debugger;
        var pastFlag = 0;
        var targetYear = (new Date).getFullYear() - 3;

        if (value3 < targetYear)
            pastFlag = -1;

        return pastFlag;
    }


    function checkFeb(value1, value2, value3, id) {
        var febFlag = 0;
        var leapCheck = 0;
        if (value2 > 29) {
            addError(id);
            febFlag = -1;
            leapCheck = -1;
        }
        else
            if (value2 == 29)
                leapCheck = 1;
            else {
                removeError(id);
            }


        if (leapCheck == 1) {
            if (value3 % 400 == 0)
                febFlag = 0;
            else if (value3 % 100 == 0)
                febFlag = -1;
            else if (value3 % 4 == 0)
                febFlag = 0;
            else
                febFlag = -1;

        }


        if (febFlag == -1) {
            addError(id);
        }
        else {
            removeError(id);
        }

        return febFlag;
    }


    function removeError(id) {
        $("#" + id).html("");
    }

    function addError(id) {
        $("#" + id).html("<br/>Please enter valid date");
    }

    function dateCheck(value, id) {

        var flagLeap = 0;
        var correctDateFlag = 0;
        var countSlash = value;
        countSlash = countSlash.replace(/[^/]/g, "").length;

        if (value.indexOf("/") > 0 && value.lastIndexOf("/") <= 5 && countSlash == 2) {
            var arrDate = value.split('/');
            var value1 = arrDate[0];
            var value2 = arrDate[1];
            var value3 = arrDate[2];

            if (value1 == "" || value2 == "" || value3 == "") {

                correctDateFlag = -1;
            }
            if (value1 == "00" || value1 == "0")
                correctDateFlag = -1;
            if (value2 == "00" || value2 == "0")
                correctDateFlag = -1;
            if (value3 == "0000")
                correctDateFlag = -1;

            if (correctDateFlag == 0) {
                if (value3.length == 4)
                    correctDateFlag = 1;
            }

        }

        if (correctDateFlag == 1) {

            if (value1 > 12 || value2 > 31) {
                addError(id);
                flagLeap = -1;
            }
            else {
                var futureFlag = checkFutureDate(value1, value2, value3);
                var pastFlag = checkPastDate(value1, value2, value3);
                if (futureFlag == -1 || pastFlag == -1) {
                    addError(id);
                    flagLeap = -1;
                }
                else
                    if (value1 == 4 || value1 == 6 || value1 == 9 || value1 == 11) {
                        if (value2 > 30) {
                            addError(id);
                            flagLeap = -1;
                        }
                        else
                            removeError(id);

                    }

                    else if (value1 == 2) {
                        var leapCheck = checkFeb(value1, value2, value3, id);
                        if (leapCheck == -1)
                            flagLeap = -1;

                    }
                    else
                        removeError(id);
            }
        }
        else {
            addError(id);
            flagLeap = -1;
        }



        return flagLeap;
    }

    function checkPastDate(value1, value2, value3) {
        var pastFlag = 0;
        var todayDate = new Date();
        var stDate = new Date();
        stDate.setYear(todayDate.getFullYear() - 3);
        var targetYear = stDate.getFullYear();
        var targetMonth = stDate.getMonth()+1;
        var targetDate = stDate.getDate();
        if (value3 < targetYear.toString())
            pastFlag = -1;
        else if (value3 == targetYear.toString() && parseInt(value1) < parseInt(targetMonth.toString()))
            pastFlag = -1;
        else if (value3 == targetYear.toString() && parseInt(value1) == parseInt(targetMonth.toString()) && parseInt(value2) < parseInt(targetDate.toString()))
            pastFlag = -1;

        return pastFlag;
    }

    function compareDate(startDate, endDate) {

        var compareFlag = 0;
        var date1 = new Date(startDate);
        var date2 = new Date(endDate);
        var diff = date2 - date1;
        var daysDiff = (diff / (1000 * 60 * 60 * 24));
        if (daysDiff > 92) {
            compareFlag = -1;

            if ($('.validationSummary40').find('.validDateRangeValidation').length == 0)
                $('.validationSummary40').append("<div class='validDateRangeValidation'>Please enter a valid date range</div>");
        }
        else
            if (daysDiff < 0) {
                compareFlag = -1;

                if ($('.validationSummary40').find('.validDateRangeValidation').length == 0)
                    $('.validationSummary40').append("<div class='validDateRangeValidation'>Please enter a valid date range</div>");
            }
            else {
                $('.validationSummary40').find('.validDateRangeValidation').remove();
            }

        //    //Difference in milliseconds
        //    var timeDiff = Date.parse(endDate) - Date.parse(startDate);
        //    if (Date.parse(endDate) > Date.parse(startDate)) {

        //        //show the date diffrent in Days in two no of fraction no.
        //        daysDiff = Math.round(Math.abs(timeDiff / (1000 * 60 * 60 * 24)) * 10);
        //        alert(Math.abs(daysDiff / 10) + ' Days');

        //        //Show the date diffrent in Month
        //        alert(Math.abs(daysDiff * 30 / 10) + ' Month')
        //    }
        //    else {
        //        alert("StartDate must be lesser than endDate");
        //    }
        //}


        return compareFlag;
    }

//})
