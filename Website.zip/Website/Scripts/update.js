﻿$(".autoFocus").keyup(function () {
    var maxLength = $(this).attr('maxLength');
    if ($(this).val().length == maxLength) {
        $(this).next().focus().select();
    }
});
$(".autoFocus").click(function () {
    $(this).focus().select();
});





//-------------Payment Address------------------//

var paymentCompanyNameChange;
var paymentAddress1Change;
var paymentAddress2Change;
var paymentStateChange;
var paymentCityChange;
var paymentZipChange;

//----------------Corrrespondance Address------------------//

var correspondanceCompanyNameChange;
var correspondanceAddress1Change;
var correspondanceAddress2Change;
var correspondanceStateChange;
var correspondanceCityChange;
var correspondanceZipChange;

//----Language Spoken-----------------///
var allLanguageAdded;

//---Office timing-----//
var MOpenChange;
var MCloseChange;
var AFOpenChange;
var AFCloseChange;




correspondanceGenericChange = "";
function CompareGeneric(oldValue, newValue, fieldName) {
    correspondanceGenericChange = "";
    if (fieldName != "City") {
        if (oldValue.toLowerCase() != newValue.toLowerCase()) {

            correspondanceGenericChange = "&lt;li&gt;  " + fieldName + " : changed to \" " + newValue + "\" &lt;/li&gt;";

        }
    } else {
        if (oldValue.toLowerCase() != newValue.toLowerCase() && oldValue != "") {

            correspondanceGenericChange = "&lt;li&gt; City: changed to \"" + (newValue == "Select a City" ? " " : newValue) + "\" &lt;/li&gt;";

        }

        if (oldValue == "" && newValue != "Select a City") {
            correspondanceGenericChange = "&lt;li&gt; City: changed to \"" + (newValue == "Select a City" ? " " : newValue) + "\" &lt;/li&gt;";
        }
    }
    
    return correspondanceGenericChange;
}
function CompareState(oldValue, newValue, newStateValue) {
    
    var temp= "";
    if (oldValue.toLowerCase() != newStateValue.toLowerCase() && oldValue != "") {

        temp = "&lt;li&gt;  State : changed to \"" + (newValue == "Select a State" ? " " : newValue) + "\" &lt;/li&gt;";

    }

    if (oldValue == "" && newStateValue != "Select a State") {
        temp = "&lt;li&gt;  State : changed to \"" + (newValue == "Select a State" ? " " : newValue) + "\" &lt;/li&gt;";
    }
    return temp;
}

function CompareCounty(oldValue, newValue) {
    var temp = "";
    if (oldValue.toLowerCase() != newValue.toLowerCase() && oldValue != "Select a County") {

        temp = "&lt;li&gt;  County : changed to \"" + (newValue == "Select a County" ? " " : newValue) + "\" &lt;/li&gt;";

    }

    if (oldValue == "Select a State" && newValue != "Select a State") {
        temp = "&lt;li&gt;  County : changed to \"" + (newValue == "Select a County" ? " " : newValue) + "\" &lt;/li&gt;";
    }
    return temp;
}



function contains(a, obj) {
    for (var i = 0; i < a.length; i++) {
        if (a[i].trim().toLowerCase() == obj.trim().toLowerCase()) {
            return true;
        }
    }
    return false;
}
function compareArray(item1, item2) {

    if (item1.length != item2.length)
        return false;
    item1 = item1.sort();
    item2 = item2.sort();
    for (var i = 0; i < item1.length; i++) {
        if (item1[i] != item2[i])
            return false;
    }
    return true;
}


function compareLanguageSpoken(oldValue, newValue) {

    languageAdded = "";
    allLanguageAdded = "";
    languageRemoved = "";
    allLanguageRemoved = "";
    if (!compareArray(oldValue, newValue)) {
        for (var i = 0; i < newValue.length; i++) {
            if (!contains(oldValue, newValue[i])) {
                languageAdded += newValue[i] + ", ";
            }
        }
        if (languageAdded != "") {
            languageAdded = languageAdded.slice(0, -2);
            allLanguageAdded = "&lt;li&gt;Languages Spoken added: " + languageAdded + "&lt;/li&gt;";
        }
    }
    if (!compareArray(oldValue, newValue)) {
        for (var i = 0; i < oldValue.length; i++) {
            if (!contains(newValue, oldValue[i])) {
                languageRemoved += oldValue[i] + ", ";
            }
        }
        if (languageRemoved != "") {
            languageRemoved = languageRemoved.slice(0, -2);
            allLanguageRemoved = "&lt;li&gt;Languages Removed: " + languageRemoved + "&lt;/li&gt;";
        }
    }
}

function comparePHO(oldValue, newValue) {

    phoAdded = "";
    allPHOAdded = "";
    phoRemoved = "";
    allPHORemoved = "";
    if (!compareArray(oldValue, newValue)) {
        for (var i = 0; i < newValue.length; i++) {
            if (!contains(oldValue, newValue[i])) {
                phoAdded += newValue[i] + ", ";
            }
        }
        if (phoAdded != "") {
            phoAdded = phoAdded.slice(0, -2);
            allPHOAdded = "&lt;li&gt;PHO added: " + phoAdded + "&lt;/li&gt;";
        }

    }
    if (!compareArray(oldValue, newValue)) {
        for (var i = 0; i < oldValue.length; i++) {
            if (!contains(newValue, oldValue[i])) {
                phoRemoved += oldValue[i] + ", ";
            }
        }
        if (phoRemoved != "") {
            phoRemoved = phoRemoved.slice(0, -2);
            allPHORemoved = "&lt;li&gt;PHO Removed: " + phoRemoved + "&lt;/li&gt;";
        }

    }
}
function CompareHospital(oldValue, newValue) {

    HospAdded = "";
    allHospAdded = "";
    HospRemoved = "";
    allHospRemoved = "";
    if (!compareArray(oldValue, newValue)) {
        for (var i = 0; i < newValue.length; i++) {
            if (!contains(oldValue, newValue[i])) {
                HospAdded += newValue[i] + ", ";
            }
        }
        if (HospAdded != "") {
            HospAdded = HospAdded.slice(0, -2);
            allHospAdded = "&lt;li&gt;Hospital added: " + HospAdded + "&lt;/li&gt;";
        }

    }
    if (!compareArray(oldValue, newValue)) {
        for (var i = 0; i < oldValue.length; i++) {
            if (!contains(newValue, oldValue[i])) {
                HospRemoved += oldValue[i] + ", ";
            }
        }
        if (HospRemoved != "") {
            HospRemoved = HospRemoved.slice(0, -2);
            allHospRemoved = "&lt;li&gt;Hospital Removed: " + HospRemoved + "&lt;/li&gt;";
        }

    }
}


function compareSpeciality(oldValue, newValue) {

    specialityAdded = "";
    allSpecialitiesAdded = "";
    specialityRemoved = "";
    allSpecialitiesRemoved = "";
    if (!compareArray(oldValue, newValue)) {
        for (var i = 0; i < newValue.length; i++) {
            if (!contains(oldValue, newValue[i])) {
                specialityAdded += newValue[i] + ", ";
            }
        }
        if (specialityAdded != "") {
            specialityAdded = specialityAdded.slice(0, -2);
            allSpecialitiesAdded = "&lt;li&gt;Specialities added: " + specialityAdded + "&lt;/li&gt;";
        }

    }
    if (!compareArray(oldValue, newValue)) {
        for (var i = 0; i < oldValue.length; i++) {
            if (!contains(newValue, oldValue[i])) {
                specialityRemoved += oldValue[i] + ", ";
            }
        }
        if (specialityRemoved != "") {
            specialityRemoved = specialityRemoved.slice(0, -2);
            allSpecialitiesRemoved = "&lt;li&gt;Specialities removed: " + specialityRemoved + "&lt;/li&gt;";
        }

    }
}

MOpenChange = "";
MCloseChange = "";
AFOpenChange = "";
AFCloseChange = "";
function CompareTiming(oldValue, newValue, timingValue) {
    
    var tempTiming = "";
    switch (timingValue) {
        case 1:
            for (var i = 0; i < oldValue.length; i++)
                if (oldValue[i][1] != newValue[i][1]) {
                    
                    tempTiming += "&lt;li&gt;" + oldValue[i][0] + " Morning Opening Timing : Changed to: \"" + newValue[i][1] + "\" AM  &lt;/li&gt;";
                 
                }
            break;

        case 2:
            for (var i = 0; i < oldValue.length; i++)
                if (oldValue[i][1] != newValue[i][1]) {
                   
                    tempTiming += "&lt;li&gt;" + oldValue[i][0] + " Morning Closing Timing : Changed to: \"" + newValue[i][1] + "\" AM  &lt;/li&gt;";
                    
                }
            break;
        case 3:
            for (var i = 0; i < oldValue.length; i++)
                if (oldValue[i][1] != newValue[i][1]) {
                    
                    tempTiming += "&lt;li&gt;" + oldValue[i][0] + " Afternoon Opening Timing : Changed to: \"" + newValue[i][1] + "\" PM  &lt;/li&gt;";
                }
            break;

        case 4:
            for (var i = 0; i < oldValue.length; i++)
                if (oldValue[i][1] != newValue[i][1]) {
                    tempTiming += "&lt;li&gt;" + oldValue[i][0] + " Afternoon Closing Timing : Changed to: \"" + newValue[i][1] + "\" PM  &lt;/li&gt;";
                }
            break;

    }
    return tempTiming;
}

arrAddress1Change = "";
arrAddress2Change = "";
arrStateChange = "";
arrCountyChange = "";
arrCityChange = "";
arrZipcodeChange = "";
arrPhoneChange = "";
arrExtensionChange = "";
arrFaxChange = "";
arrTollfreeChange = "";
arrEmailChange = "";
arrWebChange = "";
arrEbillerChange = "";
arrDirectoryChange = "";
arrAcceptingChange = "";

function compareStatearr(oldValue, newValue, newStateValue) {
    
    for (var i = 0; i < newValue.length; i++) {
        if (rowRemoved.indexOf((i + 1).toString()) == -1) {
            if (newStateValue[i] != "Select a State" && oldValue[i].toLowerCase() != newStateValue[i].toLowerCase()) {//&& oldValue[i] != "") {

                arrStateChange += "&lt;li&gt;Service address" + (i + 1) + " State : changed to \"" + newValue[i] + "\" &lt;/li&gt;";

            }

            if (newStateValue[i] == "Select a State" && oldValue[i] != "") {
                arrStateChange += "&lt;li&gt;Service address" + (i + 1) + " State : changed to \" \" &lt;/li&gt;";
            }
        }
    }
    

}

function compareCountyarr(oldValue, newValue) {
    for (var i = 0; i < newValue.length; i++) {
        if (rowRemoved.indexOf((i + 1).toString()) == -1) {
            if (newValue[i] != "Select a County" && oldValue[i].toLowerCase() != newValue[i].toLowerCase()) {//&& oldValue[i] != "") {

                arrCountyChange += "&lt;li&gt;Service address" + (i + 1) + " County : changed to \"" + newValue[i] + "\" &lt;/li&gt;";

            }

            if (newValue[i] == "Select a County" && oldValue[i] != "") {
                arrCountyChange += "&lt;li&gt;Service address" + (i + 1) + " County : changed to \"  \" &lt;/li&gt;";
            }
        }
    }
}

function compareCityarr(oldValue, newValue) {
    for (var i = 0; i < newValue.length; i++) {
        if (rowRemoved.indexOf((i + 1).toString()) == -1) {
            if (newValue[i] != "Select a City" && oldValue[i].toLowerCase() != newValue[i].toLowerCase()) {// && oldValue[i] != "") {

                arrCityChange += "&lt;li&gt;Service address" + (i + 1) + " City : changed to \"" + newValue[i] + "\" &lt;/li&gt;";

            }

            if (newValue[i] == "Select a City" && oldValue[i] != "") {
                arrCityChange += "&lt;li&gt;Service address" + (i + 1) + " City : changed to \" \" &lt;/li&gt;";
            }
        }
    }
}
trackChanges="";
function compareTrackChangearr(oldValue, newValue, fieldName) {
    trackChanges = "";
    for (var i = 0; i < newValue.length; i++) {
        if (rowRemoved.indexOf((i + 1).toString()) == -1) {
            if (oldValue[i].toLowerCase() != newValue[i].toLowerCase()) {//&& oldValue[i] != "") {

                trackChanges += "&lt;li&gt;Service address" + (i + 1) + " " + fieldName + " : changed to \"" + newValue[i] + "\" &lt;/li&gt;";

            }
            //if (oldValue[i] == "" && newValue[i] != "") {
            //    trackChanges += "&lt;li&gt;Service address" + (i + 1) + "  " + fieldName + " added: " + newValue[i] + "&lt;/li&gt;";
            //}
        }
    }
    return trackChanges;
}

function compareTrackRadioButtonChangearr(oldValue, newValue, fieldName) {
    
    trackChanges = "";
    
        
    if (oldValue != newValue && newValue!=undefined) {

        trackChanges += "&lt;li&gt;" + fieldName + " : changed to \"" + (newValue == "1" ? "Yes" : "No") + "\" &lt;/li&gt;";

    }
        
    
    return trackChanges;
}
addressRemoved = "";
function GetRemovedAddress(removedServiceObj) {
    
    addressRemoved = "";
    for (var i = 0; i < rowRemoved.length; i++) {
        var index = parseInt(rowRemoved[i]);
        addressRemoved += "&lt;h4&gt;  Service Address " + (rowRemoved[i]+1) + " Removed  &lt;/h4&gt;";
        if (removedServiceObj[index].Address1 != "") {
            addressRemoved += "&lt;li&gt;  Address 1 :" + removedServiceObj[index].Address1 + "  &lt;/li&gt;";
        }
        if (removedServiceObj[index].Address2 != "") {
            addressRemoved += "&lt;li&gt;  Address 2 :" + removedServiceObj[index].Address2 + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].State != "") {
            addressRemoved += "&lt;li&gt;  State :" + removedServiceObj[index].State + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].County != "") {
            addressRemoved += "&lt;li&gt;  County :" + removedServiceObj[index].County + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].City != "") {
            addressRemoved += "&lt;li&gt;  City :" + removedServiceObj[index].City + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].Zipcode != "") {
            addressRemoved += "&lt;li&gt;  Zipcode :" + removedServiceObj[index].Zipcode + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].Phone != "") {
            addressRemoved += "&lt;li&gt;  Phone :" + removedServiceObj[index].Phone + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].Extension != "") {
            addressRemoved += "&lt;li&gt;  Extension :" + removedServiceObj[index].Extension + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].Fax != "") {
            addressRemoved += "&lt;li&gt;  Fax :" + removedServiceObj[index].Fax + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].TollFree != "") {
            addressRemoved += "&lt;li&gt;  Toll Free :" + removedServiceObj[index].TollFree + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].Email != "") {
            addressRemoved += "&lt;li&gt;  Email :" + removedServiceObj[index].Email + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].Web != "") {
            addressRemoved += "&lt;li&gt;  Provider Website URL :" + removedServiceObj[index].Web + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].ElectronicBiller != "") {
            addressRemoved += "&lt;li&gt;  Ebiller :" + removedServiceObj[index].ElectronicBiller + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].IsListed != "") {
            addressRemoved += "&lt;li&gt;  Provider Listed in Directory :" + (removedServiceObj[index].IsListed == "1" ? "Yes" : "No") + " &lt;/li&gt;";
        }
        if (removedServiceObj[index].IsAccepting != "") {
            addressRemoved += "&lt;li&gt;  Provider Accepting New Patients :" + (removedServiceObj[index].IsAccepting == "1" ? "Yes" : "No") + " &lt;/li&gt;";
        }
    }
    return addressRemoved;
}



    $(document).ready(function () {

        phoAllLocation = $("#AllLocationPho").val().slice(0, -2).split("||");
        locationObject = [];
        for (var i = 0; i < phoAllLocation.length; i++) {
            locationObject[i] = new Object;
            locationObject[i].Text = phoAllLocation[i].split("|")[0].split("~")[1];
            locationObject[i].Value = phoAllLocation[i].split("|")[0].split("~")[0];
        }

        phoObject = [];
        for (var i = 0; i < phoAllLocation.length; i++) {
            phoObject[i] = new Object;
            phoObject[i].PhoArray = phoAllLocation[i].split("|")[1].slice(0, -1).split("~");
        }
        
        //Load Table and Correspondence

        for (var i = 0; i < locationObject.length; i++) {

            $(".LocationDDL").append("<option value='" + locationObject[i].Value + "'>" + locationObject[i].Text + "</option>")
        }
        LoadPho(0);

        
        correspondenceAllLocation = $("#AllLocationCorrespondence").val().slice(0, -2).split("||");
        correspondenceObj = [];
        for (var i = 0; i < correspondenceAllLocation.length; i++) {
            correspondenceObj[i] = new Object;
            correspondenceObj[i].Address1 = correspondenceAllLocation[i].split("|")[1].split("~")[0];
            correspondenceObj[i].Address2 = correspondenceAllLocation[i].split("|")[1].split("~")[1];
            correspondenceObj[i].State = correspondenceAllLocation[i].split("|")[1].split("~")[2] == "" ? "Select a State" : correspondenceAllLocation[i].split("|")[1].split("~")[2];
            correspondenceObj[i].City = correspondenceAllLocation[i].split("|")[1].split("~")[3] == "" ? "Select a City" : correspondenceAllLocation[i].split("|")[1].split("~")[3];
            correspondenceObj[i].Zip = correspondenceAllLocation[i].split("|")[1].split("~")[4];
            correspondenceObj[i].StateValue = "";
        }
        LoadCorrespondence(0);

        paymentAllLocation = $("#AllLocationPayment").val().slice(0, -2).split("||");
        paymentObj = [];
        for (var i = 0; i < paymentAllLocation.length; i++) {
            paymentObj[i] = new Object;
            paymentObj[i].Address1 = paymentAllLocation[i].split("|")[1].split("~")[0];
            paymentObj[i].Address2 = paymentAllLocation[i].split("|")[1].split("~")[1];
            paymentObj[i].State = paymentAllLocation[i].split("|")[1].split("~")[2] == "" ? "Select a State" : paymentAllLocation[i].split("|")[1].split("~")[2];
            paymentObj[i].City = paymentAllLocation[i].split("|")[1].split("~")[3] == "" ? "Select a City" : paymentAllLocation[i].split("|")[1].split("~")[3];
            paymentObj[i].Zip = paymentAllLocation[i].split("|")[1].split("~")[4];
            paymentObj[i].StateValue = "";
        }
        LoadPayment(0);

        timingAllLocation = $("#AllLocationTiming").val().slice(0, -2).split("||");
        timingObj = [];
        for (var i = 0; i < timingAllLocation.length; i++) {
            timingObj[i] = new Object;
            timingObj[i].WeeklyTiming = [];
            for (var j = 0; j < 7; j++) {
                timingObj[i].WeeklyTiming[j] = new Object;
                timingObj[i].WeeklyTiming[j].MorningStart = timingAllLocation[i].split("|")[1].split("~")[4 * j];
                timingObj[i].WeeklyTiming[j].MorningClose = timingAllLocation[i].split("|")[1].split("~")[(4 * j) + 1];
                timingObj[i].WeeklyTiming[j].AfternoonStart = timingAllLocation[i].split("|")[1].split("~")[(4 * j) + 2];
                timingObj[i].WeeklyTiming[j].AfternoonClose = timingAllLocation[i].split("|")[1].split("~")[(4 * j) + 3];
            }
        }
        
        LoadTiming(0);

        serviceAllLocation = $("#AllLocationService").val().slice(0, -2).split("||");
        serviceObj = [];
        for (var i = 0; i < serviceAllLocation.length; i++) {
            serviceObj[i] = new Object;
            serviceObj[i].Address1 = serviceAllLocation[i].split("|")[1].split("~")[0];
            serviceObj[i].Address2 = serviceAllLocation[i].split("|")[1].split("~")[1];
            serviceObj[i].State = serviceAllLocation[i].split("|")[1].split("~")[2];
            serviceObj[i].County = serviceAllLocation[i].split("|")[1].split("~")[3];
            serviceObj[i].City = serviceAllLocation[i].split("|")[1].split("~")[4];
            serviceObj[i].Zipcode = serviceAllLocation[i].split("|")[1].split("~")[5];
            serviceObj[i].Phone = serviceAllLocation[i].split("|")[1].split("~")[6];
            serviceObj[i].Extension = serviceAllLocation[i].split("|")[1].split("~")[7];
            serviceObj[i].Fax = serviceAllLocation[i].split("|")[1].split("~")[8];
            serviceObj[i].TollFree = serviceAllLocation[i].split("|")[1].split("~")[9];
            serviceObj[i].Email = serviceAllLocation[i].split("|")[1].split("~")[10];
            serviceObj[i].Web = serviceAllLocation[i].split("|")[1].split("~")[11];
            serviceObj[i].ElectronicBiller = serviceAllLocation[i].split("|")[1].split("~")[12];
            serviceObj[i].IsAccepting = serviceAllLocation[i].split("|")[1].split("~")[13];
            serviceObj[i].IsListed = serviceAllLocation[i].split("|")[1].split("~")[14];
            serviceObj[i].StateValue="";
        }
        
        LoadService(0);


        rowEdited = [];
        $("#submitBtn").on("click", function (e) {

            CompareValues();
            if ($("#change").val() == "" || $("#change").val() == null) {
                $("#change").val("You have not done any Changes!!!")

            }

        });

    })

function ChangeContentByLocation(idValue) {
    $("#paymentWarning").empty();
    $("#correspondenceWarning").empty();
    $("#serviceWarning").empty();
    $("#serviceStateWarning").empty();
    $("#serviceFaxWarning").empty();
    $("#servicePhoneWarning").empty();
    $("#serviceEmailWarning").empty();
    var selected = $("#" + idValue + " :selected").val();
    $(".LocationDDL").val(selected);
    var indexvalue = FindIndexValue(selected);
    if (rowRemoved.indexOf(indexvalue) == -1) {
        $("#serviceRow").removeClass("hidden");
    }
    else {
        $("#serviceRow").addClass("hidden");
    }
    LoadPho(indexvalue);
    LoadCorrespondence(indexvalue);
    LoadPayment(indexvalue);
    LoadTiming(indexvalue);
    LoadService(indexvalue);
}
function SaveIntermediateChanges() {
        
    $("#paymentWarning").empty();
    $("#correspondenceWarning").empty();
    $("#serviceWarning").empty();
    $("#serviceStateWarning").empty();
    $("#serviceFaxWarning").empty();
    $("#servicePhoneWarning").empty();
    $("#serviceEmailWarning").empty();
    var selected = $(".LocationDDL :selected").val();
    var indexvalue = FindIndexValue(selected);
    var allPHO = getPHOValues();
    phoObject[indexvalue].PhoArray = (allPHO.length > 0) ? allPHO : [""];
    if ($("#cAddress2").val() != "" || $("#cState").val() != "Select a State" || $("#cCity").val() != "Select a City" || $("#cZip").val() != "") {
        if ($("#cAddress1").val() != "") {
            var allCorrespondence = GetCorrespondenceValues();
            correspondenceObj[indexvalue] = allCorrespondence;
        } else {
            $("#correspondencebtn").click();
            $("#cAddress1").focus();
            $("#correspondenceWarning").html("Please enter address 1.");
        }
    }
    if ($("#pAddress2").val() != "" || $("#pState").val() != "Select a State" || $("#pCity").val() != "Select a City" || $("#pZip").val() != "") {
        if ($("#pAddress1").val() != "") {
            var allPayment = GetPaymentValues();
            paymentObj[indexvalue] = allPayment;
        }
        else {
            if ($("#correspondenceWarning").is(":empty")) {
                $("#paymentbtn").click();
                $("#pAddress1").focus();
            }
            $("#paymentWarning").html("Please enter address 1.");
        }
    }
    var allTiming = GetTimingValues();
        
    timingObj[indexvalue].WeeklyTiming = allTiming;
        
    if ($("#SAaddress2").val() != "" || $("#SAstate").val() != "" || $("#SAcounty").val() != "Select a County" || $("#SAcity").val() != "Select a City" || $("#SAzipcode").val() != "" ||
            $("#SAphone1").val() != "" || $("#SAphone2").val() != "" || $("#SAphone3").val() != "" || $("#SAextn").val() != "" || $("#SAfax1").val() != "" ||
                 $("#SAfax2").val() != "" || $("#SAfax3").val() != "" || $("#SAtollfree1").val() != "" || $("#SAtollfree2").val() != "" || $("#SAtollfree3").val() != "" ||
                $("#SAemail").val() != "" || $("#SAweb").val() != "" || $("#SAebiller").val() != "") {
        validateCheck = true;
        if ($("#SAaddress1").val() == "") {
            $("#tablist1-tab1").click();
            $("#servicebtn").click();
            $("#serviceWarning").html("Please Enter Address1");
            validateCheck = false;
        }

        if ($("#SAstate").val() == "Select a State") {
            $("#tablist1-tab1").click();
            $("#servicebtn").click();
            $("#serviceStateWarning").html("Please Select a State");
            validateCheck = false;
        }

        if ($("#SAphone1").val() != "" || $("#SAphone2").val() != "" || $("#SAphone3").val() != "") {
            if ($("#SAphone1").val().length + $("#SAphone2").val().length + $("#SAphone3").val().length != 10) {
                $("#tablist1-tab1").click();
                $("#servicebtn").click();
                $("#servicePhoneWarning").html("Please enter valid phone number");
                validateCheck = false;
            }
        }

        if ($("#SAfax1").val() != "" || $("#SAfax2").val() != "" || $("#SAfax3").val() != "") {
            if ($("#SAfax1").val().length + $("#SAfax2").val().length + $("#SAfax3").val().length != 10) {
                $("#tablist1-tab1").click();
                $("#servicebtn").click();
                $("#serviceFaxWarning").html("Please enter valid fax number");
                validateCheck = false;
            }
        }
        if ($("#SAemail").val() != "") {
            if (!ValidateEmail($("#SAemail").val())) {
                $("#tablist1-tab1").click();
                $("#servicebtn").click();
                $("#serviceEmailWarning").html("Please enter valid email");
                validateCheck = false;
            }
        }
        if(validateCheck) {
            var allService = GetServiceValues();
            serviceObj[indexvalue] = allService;
        }


    }       
    if (isRemoved) {
        if (rowRemoved.indexOf(indexvalue) == -1) {
            rowRemoved.push(indexvalue);
        }
    }
}

function createChangedPHO() {
        
    var temp = "";
    for (var i = 0; i < locationObject.length; i++) {
        temp += locationObject[i].Value + "~" + locationObject[i].Text + "|";
        for (var j = 0; j < phoObject[i].PhoArray.length; j++) {
            temp += phoObject[i].PhoArray[j] + "~";
        }
        temp += "||";
    }
    return temp;
}
function CreateChangedCorrespondence() {
    var temp = "";
    for (var i = 0; i < locationObject.length; i++) {
        temp += locationObject[i].Value + "~" + locationObject[i].Text + "|";
        for (var j = 0; j < correspondenceObj.length; j++) {
            temp += correspondenceObj[j].Address1 + "~" + correspondenceObj[j].Address2 + "~" + correspondenceObj[j].State + "~" + correspondenceObj[j].City + "~" + correspondenceObj[j].StateValue;
        }
        temp += "||";
    }
    return temp;
}
function CreateChangedPayment() {
    var temp = "";
    for (var i = 0; i < locationObject.length; i++) {
        temp += locationObject[i].Value + "~" + locationObject[i].Text + "|";
        for (var j = 0; j < correspondenceObj.length; j++) {
            temp += paymentObj[j].Address1 + "~" + paymentObj[j].Address2 + "~" + paymentObj[j].State + "~" + paymentObj[j].City + "~" + paymentObj[j].StateValue;
        }
        temp += "||";
    }
    return temp;
}

function ComparePHOFormat(oldValue, newValue) {
        
    var oldLocPHOArray = oldValue.slice(0, -2).split("||");
    var newLocPHOArray = newValue.slice(0, -2).split("||");

    var oldPHOValueArray = [];
    var newPHOValueArray = [];

    for (var i = 0; i < oldLocPHOArray.length; i++) {
        oldPHOValueArray.push(oldLocPHOArray[i].split("|")[1].slice(0, -1).split("~"));
        newPHOValueArray.push(newLocPHOArray[i].split("|")[1].slice(0, -1).split("~"));
    }
    allPHOString = BuildPHOChangeString(oldPHOValueArray, newPHOValueArray);
    return allPHOString;
}
function BuildPHOChangeString(oldValue, newValue) {

    finalPHOstring = "";
    for (var j = 0; j < oldValue.length; j++) {
        if (rowRemoved.indexOf(j) == -1) {
            phoAddedstring = "";
            allPHOAddedstring = "";
            phoRemovedstring = "";
            allPHORemovedstring = "";
            if (!compareArray(oldValue[j], newValue[j])) {
                for (var i = 0; i < newValue[j].length; i++) {
                    if (!contains(oldValue[j], newValue[j][i])) {
                        phoAddedstring += newValue[j][i] + ", ";
                    }
                }
                if (phoAddedstring != ", " && phoAddedstring != "") {
                    phoAddedstring = phoAddedstring.slice(0, -2);
                    allPHOAddedstring = "&lt;li&gt;PHO added: " + phoAddedstring + "&lt;/li&gt;";
                }

            }
            if (!compareArray(oldValue[j], newValue[j])) {
                for (var i = 0; i < oldValue[j].length; i++) {
                    if (!contains(newValue[j], oldValue[j][i])) {
                        phoRemovedstring += oldValue[j][i] + ", ";
                    }
                }
                if (phoRemovedstring != ", " && phoRemovedstring != "") {
                    phoRemovedstring = phoRemovedstring.slice(0, -2);
                    allPHORemovedstring = "&lt;li&gt;PHO Removed: " + phoRemovedstring + "&lt;/li&gt;";
                }

            }
            if (allPHOAddedstring != "" || allPHORemovedstring != "") {
                finalPHOstring += "&lt;h4&gt; Service Address " + (j + 1) + " PHO :&lt;/h4&gt;";
                if (allPHOAddedstring != "") {
                    finalPHOstring += allPHOAddedstring;
                }
                if (allPHORemovedstring != "") {
                    finalPHOstring += allPHORemovedstring;
                }
            }
        }
    }
    return finalPHOstring;
}
function CompareCorrespondenceFormat(oldValue, newValue) {
        
    var oldLocArray = oldValue.slice(0, -2).split("||");
    var newLocArray = newValue.slice(0, -2).split("||");
    finalCorrespondence = "";
    for (var i = 0; i < oldLocArray.length; i++) {
        if (rowRemoved.indexOf(i) == -1) {
            correspondanceAddress1Change = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[0], correspondenceObj[i].Address1, "Address 1");
            correspondanceAddress2Change = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[1], correspondenceObj[i].Address2, "Address 2");
            correspondanceStateChange = CompareState(oldLocArray[i].split("|")[1].split("~")[2], correspondenceObj[i].StateValue, correspondenceObj[i].State);
            correspondanceCityChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[3], correspondenceObj[i].City, "City");
            correspondanceZipChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[4], correspondenceObj[i].Zip, "Zipcode");

            if (correspondanceAddress1Change != "" || correspondanceAddress2Change != "" || correspondanceStateChange != "" || correspondanceCityChange != "" || correspondanceZipChange != "") {
                finalCorrespondence += "&lt;h4&gt; Service Address " + (i + 1) + " Correspondence Address : &lt;/h4&gt;" + correspondanceAddress1Change + correspondanceAddress2Change +
                    correspondanceStateChange + correspondanceCityChange + correspondanceZipChange;
            }
        }
    }
    return finalCorrespondence;
}
function ComparePaymentFormat(oldValue, newValue) {
        
    var oldLocArray = oldValue.slice(0, -2).split("||");
    var newLocArray = newValue.slice(0, -2).split("||");
    finalPayment = "";
    for (var i = 0; i < oldLocArray.length; i++) {
        if (rowRemoved.indexOf(i) == -1) {
            paymentAddress1Change = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[0], paymentObj[i].Address1, "Address 1");
            paymentAddress2Change = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[1], paymentObj[i].Address2, "Address 2");
            paymentStateChange = CompareState(oldLocArray[i].split("|")[1].split("~")[2], paymentObj[i].StateValue, paymentObj[i].State);
            paymentCityChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[3], paymentObj[i].City, "City");
            paymentZipChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[4], paymentObj[i].Zip, "Zipcode");

            if (paymentAddress1Change != "" || paymentAddress2Change != "" || paymentStateChange != "" || paymentCityChange != "" || paymentZipChange != "") {
                finalPayment += "&lt;h4&gt; Service Address " + (i + 1) + " Payment Address : &lt;/h4&gt;" + paymentAddress1Change + paymentAddress2Change +
                    paymentStateChange + paymentCityChange + paymentZipChange;
            }
        }
    }
    return finalPayment;
}
function CompareTimingFormat(oldValue) {
    var oldLocArray = oldValue.slice(0, -2).split("||");
    finalOfficeHours = "";
    var days = ['Mon', 'Tue', 'Wed', 'Thur', 'Fri', 'Sat', 'Sun'];

    for (i = 0; i < oldLocArray.length; i++) {
        if (rowRemoved.indexOf(i) == -1) {
            var oldMOpen = [];
            var oldMClose = [];
            var oldAFOpen = [];
            var oldAFClose = [];
            var newMOpen = [];
            var newMClose = [];
            var newAFOpen = [];
            var newAFClose = [];

            for (var j = 0; j < 7; j++) {

                oldMOpen.push([days[j], oldLocArray[i].split("|")[1].split("~")[4 * j]]);
                oldMClose.push([days[j], oldLocArray[i].split("|")[1].split("~")[(4 * j) + 1]]);
                oldAFOpen.push([days[j], oldLocArray[i].split("|")[1].split("~")[(4 * j) + 2]]);
                oldAFClose.push([days[j], oldLocArray[i].split("|")[1].split("~")[(4 * j) + 3]]);

                newMOpen.push([days[j], timingObj[i].WeeklyTiming[j].MorningStart]);
                newMClose.push([days[j], timingObj[i].WeeklyTiming[j].MorningClose]);
                newAFOpen.push([days[j], timingObj[i].WeeklyTiming[j].AfternoonStart]);
                newAFClose.push([days[j], timingObj[i].WeeklyTiming[j].AfternoonClose]);
            }


            MOpenChange = CompareTiming(oldMOpen, newMOpen, 1);
            MCloseChange = CompareTiming(oldMClose, newMClose, 2);
            AFOpenChange = CompareTiming(oldAFOpen, newAFOpen, 3);
            AFCloseChange = CompareTiming(oldAFClose, newAFClose, 4);



                
            if (MOpenChange != "" || MCloseChange != "" || AFOpenChange != "" || AFCloseChange != "") {
                finalOfficeHours += "&lt;h4&gt; Service Address " + (i + 1) + " Office Hours : &lt;/h4&gt;" + MOpenChange + MCloseChange + AFOpenChange + AFCloseChange;

            }
        }
    }
    return finalOfficeHours;
}
function CompareServiceFormat(oldValue) {
        
    var oldLocArray = oldValue.slice(0, -2).split("||");
    finalService="";
    for (var i = 0; i < oldLocArray.length; i++) {
        if (rowRemoved.indexOf(i) == -1) {
            arrStateChange = CompareState(oldLocArray[i].split("|")[1].split("~")[2], serviceObj[i].StateValue, serviceObj[i].State);
            arrCountyChange = CompareCounty(oldLocArray[i].split("|")[1].split("~")[3], serviceObj[i].County);
            arrCityChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[4], serviceObj[i].City, "City");
            arrAddress1Change = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[0], serviceObj[i].Address1, "Address 1");
            arrAddress2Change = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[1], serviceObj[i].Address2, "Address 2");
            arrZipcodeChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[5], serviceObj[i].Zipcode, "Zipcode");
            arrPhoneChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[6], serviceObj[i].Phone, "Phone");
            arrExtensionChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[7], serviceObj[i].Extension, "Extension");
            arrFaxChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[8], serviceObj[i].Fax, "Fax");
            arrTollfreeChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[9], serviceObj[i].TollFree, "Toll Free");
            arrEmailChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[10], serviceObj[i].Email, "Email");
            arrWebChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[11], serviceObj[i].Web, "Website URL");
            arrEbillerChange = CompareGeneric(oldLocArray[i].split("|")[1].split("~")[12], serviceObj[i].ElectronicBiller, "Ebiller");
            arrDirectoryChange = compareTrackRadioButtonChangearr(oldLocArray[i].split("|")[1].split("~")[14], serviceObj[i].IsListed, "Provider listed in directory");
            arrAcceptingChange = compareTrackRadioButtonChangearr(oldLocArray[i].split("|")[1].split("~")[13], serviceObj[i].IsAccepting, "Provider accepting new patient");

            if (arrAddress1Change != "" || arrAddress2Change != "" || arrStateChange != "" || arrCountyChange != "" || arrCityChange != ""
           || arrZipcodeChange != "" || arrPhoneChange != "" || arrExtensionChange != "" || arrFaxChange != "" || arrTollfreeChange != ""
           || arrEmailChange != "" || arrWebChange != "" || arrEbillerChange != "" || arrDirectoryChange != "" || arrAcceptingChange != "") {
                finalService += "&lt;h4&gt;Service Address " + (i + 1) + " Primary Address &lt;/h4&gt;" + arrAddress1Change + arrAddress2Change + arrStateChange +
                arrCountyChange + arrCityChange + arrZipcodeChange + arrPhoneChange +
                arrExtensionChange + arrFaxChange + arrTollfreeChange + arrEmailChange +
                arrWebChange + arrEbillerChange + arrDirectoryChange + arrAcceptingChange;

            }
        }
    }  
    return finalService;
}


function LoadCorrespondence(indexValue) {
        
    $("#cAddress1").val(correspondenceObj[indexValue].Address1);
    $("#cAddress2").val(correspondenceObj[indexValue].Address2);
    $("#cState").val(correspondenceObj[indexValue].State);
    $("#cCity").val(correspondenceObj[indexValue].City);
    $("#cZip").val(correspondenceObj[indexValue].Zip);
    SetCity(correspondenceObj[indexValue].State, correspondenceObj[indexValue].City, "cCity");
}
function LoadPayment(indexValue) {
        
    $("#pAddress1").val(paymentObj[indexValue].Address1);
    $("#pAddress2").val(paymentObj[indexValue].Address2);
    $("#pState").val(paymentObj[indexValue].State);
    $("#pCity").val(paymentObj[indexValue].City);
    $("#pZip").val(paymentObj[indexValue].Zip);
    SetCity(paymentObj[indexValue].State, paymentObj[indexValue].City, "pCity");
}
function LoadPho(indexValue) {
        
    $("#newPHO").empty();
    for (var i = 0; i < phoObject[indexValue].PhoArray.length; i++) {
        if (phoObject[indexValue].PhoArray[i] != "") {
            $("#newPHO").append("<tr><td class='getPHOValue'> " + phoObject[indexValue].PhoArray[i] + " </td><td><input type='button' class='rmv_btn' alt='Remove' value='X' /></td></tr>");
        }
    }
}
function LoadTiming(indexValue) {
        
    for (var i = 0; i < timingObj[indexValue].WeeklyTiming.length; i++) {
        $("#" + (i + 1) + "MOpening").val(timingObj[indexValue].WeeklyTiming[i].MorningStart);
        $("#" + (i + 1) + "MClosing").val(timingObj[indexValue].WeeklyTiming[i].MorningClose);
        $("#" + (i + 1) + "AFOpening").val(timingObj[indexValue].WeeklyTiming[i].AfternoonStart);
        $("#" + (i + 1) + "AFClosing").val(timingObj[indexValue].WeeklyTiming[i].AfternoonClose);
    }
}
function LoadService(indexValue) {
        
    $(".SAlabel").removeClass("hidden");
    $(".field").addClass("hidden");
    $("#serviceName").empty();
    $("#serviceName").text("Service Address " + (indexValue + 1));
    $("#displayAddress1").html(serviceObj[indexValue].Address1);
    $("#SAaddress1").val(serviceObj[indexValue].Address1);
    $("#displayAddress2").text(serviceObj[indexValue].Address2);
    $("#SAaddress2").val(serviceObj[indexValue].Address2);
    $("#displayState").text(serviceObj[indexValue].State);
    $("#SAstate").val(serviceObj[indexValue].State!=""? serviceObj[indexValue].State:"Select a State");
    $("#displayCounty").html(serviceObj[indexValue].County);
    $("#SAcounty").val(serviceObj[indexValue].County != "" ? toTitleCase(serviceObj[indexValue].County) : "Select a County");
    $("#displayCity").html(serviceObj[indexValue].City);
    $("#SAcity").val(serviceObj[indexValue].City != "" ? toTitleCase(serviceObj[indexValue].City) : "Select a City");
    $("#displayZipcode").html(serviceObj[indexValue].Zipcode);
    $("#SAzipcode").val(serviceObj[indexValue].Zipcode);
    $("#displayPhone").html(serviceObj[indexValue].Phone);
    $("#SAphone1").val(serviceObj[indexValue].Phone.substring(0, 3));
    $("#SAphone2").val(serviceObj[indexValue].Phone.substring(3, 6));
    $("#SAphone3").val(serviceObj[indexValue].Phone.substring(6, 10));
    $("#displayExtn").html(serviceObj[indexValue].Extension);
    $("#SAextn").val(serviceObj[indexValue].Extension);
    $("#displayFax").html(serviceObj[indexValue].Fax);
    $("#SAfax1").val(serviceObj[indexValue].Fax.substring(0, 3));
    $("#SAfax2").val(serviceObj[indexValue].Fax.substring(3, 6));
    $("#SAfax3").val(serviceObj[indexValue].Fax.substring(6, 10));
    $("#displayTollfree").html(serviceObj[indexValue].TollFree);
    $("#SAtollfree1").val(serviceObj[indexValue].TollFree.substring(0, 3));
    $("#SAtollfree2").val(serviceObj[indexValue].TollFree.substring(3, 6));
    $("#SAtollfree3").val(serviceObj[indexValue].TollFree.substring(6, 10));
    $("#displayEmail").html(serviceObj[indexValue].Email);
    $("#SAemail").val(serviceObj[indexValue].Email);
    $("#displayWeb").html(serviceObj[indexValue].Web);
    $("#SAweb").val(serviceObj[indexValue].Web);
    $("#displayEbiller").html(serviceObj[indexValue].ElectronicBiller);
    $("#SAebiller").val(serviceObj[indexValue].ElectronicBiller);
    if (serviceObj[indexValue].IsListed != "") {
        $("#displayListed").html((serviceObj[indexValue].IsListed == "1" ? "Yes" : "No"));
        if (serviceObj[indexValue].IsListed == "1")
        {
            $("input:radio[name='isListed'][value='1']").prop("checked", true);
        }
        else {
            $("input:radio[name='isListed'][value='0']").prop("checked", true);
        }
           
    }
    else {
        $("#displayListed").html("");
    }
    if (serviceObj[indexValue].IsAccepting != "") {
        $("#displayAccepting").html((serviceObj[indexValue].IsAccepting == "1" ? "Yes" : "No"));
        if (serviceObj[indexValue].IsAccepting == "1") {
            $("input:radio[name='isAccepting'][value='1']").prop("checked", true);
        }
        else {
            $("input:radio[name='isAccepting'][value='0']").prop("checked", true);
        }

    }
    else {
        $("#displayAccepting").html("");
    }        
}


function FindIndexValue(selectedValue) {
    for (var i = 0; i < locationObject.length; i++) {
        if (selectedValue.toLowerCase() == locationObject[i].Value.toLowerCase()) {
            return i;
        }
    }
    return -1;
}
function GetCorrespondenceValues() {
    var cAddressObj = new Object;
    cAddressObj.Address1 = $("#cAddress1").val();
    cAddressObj.Address2 = $("#cAddress2").val();
    cAddressObj.State = $("#cState").val() == "Select a State" ? "" : $("#cState").val();
    cAddressObj.City = $("#cCity").val();
    cAddressObj.Zip = $("#cZip").val();
    cAddressObj.StateValue = $("#cState :selected").text();
    return cAddressObj;
}
function GetPaymentValues() {
        
    var pAddressObj = new Object;
    pAddressObj.Address1 = $("#pAddress1").val();
    pAddressObj.Address2 = $("#pAddress2").val();
    pAddressObj.State = $("#pState").val() == "Select a State" ? "" : $("#pState").val();
    pAddressObj.City = $("#pCity").val();
    pAddressObj.Zip = $("#pZip").val();
    pAddressObj.StateValue = $("#pState :selected").text();
    return pAddressObj;
}
function GetTimingValues() {
        
    var timeObj = [];
    var tObj = [];
    for (var i = 0; i < 7; i++) {
        timeObj[i] = new Object;
        timeObj[i].MorningStart = $("#" + (i + 1) + "MOpening").val();
        timeObj[i].MorningClose = $("#" + (i + 1) + "MClosing").val();
        timeObj[i].AfternoonStart = $("#" + (i + 1) + "AFOpening").val();
        timeObj[i].AfternoonClose = $("#" + (i + 1) + "AFClosing").val();
        tObj.push(timeObj[i]);
    }
    return tObj;
}
function GetServiceValues() {
        
    var sAddressObj = new Object;
    sAddressObj.Address1 = $("#SAaddress1").val();
    sAddressObj.Address2 = $("#SAaddress2").val();
    sAddressObj.State = $("#SAstate").val();
    sAddressObj.County = $("#SAcounty").val()!="Select a County"?$("#SAcounty").val():"";
    sAddressObj.City = $("#SAcity").val()!="Select a City"?$("#SAcity").val():"";
    sAddressObj.Zipcode = $("#SAzipcode").val();
    sAddressObj.Phone = $("#SAphone1").val() + $("#SAphone2").val() + $("#SAphone3").val();
    sAddressObj.Extension = $("#SAextn").val()!=undefined?$("#SAextn").val():"";
    sAddressObj.Fax = $("#SAfax1").val() + $("#SAfax2").val() + $("#SAfax3").val();
    sAddressObj.TollFree = $("#SAtollfree1").val() + $("#SAtollfree2").val() + $("#SAtollfree3").val();
    sAddressObj.Email = $("#SAemail").val() != undefined ? $("#SAemail").val() : "";
    sAddressObj.Web = $("#SAweb").val() != undefined ? $("#SAweb").val() : "";
    sAddressObj.ElectronicBiller = $("#SAebiller").val() != undefined ? $("#SAebiller").val() : "";
    sAddressObj.IsAccepting = $("input:radio[name='isAccepting']:checked").val();
    sAddressObj.IsListed = $("input:radio[name='isListed']:checked").val();
    sAddressObj.StateValue = $("#SAstate :selected").text();
    return sAddressObj;
}

function SetCity(state, cityValue, id) {
    if (state != "Select a State") {
        var forgeryId = $("#forgeryToken").val();
        $.ajax({
            url: "/ProviderDataVerification/GetCityByStateJson?stateValue=" + state,
            data: {},
            cache: false,
            async: false,
            type: "GET",
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (data) {
                    
                $("#" + id).html(""); // clear before appending new list
                $.each(data, function (i, city) {
                    if (city.Text.toLowerCase() == cityValue.toLowerCase()) {
                        $("#" + id).append('<option value="' + city.Text + '" selected>' + city.Text + '</option>');
                    }
                    $("#" + id).append('<option value="' + city.Text + '">' + city.Text + '</option>');
                });

            },
            error: function (reponse) {
                alert("error : " + reponse);
            }
        });
    }
    else {
        $("#" + id).html("");
        $("#" + id).append('<option value="Select a City" selected>Select a City</option>');
    }
}
function toTitleCase(str) {
    return str.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
}

    

function massAssign(x) {

    switch (x) {
        case "mOpening":



            $("#1MOpening").val($("#" + x).val());
            $("#2MOpening").val($("#" + x).val());
            $("#3MOpening").val($("#" + x).val());
            $("#4MOpening").val($("#" + x).val());
            $("#5MOpening").val($("#" + x).val());
            $("#6MOpening").val($("#" + x).val());
            $("#7MOpening").val($("#" + x).val());


            break;

        case "mClosing":



            $("#1MClosing").val($("#" + x).val());
            $("#2MClosing").val($("#" + x).val());
            $("#3MClosing").val($("#" + x).val());
            $("#4MClosing").val($("#" + x).val());
            $("#5MClosing").val($("#" + x).val());
            $("#6MClosing").val($("#" + x).val());
            $("#7MClosing").val($("#" + x).val());

            break;

        case "afOpening":


            $("#1AFOpening").val($("#" + x).val());
            $("#2AFOpening").val($("#" + x).val());
            $("#3AFOpening").val($("#" + x).val());
            $("#4AFOpening").val($("#" + x).val());
            $("#5AFOpening").val($("#" + x).val());
            $("#6AFOpening").val($("#" + x).val());
            $("#7AFOpening").val($("#" + x).val());


            break;

        case "afClosing":


            $("#1AFClosing").val($("#" + x).val());
            $("#2AFClosing").val($("#" + x).val());
            $("#3AFClosing").val($("#" + x).val());
            $("#4AFClosing").val($("#" + x).val());
            $("#5AFClosing").val($("#" + x).val());
            $("#6AFClosing").val($("#" + x).val());
            $("#7AFClosing").val($("#" + x).val());
            break;
    }
    $("#" + x).val("00:00");
}

function resetAll() {

    $("#mOpening").val('00:00')
    $("#mClosing").val('00:00')
    $("#afOpening").val('00:00')
    $("#afClosing").val('00:00')
        
    var selected = $(".LocationDDL :selected").val();
    var indexvalue = FindIndexValue(selected);

    var oldTiming = $("#AllLocationTiming").val().slice(0, -2).split("||");
    var modelTimingObj = [];
    for (var i = 0; i < oldTiming.length; i++) {
        modelTimingObj[i] = new Object;
        modelTimingObj[i].WeeklyTiming = [];
        for (var j = 0; j < 7; j++) {
            modelTimingObj[i].WeeklyTiming[j] = new Object;
            modelTimingObj[i].WeeklyTiming[j].MorningStart = oldTiming[i].split("|")[1].split("~")[4 * j];
            modelTimingObj[i].WeeklyTiming[j].MorningClose = oldTiming[i].split("|")[1].split("~")[(4 * j) + 1];
            modelTimingObj[i].WeeklyTiming[j].AfternoonStart = oldTiming[i].split("|")[1].split("~")[(4 * j) + 2];
            modelTimingObj[i].WeeklyTiming[j].AfternoonClose = oldTiming[i].split("|")[1].split("~")[(4 * j) + 3];
        }
    }


    timingObj = modelTimingObj;
    LoadTiming(indexvalue);

}

function clearOfficeHours(day) {
        
    var selected = $(".LocationDDL :selected").val();
    var indexvalue = FindIndexValue(selected);

    var oldTiming = $("#AllLocationTiming").val().slice(0, -2).split("||");
    var modelTimingObj = [];
    for (var i = 0; i < oldTiming.length; i++) {
        modelTimingObj[i] = new Object;
        modelTimingObj[i].WeeklyTiming = [];
        for (var j = 0; j < 7; j++) {
            modelTimingObj[i].WeeklyTiming[j] = new Object;
            modelTimingObj[i].WeeklyTiming[j].MorningStart = oldTiming[i].split("|")[1].split("~")[4 * j];
            modelTimingObj[i].WeeklyTiming[j].MorningClose = oldTiming[i].split("|")[1].split("~")[(4 * j) + 1];
            modelTimingObj[i].WeeklyTiming[j].AfternoonStart = oldTiming[i].split("|")[1].split("~")[(4 * j) + 2];
            modelTimingObj[i].WeeklyTiming[j].AfternoonClose = oldTiming[i].split("|")[1].split("~")[(4 * j) + 3];
        }
    }

    $("#" + (day) + "MOpening").val(modelTimingObj[indexvalue].WeeklyTiming[day - 1].MorningStart);
    $("#" + (day) + "MClosing").val(modelTimingObj[indexvalue].WeeklyTiming[day - 1].MorningClose);
    $("#" + (day) + "AFOpening").val(modelTimingObj[indexvalue].WeeklyTiming[day - 1].AfternoonStart);
    $("#" + (day) + "AFClosing").val(modelTimingObj[indexvalue].WeeklyTiming[day - 1].AfternoonClose);

}

function clearCityValidation() {
    var city = $("#affiliatedHosp_city").val();
    if (city != "Select a City") {
        $("#CityValidation").html("");
    }
}
function clearStateValidation() {
    var state = $("#affiliatedHosp_state").val();
    if (state != "Select a State") {
        $("#StateValidation").html("");
    }
}
function clearSpecialtyValidation() {
    var value = $("#specialities").val();
    if (value != "Select a specialty") {
        $("#SpecialtyValidation").html("");
    }
}

function getPHOValues() {

    values = [];
    $Selct = $(document).find('.getPHOValue');
    $Selct.each(function () {
        values.push($(this).html());
    });
    return values;
}

function getLanguageValues() {

    values = [];
    $Selct = $(document).find('.getLanguageValue');
    $Selct.each(function () {
        values.push($(this).html());
    });
    return values;
}


function getSpecialitiesValues() {

    values = [];
    $Selct = $(document).find('.getSpecialitiesValue');
    $Selct.each(function () {
        values.push($(this).html());
    });
    return values;
}

function getAffiliatedHospValues() {

    values = [];
    hospName = [];
    state = [];
    city = [];
    //$HospName =$(document).find('.getHospNameValue');
    //var value=$HospName.html();
    //if(typeof value ==="undefined")

    $HospName = $(document).find('.getHospNameValue');

    //else
    //    $HospName = HttpUtility.JavaScriptStringEncode($(document).find('.getHospNameValue'));

    $State = $(document).find('.getStateNameValue');
    $City = $(document).find('.getCityNameValue');
    $HospName.each(function () {
        //alert($(this).html())
        hospName.push($(this).html());
    });
    $State.each(function () {
        state.push($(this).html());
    });
    $City.each(function () {
        city.push($(this).html());
    });
    for (var i = 0; i < hospName.length; i++) {
        values.push(hospName[i]);
    }
    return values;
}

function CompareValues() {
        
    var allAddress = '';
    var allpayment = '';
    var allcorres = '';
    var officeHours = '';
    var affiliatedHospital = '';
    var billingCompany = '';
    var specialities = '';
    var languageSpoken = '';
    var pho = '';

    //---------------------------------------------Language Spoken--------------------------------------------------------------//
    var newLanguage = getLanguageValues();

        

    //---------------------------------------------------------Specialities---------------------------------------//

    var newSpeciality = getSpecialitiesValues();
    //----------------------Affiliated Hospital-------------///
    var newHosp = getAffiliatedHospValues();





    //-------------------------------------------Contact Details-----------------------------------------------//
    //- New Service Address-//
    allAddress = "";
    actualService = $("#AllLocationService").val();
    allAddress = CompareServiceFormat(actualService);


    //---------------------Payment Address----------------------------//

    tempPaymentChanges = CreateChangedPayment();
    actualPayment = $("#AllLocationPayment").val();
    allpayment = ComparePaymentFormat(actualPayment, tempPaymentChanges);

    //--------------------Correspondance Address----------------------//

    tempCorrespondenceChanges = CreateChangedCorrespondence();
    actualCorrespondence = $("#AllLocationCorrespondence").val();
    allcorres = CompareCorrespondenceFormat(actualCorrespondence, tempCorrespondenceChanges);

    //--------------------------------Language Soken------------------------------//

    compareLanguageSpoken(oldLanguage, newLanguage)


    //---------------------------PHO Added------------------------------//
    tempPHOChanges = createChangedPHO();
    actualPHO = $("#AllLocationPho").val()
    pho = ComparePHOFormat(actualPHO, tempPHOChanges);

    //--------------------------Speciality---------------------------------//
    compareSpeciality(oldSpeciality, newSpeciality)

    //------------office Hours--------------------//
        
    officeHoursString = "";
    actualTiming = $("#AllLocationTiming").val();
    officeHoursString = CompareTimingFormat(actualTiming);

    //--------------Affiliated Hospital---------//
    CompareHospital(oldHosp, newHosp);

    //-------------Remove Service Address---//
    allAddressremoved = "";
    var modelAllLocation = $("#AllLocationService").val().slice(0, -2).split("||");
    var oldServiceObj = [];
    for (var i = 0; i < modelAllLocation.length; i++) {
        oldServiceObj[i] = new Object;
        oldServiceObj[i].Address1 = modelAllLocation[i].split("|")[1].split("~")[0];
        oldServiceObj[i].Address2 = modelAllLocation[i].split("|")[1].split("~")[1];
        oldServiceObj[i].State = modelAllLocation[i].split("|")[1].split("~")[2];
        oldServiceObj[i].County = modelAllLocation[i].split("|")[1].split("~")[3];
        oldServiceObj[i].City = modelAllLocation[i].split("|")[1].split("~")[4];
        oldServiceObj[i].Zipcode = modelAllLocation[i].split("|")[1].split("~")[5];
        oldServiceObj[i].Phone = modelAllLocation[i].split("|")[1].split("~")[6];
        oldServiceObj[i].Extension = modelAllLocation[i].split("|")[1].split("~")[7];
        oldServiceObj[i].Fax = modelAllLocation[i].split("|")[1].split("~")[8];
        oldServiceObj[i].TollFree = modelAllLocation[i].split("|")[1].split("~")[9];
        oldServiceObj[i].Email = modelAllLocation[i].split("|")[1].split("~")[10];
        oldServiceObj[i].Web = modelAllLocation[i].split("|")[1].split("~")[11];
        oldServiceObj[i].ElectronicBiller = modelAllLocation[i].split("|")[1].split("~")[12];
        oldServiceObj[i].IsAccepting = modelAllLocation[i].split("|")[1].split("~")[13];
        oldServiceObj[i].IsListed = modelAllLocation[i].split("|")[1].split("~")[14];
        oldServiceObj[i].StateValue = "";
    }
    allAddressremoved = GetRemovedAddress(oldServiceObj);


    if (allSpecialitiesAdded != "" || allSpecialitiesRemoved != "") {
        specialities = "&lt;h4&gt; Specialities &lt;/h4&gt;" + allSpecialitiesAdded + allSpecialitiesRemoved;

    }

    if (allLanguageAdded != "" || allLanguageRemoved != "") {
        languageSpoken = "&lt;h4&gt; Languages &lt;/h4&gt;" + allLanguageAdded + allLanguageRemoved;

    }

    if (allHospAdded != "" || allHospRemoved != "") {
        affiliatedHospital = "&lt;h4&gt; Affiliated Hospital &lt;/h4&gt;" + allHospAdded + allHospRemoved;
    }

    $("#change").val(allAddressremoved + allAddress + allcorres + allpayment + officeHoursString + affiliatedHospital + specialities + languageSpoken + pho);


}
       


$("#addSpecialitiesBtn").click(
function () {

    var value = $("#specialities").val();
    var allSpeciality = getSpecialitiesValues();
    var found = contains(allSpeciality, value);
    if (value != "Select a specialty" && found == false) {
        var data = '<tr ><td class="getSpecialitiesValue">' + value + '</td><td> <input type="button" class="rmv_btn" alt="Remove" value="X" /></td></tr>';
        $("#newSpecialities").append(data);
        $("#specialities").val("Select a specialty");

    }
    if (found) {
        $("#SpecialtyValidation").html("<br/>Speciality is already present");
        $("#specialities").focus();
    }
    else if (value == "Select a specialty") {
        $("#SpecialtyValidation").html("<br/>Please select a speciality");
        $("#specialities").focus();
    }
}
);
$('#newSpecialities').on("click", ".rmv_btn", function () {

    $(this).closest("tr").remove();
    $(this).remove();
});

$("#addLanguageBtn").click(  function () {

    var value = $("#languageValues").val();
    var allLanguage = getLanguageValues();
    var found = contains(allLanguage, value);
    if (value != "" && found == false) {
        var data = '<tr ><td class="getLanguageValue">' + value + '</td><td> <input type="button" class="rmv_btn" alt="Remove" value="X" /></td></tr>';
        $("#newLanguage").append(data);
        $("#languageValues").val("");
        $("#languageValidation").empty();
    }
    else if (found) {
        $("#languageValidation").html("Language is already present");
        $("#languageValues").focus();
    }
    else {
        $("#languageValidation").html("Please enter the Language");
        $("#languageValues").focus();
    }

}
);
$('#newLanguage').on("click", ".rmv_btn", function () {

    $(this).closest("tr").remove();
    $(this).remove();
});


$("#addPHObtn").click(  function () {
    var value = $("#phoValues").val();
    var allPHO = getPHOValues();
    var found = contains(allPHO, value);
    if (value != "" && found == false) {
        var data = '<tr ><td class="getPHOValue">' + value + '</td><td> <input type="button" class="rmv_btn" alt="Remove" value="X" /></td></tr>';
        $("#newPHO").append(data);
        $("#phoValues").val("");
        $("#phoValidation").empty();
        SaveIntermediateChanges();
    } else if (found) {
        $("#phoValidation").html("PHO/PO name is already present");
        $("#phoValues").focus();
    }
    else {
        $("#phoValidation").html("Please enter the PHO/PO name");
        $("#phoValues").focus();
    }
}
);
$('#newPHO').on("click", ".rmv_btn", function () {

    $(this).closest("tr").remove();
    $(this).remove();
    SaveIntermediateChanges();
});


$("#addHospitalBtn").click(  function () {
    $("#CityValidation").html("");
    $("#HospitalValidation").html("");
    $("#StateValidation").html("");
    var value = $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").val();
    var city = $("#affiliatedHosp_city").val();
    var state = $('#affiliatedHosp_state :selected').text();
    var allHosp = getAffiliatedHospValues();
    var found = contains(allHosp, value);
    if (value != "" && value != "Select a Hospital" && state != "Select a State" && found == false) {
        var data = '<tr ><td class="getHospNameValue">' + value + '</td><td class=" getStateNameValue hidden">' + state + '</td><td class="getCityNameValue hidden">' + (city == "Select a City" ? "" : city) + '</td><td> <input type="button" class="rmv_btn" alt="Remove" value="X" /></td></tr>';
        $("#hospitalAffiliated").append(data);
        $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").val("Select a Hospital");
        $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").focus();


    }
    else if (found) {
        $("#HospitalValidation").html("<br/>Affiliated hospital Name is already present");
        $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").focus();
    }
    else if (value == null || value == "" || value == "Select a Hospital") {
        $("#HospitalValidation").html("<br/>Please select the Affiliated hospital Name");
        $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").focus();
    }
    //if (city == "Select a City") {
    //    $("#CityValidation").html("<br/>Please select a valid city");

    //}
    if (state == "Select a State") {
        $("#StateValidation").html("<br/>Please select a valid state");
        $('#affiliatedHosp_state').focus();
    }
});
$('#hospitalAffiliated').on("click", ".rmv_btn", function () {

    $(this).closest("tr").remove();
    $(this).remove();
});



function getCounty() {
        
    var forgeryId = $("#forgeryToken").val();
    var state = $("#SAstate").val();
    $.ajax({
        url: "/ProviderDataVerification/GetCountyByStateJson?stateValue=" + state,
        data: {},
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#SAcounty").html(""); // clear before appending new list
            $("#SAcity").html("");
            $("#SAcity").append($('<option></option>').val('Select a City').html('Select a City'));
            $.each(data, function (i, county) {
                $("#SAcounty").append(
                    $('<option></option>').val(county.Text).html(county.Text));
            });

        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}
function getCounty(Id) {
    var forgeryId = $("#forgeryToken").val();
    var state = $("#SAstate").val();
    $.ajax({
        url: "/ProviderDataVerification/GetCountyByStateJson?stateValue=" + state,
        data: {},
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#SAzipcode").val('');
            $("#SAcounty").html(""); // clear before appending new list
            getCity(Id);
            $("#SAcity").html("");
            $("#SAcity").append($('<option></option>').val('Select a City').html('Select a City'));
            $.each(data, function (i, county) {
                $("#SAcounty").append(
                    $('<option></option>').val(county.Text).html(county.Text));
            });

        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}
function getCity() {
    var forgeryId = $("#forgeryToken").val();
    var county = $("#county").val();
    var state = $("#state").val();
    if (state != null) {
        $("#StateValidation").html("");
    }
    $.ajax({
        url: "/ProviderDataVerification/GetCityByCountyJson?county=" + county + "&stateValue=" + state,
        data: {},
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#city1").html(""); // clear before appending new list
            $.each(data, function (i, city1) {
                $("#city1").append(
                    $('<option></option>').val(city1.Text).html(city1.Text));
            });

        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}

function getCity(Id) {
    var forgeryId = $("#forgeryToken").val();
    var county = $("#SAcounty").val();
    var state = $("#SAstate").val();
    if (state != null) {
        $("#StateValidation").html("");
    }
    if (county == null) {
        county = "Select a County";
    }
    $.ajax({
        url: "/ProviderDataVerification/GetCityByCountyJson?county=" + county + "&stateValue=" + state,
        data: {},
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#SAzipcode").val('');
            $("#SAcity").html(""); // clear before appending new list
            $.each(data, function (i, city1) {
                $("#SAcity").append(
                    $('<option></option>').val(city1.Text).html(city1.Text));
            });

        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}

function getZip() {
    var forgeryId = $("#forgeryToken").val();
    var city = $("#SAcity").val();
    var county = $("#SAcounty").val();
    var state = $("#SAstate").val();
    $.ajax({
        url: "/ProviderDataVerification/GetZipByCityJson?city=" + city + "&state=" + state + "&county=" + county,
        data: {},
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#SAzipcode").val(data);
        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}

function getBillingCity() {
    var forgeryId = $("#forgeryToken").val();
    var bill_state = $("#billing_State").val();
    $.ajax({
        url: "/ProviderDataVerification/GetCityByStateJson?stateValue=" + bill_state,
        data: {},
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#billing_City").html(""); // clear before appending new list
            $.each(data, function (i, city) {
                $("#billing_City").append(
                    $('<option></option>').val(city.Text).html(city.Text));
            });

        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}

function getPaymentCity() {
    var forgeryId = $("#forgeryToken").val();
    var payment_state = $("#pState").val();
    $.ajax({
        url: "/ProviderDataVerification/GetCityByStateJson?stateValue=" + payment_state,
        data: {},
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#pZip").val('');
            $("#pCity").html(""); // clear before appending new list
            $.each(data, function (i, city) {
                $("#pCity").append(
                    $('<option></option>').val(city.Text).html(city.Text));
            });

        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}

function getPaymentZip() {
    var forgeryId = $("#forgeryToken").val();
    var payment_City = $("#pCity").val();
    var payment_state = $("#pState").val();
    $.ajax({
        url: "/ProviderDataVerification/GetZipByCityJson?city=" + payment_City + "&state=" + payment_state + "&county=" + "",
        data: {},
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#pZip").val(data);
        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}

function getcorrAdressZip() {
    var forgeryId = $("#forgeryToken").val();
    var City = $("#cCity").val();
    var corrAdress_state = $("#cState").val();
    $.ajax({
        url: "/ProviderDataVerification/GetZipByCityJson?city=" + City + "&state=" + corrAdress_state + "&county=" + "",
        data: {},
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#cZip").val(data);
        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}

function getcorrAdressCity() {
    var forgeryId = $("#forgeryToken").val();
    var corrAdress_state = $("#cState").val();
    $.ajax({
        url: "/ProviderDataVerification/GetCityByStateJson?stateValue=" + corrAdress_state,
        data: {},
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#cZip").val('');
            $("#cCity").html(""); // clear before appending new list
            $.each(data, function (i, city) {
                $("#cCity").append(
                    $('<option></option>').val(city.Text).html(city.Text));
            });

        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}

function affiliatedHospGetCity() {
    var forgeryId = $("#forgeryToken").val();
    var affiliatedHosp_state = $("#affiliatedHosp_state").val();
    $.ajax({
        url: "/ProviderDataVerification/GetCityByStateJson?stateValue=" + affiliatedHosp_state,
        data: {},
        dataType: "json",
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#affiliatedHosp_city").html(""); // clear before appending new list
            $.each(data, function (i, city) {
                $("#affiliatedHosp_city").append(
                    $('<option></option>').val(city.Value).html(city.Text));
            });

        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
    $.ajax({
        url: "/ProviderDataVerification/GetHospital?stateValue=" + affiliatedHosp_state,
        data: {},
        dataType: "json",
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").html(""); // clear before appending new list
            $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").append(
                                $('<option></option>').val("Select a Hospital").html("Select a Hospital"));

            $.each(data, function (i, hospital) {
                $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").append(
                    $('<option></option>').val(hospital.Value).html(hospital.Text));
            });

        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });

}

function GetAffiliatedHospital() {
    var forgeryId = $("#forgeryToken").val();
    var affiliatedHosp_state = $("#affiliatedHosp_state").val();
    var affiliatedHosp_city = $("#affiliatedHosp_city").val();
    $.ajax({
        url: "/ProviderDataVerification/GetHospital",
        data: { stateValue: affiliatedHosp_state, city: affiliatedHosp_city },
        cache: false,
        type: "GET",
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (data) {
            $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").html(""); // clear before appending new list
            $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").append(
                                $('<option></option>').val("Select a Hospital").html("Select a Hospital"));
            $.each(data, function (i, hospital) {
                $("#ProviderModel_AffiliatedHosp_AffiliatedHospital").append(
                    $('<option></option>').val(hospital.Value).html(hospital.Text));
            });

        },
        error: function (reponse) {
            alert("error : " + reponse);
        }
    });
}

$('[id^="rowEdit"]').click(function (e) {
    $(".SAlabel").addClass("hidden");
    $(".field").removeClass("hidden");
});
rowRemoved = [];
isRemoved = "";
$('[id^="rowRemove"]').click(function (e) {
    isRemoved = true;
    $("#serviceRow").addClass("hidden");
});
function ValidateEmail(emailValue) {
        
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(emailValue);

}
