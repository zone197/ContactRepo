﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;

namespace NABWebsite.Models
{
    public class ClientListModel
    {
        public  List<FavProviderList> FavProvider { get; set; }
        public List<FavProviderList> FavProviderR { get; set; }
        public int Total { get; set; }
        public int TotalR { get; set; }
        public string ProviderList { get; set; }
        public string ProviderTinPairList { get; set; }
        public List<UserFavProviderTins> Tinlist { get; set; }
        public List<ClientListResponse> results { get; set; }
        public List<ProviderDetailsResponse> provDetails { get; set; }
        public ClientDetailsRequestEntity entity { get; set; }

        public ClientListDetailsRequest Clientrequest { get; set; }
        public ClientList ClModel { get; set; }
        public string ProductName { get; set; }
        public string OnlyShow { get; set; }

       
    }
}