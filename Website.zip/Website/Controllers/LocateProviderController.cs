﻿using Aetna.ProviderContracts.DataContracts;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models.LocateProvider;
using NABWebsite.Models;
using System.Collections.ObjectModel;
using System.Net.Mail;
using System.Text;
using NABWebsite.Helper;
using NABResources;
using System.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.ServiceModel;
using FlexMapper.MapperService;
using System.Web.UI;
using System.Globalization;
using System.Threading;
using System.Web.Security.AntiXss;
using System.Net;
using Newtonsoft.Json;
using System.Security.Cryptography;
using Utilities;

namespace NABWebsite.Controllers
{
    //[NoCache]
    public class LocateProviderController : BaseController
    {

        #region Declaration
        private static Dictionary<string, string> _cacheHostUrl;
        #endregion
        // will assign by lang selection
        int langcode = Convert.ToInt32(ConfigurationManager.AppSettings["langCode"], System.Globalization.CultureInfo.InvariantCulture);
        int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
        #region Header
        /// <summary>
        /// Renders Headers as part of layout
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ChildActionOnly]
        public ActionResult Header(string id)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, Header Method with Param id: " + id);
                if (!string.IsNullOrEmpty(id))
                {
                    string plancode = Session[SessionConstant.CookiePlanCode] as string;
                    LayoutViewModel layoutmodel = new LayoutViewModel();
                    layoutmodel = GetLayoutData(plancode);
                    List<SelectListItem> items = new List<SelectListItem>();

                    //Add selectitems from Session Roles List
                    if (((UserDetails)Session[Constants.UserDetails]) != null)
                    {
                        if (((UserDetails)Session[Constants.UserDetails]).UserRoles != null)
                        {
                            foreach (var role in ((UserDetails)Session[Constants.UserDetails]).UserRoles)
                            {
                                items.Add(new SelectListItem { Text = role.RoleName, Value = role.RoleName });
                            }
                            layoutmodel.userroles = items;
                            if (((UserDetails)Session[Constants.UserDetails]).SelectedRole == null)
                            {
                                ((UserDetails)Session[Constants.UserDetails]).SelectedRole = items.FirstOrDefault().Value;
                            }
                            else
                            {
                                layoutmodel.selectedRole = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                            }
                        }

                    }
                    traceLog.AppendLine(" & End: LocateProviderController, Header Method");
                    return PartialView("~/views/shared/LocateProviderHeader.cshtml", layoutmodel);

                }
                else
                    throw new ArgumentNullException(VariableConstant.Header);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// fetches header data from database
        /// </summary>
        /// <param name="plancode"></param>
        /// <returns></returns>
        private LayoutViewModel GetLayoutData(string plancode)
        {
            StringBuilder traceLog = new StringBuilder();
            LayoutViewModel layoutmodel = new LayoutViewModel();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetLayoutData Method with Param plancode: " + plancode);
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                ManageContent omngcontent = new ManageContent();
                Session["MedicaCustomURLCheck"] = false;
                layoutmodel.FooterInfo = omngcontent.GetFooterInfo(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                if (string.IsNullOrEmpty(plancode))
                {
                    NABWebsite.DTO.Header header = omngcontent.GetHeaderInfo(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                    HeaderInfo headerInfo = new HeaderInfo();
                    headerInfo.logo = header.logo;
                    layoutmodel.LocateProviderHeaderInfo = headerInfo;
                }
                else
                {
                    layoutmodel.LocateProviderHeaderInfo = omngcontent.GetHeaderInfoForLocateProvider(plancode, request);
                    string medicaUrl = ConfigurationManager.AppSettings["MedicaCustomURLCheck"];
                    if (medicaUrl != null)
                    {
                        List<string> MedicaURLList = medicaUrl.Split(',').ToList();
                        if (MedicaURLList.Contains(layoutmodel.LocateProviderHeaderInfo.ClientLoginCode.Trim()))
                        {
                            Session["MedicaCustomURLCheck"] = true;
                        }
                        else
                        {
                            Session["MedicaCustomURLCheck"] = false;
                        }
                    }
                }
                layoutmodel.hosturl = GetHostUrl("HOSTURL");
                traceLog.AppendLine(" & End: LocateProviderController, GetLayoutData Method");
                return layoutmodel;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// gets current host url
        /// </summary>
        /// <param name="keyname"></param>
        /// <returns></returns>
        private static string GetHostUrl(string keyname)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetHostUrl Method with Param keyname: " + keyname);
                string strhosturl = string.Empty;
                Dictionary<string, string> dictionary = new Dictionary<string, string>();
                if (_cacheHostUrl == null)
                {
                    strhosturl = Convert.ToString(ConfigurationManager.AppSettings["HOSTURL"], CultureInfo.CurrentCulture);
                    dictionary.Add("HOSTURL", strhosturl);
                    _cacheHostUrl = dictionary;
                }
                _cacheHostUrl.TryGetValue(keyname.ToUpper(CultureInfo.InvariantCulture), out strhosturl);
                traceLog.AppendLine(" & End: LocateProviderController, GetHostUrl Method");
                return strhosturl;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        #endregion

        #region ActionResults

        /// <summary>
        /// Locate provider home page for desktop
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult FirstHealthRole()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, FirstHealthRole Method");
                traceLog.AppendLine(" & End: LocateProviderController, FirstHealthRole Method");
                return View("~/Views/LocateProvider/FirstHealthRole.cshtml");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
            /// Locate provider home page for desktop
            /// </summary>
            /// <returns></returns>
            [NoCache]
        public ActionResult SelectNetworkType()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, SelectNetworkType Method");
                /*               
                 * START Set Locate provider Session set by User 
                 * 
                 */
                if (Session["CurrentCulture"] != null)
                {
                    Session[CookieConstant.Culture] = Session["CurrentCulture"];

                    string cultureName = null;

                    //Attempt to read the culture from session
                    string cultureCookie = Session["_culture"] as string;
                    if (cultureCookie != null)
                        cultureName = cultureCookie.ToString();
                    else
                        cultureName = Request.UserLanguages != null && Request.UserLanguages.Length > 0 ? Request.UserLanguages[0] : null; // obtain it from HTTP header AcceptLanguages

                    // Validate culture name
                    cultureName = CultureHelper.GetImplementedCulture(cultureName); // This is safe

                    // Set culture

                    // Modify current thread's cultures            
                    Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(cultureName);
                    Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentCulture;
                }
                /*               
                 * END Set current 
                 * 
                 */
                if (Session[CookieConstant.Culture] == null)
                {
                    Session[CookieConstant.Culture] = "en-us";
                }
                if (Session[SessionConstant.CookiePlanCode] != null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, SelectNetworkType Method");
                    return RedirectToAction("CustomPage");
                }
                Session[SessionConstant.ComparedProvider] = null;
                Session[SessionConstant.TaggedProvider] = null;
                Session[SessionConstant.SortingPagingInfo] = null;
                Session[SessionConstant.TaggedSortingPagingInfo] = null;
                Session["ClientLoginName"] = null;
                if (new CommonHelper().IsMobileDevice())
                {
                    if (!Request.UserAgent.Contains("iPad"))
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, SelectNetworkType Method");
                        return Redirect("/" + ApplicationConstants.LocateProviderMobileController + "/" + ApplicationConstants.IndexActionMobile);
                    }

                }

                PageViewModel pageViewModel = new Models.PageViewModel();
                string clientCode = string.Empty;

                ManageContent contentManager = new ManageContent();
                string culture = ReturnCultureInfo();
                RequestHeader requestForNetworkType = new CommonHelper().GetRequestHeader(culture, defaultSourceId);

                Collection<NetworkTypes> networkType = new Collection<NetworkTypes>();
                networkType = contentManager.GetNetworkTypesLocateProviderMobile(requestForNetworkType);
                pageViewModel.NetworkTypeList = networkType;

                requestForNetworkType.Functionality = AppSettingHelper.GetAppSettingValue(VariableConstant.TermsOfUseKey);
                pageViewModel.TermsOfUse = contentManager.GetTermsOfUse(requestForNetworkType).ToList();
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                pageViewModel.SearchRequest = searchRequest;
                SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.SelectNetworkTypeAction);
                traceLog.AppendLine(" & End: LocateProviderController, SelectNetworkType Method");
                return View("~/Views/LocateProvider/SelectNetworkType.cshtml", pageViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// landing page for custom urls
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult CustomPage()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, CustomPage Method");
                if (new CommonHelper().IsMobileDevice())
                {
                    if (!Request.UserAgent.Contains("iPad"))
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, CustomPage Method");
                        return RedirectToAction("CustomPageMobile", "LocateProviderMobile");
                    }
                }
                if (Session[CookieConstant.Culture] == null)
                {
                    Session[CookieConstant.Culture] = "en-us";
                }
                string planCode = string.Empty;
                if (Session[SessionConstant.CookiePlanCode] != null)// || Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                {
                    planCode = Convert.ToString(Session[SessionConstant.CookiePlanCode]);
                    PageViewModel pageViewModel = new Models.PageViewModel();
                    ManageContent contentManager = new ManageContent();
                    string culture = ReturnCultureInfo();
                    RequestHeader requestForNetworkType = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                    HeaderInfo locateProviderHeaderInfo = contentManager.GetHeaderInfoForLocateProvider(planCode, requestForNetworkType);

                    Collection<NetworkTypes> networkType = new Collection<NetworkTypes>();
                    networkType = contentManager.GetNetworkTypesLocateProviderMobile(requestForNetworkType);
                    pageViewModel.NetworkTypeList = networkType;
                    SearchRequestEntity searchRequest = new SearchRequestEntity();

                    if (locateProviderHeaderInfo != null && !string.IsNullOrWhiteSpace(locateProviderHeaderInfo.ClientLoginCode))
                    {
                        pageViewModel.RadioButtonSelected = ApplicationConstants.RadioOtherClientNetwork;
                        pageViewModel.OtherClientNetwork = locateProviderHeaderInfo.ClientLoginCode;
                    }

                    requestForNetworkType.Functionality = AppSettingHelper.GetAppSettingValue(VariableConstant.TermsOfUseKey);
                    pageViewModel.TermsOfUse = contentManager.GetTermsOfUse(requestForNetworkType).ToList();
                    pageViewModel.ClientLoginInfo = locateProviderHeaderInfo;
                    Session["ClientLoginName"] = locateProviderHeaderInfo.ClientLoginName;
                    SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.CustomPage);
                    traceLog.AppendLine(" & End: LocateProviderController, CustomPage Method");
                    return View("~/views/LocateProvider/CustomPage.cshtml", pageViewModel);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, CustomPage Method");
                    return RedirectToAction("SelectNetworkType", "LocateProvider");
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// compare provider page
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult CompareResult()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, CompareResult Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, CompareResult Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                CompareProviderViewModel objCompareproviderViewModel = new CompareProviderViewModel();
                List<CompareProvider> comparedProviders = Session[SessionConstant.ComparedProvider] as List<CompareProvider>;
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;

                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, CompareResult Method");
                        return RedirectToAction(ApplicationConstants.CustomPage);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, CompareResult Method");
                        return RedirectToAction(ApplicationConstants.SelectNetworkTypeAction);
                    }
                }
                if (comparedProviders == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, CompareResult Method");
                    return RedirectToAction(ApplicationConstants.LocateProviderSearchResultAction);
                }
                if (!CommonHelper.ValidateCompareList(comparedProviders))
                {
                    throw new System.Exception(ExceptionMessageConstant.CompareProvider);
                }

                if (!new CommonHelper().Validate(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }
                ManageContent contentManager = new ManageContent();
                List<ProviderDataForComparison> objCompareList = new List<ProviderDataForComparison>();
                if (comparedProviders.Count() == AppSettingHelper.ReturnValue(VariableConstant.MinimumProvidersForComparison) || comparedProviders.Count() == AppSettingHelper.ReturnValue(VariableConstant.MaximumProvidersForComparison))
                {
                    List<ProviderSelector> pList = new List<ProviderSelector>();
                    foreach (var item in comparedProviders)
                    {
                        ProviderSelector obj = new ProviderSelector();
                        obj.ProvLocationID = item.LocationId.Replace("-", "/");
                        obj.ProvNum = item.ProviderNumber;
                        obj.ProvTaxId = item.TaxId;

                        pList.Add(obj);
                    }
                    int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                    string culture = ReturnCultureInfo();
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, networkId);
                    objCompareList = contentManager.CompareProviders(pList, searchRequest.ZipCode, request).ToList();

                    foreach (var item in objCompareList)
                    {
                        item.ProviderNumber = item.ProviderNumber.Trim();
                        item.ProvTaxId = item.ProvTaxId.Trim();
                        item.ProvLocationID = item.ProvLocationID.Trim();
                        objCompareproviderViewModel.ListProviderDataForComparison.Add(item);
                    }

                    objCompareproviderViewModel.RecaptchaPublicKey = AppSettingHelper.GetAppSettingValue(VariableConstant.PublicKey);
                    objCompareproviderViewModel.GoogleRecaptchaAPIAddressSingle = AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleAPIAddress);

                    SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.CompareResultAction);
                    traceLog.AppendLine(" & End: LocateProviderController, CompareResult Method");
                    return View(objCompareproviderViewModel);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, CompareResult Method");
                    return RedirectToAction(ApplicationConstants.LocateProviderSearchResultAction);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// compared tagged providers page
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult TaggedCompareResult()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, TaggedCompareResult Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, TaggedCompareResult Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                CompareProviderViewModel objCompareproviderViewModel = new CompareProviderViewModel();
                List<CompareProvider> comparedProviders = Session[SessionConstant.TaggedComparedProvider] as List<CompareProvider>;
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, TaggedCompareResult Method");
                        return RedirectToAction(ApplicationConstants.CustomPage);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, TaggedCompareResult Method");
                        return RedirectToAction(ApplicationConstants.SelectNetworkTypeAction);
                    }
                }
                if (comparedProviders == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, TaggedCompareResult Method");
                    return RedirectToAction(ApplicationConstants.LocateProviderSearchResultAction);
                }
                if (!CommonHelper.ValidateCompareList(comparedProviders))
                {
                    throw new System.Exception(ExceptionMessageConstant.CompareProvider);
                }

                if (!new CommonHelper().Validate(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }
                ManageContent contentManager = new ManageContent();
                List<ProviderDataForComparison> objCompareList = new List<ProviderDataForComparison>();
                if (comparedProviders.Count() == AppSettingHelper.ReturnValue(VariableConstant.MinimumProvidersForComparison) || comparedProviders.Count() == AppSettingHelper.ReturnValue(VariableConstant.MaximumProvidersForComparison))
                {
                    List<ProviderSelector> pList = new List<ProviderSelector>();
                    foreach (var item in comparedProviders)
                    {
                        ProviderSelector obj = new ProviderSelector();
                        obj.ProvLocationID = item.LocationId;
                        obj.ProvNum = item.ProviderNumber;
                        obj.ProvTaxId = item.TaxId;

                        pList.Add(obj);
                    }
                    int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                    string culture = ReturnCultureInfo();
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, networkId);
                    objCompareList = contentManager.CompareProviders(pList, searchRequest.ZipCode, request).ToList();
                    List<ProviderDataForComparison> tempSearch = new List<ProviderDataForComparison>();
                    for (int i = 0; i < comparedProviders.Count; i++)
                    {
                        foreach (var item in objCompareList)
                        {
                            if (item.ProvLocationID.Equals(comparedProviders[i].LocationId.Replace("-", "/")) && item.ProvTaxId.Equals(comparedProviders[i].TaxId))
                            {
                                tempSearch.Add(item);
                            }

                        }
                    }
                    foreach (var item in tempSearch)
                    {
                        item.ProviderNumber = item.ProviderNumber.Trim();
                        item.ProvTaxId = item.ProvTaxId.Trim();
                        item.ProvLocationID = item.ProvLocationID.Trim();
                        objCompareproviderViewModel.ListProviderDataForComparison.Add(item);
                    }
                    objCompareproviderViewModel.RecaptchaPublicKey = AppSettingHelper.GetAppSettingValue(VariableConstant.PublicKey);
                    objCompareproviderViewModel.GoogleRecaptchaAPIAddressSingle = AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleAPIAddress);

                    SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.CompareResultAction);
                    traceLog.AppendLine(" & End: LocateProviderController, TaggedCompareResult Method");
                    return View(objCompareproviderViewModel);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, TaggedCompareResult Method");
                    return RedirectToAction(ApplicationConstants.TaggedProvidersAction);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// Renders search criteria page
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult LocateProviderSearch()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, LocateProviderSearch Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, LocateProviderSearch Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, LocateProviderSearch Method");
                        return RedirectToAction(ApplicationConstants.CustomPage);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, LocateProviderSearch Method");
                        return RedirectToAction(ApplicationConstants.SelectNetworkTypeAction);
                    }
                }

                if (!CommonHelper.ValidateSearchRequestForCriteria(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));
                ManageContent contentManager = new ManageContent();
                LocateProviderSearchViewModel objLocateProviderSearchViewModel = new LocateProviderSearchViewModel();

                objLocateProviderSearchViewModel.ListProviderType = contentManager.GetProviderTypesLocateProvider(request).ToList();


                SearchRequestEntity refineRequest = new SearchRequestEntity();
                refineRequest = Session[SessionConstant.RefineRequest] as SearchRequestEntity;
                if (refineRequest != null)
                {
                    objLocateProviderSearchViewModel.RefineRequest = refineRequest;
                }
                objLocateProviderSearchViewModel.SearchRequest = searchRequest;
                objLocateProviderSearchViewModel.SearchRequest.FocusCodes = searchRequest.FocusCodes;
                objLocateProviderSearchViewModel.ZipLookupSiteUrl = AppSettingHelper.GetAppSettingValue(ApplicationConstants.ZipLookupSiteUrl);

                if (refineRequest.State != null)
                {
                    objLocateProviderSearchViewModel.ListState = GetStatesOTMC(searchRequest.NetworkType.NetworkId, searchRequest.CustomerType);
                    objLocateProviderSearchViewModel.CountyList = contentManager.GetCountiesByStateLocateProvider(refineRequest.State, request).ToList();
                    if (refineRequest.CountyCodes != null && refineRequest.CountyCodes.Count != 0)
                    {
                        List<string> stateList = new List<string>();
                        stateList.Add(refineRequest.State);
                        objLocateProviderSearchViewModel.CityList = contentManager.GetCitiesByStateAndCountyLocateProvider(stateList, refineRequest.CountyCodes, request).ToList();
                    }
                    else
                    {
                        objLocateProviderSearchViewModel.CityList = contentManager.GetCitiesByStateLocateProvider(refineRequest.State, request).ToList();

                    }

                }

                objLocateProviderSearchViewModel.SearchRequest = searchRequest;
                objLocateProviderSearchViewModel.ZipLookupSiteUrl = AppSettingHelper.GetAppSettingValue(ApplicationConstants.ZipLookupSiteUrl);

                if (new CommonHelper().IsMobileDevice())
                {
                    if (!Request.UserAgent.Contains("iPad"))
                    {
                        SetActiveControllerToSession(ApplicationConstants.LocateProviderMobileController, ApplicationConstants.SearchIndexActionMobile);
                        traceLog.AppendLine(" & End: LocateProviderController, LocateProviderSearch Method");

                        return RedirectToAction(ApplicationConstants.SearchIndexActionMobile, ApplicationConstants.LocateProviderMobileController, searchRequest.ProviderType.ProviderTypeId);
                    }
                    else
                    {
                        SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.LocateProviderSearchAction);
                        traceLog.AppendLine(" & End: LocateProviderController, LocateProviderSearch Method");

                        return View(objLocateProviderSearchViewModel);
                    }


                }
                else
                {
                    SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.LocateProviderSearchAction);
                    traceLog.AppendLine(" & End: LocateProviderController, LocateProviderSearch Method");

                    return View(objLocateProviderSearchViewModel);
                }


            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// Renders search criteria page again for New Search
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult NewSearch()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, NewSearch Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, NewSearch Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                traceLog.AppendLine(" & End: LocateProviderController, NewSearch Method");
                //Session[SessionConstant.SearchRequest] = null;
                return RedirectToAction(ApplicationConstants.LocateProviderSearchAction);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Search result 
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult LocateProviderSearchResult()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, LocateProviderSearchResult Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, LocateProviderSearchResult Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                Session[SessionConstant.ExpandedProviders] = null;
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, LocateProviderSearchResult Method");
                        return RedirectToAction(ApplicationConstants.CustomPage);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, LocateProviderSearchResult Method");
                        return RedirectToAction(ApplicationConstants.SelectNetworkTypeAction);
                    }

                }
                if (!new CommonHelper().Validate(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }
                ManageContent contentManager = new ManageContent();
                LocateProviderSearchResultViewModel searchResultViewModel = new LocateProviderSearchResultViewModel();
                SortingPagingInfo info = new SortingPagingInfo();
                if (Session[SessionConstant.SortingPagingInfo] != null)
                {
                    info = Session[SessionConstant.SortingPagingInfo] as SortingPagingInfo;
                    searchRequest.StartIndexForRecordDisplay = info.CurrentPageIndex + 1;
                    searchRequest.LastIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    searchRequest.SortColumn = info.SortField;
                    searchRequest.SortOrder = info.SortDirection;

                }
                else
                {
                    searchRequest.StartIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.StartIndexForRecordDisplay);
                    searchRequest.LastIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    if (searchRequest.ZipCode != null)
                    {
                        searchRequest.SortColumn = AppSettingHelper.GetAppSettingValue(VariableConstant.SortColumn);
                        info.SortField = AppSettingHelper.GetAppSettingValue(VariableConstant.SortField);
                    }
                    else
                    {
                        searchRequest.SortColumn = System.Configuration.ConfigurationManager.AppSettings["FirstName"];
                        info.SortField = System.Configuration.ConfigurationManager.AppSettings["FirstName"];
                    }
                    searchRequest.SortOrder = AppSettingHelper.GetAppSettingValue(VariableConstant.SortDirection);
                    info.SortDirection = AppSettingHelper.GetAppSettingValue(VariableConstant.SortDirection);
                    info.PageSize = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    info.CurrentPageIndex = AppSettingHelper.ReturnValue(VariableConstant.CurrentPageIndex);
                }
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));
                searchResultViewModel.SearchResult = contentManager.GetCriteriaBasedProviders(searchRequest, request);

                //Fetch Client Specific network name
                if (!string.IsNullOrEmpty(searchRequest.ClientSpecificCode))
                {
                    var clientNetwork = GetNetworkNameFromCode(searchRequest.ClientSpecificCode);
                    searchRequest.ClientSpecificNetwork = clientNetwork;
                }

                info.PageCount = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(searchResultViewModel.SearchResult.ProviderMatchCount) / Convert.ToDouble(VariableConstant.TwentyProviders)));
                info.TotalRecords = searchResultViewModel.SearchResult.ProviderMatchCount;
                ViewBag.SortingPagingInfo = info;
                Session[SessionConstant.SortingPagingInfo] = ViewBag.SortingPagingInfo;
                SearchRequestEntity refineRequest = new SearchRequestEntity();
                refineRequest = Session[SessionConstant.RefineRequest] as SearchRequestEntity;
                if (refineRequest != null)
                {
                    searchResultViewModel.RefineRequest = refineRequest;
                }

                searchResultViewModel.SearchRequest = searchRequest;

                List<string> taggedProviders = Session[SessionConstant.TaggedProvider] as List<string>;
                searchResultViewModel.TaggedProviderNumbers = taggedProviders;
                searchResultViewModel.TaggedProvidersCount = (taggedProviders == null) ? 0 : taggedProviders.Count;
                searchResultViewModel.ProvidersForComparison = Session[SessionConstant.ComparedProvider] as List<CompareProvider>;

                searchResultViewModel.ListProviderType = contentManager.GetProviderTypesLocateProvider(request).ToList();
                searchResultViewModel.ZipLookupSiteUrl = AppSettingHelper.GetAppSettingValue(ApplicationConstants.ZipLookupSiteUrl);

                SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.LocateProviderSearchResultAction);
                searchResultViewModel.PublicKey = AppSettingHelper.GetAppSettingValue(VariableConstant.PublicKey);
                searchResultViewModel.GoogleRecaptchaAPIAddressSingle = AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleAPIAddress);

                if (searchRequest.State != null)
                {
                    searchResultViewModel.ListState = GetStatesOTMC(searchRequest.NetworkType.NetworkId, searchRequest.CustomerType);
                    searchResultViewModel.SearchByStateCityCounty = true;
                    searchResultViewModel.CountyList = contentManager.GetCountiesByStateLocateProvider(searchRequest.State, request).ToList();
                    searchResultViewModel.CityList = contentManager.GetCitiesByStateLocateProvider(searchRequest.State, request).ToList();

                }
                traceLog.AppendLine(" & End: LocateProviderController, LocateProviderSearchResult Method");
                return View(searchResultViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// Get Facility Provider
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult GetFacilityProvider(string specialityId, string providerInfo)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetFacilityProvider Method with Param specialityId: " + specialityId);
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetFacilityProvider Method");
                    return RedirectToAction("IndexSession", "Error");
                }

                var model = new FacilityProviderModel();

                if (!string.IsNullOrEmpty(specialityId))
                {

                    model.FacilityProvider = GetTXFacilityProviders(specialityId, providerInfo);

                    //get Hospital Details

                    traceLog.AppendLine("Start: LocateProviderController, GetDetailedProviderInfo Method with Param providerNumber: " + providerInfo);
                    if (Session[CookieConstant.Culture] == null)
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, GetDetailedProviderInfo Method");
                        return RedirectToAction("IndexSession", "Error");
                    }
                    SearchRequestEntity searchRequest = new SearchRequestEntity();
                    searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                    ManageContent contentManager = new ManageContent();


                    if (!new CommonHelper().Validate(searchRequest))
                    {
                        throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                    }
                    char[] splitchar = { ApplicationConstants.SplitString };

                    if (!CommonHelper.ValidateProviderNumber(providerInfo))
                        throw new System.Exception(VariableConstant.ProviderNumber);

                    string[] providerNumberIndex = providerInfo.Split(splitchar);
                    int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                    string culture = ReturnCultureInfo();
                    RequestHeader requestForProviderDetails = new CommonHelper().GetRequestHeader(culture, networkId);
                    Aetna.ProviderContracts.DataContracts.Provider detailedProviderInfo = new Aetna.ProviderContracts.DataContracts.Provider();
                    if (providerNumberIndex.Count() == 3)
                    {
                        detailedProviderInfo = contentManager.GetProviderDetails(providerNumberIndex[0], providerNumberIndex[1].Replace("-", "/"), providerNumberIndex[2], searchRequest.ZipCode, requestForProviderDetails, searchRequest.ClientSpecificCode);
                    }
                    else
                    {
                        throw new ArgumentNullException(VariableConstant.ProviderNumber);
                    }

                    ///////

                    model.HospitalName = detailedProviderInfo.PracticeName;
                    model.HospitalAddress = detailedProviderInfo.OtherOfficeLocations[0].AddressLine1 + ", " + detailedProviderInfo.OtherOfficeLocations[0].CITY + " " + detailedProviderInfo.OtherOfficeLocations[0].State + " " + detailedProviderInfo.OtherOfficeLocations[0].Zipcode; ;
                    model.HospitalPhone = detailedProviderInfo.OtherOfficeLocations[0].PhoneNbr;
                    traceLog.AppendLine(" & End: LocateProviderController, GetFacilityProvider Method");
                    return PartialView("~/Views/Shared/LocateProvider/facilityProviderPopup.cshtml", model);
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return null;

        }

        /// <summary>
        /// Renders partial view for more provider details
        /// </summary>
        /// <param name="providerNumber"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public ActionResult GetDetailedProviderInfo(string providerNumber)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetDetailedProviderInfo Method with Param providerNumber: " + providerNumber);
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetDetailedProviderInfo Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (string.IsNullOrEmpty(providerNumber) || searchRequest == null)
                {
                    if (Session[SessionConstant.ProviderNumber] != null)
                    {
                        providerNumber = Session[SessionConstant.ProviderNumber].ToString();
                    }
                    else
                    {
                        TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                        traceLog.AppendLine(" & End: LocateProviderController, GetDetailedProviderInfo Method");
                        return Json(ApplicationConstants.SelectNetworkTypeAction);
                    }
                }
                else
                {
                    Session[SessionConstant.ProviderNumber] = providerNumber;
                }
                ManageContent contentManager = new ManageContent();


                if (!new CommonHelper().Validate(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }
                char[] splitchar = { ApplicationConstants.SplitString };

                if (!CommonHelper.ValidateProviderNumber(providerNumber))
                    throw new System.Exception(VariableConstant.ProviderNumber);

                string[] providerNumberIndex = providerNumber.Split(splitchar);
                int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                string culture = ReturnCultureInfo();
                RequestHeader requestForProviderDetails = new CommonHelper().GetRequestHeader(culture, networkId);
                Aetna.ProviderContracts.DataContracts.Provider detailedProviderInfo = new Aetna.ProviderContracts.DataContracts.Provider();
                if (providerNumberIndex.Count() == 3)
                {
                    detailedProviderInfo = contentManager.GetProviderDetails(providerNumberIndex[0], providerNumberIndex[1].Replace("-", "/"), providerNumberIndex[2], searchRequest.ZipCode, requestForProviderDetails, searchRequest.ClientSpecificCode);
                }
                else
                {
                    throw new ArgumentNullException(VariableConstant.ProviderNumber);
                }
                LocateProviderSearchResultViewModel searchResultViewModel = new LocateProviderSearchResultViewModel();
                ProviderDetailsModel providerDetailsModel = new ProviderDetailsModel();
                
                List<Hours> hoursList = new List<Hours>();
                int startAm = 0;
                int endAm = 1;
                int startPm = 2;
                int endPm = 3;
                string days = Resources.Weekdays;
                string[] weekDays = days.Split(',');
                if (detailedProviderInfo != null)
                {
                    if (detailedProviderInfo.OfficeHours.Count() > 0)
                    {
                        for (int i = 0; i < 7; i++)
                        {
                            Hours hours = new Hours();
                            hours.Day = weekDays[i];

                            if (detailedProviderInfo.OfficeHours[startAm].OfficeTimeSlot.Trim().Length > 0 && detailedProviderInfo.OfficeHours[endAm].OfficeTimeSlot.Trim().Length > 0)
                            {
                                string html = "<table ><tr><td >" + detailedProviderInfo.OfficeHours[startAm].OfficeTimeSlot + VariableConstant.StartTimeInAM;

                                if (detailedProviderInfo.OfficeHours[endAm].OfficeTimeSlot.Trim().Length > 0)
                                {
                                    html = html + "</td><td style='width:15%'>-</td><td >" + detailedProviderInfo.OfficeHours[endAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + "</td></tr></table>";
                                }
                                else
                                    html = html + "</td><td style='width:15%'></td><td >" + "         " + "</td></tr></table>";
                                hours.Time = html;
                            }
                            else
                            {
                                if (detailedProviderInfo.OfficeHours[startAm].OfficeTimeSlot.Trim().Length > 0)
                                {
                                    string html = "<table><tr><td >" + detailedProviderInfo.OfficeHours[startAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + "</td><td style='width:15%'></td><td ></td></tr></table>";

                                    hours.Time = html;
                                }
                                else if (detailedProviderInfo.OfficeHours[endAm].OfficeTimeSlot.Trim().Length > 0)
                                {
                                    string html = "<table ><tr><td ></td><td style='width:15%'></td><td >" + detailedProviderInfo.OfficeHours[endAm].OfficeTimeSlot + VariableConstant.StartTimeInAM + "</td></tr></table>";

                                    hours.Time = html;

                                }
                            }




                            if (detailedProviderInfo.OfficeHours[startPm].OfficeTimeSlot.Trim().Length > 0 && detailedProviderInfo.OfficeHours[endPm].OfficeTimeSlot.Length > 0)
                            {
                                //hours.TimePM = detailedProviderInfo.OfficeHours[startPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + " - " + detailedProviderInfo.OfficeHours[endPm].OfficeTimeSlot + VariableConstant.EndTimeInPM ;
                                string html = "<table ><tr><td >" + detailedProviderInfo.OfficeHours[startPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td><td style='width:15%'>-</td><td >" + detailedProviderInfo.OfficeHours[endPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td></tr></table>";

                                hours.TimePM = html;
                            }
                            else
                            {
                                if (detailedProviderInfo.OfficeHours[startPm].OfficeTimeSlot.Trim().Length > 0)
                                {
                                    //hours.TimePM ="      "+  detailedProviderInfo.OfficeHours[startPm].OfficeTimeSlot + VariableConstant.EndTimeInPM  ;
                                    string html = "<table ><tr><td >" + detailedProviderInfo.OfficeHours[startPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td><td style='width:15%'></td><td ></td></tr></table>";

                                    hours.TimePM = html;
                                }
                                else if (detailedProviderInfo.OfficeHours[endPm].OfficeTimeSlot.Trim().Length > 0)
                                {
                                    //hours.TimePM ="               " +  detailedProviderInfo.OfficeHours[endPm].OfficeTimeSlot + VariableConstant.EndTimeInPM;
                                    string html = "<table ><tr><td ></td><td style='width:15%'></td><td >" + detailedProviderInfo.OfficeHours[endPm].OfficeTimeSlot + VariableConstant.EndTimeInPM + "</td></tr></table>";

                                    hours.TimePM = html;
                                }
                            }



                            hoursList.Add(hours);
                            startAm = startAm + 4;
                            endAm = endAm + 4;
                            startPm = startPm + 4;
                            endPm = endPm + 4;
                        }
                    }
                }

                providerDetailsModel.ProviderData = detailedProviderInfo;
                providerDetailsModel.ProviderData.OtherOfficeLocations = GetPrimaryAddress.GetAddressForProvider(detailedProviderInfo, providerNumberIndex);

                providerDetailsModel.LocationId = providerNumberIndex[1].Replace("-", "/");
                providerDetailsModel.TaxId = providerNumberIndex[2];


                searchResultViewModel.SearchRequest = searchRequest;

                UserPhoneNumber UserPhoneNumber = new UserPhoneNumber();
                UserPhoneNumber.ListCarrier = contentManager.GetCarrierInfoLocateProvider(requestForProviderDetails).ToList();

                SendProviderDetails sendProviderDetails = new SendProviderDetails();
                sendProviderDetails.UserPhoneNumber = UserPhoneNumber;
                searchResultViewModel.SendProviderDetails = sendProviderDetails;
                searchResultViewModel.Hours = hoursList;
                searchResultViewModel.ProviderDetails = providerDetailsModel;
                searchResultViewModel.PublicKey = AppSettingHelper.GetAppSettingValue(VariableConstant.PublicKey);
                searchResultViewModel.GoogleRecaptchaAPIAddressMultiple = AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleApiAddressMultiple);
                //SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.GetDetailedProviderInfoAction);
                if (searchRequest.State != null)
                {
                    searchResultViewModel.SearchByStateCityCounty = true;
                }


                if (detailedProviderInfo.OtherOfficeLocations != null)
                {

                    if ((searchRequest.ProviderType.ProviderTypeName.ToUpper() == "HOSPITAL") && (detailedProviderInfo.OtherOfficeLocations[0].State.ToUpper() == "GA" || detailedProviderInfo.OtherOfficeLocations[0].State.ToUpper() == "TX"))
                    {
                        if (detailedProviderInfo.OtherOfficeLocations[0].State.ToUpper() == "TX")
                        {
                            if (detailedProviderInfo.GATXSpecialty != null || detailedProviderInfo.GATXSpecialty.Count() != 0)
                            {
                                foreach (var i in detailedProviderInfo.GATXSpecialty)
                                {
                                    //get Associate Provider
                                    var facilityProvider = GetTXFacilityProviders(i.SpecilityID, providerNumber);
                                    i.AssociateProvider = facilityProvider.Count() == 0 ? false : true;
                                }
                            }
                        }
                        searchResultViewModel.GATXSpecialty = detailedProviderInfo.GATXSpecialty;
                        Session[SessionConstant.HospitalName] = detailedProviderInfo.PracticeName;

                    }
                }
                traceLog.AppendLine(" & End: LocateProviderController, GetDetailedProviderInfo Method");
                return PartialView("~/Views/Shared/LocateProvider/_ProviderDetailsPage.cshtml", searchResultViewModel);

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// Renders My list page
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult TaggedProviders()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, TaggedProviders Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, TaggedProviders Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, TaggedProviders Method");
                        return RedirectToAction(ApplicationConstants.CustomPage);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, TaggedProviders Method");
                        return RedirectToAction(ApplicationConstants.SelectNetworkTypeAction);
                    }
                }
                List<string> taggedProviders = null;
                if (Session[SessionConstant.TaggedProvider] != null)
                {
                    taggedProviders = Session[SessionConstant.TaggedProvider] as List<string>;
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, TaggedProviders Method");
                    return RedirectToAction(ApplicationConstants.LocateProviderSearchResultAction);
                }
                LocateProviderSearchResultViewModel locateProviderSearchResultViewModel = new LocateProviderSearchResultViewModel();
                SortingPagingInfo sortingPagingInfo = new SortingPagingInfo();
                sortingPagingInfo.SortField = AppSettingHelper.GetAppSettingValue(VariableConstant.SortField);
                sortingPagingInfo.SortDirection = AppSettingHelper.GetAppSettingValue(VariableConstant.SortDirection);
                SearchResult searchResult = GetTaggedProviders();
                if (searchResult != null)
                {

                    if (Session[SessionConstant.TaggedSortingPagingInfo] != null)
                    {
                        sortingPagingInfo = Session[SessionConstant.TaggedSortingPagingInfo] as SortingPagingInfo;
                        sortingPagingInfo.TotalRecords = searchResult.ProviderMatchCount;
                        searchResult.Providers = GetTaggedProvidersList(searchResult, sortingPagingInfo).Providers;
                    }
                    else
                    {
                        searchResult.Providers = searchResult.Providers.OrderBy(o => o.ProviderPrimaryAddress.ProviderDistance).ToList();
                        searchResult.Providers = searchResult.Providers.Skip(0).Take(20).ToList();
                        sortingPagingInfo.CurrentPageIndex = 0;
                        sortingPagingInfo.PageSize = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    }
                    locateProviderSearchResultViewModel.SearchResult = searchResult;
                    sortingPagingInfo.TotalRecords = searchResult.ProviderMatchCount;
                    sortingPagingInfo.PageCount = (Convert.ToInt32(locateProviderSearchResultViewModel.SearchResult.ProviderMatchCount) / 20) + 1;
                    ViewBag.SortingPagingInfo = sortingPagingInfo;
                    locateProviderSearchResultViewModel.SearchResult.ProviderMatchCount = locateProviderSearchResultViewModel.SearchResult.Providers.Count();
                    locateProviderSearchResultViewModel.SearchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                    locateProviderSearchResultViewModel.TaggedProviderNumbers = taggedProviders;
                    locateProviderSearchResultViewModel.TaggedProvidersCount = (taggedProviders == null) ? 0 : taggedProviders.Count;
                    locateProviderSearchResultViewModel.ProvidersForComparison = Session[SessionConstant.TaggedComparedProvider] as List<CompareProvider>;
                    SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.TaggedProvidersAction);
                    traceLog.AppendLine(" & End: LocateProviderController, TaggedProviders Method");
                    return View(locateProviderSearchResultViewModel);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, TaggedProviders Method");
                    return RedirectToAction(ApplicationConstants.LocateProviderSearchAction, ApplicationConstants.LocateProviderController);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Create tagged provider's details
        /// </summary>
        /// <param name="searchResult"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        [NoCache]
        public SearchResult GetTaggedProvidersList(SearchResult searchResult, SortingPagingInfo info)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetTaggedProvidersList Method with Param searchResult: " + searchResult + "and with Param info: " + info);
                if (searchResult == null || info == null)
                    throw new ArgumentNullException(VariableConstant.SearchResult);
                info = Session[SessionConstant.TaggedSortingPagingInfo] as SortingPagingInfo;
                string firstName = AppSettingHelper.GetAppSettingValue(VariableConstant.FirstName);
                string sortDirectionDesc = VariableConstant.Descending;
                string sortDirectionAsc = AppSettingHelper.GetAppSettingValue(VariableConstant.SortDirection);
                string sortFieldDistance = AppSettingHelper.GetAppSettingValue(VariableConstant.SortField);
                string sortFieldSpecialty = AppSettingHelper.GetAppSettingValue(VariableConstant.SpecialtyName);
                string sortCity = AppSettingHelper.GetAppSettingValue(VariableConstant.CityName);
                if (info.SortField == firstName && info.SortDirection == sortDirectionDesc)
                {
                    searchResult.Providers = searchResult.Providers.OrderByDescending(o => o.ProviderName.LastName).ToList();

                }
                else if (info.SortField == firstName && info.SortDirection == sortDirectionAsc)
                {
                    searchResult.Providers = searchResult.Providers.OrderBy(o => o.ProviderName.LastName).ToList();

                }
                else if (info.SortField == sortFieldDistance && info.SortDirection == sortDirectionDesc)
                {
                    searchResult.Providers = searchResult.Providers.OrderByDescending(o => o.ProviderPrimaryAddress.ProviderDistance).ToList();

                }
                else if (info.SortField == sortFieldDistance && info.SortDirection == sortDirectionAsc)
                {
                    searchResult.Providers = searchResult.Providers.OrderBy(o => o.ProviderPrimaryAddress.ProviderDistance).ToList();

                }
                else if (info.SortField == sortFieldSpecialty && info.SortDirection == sortDirectionDesc)
                {
                    searchResult.Providers = searchResult.Providers.OrderByDescending(o => o.Speciality.SpecialtyName).ToList();

                }
                else if (info.SortField == sortFieldSpecialty && info.SortDirection == sortDirectionAsc)
                {
                    searchResult.Providers = searchResult.Providers.OrderBy(o => o.Speciality.SpecialtyName).ToList();

                }

                else if (info.SortField == sortCity && info.SortDirection == sortDirectionAsc)
                {
                    searchResult.Providers = searchResult.Providers.OrderBy(o => o.ProviderPrimaryAddress.CITY).ToList();

                }
                else if (info.SortField == sortCity && info.SortDirection == sortDirectionDesc)
                {
                    searchResult.Providers = searchResult.Providers.OrderByDescending(o => o.ProviderPrimaryAddress.CITY).ToList();

                }

                searchResult.Providers = searchResult.Providers.Skip(info.CurrentPageIndex * info.PageSize).Take(info.PageSize).ToList();
                traceLog.AppendLine(" & End: LocateProviderController, GetTaggedProvidersList Method");
                return searchResult;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Renders create directory page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ValidateInput(false)]
        [NoCache]
        public ActionResult CreateDirectory()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, CreateDirectory Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, CreateDirectory Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                if (searchRequest != null)
                {
                    if (!new CommonHelper().Validate(searchRequest))
                    {
                        throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                    }
                    CreateDirectoryViewModel objCreateDirectoryViewModel = new CreateDirectoryViewModel();

                    List<DirectoryType> objListDirectoryType = new List<DirectoryType>();
                    objListDirectoryType.Add(new DirectoryType() { DirectoryTypeId = ApplicationConstants.MyList, DirectoryTypeName = Resources.lblMyList });
                    objListDirectoryType.Add(new DirectoryType() { DirectoryTypeId = ApplicationConstants.SearchResult, DirectoryTypeName = Resources.lblSearchResults });


                    List<DirectoryCreationType> objListDirectoryCreationType = new List<DirectoryCreationType>();

                    objListDirectoryCreationType.Add(new DirectoryCreationType() { CreationId = ApplicationConstants.Email, CreationName = Resources.lblEmailDirectory });
                    objListDirectoryCreationType.Add(new DirectoryCreationType() { CreationId = ApplicationConstants.Pdf, CreationName = Resources.lblDownloadPDF });

                    objCreateDirectoryViewModel.DirectoryTypeList = objListDirectoryType;
                    objCreateDirectoryViewModel.DirectoryCreationTypeList = objListDirectoryCreationType;

                    objCreateDirectoryViewModel.SearchRequest = searchRequest;

                    var objIncludedItemsList = new List<IncludedItem>
                {
                     new IncludedItem{Id = 1, Name = Resources.lblTableOfContents, Checked = true},
                     new IncludedItem{Id = 2, Name = Resources.lblIndex, Checked = true}
                };
                    int numberOfProviders = 0;
                    SortingPagingInfo info = new SortingPagingInfo();
                    if (Session[SessionConstant.SortingPagingInfo] != null)
                    {
                        info = Session[SessionConstant.SortingPagingInfo] as SortingPagingInfo;
                        numberOfProviders = info.TotalRecords;

                    }
                    int minimumProviders = AppSettingHelper.ReturnValue(VariableConstant.MinimumProviders);
                    if (numberOfProviders > minimumProviders)
                    {
                        objCreateDirectoryViewModel.MoreProviders = true;
                    }
                    else
                    {
                        objCreateDirectoryViewModel.MoreProviders = false;
                    }
                    objCreateDirectoryViewModel.RecaptchaPublicKey = AppSettingHelper.GetAppSettingValue(VariableConstant.PublicKey);
                    objCreateDirectoryViewModel.GoogleRecaptchaAPIAddressSingle = AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleAPIAddress);
                    objCreateDirectoryViewModel.IncludeTOC = true;
                    objCreateDirectoryViewModel.IncludeIndex = true;
                    objCreateDirectoryViewModel.IncludedItemsList = objIncludedItemsList;
                    SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.CreateDirectoryAction);
                    traceLog.AppendLine(" & End: LocateProviderController, CreateDirectory Method");
                    return View(objCreateDirectoryViewModel);
                }
                else
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, CreateDirectory Method");
                        return RedirectToAction(ApplicationConstants.CustomPage);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, CreateDirectory Method");
                        return RedirectToAction(ApplicationConstants.SelectNetworkTypeAction);
                    }

                }


            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// Renders pdf for stae disclaimers
        /// </summary>
        /// <param name="stateDisclaimersCode"></param>
        /// <returns></returns>
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public ActionResult GetDisclaimersPdf(string stateDisclaimersCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetDisclaimersPdf Method with Param stateDisclaimersCode: " + stateDisclaimersCode);
                if (stateDisclaimersCode == null)
                    throw new ArgumentNullException(VariableConstant.StateDisclaimersCode);
                MemoryStream workStream = new MemoryStream();
                if (!CommonHelper.ValidDisclaimersId(stateDisclaimersCode))
                    throw new ArgumentNullException(VariableConstant.StateDisclaimersCode);
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                ManageContent omngcontent = new ManageContent();
                request.Functionality = AppSettingHelper.GetAppSettingValue(VariableConstant.StateDisclaimerKey);
                List<StateDisclaimerEntity> stateDisclaimerList = omngcontent.GetStateDisclaimers(request).ToList();

                byte[] pdfByte = null;
                string fileName = string.Empty;
                string fileType = string.Empty;
                if (stateDisclaimerList != null && stateDisclaimerList.Count > 0)
                {
                    foreach (var item in stateDisclaimerList)
                    {
                        if (item.Id == Convert.ToInt32(stateDisclaimersCode.Trim(), CultureInfo.InvariantCulture))
                        {
                            pdfByte = item.FileContent;
                            fileName = item.FileName + "." + item.FileType;
                            fileType = item.FileType;
                            break;
                        }
                    }
                    var cd = new System.Net.Mime.ContentDisposition
                    {
                        FileName = fileName,
                        Inline = false,
                    };

                    if (fileType.ToUpper().Trim() == "PDF")
                        cd.Inline = true;

                    Response.AppendHeader("Content-Disposition", cd.ToString());
                    traceLog.AppendLine(" & End: LocateProviderController, GetDisclaimersPdf Method");
                    return File(pdfByte, "application/" + fileType);

                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetDisclaimersPdf Method");
                    return null;
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }


        /// <summary>
        /// Renders pdf for state EN disclaimers
        /// </summary>
        /// <param name="stateDisclaimersCode"></param>
        /// <returns></returns>
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public ActionResult GetDisclaimersPdfES(string stateDisclaimersCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetDisclaimersPdfES Method with Param stateDisclaimersCode: " + stateDisclaimersCode);
                if (stateDisclaimersCode == null)
                    throw new ArgumentNullException(VariableConstant.StateDisclaimersCode);
                MemoryStream workStream = new MemoryStream();
                if (!CommonHelper.ValidDisclaimersId(stateDisclaimersCode))
                    throw new ArgumentNullException(VariableConstant.StateDisclaimersCode);

                RequestHeader request = new CommonHelper().GetRequestHeader("es-CR", 0);
                ManageContent omngcontent = new ManageContent();

                request.Functionality = AppSettingHelper.GetAppSettingValue(VariableConstant.StateDisclaimerKey);
                List<StateDisclaimerEntity> stateDisclaimerList = omngcontent.GetStateDisclaimers(request).ToList();

                byte[] pdfByte = null;
                string fileName = string.Empty;
                string fileType = string.Empty;
                if (stateDisclaimerList != null && stateDisclaimerList.Count > 0)
                {
                    foreach (var item in stateDisclaimerList)
                    {
                        if (item.Id == Convert.ToInt32(stateDisclaimersCode.Trim(), CultureInfo.InvariantCulture))
                        {
                            pdfByte = item.FileContent;
                            fileName = item.FileName + "." + item.FileType;
                            fileType = item.FileType;
                            break;
                        }
                    }
                    var cd = new System.Net.Mime.ContentDisposition
                    {
                        FileName = fileName,
                        Inline = false,
                    };
                    if (fileType.ToUpper().Trim() == "PDF")
                        cd.Inline = true;

                    Response.AppendHeader("Content-Disposition", cd.ToString());
                    traceLog.AppendLine(" & End: LocateProviderController, GetDisclaimersPdfES Method");
                    return File(pdfByte, "application/" + fileType);

                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetDisclaimersPdfES Method");
                    return null;
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// Renders pdf for state English disclaimers
        /// </summary>
        /// <param name="stateDisclaimersCode"></param>
        /// <returns></returns>
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public ActionResult GetDisclaimersPdfEn(string stateDisclaimersCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetDisclaimersPdfEn Method with Param stateDisclaimersCode: " + stateDisclaimersCode);
                if (stateDisclaimersCode == null)
                    throw new ArgumentNullException(VariableConstant.StateDisclaimersCode);
                MemoryStream workStream = new MemoryStream();
                if (!CommonHelper.ValidDisclaimersId(stateDisclaimersCode))
                    throw new ArgumentNullException(VariableConstant.StateDisclaimersCode);

                RequestHeader request = new CommonHelper().GetRequestHeader("en-us", 0);
                ManageContent omngcontent = new ManageContent();

                request.Functionality = AppSettingHelper.GetAppSettingValue(VariableConstant.StateDisclaimerKey);
                List<StateDisclaimerEntity> stateDisclaimerList = omngcontent.GetStateDisclaimers(request).ToList();

                byte[] pdfByte = null;
                string fileName = string.Empty;
                string fileType = string.Empty;
                if (stateDisclaimerList != null && stateDisclaimerList.Count > 0)
                {
                    foreach (var item in stateDisclaimerList)
                    {
                        if (item.Id == Convert.ToInt32(stateDisclaimersCode.Trim(), CultureInfo.InvariantCulture))
                        {
                            pdfByte = item.FileContent;
                            fileName = item.FileName + "." + item.FileType;
                            fileType = item.FileType;
                            break;
                        }
                    }
                    var cd = new System.Net.Mime.ContentDisposition
                    {
                        FileName = fileName,
                        Inline = false,
                    };
                    if (fileType.ToUpper().Trim() == "PDF")
                        cd.Inline = true;

                    Response.AppendHeader("Content-Disposition", cd.ToString());
                    traceLog.AppendLine(" & End: LocateProviderController, GetDisclaimersPdfEn Method");
                    return File(pdfByte, "application/" +fileType);

                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetDisclaimersPdfEn Method");
                    return null;
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }



        /// <summary>
        /// Renders my directory page for logged in user
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult MyDirectory()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, MyDirectory Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, MyDirectory Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                string userId = null;
                if ((UserDetails)Session[Constants.UserDetails] != null && ((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId.ToString();

                    MyDirectoryViewModel directoryModel = new MyDirectoryViewModel();
                    List<ProviderDirectory> directories = new List<ProviderDirectory>();
                    string culture = ReturnCultureInfo();
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                    ManageContent omngcontent = new ManageContent();
                    directories = omngcontent.GetDirectories(request, userId);
                    directoryModel.Directories = directories;
                    SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.MyDirectory);
                    traceLog.AppendLine(" & End: LocateProviderController, MyDirectory Method");
                    return View(directoryModel);
                }
                return RedirectToAction("SelectNetworkType", "LocateProvider");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// send the provider or map details
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult SendMailPage()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, SendMailPage Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, SendMailPage Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SendProviderDetails sendProviderDetails = new SendProviderDetails();
                sendProviderDetails = Session[SessionConstant.SendMail] as SendProviderDetails;
                if (sendProviderDetails == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, SendMailPage Method");
                    return RedirectToAction("SelectNetworkType");
                }
                sendProviderDetails.PublicKey = AppSettingHelper.GetAppSettingValue(VariableConstant.PublicKey);
                sendProviderDetails.GoogleRecaptchaAPIAddressSingle = AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleApiAddressSingle);
                SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.SendMailAction);
                traceLog.AppendLine(" & End: LocateProviderController, SendMailPage Method");
                return View(sendProviderDetails);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        #endregion

        #region Session
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public void ClearCriteria(SearchRequestEntity search)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, ClearCriteria Method with Param search: " + search);
                if (search != null)
                {
                    Session[SessionConstant.SearchRequest] = search;
                    Session[SessionConstant.RefineRequest] = search;
                }
                traceLog.AppendLine(" & End: LocateProviderController, ClearCriteria Method");

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Save Sorting Paging Informations To Session
        /// </summary>
        /// <param name="sortingPagingInfo"></param>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public void SaveSortingPagingInfoToSession(SortingPagingInfo sortingPagingInfo)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, SaveSortingPagingInfoToSession Method with Param sortingPagingInfo: " + sortingPagingInfo);
                Session[SessionConstant.SortingPagingInfo] = sortingPagingInfo;
                traceLog.AppendLine(" & End: LocateProviderController, SaveSortingPagingInfoToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Save Search Request To Session 
        /// </summary>
        /// <param name="search"></param>
        [AjaxValidateAntiForgeryToken]
        public void SaveSearchRequestToSession(SearchRequestEntity search)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, SaveSearchRequestToSession Method with Param search: " + search);
                if (search != null)
                {
                    //remove empty items from city list as third party dropdown-Semantic UI
                    //send blank values when no option selected
                    if (search.CityCodes != null)
                    {
                        if (search.CityCodes.Count == 1 && string.IsNullOrEmpty(search.CityCodes[0]))
                        {
                            search.CityCodes = null;
                        }
                    }
                    //remove empty items from county list as third party dropdown-Semantic UI
                    //send blank values when no option selected
                    if (search.CountyCodes != null)
                    {
                        if (search.CountyCodes.Count == 1 && string.IsNullOrEmpty(search.CountyCodes[0]))
                        {
                            search.CountyCodes = null;
                        }
                    }
                    //remove empty items from language list as third party dropdown-Semantic UI
                    //send blank values when no option selected
                    if (search.SpokenLanguages != null)
                    {
                        if (search.SpokenLanguages.Count == 1 && string.IsNullOrEmpty(search.SpokenLanguages[0]))
                        {
                            search.SpokenLanguages = null;
                        }
                    }
                    if (search.ConditionCodes != null && search.ConditionCodes.Count == 0)
                    {
                        search.ConditionCodes = null;
                    }
                    if (search.SpecialtyCodes != null && search.SpecialtyCodes.Count == 0)
                    {
                        search.SpecialtyCodes = null;
                    }
                    if (search.FocusCodes != null && search.FocusCodes.Count == 0)
                    {
                        search.FocusCodes = null;
                    }
                    //Saving customer type to session
                    if ((UserDetails)Session[Constants.UserDetails] != null && ((UserDetails)Session[Constants.UserDetails]).SelectedRole != null)
                    {
                        if (search.NetworkType.NetworkId == "3" && (search.NetworkType.NetworkName.ToLower() == "cofinity"
                                                                || (search.NetworkType.NetworkName.ToLower() == "client specific"
                                                                && search.ClientSpecificCode.ToUpper() == NABWebsite.DTO.Constants.CofinityClientSpecCode)))
                        {
                            // Allowing provider search for payer  
                            if (ConfigurationManager.AppSettings[Constants.PowerSTEPPSunset] == Constants.TrueId)
                            {
                                search.CustomerType = "Payer";
                            }
                            else
                            {
                                search.CustomerType = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                            }
                        }
                    }
                }

                Session[SessionConstant.TaggedSortingPagingInfo] = null;
                Session[SessionConstant.SortingPagingInfo] = null;
                Session[SessionConstant.SearchRequest] = search;
                traceLog.AppendLine(" & End: LocateProviderController, SaveSearchRequestToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Save Refine Request To Session
        /// </summary>
        /// <param name="search"></param>
        [AjaxValidateAntiForgeryToken]
        public void SaveRefineRequestToSession(SearchRequestEntity search)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, SaveRefineRequestToSession Method with Param search: " + search);
                if (search != null)
                {
                    //remove empty items from city list as third party dropdown-Semantic UI
                    //send blank values when no option selected
                    if (search.CityCodes != null)
                    {
                        if (search.CityCodes.Count == 1 && string.IsNullOrEmpty(search.CityCodes[0]))
                        {
                            search.CityCodes = null;
                        }
                    }
                    //remove empty items from county list as third party dropdown-Semantic UI
                    //send blank values when no option selected
                    if (search.CountyCodes != null)
                    {
                        if (search.CountyCodes.Count == 1 && string.IsNullOrEmpty(search.CountyCodes[0]))
                        {
                            search.CountyCodes = null;
                        }
                    }
                    //remove empty items from language list as third party dropdown-Semantic UI
                    //send blank values when no option selected
                    if (search.SpokenLanguages != null)
                    {
                        if (search.SpokenLanguages.Count == 1 && string.IsNullOrEmpty(search.SpokenLanguages[0]))
                        {
                            search.SpokenLanguages = null;
                        }
                    }
                }
                Session[SessionConstant.RefineRequest] = search;
                traceLog.AppendLine(" & End: LocateProviderController, SaveRefineRequestToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Remove Saved Search Request from Session
        /// </summary>
        /// <param name="action"></param>
        /// <param name="code"></param>
        [AjaxValidateAntiForgeryToken]
        public void RemoveSaveSearchRequestToSession(string action)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, RemoveSaveSearchRequestToSession Method with Param action: " + action);
                SearchRequestEntity searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                if (action == VariableConstant.Name)
                {
                    searchRequest.ProviderName = null;
                    searchRequest.ProviderNumber = null;

                }
                else if (action == VariableConstant.Gender)
                {
                    searchRequest.Gender = null;
                }
                else if (action == VariableConstant.Language)
                {
                    searchRequest.SpokenLanguages = null;
                }
                else if (action == VariableConstant.Specialty)
                {
                    searchRequest.SpecialtyCodes = null;

                }
                else if (action == VariableConstant.Condition)
                {
                    searchRequest.ConditionCodes = null;

                }
                else if (action == VariableConstant.Focus)
                {
                    searchRequest.FocusCodes = null;

                }
                else if (action == VariableConstant.Tin)
                {
                    searchRequest.Tin = null;
                }
                else if (action == VariableConstant.StreetName)
                {
                    searchRequest.RefineStreetname = null;
                }
                else if (action == VariableConstant.RefinePCP)
                {
                    searchRequest.RefinePCPOnly = null;
                }

                else if (action == VariableConstant.HospitalAccrediation)
                {
                    searchRequest.RefineHospitalAccrediation = null;
                }
                else if (action == VariableConstant.BoardCetified)
                {
                    searchRequest.RefineBoardCertified = null;
                }
                else if (action == VariableConstant.ADAAccessible)
                {
                    searchRequest.RefineADAAccessible = null;
                }
                else if (action == VariableConstant.ECP)
                {
                    searchRequest.ECPCodes = null;
                }
                else if (action == VariableConstant.AcceptingNewPatients)
                {
                    searchRequest.AcceptingNewPatients = null;
                }
                else if (action == VariableConstant.PracticeName)
                {
                    searchRequest.RefinePracticename = null;
                }
                else if (action == VariableConstant.HospitalAffiliation)
                {
                    searchRequest.RefineHospitalAffiliation = null;
                }
                else if (action == VariableConstant.Phone)
                {
                    searchRequest.ProviderPhNo = null;
                }
                else if (action == VariableConstant.License)
                {
                    searchRequest.ProviderMedicalLicNo = null;
                }
                else if (action == VariableConstant.NPI)
                {
                    searchRequest.ProviderNPI = null;
                }
                else if (action == VariableConstant.All)
                {
                    if (searchRequest.ConditionCodes != null)
                    {
                        searchRequest.ConditionCodes = null;
                    }
                    if (searchRequest.SpecialtyCodes != null)
                    {
                        searchRequest.SpecialtyCodes = null;
                    }
                    if (searchRequest.FocusCodes != null)
                    {
                        searchRequest.FocusCodes = null;
                    }

                    if (!string.IsNullOrEmpty(searchRequest.ProviderName))
                    {
                        searchRequest.ProviderName = null;
                    }
                    if (!string.IsNullOrEmpty(searchRequest.ProviderNumber))
                    {
                        searchRequest.ProviderNumber = null;
                    }
                    if (string.IsNullOrEmpty(searchRequest.Tin))
                    {
                        searchRequest.Tin = null;
                    }
                    if (searchRequest.SpokenLanguages != null)
                    {
                        searchRequest.SpokenLanguages = null;
                    }
                    if (searchRequest.Gender != null)
                    {
                        searchRequest.Gender = null;
                    }
                    if (!string.IsNullOrEmpty(searchRequest.RefineStreetname))
                    {
                        searchRequest.RefineStreetname = null;
                    }
                    if (searchRequest.RefinePCPOnly != null)
                    {
                        searchRequest.RefinePCPOnly = null;
                    }
                    if (searchRequest.RefineHospitalAccrediation != null)
                    {
                        searchRequest.RefineHospitalAccrediation = null;
                    }
                    if (searchRequest.RefineBoardCertified != null)
                    {
                        searchRequest.RefineBoardCertified = null;
                    }
                    if (searchRequest.AcceptingNewPatients != null)
                    {
                        searchRequest.AcceptingNewPatients = null;
                    }
                    if (!string.IsNullOrEmpty(searchRequest.RefinePracticename))
                    {
                        searchRequest.RefinePracticename = null;
                    }
                    if (!string.IsNullOrEmpty(searchRequest.RefineHospitalAffiliation))
                    {
                        searchRequest.RefineHospitalAffiliation = null;
                    }
                    if (searchRequest.ECPCodes != null)
                    {
                        searchRequest.ECPCodes = null;
                    }
                    if (searchRequest.ProviderPhNo != null)
                    {
                        searchRequest.ProviderPhNo = null;
                    }
                    if (searchRequest.ProviderMedicalLicNo != null)
                    {
                        searchRequest.ProviderMedicalLicNo = null;
                    }
                    if (searchRequest.ProviderNPI != null)
                    {
                        searchRequest.ProviderNPI = null;
                    }
                }

                Session[SessionConstant.RefineRequest] = searchRequest;
                traceLog.AppendLine(" & End: LocateProviderController, RemoveSaveSearchRequestToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// remove saved compare providers from session
        /// </summary>
        /// <param name="action"></param>
        [AjaxValidateAntiForgeryToken]
        public void RemoveCompareProvidersFromSession(string action)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, RemoveCompareProvidersFromSession Method with Param action: " + action);
                if (action == VariableConstant.All)
                {
                    List<CompareProvider> comparedProviders = Session[SessionConstant.ComparedProvider] as List<CompareProvider>;
                    comparedProviders.Clear();
                }
                traceLog.AppendLine(" & End: LocateProviderController, RemoveCompareProvidersFromSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [AjaxValidateAntiForgeryToken]
        public void RemoveTaggedCompareProvidersFromSession(string action)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, RemoveTaggedCompareProvidersFromSession Method with Param action: " + action);
                if (action == VariableConstant.All)
                {
                    List<CompareProvider> comparedProviders = Session[SessionConstant.TaggedComparedProvider] as List<CompareProvider>;
                    comparedProviders.Clear();
                }
                traceLog.AppendLine(" & End: LocateProviderController, RemoveTaggedCompareProvidersFromSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Storing tagged providers in session
        /// </summary>
        /// <param name="providerNumber"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult ManageTaggedProviders(string providerNumber)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, ManageTaggedProviders Method with Param providerNumber: " + providerNumber);
                List<string> taggedProviders = null;
                if (Session[SessionConstant.TaggedProvider] != null)
                {
                    taggedProviders = Session[SessionConstant.TaggedProvider] as List<string>;
                }
                if (taggedProviders == null || taggedProviders.Count < 1)
                {
                    taggedProviders = new List<string>();
                    taggedProviders.Add(providerNumber);
                    Session[SessionConstant.TaggedProvider] = taggedProviders;
                }
                else
                {
                    if (taggedProviders.Exists(x => x == providerNumber))
                    {
                        taggedProviders.Remove(providerNumber);
                        Session[SessionConstant.TaggedProvider] = taggedProviders;
                    }
                    else
                    {
                        taggedProviders.Add(providerNumber);
                        Session[SessionConstant.TaggedProvider] = taggedProviders;
                    }
                }
                traceLog.AppendLine(" & End: LocateProviderController, ManageTaggedProviders Method");
                return Json(taggedProviders.Count);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }



        /// <summary>
        /// Fetches count of compare provider list
        /// </summary>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetComparedProvidersCount()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetComparedProvidersCount Method");
                int compareCount = 0;
                List<CompareProvider> comparedProviders = Session[SessionConstant.ComparedProvider] as List<CompareProvider>;
                if (comparedProviders != null)
                {
                    compareCount = comparedProviders.Count();
                }
                traceLog.AppendLine(" & End: LocateProviderController, GetComparedProvidersCount Method");
                return Json(compareCount);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// fetches count of tagged compared providers list
        /// </summary>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetTaggedComparedProvidersCount()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetTaggedComparedProvidersCount Method");
                int compareCount = 0;
                List<CompareProvider> comparedProviders = Session[SessionConstant.TaggedComparedProvider] as List<CompareProvider>;
                if (comparedProviders != null)
                {
                    compareCount = comparedProviders.Count();
                }
                traceLog.AppendLine(" & End: LocateProviderController, GetTaggedComparedProvidersCount Method");
                return Json(compareCount);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Storing comapred providers in session
        /// </summary>
        /// <param name="compareProvider"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult ManageComparedProviders(CompareProvider compareProvider)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, ManageComparedProviders Method with Param compareProvider: " + compareProvider);
                char[] splitchar = { '_' };
                string providerNumber = string.Empty;
                string locationId = string.Empty;
                string taxId = string.Empty;
                string numberLocationIdTaxId = string.Empty;
                string providerId = string.Empty;
                string providerName = string.Empty;
                List<CompareProvider> comparedProviders = Session[SessionConstant.ComparedProvider] as List<CompareProvider>;
                if (compareProvider != null)
                {
                    providerNumber = compareProvider.ProviderNumber.Split(splitchar)[0];
                    locationId = compareProvider.ProviderNumber.Split(splitchar)[1];
                    taxId = compareProvider.ProviderNumber.Split(splitchar)[2];
                    numberLocationIdTaxId = compareProvider.ProviderNumber;
                    providerId = compareProvider.ProviderType.ProviderTypeId.ToString();
                    providerName = compareProvider.ProviderType.ProviderTypeName;

                    compareProvider.ProviderNumber = providerNumber;
                    compareProvider.LocationId = locationId;
                    compareProvider.TaxId = taxId;
                    compareProvider.NumberLocationIdTaxId = numberLocationIdTaxId;
                    compareProvider.ProviderType.ProviderTypeId = Convert.ToInt16(providerId, CultureInfo.CurrentCulture);
                    compareProvider.ProviderType.ProviderTypeName = providerName;

                }
                if (comparedProviders == null || comparedProviders.Count < 1)
                {
                    comparedProviders = new List<CompareProvider>();
                    comparedProviders.Add(compareProvider);
                    Session[SessionConstant.ComparedProvider] = comparedProviders;
                }
                else
                {
                    if (comparedProviders.Exists(x => x.ProviderType.ProviderTypeId == compareProvider.ProviderType.ProviderTypeId))
                    {
                        if (comparedProviders.Exists(x => x.NumberLocationIdTaxId == compareProvider.NumberLocationIdTaxId))
                        {
                            comparedProviders.RemoveAll(x => x.NumberLocationIdTaxId == compareProvider.NumberLocationIdTaxId);
                            Session[SessionConstant.ComparedProvider] = comparedProviders;
                        }

                        else
                        {
                            if (comparedProviders.Count >= 0 && comparedProviders.Count <= 2)
                            {
                                comparedProviders.Add(compareProvider);
                                Session[SessionConstant.ComparedProvider] = comparedProviders;
                            }
                            else
                            {
                                traceLog.AppendLine(" & End: LocateProviderController, ManageComparedProviders Method");
                                return Json(VariableConstant.ReturnStringFalse);
                            }
                        }

                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, ManageComparedProviders Method");
                        return Json(VariableConstant.NotCompared);
                    }
                }
                traceLog.AppendLine(" & End: LocateProviderController, ManageComparedProviders Method");
                return Json(VariableConstant.ReturnTrue);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// storing tagged compared providers to session
        /// </summary>
        /// <param name="compareProvider"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult ManageTaggedComparedProviders(CompareProvider compareProvider)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, ManageTaggedComparedProviders Method with Param compareProvider: " + compareProvider);
                char[] splitchar = { '_' };
                string providerNumber = string.Empty;
                string locationId = string.Empty;
                string taxId = string.Empty;
                string numberLocationIdTaxId = string.Empty;
                string providerId = string.Empty;
                string providerName = string.Empty;
                List<CompareProvider> comparedProviders = Session[SessionConstant.TaggedComparedProvider] as List<CompareProvider>;
                if (compareProvider != null)
                {
                    providerNumber = compareProvider.ProviderNumber.Split(splitchar)[0];
                    locationId = compareProvider.ProviderNumber.Split(splitchar)[1];
                    taxId = compareProvider.ProviderNumber.Split(splitchar)[2];
                    numberLocationIdTaxId = compareProvider.ProviderNumber;
                    providerId = compareProvider.ProviderType.ProviderTypeId.ToString();
                    providerName = compareProvider.ProviderType.ProviderTypeName;

                    compareProvider.ProviderNumber = providerNumber;
                    compareProvider.LocationId = locationId;
                    compareProvider.TaxId = taxId;
                    compareProvider.NumberLocationIdTaxId = numberLocationIdTaxId;
                    compareProvider.ProviderType.ProviderTypeId = Convert.ToInt16(providerId, CultureInfo.CurrentCulture);
                    compareProvider.ProviderType.ProviderTypeName = providerName;

                }
                if (comparedProviders == null || comparedProviders.Count < 1)
                {
                    comparedProviders = new List<CompareProvider>();
                    comparedProviders.Add(compareProvider);
                    Session[SessionConstant.TaggedComparedProvider] = comparedProviders;
                }
                else
                {
                    if (comparedProviders.Exists(x => x.ProviderType.ProviderTypeId == compareProvider.ProviderType.ProviderTypeId))
                    {
                        if (comparedProviders.Exists(x => x.NumberLocationIdTaxId == compareProvider.NumberLocationIdTaxId))
                        {
                            comparedProviders.RemoveAll(x => x.NumberLocationIdTaxId == compareProvider.NumberLocationIdTaxId);
                            Session[SessionConstant.TaggedComparedProvider] = comparedProviders;
                        }

                        else
                        {
                            if (comparedProviders.Count >= 0 && comparedProviders.Count <= 2)
                            {
                                comparedProviders.Add(compareProvider);
                                Session[SessionConstant.TaggedComparedProvider] = comparedProviders;
                            }
                            else
                            {
                                traceLog.AppendLine(" & End: LocateProviderController, ManageTaggedComparedProviders Method");
                                return Json(VariableConstant.ReturnStringFalse);
                            }
                        }

                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, ManageTaggedComparedProviders Method");
                        return Json(VariableConstant.NotCompared);
                    }
                }
                traceLog.AppendLine(" & End: LocateProviderController, ManageTaggedComparedProviders Method");
                return Json(VariableConstant.ReturnTrue);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [AjaxValidateAntiForgeryToken]
        public void SendMailPageSession(SendProviderDetails sendProviderDetails)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, SendMailPageSession Method with Param sendProviderDetails: " + sendProviderDetails);
                Session[SessionConstant.SendMail] = sendProviderDetails;
                traceLog.AppendLine(" & End: LocateProviderController, SendMailPageSession Method");
                //return Json(VariableConstant.ReturnTrue);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion

        #region HelperMethods

        /// <summary>
        /// Send email for compared providers
        /// </summary>
        /// <param name="email"></param>
        /// <param name="providerCount"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult EmailComparisonLocateProvider(string email, string providerCount, string captcha)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, EmailComparisonLocateProvider Method with Param email: " + email + "and with Param providerCount: " + providerCount + "and with Param captcha: " + captcha);
                string errorMessage = string.Empty;
                if (!ValidateCaptcha(captcha, out errorMessage))
                {
                    traceLog.AppendLine(" & End: LocateProviderController, EmailComparisonLocateProvider Method");
                    return Json(errorMessage);
                }
                else
                {
                    if (!CommonHelper.ValidateEmail(email))
                    {
                        throw new System.Exception(ExceptionMessageConstant.Email);
                    }
                    List<string> emailAddressesList = new List<string>();
                    if (!string.IsNullOrEmpty(email)) emailAddressesList.Add(email);
                    string[] emailAddresses = emailAddressesList.ToArray();
                    SearchRequestEntity searchRequest = new SearchRequestEntity();
                    searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                    if (searchRequest == null)
                    {
                        TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                        if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                        {
                            //Fixed Checkmarx issue of XSHM on dated 24-Sep-2018
                            string consonant = "a0b1c2d3e4f5g6h7i8j9klmnopqrstvuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

                            int length2 = CommonHelper.GetSecureRandom(1, 62);
                            this.Response.Redirect("https://" + AppSettingHelper.GetAppSettingValue("CustomHOSTURL") + "?r=" + consonant.Substring(length2, 1));
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: LocateProviderController, EmailComparisonLocateProvider Method");
                            return Json("sessionTimeOut");
                        }
                    }
                    if (!new CommonHelper().Validate(searchRequest))
                    {
                        throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                    }
                    int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);

                    CompareProviderViewModel objCompareproviderViewModel = new CompareProviderViewModel();
                    ManageContent contentManager = new ManageContent();
                    List<CompareProvider> comparedProviders = Session[SessionConstant.ComparedProvider] as List<CompareProvider>;

                    List<ProviderDataForComparison> objCompareList = new List<ProviderDataForComparison>();
                    List<ProviderSelector> pList = new List<ProviderSelector>();
                    foreach (var item in comparedProviders)
                    {
                        ProviderSelector obj = new ProviderSelector();
                        obj.ProvLocationID = item.LocationId;
                        obj.ProvNum = item.ProviderNumber;
                        obj.ProvTaxId = item.TaxId;

                        pList.Add(obj);
                    }
                    string culture = ReturnCultureInfo();
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, networkId);
                    objCompareList = contentManager.CompareProviders(pList, searchRequest.ZipCode, request).ToList();
                    List<ProviderDataForComparison> tempSearch = new List<ProviderDataForComparison>();
                    for (int i = 0; i < comparedProviders.Count; i++)
                    {
                        foreach (var item in objCompareList)
                        {
                            if (item.ProvLocationID.Trim().Equals(comparedProviders[i].LocationId.Replace("-", "/").Trim()) &&
                                item.ProvTaxId.Trim().Equals(comparedProviders[i].TaxId.Trim()) && item.ProviderNumber.Trim().Equals(comparedProviders[i].ProviderNumber.Trim()))
                            {
                                tempSearch.Add(item);
                            }

                        }
                    }
                    foreach (var item in tempSearch)
                    {
                        objCompareproviderViewModel.ListProviderDataForComparison.Add(item);
                    }
                    string body = string.Empty;
                    if (providerCount == AppSettingHelper.GetAppSettingValue(VariableConstant.TwoProviders))
                    {
                        body = CompareTwoProviders(tempSearch);
                    }
                    else if (providerCount == AppSettingHelper.GetAppSettingValue(VariableConstant.ThreeProviders))
                    {
                        body = CompareThreeProviders(tempSearch);
                    }

                    bool emailto = false;
                    emailto = contentManager.SendMail(body, emailAddresses, VariableConstant.ProviderCompareHeading);
                    traceLog.AppendLine(" & End: LocateProviderController, EmailComparisonLocateProvider Method");
                    return Json(emailto);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Send email for tagged compared providers
        /// </summary>
        /// <param name="email"></param>
        /// <param name="providerCount"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult EmailTaggedProvidersComparison(string email, string providerCount, string captcha)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, EmailTaggedProvidersComparison Method with Param email: " + email + "and with Param providerCount: " + providerCount + "and with Param captcha: " + captcha);
                string errorMessage = string.Empty;
                if (!ValidateCaptcha(captcha, out errorMessage))
                {
                    traceLog.AppendLine(" & End: LocateProviderController, EmailTaggedProvidersComparison Method");
                    return Json(errorMessage);
                }
                else
                {
                    if (!CommonHelper.ValidateEmail(email))
                    {
                        throw new System.Exception(ExceptionMessageConstant.Email);
                    }
                    List<string> emailAddressesList = new List<string>();
                    if (!string.IsNullOrEmpty(email)) emailAddressesList.Add(email);
                    string[] emailAddresses = emailAddressesList.ToArray();
                    SearchRequestEntity searchRequest = new SearchRequestEntity();
                    searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                    if (searchRequest == null)
                    {
                        TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;

                        if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                        {
                            //Fixed Checkmarx issue of XSHM on dated 24-Sep-2018
                            string consonant = "a0b1c2d3e4f5g6h7i8j9klmnopqrstvuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

                            int length2 = CommonHelper.GetSecureRandom(1, 62);
                            this.Response.Redirect("https://" + AppSettingHelper.GetAppSettingValue("CustomHOSTURL") + "?r=" + consonant.Substring(length2, 1));
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: LocateProviderController, EmailTaggedProvidersComparison Method");
                            return Json("sessionTimeOut");
                        }


                    }
                    if (!new CommonHelper().Validate(searchRequest))
                    {
                        throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                    }
                    int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);

                    CompareProviderViewModel objCompareproviderViewModel = new CompareProviderViewModel();
                    ManageContent contentManager = new ManageContent();
                    List<CompareProvider> comparedProviders = Session[SessionConstant.TaggedComparedProvider] as List<CompareProvider>;
                    List<ProviderDataForComparison> objCompareList = new List<ProviderDataForComparison>();
                    List<ProviderSelector> pList = new List<ProviderSelector>();
                    foreach (var item in comparedProviders)
                    {
                        ProviderSelector obj = new ProviderSelector();
                        obj.ProvLocationID = item.LocationId;
                        obj.ProvNum = item.ProviderNumber;
                        obj.ProvTaxId = item.TaxId;

                        pList.Add(obj);
                    }
                    string culture = ReturnCultureInfo();
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, networkId);
                    objCompareList = contentManager.CompareProviders(pList, searchRequest.ZipCode, request).ToList();
                    foreach (var item in objCompareList)
                    {
                        objCompareproviderViewModel.ListProviderDataForComparison.Add(item);
                    }
                    string body = string.Empty;
                    if (providerCount == AppSettingHelper.GetAppSettingValue(VariableConstant.TwoProviders))
                    {
                        body = CompareTwoProviders(objCompareList);
                    }
                    else if (providerCount == AppSettingHelper.GetAppSettingValue(VariableConstant.ThreeProviders))
                    {
                        body = CompareThreeProviders(objCompareList);
                    }

                    bool emailto = false;
                    emailto = contentManager.SendMail(body, emailAddresses, VariableConstant.ProviderCompareHeading);
                    traceLog.AppendLine(" & End: LocateProviderController, EmailTaggedProvidersComparison Method");
                    return Json(emailto);
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// generate body if there are two providers in compared list
        /// </summary>
        /// <param name="objCompareList"></param>
        /// <returns></returns>
        private string CompareTwoProviders(List<ProviderDataForComparison> objCompareList)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, CompareTwoProviders Method with Param objCompareList: " + objCompareList);
                CompareProviderViewModel objCompareproviderViewModel = new CompareProviderViewModel();
                if (objCompareList == null)
                    throw new ArgumentNullException(VariableConstant.CompareList, "objCompareList is null");
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                foreach (var item in objCompareList)
                {
                    objCompareproviderViewModel.ListProviderDataForComparison.Add(item);
                }
                string body = string.Empty;
                using (StreamReader reader = new StreamReader(Server.MapPath("~/Templates/LocateProviderEmail/CompareProviders.html")))
                {
                    body = reader.ReadToEnd();
                }
                
                if (searchRequest.ClientSpecificCode != null && searchRequest.ClientSpecificNetwork != null)
                {
                    body = body.Replace(EmailBodyConstant.NetworkType, searchRequest.ClientSpecificNetwork);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.NetworkType, searchRequest.NetworkType.NetworkName + " " + EmailBodyConstant.Network);
                }
                // }

                // Create headings for the email 
                body = CreateCompareProviderHeadings(body);

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderName1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderName1, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderAcceptNewPatient))
                {
                    body = body.Replace(EmailBodyConstant.AcceptNewPatient1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderAcceptNewPatient);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.AcceptNewPatient1, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderAddress))
                {
                    body = body.Replace(EmailBodyConstant.ProviderAddress1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderAddress);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderAddress1, VariableConstant.NotAvailable);
                }

                body = body.Replace(EmailBodyConstant.ProviderDistance1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderDistance.ToString(CultureInfo.CurrentCulture).Replace(',', '.') + " " + Resources.lblMiles);

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderHospitalName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderHospitalName1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderHospitalName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderHospitalName1, VariableConstant.NotAvailable);
                }


                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSpokenLanguage))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpokenLanguage1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSpokenLanguage);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpokenLanguage1, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderPhone))
                {
                    body = body.Replace(EmailBodyConstant.ProviderPhone1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderPhone);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderPhone1, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSpeciality))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpecialty1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSpeciality);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpecialty1, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderFocus))
                {
                    body = body.Replace(EmailBodyConstant.ProviderFocus1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderFocus);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderFocus1, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSex))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSex1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSex);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSex1, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderType.ProviderTypeName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderType1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderType.ProviderTypeName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderType1, VariableConstant.NotAvailable);
                }

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].FacilityPAR))
                {
                    string[] networkArr = objCompareproviderViewModel.ListProviderDataForComparison[0].FacilityPAR.Trim().Split(',');
                    String f = string.Empty;
                    int rating = 0;
                    foreach (var i in networkArr)
                    {
                        if (!string.IsNullOrEmpty(i))
                        {
                            var networkOpt = i.Split('|');
                            if (networkOpt[0].Trim().ToUpper() == "PAR")
                            {
                                rating += 1;
                                f += " In-Network " + networkOpt[1].Trim() +" " + Constants.BreakLine;
                            }
                            else if (networkOpt[0].Trim().ToUpper() == "NON-PAR")
                            {
                                f += " No In-Network " + networkOpt[1].Trim() + " " + Constants.BreakLine;
                            }
                        }
                    }
                    f += "<b>" + Resources.lblSurpriseBill + ": " + rating + "</b>";
                    body = body.Replace(EmailBodyConstant.GASurprisebillrating1, f);

                }
                else
                {
                    body = body.Replace(EmailBodyConstant.GASurprisebillrating1, VariableConstant.NotAvailable);
                }

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderPHOName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderPracticeName1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderPHOName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderPracticeName1, VariableConstant.NotAvailable);
                }

                //for second provider
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderName2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderName2, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderAcceptNewPatient))
                {
                    body = body.Replace(EmailBodyConstant.AcceptNewPatient2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderAcceptNewPatient);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.AcceptNewPatient2, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderAddress))
                {
                    body = body.Replace(EmailBodyConstant.ProviderAddress2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderAddress);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderAddress2, VariableConstant.NotAvailable);
                }

                body = body.Replace(EmailBodyConstant.ProviderDistance2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderDistance.ToString(CultureInfo.CurrentCulture).Replace(',', '.') + " " + Resources.lblMiles);

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderHospitalName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderHospitalName2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderHospitalName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderHospitalName2, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSpokenLanguage))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpokenLanguage2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSpokenLanguage);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpokenLanguage2, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderPhone))
                {
                    body = body.Replace(EmailBodyConstant.ProviderPhone2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderPhone);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderPhone2, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSpeciality))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpecialty2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSpeciality);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpecialty2, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderFocus))
                {
                    body = body.Replace(EmailBodyConstant.ProviderFocus2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderFocus);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderFocus2, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSex))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSex2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSex);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSex2, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderType.ProviderTypeName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderType2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderType.ProviderTypeName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderType2, VariableConstant.NotAvailable);
                }

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].FacilityPAR))
                {
                    string[] networkArr = objCompareproviderViewModel.ListProviderDataForComparison[1].FacilityPAR.Trim().Split(',');
                    String f = string.Empty;
                    int rating = 0;
                    foreach (var i in networkArr)
                    {
                        if (!string.IsNullOrEmpty(i))
                        {
                            var networkOpt = i.Split('|');
                            if (networkOpt[0].Trim().ToUpper() == "PAR")
                            {
                                rating += 1;
                                f += " In-Network " + networkOpt[1].Trim() + " " + Constants.BreakLine;
                            }
                            else if (networkOpt[0].Trim().ToUpper() == "NON-PAR")
                            {
                                f += " No In-Network " + networkOpt[1].Trim() + " " + Constants.BreakLine;
                            }
                        }
                    }
                    f += "<b>" + Resources.lblSurpriseBill + ": " + rating + "</b>";
                    body = body.Replace(EmailBodyConstant.GASurprisebillrating2, f);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.GASurprisebillrating2, VariableConstant.NotAvailable);
                }

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderPHOName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderPracticeName2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderPHOName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderPracticeName2, VariableConstant.NotAvailable);
                }

                traceLog.AppendLine(" & End: LocateProviderController, CompareTwoProviders Method");
                return body;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Create email body headdings 
        /// </summary>
        /// <param name="body"></param>
        /// <returns></returns>
        private string CreateCompareProviderHeadings(string body)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, CreateCompareProviderHeadings Method with Param body: " + body);
                body = body.Replace(EmailBodyConstant.LabelSpecialty, Resources.lblSpecialty);
                body = body.Replace(EmailBodyConstant.LabelFocus, Resources.lblFocus);
                body = body.Replace(EmailBodyConstant.LabelTypeOfProvider, Resources.lblTypeOfProvider);
                body = body.Replace(EmailBodyConstant.LabelSurprisebilling,Resources.lblSurpriseBill);
                body = body.Replace(EmailBodyConstant.LabelGender, Resources.lblGender);
                body = body.Replace(EmailBodyConstant.LabelSpokenLanguage, Resources.lblLanguageSpoken);
                body = body.Replace(EmailBodyConstant.LabelDistance, Resources.lblDistance);
                body = body.Replace(EmailBodyConstant.LabelPhoneNumber, Resources.lblPhoneNumber);
                body = body.Replace(EmailBodyConstant.LabelAddress, Resources.lblAddress);
                body = body.Replace(EmailBodyConstant.LabelAcceptingNewPatients, Resources.lblAcceptNewPatients);
                body = body.Replace(EmailBodyConstant.LabelPracticeName, Resources.lblPracticeName);
                body = body.Replace(EmailBodyConstant.LabelHospitalAffiliation, Resources.lblHospitalAffiliations);
                traceLog.AppendLine(" & End: LocateProviderController, CreateCompareProviderHeadings Method");
                return body;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// generate body if there are three provider in compared list
        /// </summary>
        /// <param name="objCompareList"></param>
        /// <returns></returns>
        private string CompareThreeProviders(List<ProviderDataForComparison> objCompareList)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, CompareThreeProviders Method with Param objCompareList: " + objCompareList);
                CompareProviderViewModel objCompareproviderViewModel = new CompareProviderViewModel();
                if (objCompareList == null)
                    throw new ArgumentNullException(VariableConstant.CompareList, "objCompareList is null");
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                foreach (var item in objCompareList)
                {
                    objCompareproviderViewModel.ListProviderDataForComparison.Add(item);
                }
                string body = string.Empty;
                using (StreamReader reader = new StreamReader(Server.MapPath("~/Templates/LocateProviderEmail/CompareThreeProviders.html")))
                {
                    body = reader.ReadToEnd();
                }
               
                if (searchRequest.ClientSpecificCode != null && searchRequest.ClientSpecificNetwork != null)
                {
                    body = body.Replace(EmailBodyConstant.NetworkType, searchRequest.ClientSpecificNetwork);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.NetworkType, searchRequest.NetworkType.NetworkName + " " + EmailBodyConstant.Network);
                }
                //}

                // Create headings for the email 
                body = CreateCompareProviderHeadings(body);

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderName1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderName1, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderAcceptNewPatient))
                {
                    body = body.Replace(EmailBodyConstant.AcceptNewPatient1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderAcceptNewPatient);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.AcceptNewPatient1, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderAddress))
                {
                    body = body.Replace(EmailBodyConstant.ProviderAddress1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderAddress);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderAddress1, VariableConstant.NotAvailable);
                }

                body = body.Replace(EmailBodyConstant.ProviderDistance1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderDistance.ToString(CultureInfo.CurrentCulture).Replace(',', '.') + " " + Resources.lblMiles);

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderHospitalName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderHospitalName1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderHospitalName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderHospitalName1, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSpokenLanguage))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpokenLanguage1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSpokenLanguage);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpokenLanguage1, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderPhone))
                {
                    body = body.Replace(EmailBodyConstant.ProviderPhone1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderPhone);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderPhone1, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSpeciality))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpecialty1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSpeciality);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpecialty1, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderFocus))
                {
                    body = body.Replace(EmailBodyConstant.ProviderFocus1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderFocus);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderFocus1, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSex))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSex1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderSex);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSex1, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderType.ProviderTypeName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderType1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderType.ProviderTypeName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderType1, VariableConstant.NotAvailable);
                }

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].FacilityPAR))
                {
                    string[] networkArr = objCompareproviderViewModel.ListProviderDataForComparison[0].FacilityPAR.Trim().Split(',');
                    String f = string.Empty;
                    int rating = 0;
                    foreach (var i in networkArr)
                    {
                        if (!string.IsNullOrEmpty(i))
                        {
                            var networkOpt = i.Split('|');
                            if (networkOpt[0].Trim().ToUpper() == "PAR")
                            {
                                rating += 1;
                                f += " In-Network " + networkOpt[1].Trim() + " " + Constants.BreakLine;
                            }
                            else if (networkOpt[0].Trim().ToUpper() == "NON-PAR")
                            {
                                f += " No In-Network " + networkOpt[1].Trim() + " " + Constants.BreakLine;
                            }
                        }
                    }

                    f += "<b>" + Resources.lblSurpriseBill + ": " + rating + "</b>";
                    body = body.Replace(EmailBodyConstant.GASurprisebillrating1, f);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.GASurprisebillrating1, VariableConstant.NotAvailable);
                }

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderPHOName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderPracticeName1, objCompareproviderViewModel.ListProviderDataForComparison[0].ProviderPHOName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderPracticeName1, VariableConstant.NotAvailable);
                }

                //for second provider
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderName2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderName2, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderAcceptNewPatient))
                {
                    body = body.Replace(EmailBodyConstant.AcceptNewPatient2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderAcceptNewPatient);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.AcceptNewPatient2, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderAddress))
                {
                    body = body.Replace(EmailBodyConstant.ProviderAddress2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderAddress);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderAddress2, VariableConstant.NotAvailable);
                }

                body = body.Replace(EmailBodyConstant.ProviderDistance2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderDistance.ToString(CultureInfo.CurrentCulture).Replace(',', '.') + " " + Resources.lblMiles);


                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderHospitalName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderHospitalName2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderHospitalName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderHospitalName2, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSpokenLanguage))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpokenLanguage2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSpokenLanguage);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpokenLanguage2, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderPhone))
                {
                    body = body.Replace(EmailBodyConstant.ProviderPhone2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderPhone);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderPhone2, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSpeciality))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpecialty2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSpeciality);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpecialty2, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderFocus))
                {
                    body = body.Replace(EmailBodyConstant.ProviderFocus2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderFocus);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderFocus2, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSex))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSex2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderSex);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSex2, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderType.ProviderTypeName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderType2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderType.ProviderTypeName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderType2, VariableConstant.NotAvailable);
                }

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].FacilityPAR))
                {
                    string[] networkArr = objCompareproviderViewModel.ListProviderDataForComparison[1].FacilityPAR.Trim().Split(',');
                    String f = string.Empty;
                    int rating = 0;
                    foreach (var i in networkArr)
                    {
                        if (!string.IsNullOrEmpty(i))
                        {
                            var networkOpt = i.Split('|');
                            if (networkOpt[0].Trim().ToUpper() == "PAR")
                            {
                                rating += 1;
                                f += " In-Network " + networkOpt[1].Trim() + " " + Constants.BreakLine;
                            }
                            else if (networkOpt[0].Trim().ToUpper() == "NON-PAR")
                            {
                                f += " No In-Network " + networkOpt[1].Trim() + " " + Constants.BreakLine;
                            }
                        }
                    }
                    f += "<b>" + Resources.lblSurpriseBill + ": " + rating + "</b>";
                    body = body.Replace(EmailBodyConstant.GASurprisebillrating2, f);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.GASurprisebillrating2, VariableConstant.NotAvailable);
                }

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderPHOName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderPracticeName2, objCompareproviderViewModel.ListProviderDataForComparison[1].ProviderPHOName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderPracticeName2, VariableConstant.NotAvailable);
                }

                //for third provider
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderName3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderName3, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderAcceptNewPatient))
                {
                    body = body.Replace(EmailBodyConstant.AcceptNewPatient3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderAcceptNewPatient);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.AcceptNewPatient3, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderAddress))
                {
                    body = body.Replace(EmailBodyConstant.ProviderAddress3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderAddress);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderAddress3, VariableConstant.NotAvailable);
                }

                body = body.Replace(EmailBodyConstant.ProviderDistance3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderDistance.ToString(CultureInfo.CurrentCulture).Replace(',', '.') + " " + Resources.lblMiles);

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderHospitalName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderHospitalName3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderHospitalName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderHospitalName3, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderSpokenLanguage))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpokenLanguage3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderSpokenLanguage);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpokenLanguage3, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderPhone))
                {
                    body = body.Replace(EmailBodyConstant.ProviderPhone3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderPhone);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderPhone3, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderSpeciality))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpecialty3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderSpeciality);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSpecialty3, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderFocus))
                {
                    body = body.Replace(EmailBodyConstant.ProviderFocus3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderFocus);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderFocus3, VariableConstant.NotAvailable);

                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderSex))
                {
                    body = body.Replace(EmailBodyConstant.ProviderSex3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderSex);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderSex3, VariableConstant.NotAvailable);
                }
                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderType.ProviderTypeName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderType3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderType.ProviderTypeName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderType3, VariableConstant.NotAvailable);
                }

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].FacilityPAR))
                {
                    string[] networkArr = objCompareproviderViewModel.ListProviderDataForComparison[2].FacilityPAR.Trim().Split(',');
                    String f = string.Empty;
                    int rating = 0;
                    foreach (var i in networkArr)
                    {
                        if (!string.IsNullOrEmpty(i))
                        {
                            var networkOpt = i.Split('|');
                            if (networkOpt[0].Trim().ToUpper() == "PAR")
                            {
                                rating += 1;
                                f += " In-Network " + networkOpt[1].Trim() + " " + Constants.BreakLine;
                            }
                            else if (networkOpt[0].Trim().ToUpper() == "NON-PAR")
                            {
                                f += " No In-Network " + networkOpt[1].Trim() + " " + Constants.BreakLine;
                            }
                        }
                    }
                    f += "<b>" + Resources.lblSurpriseBill + ": " + rating + "</b>";
                    body = body.Replace(EmailBodyConstant.GASurprisebillrating3, f);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.GASurprisebillrating3, VariableConstant.NotAvailable);
                }

                if (!string.IsNullOrEmpty(objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderPHOName))
                {
                    body = body.Replace(EmailBodyConstant.ProviderPracticeName3, objCompareproviderViewModel.ListProviderDataForComparison[2].ProviderPHOName);
                }
                else
                {
                    body = body.Replace(EmailBodyConstant.ProviderPracticeName3, VariableConstant.NotAvailable);
                }

                traceLog.AppendLine(" & End: LocateProviderController, CompareThreeProviders Method");
                return body;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// get states
        /// </summary>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_none")]
        public JsonResult GetStates()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetStates Method");
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                List<State> allStateList = contentManager.GetStatesLocateProvider(request).ToList();
                List<State> stateList = new List<State>();
                string statesForUsers = AppSettingHelper.GetAppSettingValue(VariableConstant.AcceptedStateForUsers);
                char[] splitchar = { ApplicationConstants.SplitString };
                string[] displayState = statesForUsers.Split(splitchar);
                foreach (var item in allStateList)
                {
                    if (displayState.Contains(item.StateCode))
                    {
                        State stateVal = new State();
                        stateVal.StateCode = item.StateCode;
                        stateVal.StateName = item.StateName;

                        stateList.Add(stateVal);
                    }
                }
                traceLog.AppendLine(" & End: LocateProviderController, GetStates Method");
                return Json(stateList);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }



        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_none")]
        public JsonResult ReportGetStates()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, ReportGetStates Method");
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                List<State> allStateList = contentManager.GetStatesLocateProvider(request).ToList();
                List<State> stateList = new List<State>();
                string statesForUsers = AppSettingHelper.GetAppSettingValue(VariableConstant.AcceptedStateForUsers);
                char[] splitchar = { ApplicationConstants.SplitString };
                string[] displayState = statesForUsers.Split(splitchar);
                foreach (var item in allStateList)
                {
                    // if (displayState.Contains(item.StateCode))
                    {
                        State stateVal = new State();
                        stateVal.StateCode = item.StateCode;
                        stateVal.StateName = item.StateName;

                        stateList.Add(stateVal);
                    }
                }
                traceLog.AppendLine(" & End: LocateProviderController, ReportGetStates Method");
                return Json(stateList);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// get states for provider
        /// </summary>
        /// <param name="objCompareList"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_none")]
        public JsonResult GetStatesForProvider()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetStatesForProvider Method");
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                traceLog.AppendLine(" & End: LocateProviderController, GetStatesForProvider Method");
                return Json(contentManager.GetStatesLocateProvider(request).ToList());
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// get states based on OTMC logic
        /// </summary>
        /// <param name="networkId"></param>
        /// <param name="userType"></param>
        /// <returns></returns>
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        private List<State> GetStatesOTMC(string networkId, string userType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetStatesOTMC Method with Param networkId: " + networkId + "and with Param userType: " + userType);
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                List<State> allStateList = contentManager.GetStatesLocateProvider(request).ToList();

                // This code will identify the name os network type
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                // This code will tell powerstepp is on with cofinity network or cofinity client specific code   
                bool isPowerStepON =
                    networkId == "3" && (searchRequest.NetworkType.NetworkName == "Cofinity" ||
                    (searchRequest.ClientSpecificCode != null && Convert.ToString(searchRequest.ClientSpecificCode).ToUpper() == NABWebsite.DTO.Constants.CofinityClientSpecCode))
                    && ConfigurationManager.AppSettings[NABWebsite.DTO.Constants.PowerSTEPPSunset] == Constants.TrueId;


                if (!string.IsNullOrEmpty(userType) && (userType.Equals("Customer", StringComparison.OrdinalIgnoreCase)
                        || userType.Equals("Vendor", StringComparison.OrdinalIgnoreCase)
                        || userType.Equals("Agent", StringComparison.OrdinalIgnoreCase)
                        || userType.Equals("Payer", StringComparison.OrdinalIgnoreCase)
                        || userType.Equals("Member", StringComparison.OrdinalIgnoreCase))
                        // New condition will check for Powersetppt on and cofinity network is selected 
                        && (networkId == "1" || isPowerStepON))
                {
                    List<State> stateList = new List<State>();
                    string statesForUsers = AppSettingHelper.GetAppSettingValue(VariableConstant.AcceptedStateForUsers);
                    char[] splitchar = { ApplicationConstants.SplitString };
                    string[] displayState = statesForUsers.Split(splitchar);
                    foreach (var item in allStateList)
                    {
                        if (displayState.Contains(item.StateCode))
                        {
                            State stateVal = new State();
                            stateVal.StateCode = item.StateCode;
                            stateVal.StateName = item.StateName;

                            stateList.Add(stateVal);
                        }
                    }
                    traceLog.AppendLine(" & End: LocateProviderController, GetStatesOTMC Method");
                    return stateList;
                }
                if (((UserDetails)Session[Constants.UserDetails] != null)
                    && ((UserDetails)Session[Constants.UserDetails]).SelectedRole != null
                     // New condition will check for Powersetppt on and cofinity network is selected 
                     && (networkId == "1" || isPowerStepON))
                {
                    string role = ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToString();
                    if (role.Equals("Customer", StringComparison.OrdinalIgnoreCase)
                        || role.Equals("Vendor", StringComparison.OrdinalIgnoreCase)
                        || role.Equals("Agent", StringComparison.OrdinalIgnoreCase)
                        || role.Equals("Payer", StringComparison.OrdinalIgnoreCase)
                        || role.Equals("Member", StringComparison.OrdinalIgnoreCase))
                    {
                        List<State> stateList = new List<State>();
                        string statesForUsers = AppSettingHelper.GetAppSettingValue(VariableConstant.AcceptedStateForUsers);
                        char[] splitchar = { ApplicationConstants.SplitString };
                        string[] displayState = statesForUsers.Split(splitchar);
                        foreach (var item in allStateList)
                        {
                            if (displayState.Contains(item.StateCode))
                            {
                                State stateVal = new State();
                                stateVal.StateCode = item.StateCode;
                                stateVal.StateName = item.StateName;

                                stateList.Add(stateVal);
                            }
                        }
                        traceLog.AppendLine(" & End: LocateProviderController, GetStatesOTMC Method");
                        return stateList;
                    }

                }
                traceLog.AppendLine(" & End: LocateProviderController, GetStatesOTMC Method");
                return allStateList;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Fetches states
        /// </summary>
        /// <param name="stateCode"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public JsonResult GetState(string networkId, string cutomerType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetState Method with Param networkId: " + networkId + "and with Param cutomerType: " + cutomerType);
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                List<State> listState = GetStatesOTMC(networkId, cutomerType);
                traceLog.AppendLine(" & End: LocateProviderController, GetState Method");
                return Json(listState);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Fetches cities based on state
        /// </summary>
        /// <param name="stateCode"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public JsonResult GetCitiesByState(string stateCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetCitiesByState Method with Param stateCode: " + stateCode);
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                traceLog.AppendLine(" & End: LocateProviderController, GetCitiesByState Method");
                return Json(contentManager.GetCitiesByStateLocateProvider(AntiXssEncoder.HtmlEncode(stateCode, false), request).ToList());
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get Cities ByState And County
        /// Edited by NAB-IT on 05Apr2018 to encode the input perameters
        /// </summary>
        /// <param name="stateCode"></param>
        /// <param name="county"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public JsonResult GetCitiesByStateAndCounty(List<string> stateCode, List<string> county)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {

                //string strStateCode = string.Join(",", stateCode.ToArray());
                //string strCounty = string.Join(",", county.ToArray());

                //AntiXssEncoder.HtmlEncode(strStateCode, false);
                //AntiXssEncoder.HtmlEncode(strCounty, false);

                //RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                //ManageContent contentManager = new ManageContent();

                //return Json(contentManager.GetCitiesByStateAndCountyLocateProvider(strStateCode.Split(',').ToList(), strCounty.Split(',').ToList(), request));
                traceLog.AppendLine("Start: LocateProviderController, GetCitiesByStateAndCounty Method with Param stateCode: " + stateCode + "and with Param county: " + county);
                string strCounties = string.Join(",", county.ToArray());
                strCounties = AntiXssEncoder.HtmlEncode(strCounties, false);
                List<string> listCounty = new List<string>();
                listCounty = strCounties.Split(',').ToList();

                county = listCounty;

                string strStateCode = string.Join(",", stateCode.ToArray());
                strStateCode = AntiXssEncoder.HtmlEncode(strStateCode, false);
                List<string> listState = new List<string>();
                listState = strStateCode.Split(',').ToList();
                stateCode = listState;

                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                traceLog.AppendLine(" & End: LocateProviderController, GetCitiesByStateAndCounty Method");
                return Json(contentManager.GetCitiesByStateAndCountyLocateProvider(stateCode, county, request).ToList());


            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get Counties By State
        /// Edited By NAB-IT on 4 march 2018 to encode the paramenters
        /// </summary>
        /// <param name="stateCode"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public JsonResult GetCountiesByState(string stateCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetCountiesByState Method with Param stateCode: " + stateCode);
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                ManageContent contentManager = new ManageContent();
                traceLog.AppendLine(" & End: LocateProviderController, GetCountiesByState Method");
                return Json(contentManager.GetCountiesByStateLocateProvider(AntiXssEncoder.HtmlEncode(stateCode, false), request).ToList());
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get Specialties By Provider Type
        /// Edited By NAB-IT on 4 march 2018 to encode the paramenters
        /// </summary>
        /// <param name="providerType"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public JsonResult GetSpecialtiesByProviderType(string providerType, string networkTypeId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetSpecialtiesByProviderType Method with Param providerType: " + providerType + "and with Param networkTypeId: " + networkTypeId);
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(AntiXssEncoder.HtmlEncode(networkTypeId, false), CultureInfo.InvariantCulture));
                ManageContent contentManager = new ManageContent();
                List<Specialty> listSpecialty = contentManager.GetSpecialtiesLocateProvider(AntiXssEncoder.HtmlEncode(providerType, false), request).ToList();
                traceLog.AppendLine(" & End: LocateProviderController, GetSpecialtiesByProviderType Method");
                return Json(listSpecialty);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get selected Specialties By Provider Type
        /// </summary>
        /// <param name="providerType"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetSelectedSpecialties(string providerType, string networkTypeId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetSelectedSpecialties Method with Param providerType: " + providerType + "and with Param networkTypeId: " + networkTypeId);
                SearchRequestEntity refineRequest = new SearchRequestEntity();
                refineRequest = Session[SessionConstant.RefineRequest] as SearchRequestEntity;
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(AntiXssEncoder.HtmlEncode(networkTypeId, false), CultureInfo.InvariantCulture));
                ManageContent contentManager = new ManageContent();
                List<Specialty> listSpecialty = contentManager.GetSpecialtiesLocateProvider(AntiXssEncoder.HtmlEncode(providerType, false), request).ToList();
                if (refineRequest != null)
                {
                    if (refineRequest.SpecialtyCodes == null)
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, GetSelectedSpecialties Method");
                        return Json(listSpecialty);
                    }
                    else
                    {
                        if (culture == "en-us")
                        {
                            traceLog.AppendLine(" & End: LocateProviderController, GetSelectedSpecialties Method");
                            return Json(listSpecialty.Where(i => !refineRequest.SpecialtyCodes.Any(e => i.SpecialtyName.Contains(e.SpecialtyName))).ToList());

                        }
                        else
                        {
                            traceLog.AppendLine(" & End: LocateProviderController, GetSelectedSpecialties Method");
                            return Json(listSpecialty.Where(i => !refineRequest.SpecialtyCodes.Any(e => i.SpecialtySpanish.Contains(e.SpecialtySpanish))).ToList());

                        }
                    }

                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetSelectedSpecialties Method");
                    return Json(listSpecialty);
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get Focus By Provider Type
        /// </summary>
        /// <param name="providerType"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public JsonResult GetFocusByProviderType(string providerType, string networkTypeId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetFocusByProviderType Method with Param providerType: " + providerType + "and with Param networkTypeId: " + networkTypeId);
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(AntiXssEncoder.HtmlEncode(networkTypeId, false), CultureInfo.InvariantCulture));
                ManageContent contentManager = new ManageContent();
                List<Focus> listFocus = contentManager.GetFocusLocateProvider(AntiXssEncoder.HtmlEncode(providerType, false), request).ToList();
                traceLog.AppendLine(" & End: LocateProviderController, GetFocusByProviderType Method");
                return Json(listFocus);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get selected Focus By Provider Type
        /// </summary>
        /// <param name="providerType"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetSelectedFocus(string providerType, string networkTypeId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetSelectedFocus Method with Param providerType: " + providerType + "and with Param networkTypeId: " + networkTypeId);
                SearchRequestEntity refineRequest = new SearchRequestEntity();
                refineRequest = Session[SessionConstant.RefineRequest] as SearchRequestEntity;
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(AntiXssEncoder.HtmlEncode(networkTypeId, false), CultureInfo.InvariantCulture));
                ManageContent contentManager = new ManageContent();
                List<Focus> listFocus = contentManager.GetFocusLocateProvider(AntiXssEncoder.HtmlEncode(providerType, false), request).ToList();
                if (refineRequest != null)
                {
                    if (refineRequest.FocusCodes == null)
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, GetSelectedFocus Method");
                        return Json(listFocus);
                    }
                    else
                    {
                        if (culture == "en-us")
                        {
                            traceLog.AppendLine(" & End: LocateProviderController, GetSelectedFocus Method");
                            return Json(listFocus.Where(i => !refineRequest.FocusCodes.Any(e => i.FocusName.Contains(e.FocusName))).ToList());

                        }
                        else
                        {
                            traceLog.AppendLine(" & End: LocateProviderController, GetSelectedSpecialties Method");
                            return Json(listFocus.Where(i => !refineRequest.FocusCodes.Any(e => i.FocusSpanish.Contains(e.FocusSpanish))).ToList());

                        }
                    }

                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetSelectedSpecialties Method");
                    return Json(listFocus);
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Get selected Specialties By Provider Type
        /// </summary>
        /// <param name="providerType"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetMappedpecialties()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetMappedpecialties Method");
                SearchRequestEntity refineRequest = new SearchRequestEntity();
                refineRequest = Session[SessionConstant.RefineRequest] as SearchRequestEntity;
                traceLog.AppendLine(" & End: LocateProviderController, GetMappedpecialties Method");
                return Json(refineRequest.SpecialtyCodes);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Get selected conditions
        /// </summary>
        /// <param name="providerType"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public JsonResult GetSelectedConditions(string networkTypeId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetSelectedConditions Method with Param networkTypeId: " + networkTypeId);
                SearchRequestEntity refineRequest = new SearchRequestEntity();
                refineRequest = Session[SessionConstant.RefineRequest] as SearchRequestEntity;

                if (refineRequest != null)
                {
                    string culture = ReturnCultureInfo();
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(networkTypeId, CultureInfo.InvariantCulture));
                    ManageContent contentManager = new ManageContent();
                    List<Condition> listCondition = contentManager.GetConditionsLocateProvider(request).ToList();
                    traceLog.AppendLine(" & End: LocateProviderController, GetSelectedConditions Method");
                    return Json(listCondition);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetSelectedConditions Method");
                    return Json("SelectNetworkTypeAction");
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Get resource valuse form resource files
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetResources(string key)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetResources Method with Param key: " + key);
                switch (key)
                {
                    case VariableConstant.LabelHideOptions: return Json(Resources.lblHideOptions);
                    case VariableConstant.LabelShowOptions: return Json(Resources.lblShowOptions);
                    case VariableConstant.LabelSeeLessDetails: return Json(Resources.lblSeeLessDetails);
                    case VariableConstant.LabelSeeMoreDetails: return Json(Resources.lblSeeMoreDetails);

                    case VariableConstant.LabelErrorEnterNumericValuesInZip: return Json(Resources.lblErrorMsgEnterNumericValuesInZip);
                    case VariableConstant.LabelErrorMessageValidZip: return Json(Resources.lblErrorMsgValidZip);
                    case VariableConstant.LabelErrorSpecialtySelectionMandatory: return Json(Resources.lblErrorSpecialtySelectionMandatory);
                    case VariableConstant.LabelErrorSelectSpecialtyBeforeAdding: return Json(Resources.lblErrorSelectSpecialtyBeforeAdding);
                    case VariableConstant.LabelAddOnlyFiveSpecialties: return Json(Resources.lblAddAtmostFiveSpecialties);
                    case VariableConstant.LabelSpecialtySelectionNotPossible: return Json(Resources.lblSpecialtySelectionNotPossible);
                    case VariableConstant.LabelSelectFiveSpecialties: return Json(Resources.lblSelectFiveSpecialties);
                    case VariableConstant.LabelSpecialtyAdditionMandatoryBeforeRemoving: return Json(Resources.lblSpcAdditionMandatoryBeforeRemoving);
                    case VariableConstant.LabelAddSpecialtyBeforeRemoving: return Json(Resources.lblAddSpecialtyBeforeRemoving);
                    case VariableConstant.LabelSpecialtySelectionMandatoryBeforeRemoving: return Json(Resources.lblSpcSelectionMandatoryBeforeRemoving);
                    case VariableConstant.LabelSelectSpecialtyBeforeRemoving: return Json(Resources.lblSelectSpcBeforeRemoving);

                    case VariableConstant.LabelErrorFocusSelectionMandatory: return Json(Resources.lblErrorFocusSelectionMandatory);
                    case VariableConstant.LabelErrorSelectFocusBeforeAdding: return Json(Resources.lblErrorSelectFocusBeforeAdding);
                    case VariableConstant.LabelAddOnlyFiveFocus: return Json(Resources.lblAddAtmostFiveFocus);
                    case VariableConstant.LabelFocusSelectionNotPossible: return Json(Resources.lblFocusSelectionNotPossible);
                    case VariableConstant.LabelSelectFiveFocus: return Json(Resources.lblSelectFiveFocus);
                    case VariableConstant.LabelFocusAdditionMandatoryBeforeRemoving: return Json(Resources.lblFocusAdditionMandatoryBeforeRemoving);
                    case VariableConstant.LabelAddFocusBeforeRemoving: return Json(Resources.lblAddFocusBeforeRemoving);
                    case VariableConstant.LabelFocusSelectionMandatoryBeforeRemoving: return Json(Resources.lblFocusSelectionMandatoryBeforeRemoving);
                    case VariableConstant.LabelSelectFocusBeforeRemoving: return Json(Resources.lblSelectFocusBeforeRemoving);

                    case VariableConstant.LabelEnterNumericRadiusErrorMessage: return Json(Resources.lblEnterNumericRadiusErrorMessage);
                    case VariableConstant.LabelTinNumericErrorMessage: return Json(Resources.lblTinNumericErrorMessage);
                    case VariableConstant.LabelEnterNumericValuesInTin: return Json(Resources.lblEnterNumericValuesInTin);
                    case VariableConstant.LabelUserTypeMandatory: return Json(Resources.lblUserTypeMandatory);
                    case VariableConstant.LabelSelectUserType: return Json(Resources.lblSelectUserType);
                    case VariableConstant.LabelProviderTypeIsMandatory: return Json(Resources.lblProviderTypeIsMandatory);
                    case VariableConstant.LabelSelectProviderTypeErrorMessage: return Json(Resources.lblSelectProviderTypeErrorMessage);
                    case VariableConstant.LabelZipMandatoryOnZipSelection: return Json(Resources.lblZipMandatoryOnZipSelection);
                    case VariableConstant.LabelSelectZipBeforeSearchNow: return Json(Resources.lblSelectZipBeforeSearchNow);
                    case VariableConstant.LabelStateMandatoryOnStateSelection: return Json(Resources.lblStateMandatoryOnStateSelection);
                    case VariableConstant.LabelSelectStateBeforeSearchNow: return Json(Resources.lblSelectStateBeforeSearchNow);
                    case VariableConstant.LabelOptionalCriteriaErrorMessage: return Json(Resources.lblOptionalCriteriaErrorMessage);
                    case VariableConstant.LabelSelectBeforeExpandingOptionalCriteria: return Json(Resources.lblSelectBeforeExpandingOptionalCriteria);
                    case VariableConstant.LabelOptionalCriteriaErrorWithoutUser: return Json(Resources.lblOptionalCriteriaErrorWithoutUser);
                    case VariableConstant.LabelSelectBeforeExpandOptionalWithoutUser: return Json(Resources.lblSelectBeforeExpandOptWithoutUser);

                    case VariableConstant.LabelNetworkSelectionRequired: return Json(Resources.lblNetworkSelectionRequired);
                    case VariableConstant.LabelEnterValidClientCodeBeforeStartNow: return Json(Resources.lblEnterValidClientCodeBeforeStartNow);
                    case VariableConstant.LabelClientCodeFieldMandatoryForClientSpecificNetwork: return Json(Resources.lblClientCodeFieldMandatoryForClientSpecificNetwork);
                    case VariableConstant.LabelInvalidClientSpecificNetworkCode: return Json(Resources.lblInvalidClientSpecificNetworkCode);
                    case VariableConstant.LabelClientCodeIsNotValid: return Json(Resources.lblClientCodeIsNotValid);

                    case VariableConstant.LabelSelectMinimumTwoProvidersForComparison: return Json(Resources.lblSelectAtleastTwoProvidersForComparison);
                    case VariableConstant.LabelInvalidZipCode: return Json(Resources.lblInvalidZipCode);
                    case VariableConstant.LabelEnterValidZipOrState: return Json(Resources.lblEnterValidZipOrState);
                    case VariableConstant.LabelNoMoreThanThreeProvidersSelected: return Json(Resources.lblNoMoreThanThreeProvidersSelected);
                    case VariableConstant.LabelSelectAnotherSimilarProviderForComparison: return Json(Resources.lblSelectAnotherSimilarProviderForComparison);
                    case VariableConstant.LabelMaximumTwoHundredProviders: return Json(Resources.lblAtmostTwoHundredProvidersToBeSelected);
                    case VariableConstant.LabelNothingSelected: return Json(Resources.lblNothingSelected);
                    case VariableConstant.LabelNoMatchCount: return Json(Resources.lblNoMatchCount);

                    case VariableConstant.LabelProvideValidIdOrPhoneNumber: return Json(Resources.lblProvideValidIdOrPhoneNumber);
                    case VariableConstant.LabelEnterIdOrPhoneNumber: return Json(Resources.lblEnterIdOrPhoneNumber);
                    case VariableConstant.LabelEmailOrTextNotSent: return Json(Resources.lblEmailOrTextNotSent);
                    case VariableConstant.LabelValidatingCaptchaError: return Json(Resources.lblValidatingCaptchaError);

                    case VariableConstant.LabelEmailSuccessFull: return Json(Resources.lblEmailSuccessFul);
                    case VariableConstant.LabelEmailNotSent: return Json(Resources.lblEmailNotSent);
                    case VariableConstant.LabelErrorCaptchaValidation: return Json(Resources.lblErrorCaptchaValidation);
                    case VariableConstant.LabelErrorEnterEmail: return Json(Resources.lblErrorEnterEmail);
                    case VariableConstant.LabelPleaseFillCaptchaErrorMessage: return Json(Resources.lblPleaseFillCaptchaErrorMessage);

                    case VariableConstant.LabelEnterMinimumOneEmailAddress: return Json(Resources.lblEnterAtleastOneEmailAddress);
                    case VariableConstant.LabelEmailAddressMandatory: return Json(Resources.lblEmailAddressMandatory);
                    case VariableConstant.LabelFindDirectoryAttachedInMail: return Json(Resources.lblFindDirectoryAttachedInMail);
                    case VariableConstant.LabelLinkSentInFiveHours: return Json(Resources.lblLinkSentInFiveHours);
                    case VariableConstant.LabelLinkSentInTwentyFourHours: return Json(Resources.lblLinkSentInTwentyFourHours);

                    case VariableConstant.LabelDirectoryNameRequired: return Json(Resources.lblDirectoryNameRequired);

                    case "DirectoryCreationSuccess": return Json(Resources.DirectoryCreationSuccess);
                    case "DirectoryCreationError": return Json(Resources.DirectoryCreationError);
                    case "lblSpecialtiesRemaining": return Json(Resources.lblSpecialtiesRemaining);
                    case "lblFocusRemaining": return Json(Resources.lblFocusRemaining);
                    case "errorEnterPhone": return Json(Resources.errorEnterPhone);
                    case "errorSelectCarrier": return Json(Resources.errorSelectCarrier);
                    case "lblDirectoryCreationType": return Json(Resources.lblDirectoryCreationType);
                    case "lblLinkSentInFifteenMin": return Json(Resources.lblLinkSentInFifteenMin);
                    case "MapQuestConsumerKeySecret": return Json(AppSettingHelper.GetAppSettingValue("MapQuestConsumerKeySecret"));
                    case "MapQuestConsumerKeyPublic": return Json(AppSettingHelper.GetAppSettingValue("MapQuestConsumerKeyPublic"));
                    case "txtEnterCounty": return Json(Resources.txtEnterCounty);
                    case "txtEnterCity": return Json(Resources.txtEnterCity);
                    case "txtStateRequired": return Json(Resources.txtStateRequired);
                    case "lblEnterSpecialty": return Json(Resources.lblEnterSpecialty);
                    case "lblEnterFocus": return Json(Resources.lblEnterFocus);
                    case "lblEnterECP": return Json(Resources.lblEnterECP);
                    case VariableConstant.LabelErrorEnterNumericValuesInPhysicianPhone: return Json(Resources.lblEnterValidData);
                    case VariableConstant.LabelErrorEnterAlphanumericOnly: return Json(Resources.lblSpecialCharsNotAllowed);

                }
                traceLog.AppendLine(" & End: LocateProviderController, GetResources Method");
                return Json("");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Creates pdf for directory
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult CreateDirectory(CreateDirectoryViewModel model, string captcha)
        {
            StringBuilder traceLog = new StringBuilder();
            string value = string.Empty;
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, CreateDirectory Method with Param model: " + model + "and with Param captcha: " + captcha);
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, CreateDirectory Method");
                    return Json(ApplicationConstants.SelectNetworkTypeAction);
                }
                string errorMessage = string.Empty;
                if (!ValidateCaptcha(captcha, out errorMessage))
                {
                    traceLog.AppendLine(" & End: LocateProviderController, CreateDirectory Method");
                    return Json(errorMessage);
                }
                else
                {
                    byte[] fileDetail = null;
                    string path = AppSettingHelper.GetAppSettingValue(VariableConstant.DirectoryPath);
                    string filename = "\\" + Guid.NewGuid();
                    Session["ProviderDirectoryFileName"] = filename;
                    string pdfname = path + filename;
                    if (System.IO.File.Exists(pdfname))
                    {
                        System.IO.File.Delete(pdfname);
                    }
                    if (!CommonHelper.ValidateModelEmailAddresses(model))
                    {
                        throw new System.Exception(ExceptionMessageConstant.Model);
                    }
                    List<string> emailAddressesList = new List<string>();
                    if (model == null)
                        throw new ArgumentNullException(VariableConstant.ModelValue);
                    if (!string.IsNullOrEmpty(model.EmailId1)) emailAddressesList.Add(model.EmailId1);
                    if (!string.IsNullOrEmpty(model.EmailId2)) emailAddressesList.Add(model.EmailId2);
                    if (!string.IsNullOrEmpty(model.EmailId3)) emailAddressesList.Add(model.EmailId3);

                    string[] newEmails = emailAddressesList.ToArray();

                    ManageContent contentManager = new ManageContent();
                    SearchRequestEntity searchRequest = new SearchRequestEntity();
                    searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                    if (searchRequest == null)
                    {
                        TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                        if (Convert.ToBoolean(HttpContext.Application["AllowCustomUrlFlag"]) == true)
                        {
                            //Fixed Checkmarx issue of XSHM on dated 24-Sep-2018
                            string consonant = "a0b1c2d3e4f5g6h7i8j9klmnopqrstvuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

                            int length2 = CommonHelper.GetSecureRandom(1, 62);
                            this.Response.Redirect("https://" + AppSettingHelper.GetAppSettingValue("CustomHOSTURL") + "?r=" + consonant.Substring(length2, 1));
                        }
                        else
                        {
                            traceLog.AppendLine(" & End: LocateProviderController, CreateDirectory Method");
                            return Json("sessionTimeOut");
                        }

                    }

                    RequestHeader request = new CommonHelper().GetRequestHeader(ReturnCultureInfo(), Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));
                    string networkName = null;
                    if (searchRequest.ClientSpecificCode != null && searchRequest.ClientSpecificNetwork != null)
                    {
                        networkName = searchRequest.ClientSpecificNetwork;
                    }
                    else
                    {
                        networkName = searchRequest.NetworkType.NetworkName;
                    }
                    string dateTime = DateTime.Now.ToString(VariableConstant.DateTimeFormat, CultureInfo.CurrentCulture);
                    string directoryName = model.DirectoryName;
                    string newDirectoryName = directoryName + VariableConstant.Underscore + networkName + VariableConstant.Underscore + dateTime;
                    ReportRequestHeaderEntity reportRequestHeaderEntity = new ReportRequestHeaderEntity();
                    if ((UserDetails)Session[Constants.UserDetails] != null && ((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                    {
                        UserDetails user = (UserDetails)Session[Constants.UserDetails];
                        if (!string.IsNullOrEmpty(user.UserId))
                        {
                            reportRequestHeaderEntity.LoggedInUserId = user.UserId;
                        }
                        if (!string.IsNullOrEmpty(user.SelectedRole))
                        {
                            reportRequestHeaderEntity.Role = user.SelectedRole;
                        }

                    }
                    reportRequestHeaderEntity.Site = ConfigurationManager.AppSettings[Constants.Site];
                    reportRequestHeaderEntity.RequiredIndex = model.IncludeIndex;
                    reportRequestHeaderEntity.RequiredTableOfContent = model.IncludeTOC;
                    reportRequestHeaderEntity.DirectoryName = model.DirectoryName;

                    #region mylist
                    if (model.DirectoryType == ApplicationConstants.MyList)
                    {
                        List<string> taggedProviders = Session[SessionConstant.TaggedProvider] as List<string>;
                        List<ReportProviderSelectorEntity> taggedProviderList = new List<ReportProviderSelectorEntity>();
                        if (taggedProviders != null)
                        {
                            foreach (var item in taggedProviders)
                            {
                                ReportProviderSelectorEntity obj = new ReportProviderSelectorEntity();
                                obj.ProvLocationID = item.Split('_')[1].Replace("-", "/");
                                obj.ProvNum = item.Split('_')[0];
                                obj.ProvTaxId = item.Split('_')[2];

                                taggedProviderList.Add(obj);
                            }
                            if (model.DirectoryCreationType == ApplicationConstants.Pdf)
                            {
                                fileDetail = contentManager.GetProviderReportForTagged(searchRequest, request, taggedProviderList, reportRequestHeaderEntity, filename);
                                //using (FileStream fs = System.IO.File.Create(pdfname))
                                //{
                                //    fs.Write(fileDetail, 0, fileDetail.Length);
                                //}
                                value = VariableConstant.DurationFiveMinutes;
                            }
                            else if (model.DirectoryCreationType == ApplicationConstants.Email)
                            {
                                string body = string.Empty;
                                using (StreamReader reader = new StreamReader(Server.MapPath("~/Templates/LocateProviderEmail/ProviderDirectory.html")))
                                {
                                    body = reader.ReadToEnd();
                                }
                                body = body.Replace(EmailBodyConstant.DirectoryName, newDirectoryName);
                                body = body.Replace(EmailBodyConstant.Url, EmailBodyConstant.CustomPath);
                                body = body.Replace(EmailBodyConstant.NumberOfProviders, Convert.ToString(taggedProviders.Count(), CultureInfo.CurrentCulture));
                                body = body.Replace(EmailBodyConstant.Duration, VariableConstant.DurationSixDays);
                                body = body.Replace(EmailBodyConstant.DateTime, DateTime.Now.ToString());
                                body = body.Replace(EmailBodyConstant.FindYourDirectory, AppSettingHelper.GetAppSettingValue("WebsiteAction") + filename.Replace(".pdf", "").Replace("\\", ""));
                                contentManager.GetProviderReportBatchForeTagged(searchRequest, taggedProviderList, request, filename.Replace(".pdf", ""), body, newEmails, VariableConstant.ProviderDirectoryHeading, reportRequestHeaderEntity, Session["ReportRelayServiceUser"].ToString(), Session["ReportRelayServicePassword"].ToString());
                                value = VariableConstant.DurationFifteenMinutes;
                            }
                        }
                        else
                        {
                            value = VariableConstant.ZeroMyList;
                        }

                    }
                    #endregion

                    #region search result
                    else if (model.DirectoryType == ApplicationConstants.SearchResult)
                    {
                        int numberOfProviders = 0;
                        SortingPagingInfo info = new SortingPagingInfo();
                        if (Session[SessionConstant.SortingPagingInfo] != null)
                        {
                            info = Session[SessionConstant.SortingPagingInfo] as SortingPagingInfo;
                            numberOfProviders = info.TotalRecords;

                        }

                        if (searchRequest != null)
                        {
                            if (model.DirectoryCreationType == ApplicationConstants.Pdf)
                            {
                                fileDetail = contentManager.GetProviderReport(searchRequest, request, reportRequestHeaderEntity, filename);
                                //using (FileStream fs = System.IO.File.Create(pdfname))
                                //{
                                //    fs.Write(fileDetail, 0, fileDetail.Length);
                                //}
                                //Session[SessionConstant.PathInfo] = path;
                                value = VariableConstant.DurationFiveMinutes;
                            }
                            else if (model.DirectoryCreationType == ApplicationConstants.Email)
                            {
                                string body = string.Empty;

                                using (StreamReader reader = new StreamReader(Server.MapPath("~/Templates/LocateProviderEmail/ProviderDirectory.html")))
                                {
                                    body = reader.ReadToEnd();
                                }
                                bool emailto = false;
                                string duration = string.Empty;
                                int minimumProviders = AppSettingHelper.ReturnValue(VariableConstant.MinimumProviders);
                                int maximumProviders = AppSettingHelper.ReturnValue(VariableConstant.MaximumProviders);
                                body = body.Replace(EmailBodyConstant.DirectoryName, newDirectoryName);
                                body = body.Replace(EmailBodyConstant.Url, EmailBodyConstant.CustomPath);
                                body = body.Replace(EmailBodyConstant.NumberOfProviders, Convert.ToString(numberOfProviders, CultureInfo.CurrentCulture));
                                body = body.Replace(EmailBodyConstant.DateTime, DateTime.Now.ToString());


                                if (numberOfProviders > 0 && numberOfProviders <= minimumProviders)
                                {
                                    fileDetail = contentManager.GetProviderReport(searchRequest, request, reportRequestHeaderEntity, filename);
                                    //using (FileStream fs = System.IO.File.Create(pdfname))
                                    //{
                                    //    fs.Write(fileDetail, 0, fileDetail.Length);
                                    //}
                                    duration = VariableConstant.DurationSixDays;
                                    body = body.Replace(EmailBodyConstant.Duration, duration);
                                    body = body.Replace(EmailBodyConstant.FindYourDirectory, AppSettingHelper.GetAppSettingValue("WebsiteAction") + filename.Replace(".pdf", "").Replace("\\", ""));
                                    emailto = contentManager.SendMail(body, newEmails, VariableConstant.ProviderDirectoryHeading);
                                    value = VariableConstant.ReturnStringFalse;
                                }
                                else if (numberOfProviders > minimumProviders && numberOfProviders <= maximumProviders)
                                {
                                    duration = VariableConstant.DurationSixDays;
                                    body = body.Replace(EmailBodyConstant.Duration, duration);
                                    body = body.Replace(EmailBodyConstant.FindYourDirectory, AppSettingHelper.GetAppSettingValue("WebsiteAction") + filename.Replace(".pdf", "").Replace("\\", ""));
                                    contentManager.GetProviderReportBatch(searchRequest, request, filename.Replace(".pdf", ""), body, newEmails, VariableConstant.ProviderDirectoryHeading, reportRequestHeaderEntity);

                                    emailto = true;
                                    value = VariableConstant.DurationFiveHours;
                                }
                                else if (numberOfProviders > maximumProviders)
                                {
                                    duration = VariableConstant.DurationSixDays;
                                    body = body.Replace(EmailBodyConstant.Duration, duration);
                                    ProviderDirectory ProviderDirectory = new ProviderDirectory();
                                    ProviderDirectory.Name = model.DirectoryName;
                                    ProviderDirectory.ExportEmailIDs = emailAddressesList;
                                    ProviderDirectory.RecordCount = numberOfProviders.ToString();
                                    ProviderDirectory.IncludeIndex = model.IncludeIndex;
                                    ProviderDirectory.IncludeTOC = model.IncludeTOC;
                                    RequestCreateDirectory(request, reportRequestHeaderEntity.LoggedInUserId, ProviderDirectory, searchRequest);
                                    emailto = true;
                                    value = VariableConstant.DurationTwentyFourHours;
                                }

                            }
                        }
                    }
                    #endregion

                }
            }
            catch (Exception ex)
            {
                string enablelocalLogging = ConfigurationManager.AppSettings["EnableLocalLogging"];
                if (!string.IsNullOrEmpty(enablelocalLogging) && enablelocalLogging.ToLower() == "true")
                {
                    ex.Data["Method"] = String.Format("CreateDirectory(CreateDirectoryViewModel, captcha={0})", captcha);
                    CommonHelper.LogErrorInTextFile(ex);
                }
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            traceLog.AppendLine(" & End: LocateProviderController, CreateDirectory Method");
            return Json(value);
        }
        /// <summary>
        /// schedule batch for bulky report
        /// </summary>
        /// <param name="req"></param>
        /// <param name="header"></param>
        /// <param name="newDirectoryName"></param>
        /// <param name="emailAddressesList"></param>
        /// <param name="recordCount"></param>
        private void RequestCreateDirectory(RequestHeader req, string userId, ProviderDirectory providerDirectory, SearchRequestEntity searchRequestEntity)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, RequestCreateDirectory Method with Param req: " + req + "and with Param userId: " + userId + "and with Param providerDirectory: " + providerDirectory + "and with Param searchRequestEntity: " + searchRequestEntity);
                ManageContent contentManager = new ManageContent();
                contentManager.RequestSearchedProvidersDirectory(req, userId, providerDirectory, searchRequestEntity);
                traceLog.AppendLine(" & End: LocateProviderController, RequestCreateDirectory Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// display pdf for directory
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public ActionResult PdfDisplayForDirectory()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, PdfDisplayForDirectory Method");
                if (Session["ProviderDirectoryFileName"] != null)
                {
                    string path = AppSettingHelper.GetAppSettingValue(VariableConstant.DirectoryPath);
                    string filename = Session["ProviderDirectoryFileName"].ToString();
                    string pdfname = path + filename;
                    byte[] bytes = System.IO.File.ReadAllBytes(pdfname);
                    var cd = new System.Net.Mime.ContentDisposition
                    {
                        FileName = filename.Replace("\\", "") + ".pdf",
                        Inline = true,
                    };

                    Response.AppendHeader("Content-Disposition", cd.ToString());
                    traceLog.AppendLine(" & End: LocateProviderController, PdfDisplayForDirectory Method");
                    return File(bytes, "application/pdf");
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, PdfDisplayForDirectory Method");
                    return null;
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// delete pdf for directory
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult DeleteProviderReportFile()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, DeleteProviderReportFile Method");
                bool value = true;
                string path = AppSettingHelper.GetAppSettingValue(VariableConstant.DirectoryPath);
                string pdfname = path + "\\Report_" + Session.SessionID + ".pdf";
                if (System.IO.File.Exists(pdfname))
                {
                    System.IO.File.Delete(pdfname);
                }
                traceLog.AppendLine(" & End: LocateProviderController, DeleteProviderReportFile Method");
                return Json(value);

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Saves pdf for directory
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult SaveDirectory(CreateDirectoryViewModel model)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, SaveDirectory Method with Param model: " + model);
                bool value = false;
                string userId = null;
                if ((UserDetails)Session[Constants.UserDetails] != null && ((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId.ToString();
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                    {
                        //Fixed Checkmarx issue of XSHM on dated 24-Sep-2018
                        string consonant = "a0b1c2d3e4f5g6h7i8j9klmnopqrstvuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

                        int length2 = CommonHelper.GetSecureRandom(1, 62);
                        this.Response.Redirect("https://" + AppSettingHelper.GetAppSettingValue("CustomHOSTURL") + "?r=" + consonant.Substring(length2, 1));
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, SaveDirectory Method");
                        return Json("sessionTimeOut");
                    }

                }


                if (!CommonHelper.ValidateModelEmailAddresses(model))
                {
                    throw new System.Exception(ExceptionMessageConstant.Model);
                }
                List<string> emailAddressesList = new List<string>();
                if (model == null)
                    throw new ArgumentNullException(VariableConstant.ModelValue);

                if (!string.IsNullOrEmpty(model.EmailId1)) emailAddressesList.Add(model.EmailId1);
                if (!string.IsNullOrEmpty(model.EmailId2)) emailAddressesList.Add(model.EmailId2);
                if (!string.IsNullOrEmpty(model.EmailId3)) emailAddressesList.Add(model.EmailId3);

                string networkName = searchRequest.NetworkType.NetworkName;
                string dateTime = DateTime.Now.ToString(VariableConstant.DateTimeFormat, CultureInfo.CurrentCulture);
                string directoryName = model.DirectoryName;
                string newDirectoryName = directoryName + VariableConstant.Underscore + networkName + VariableConstant.Underscore + dateTime;
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));
                ManageContent contentManager = new ManageContent();

                if (searchRequest != null)
                {
                    value = contentManager.SaveSearchedProvidersDirectory(request, searchRequest, userId, newDirectoryName, new List<string> { "" });
                }
                traceLog.AppendLine(" & End: LocateProviderController, SaveDirectory Method");
                return Json(value);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// load search directory
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult LoadSearchCriteriaDirectory(string directoryId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, LoadSearchCriteriaDirectory Method with Param directoryId: " + directoryId);
                string userId = null;
                if ((UserDetails)Session[Constants.UserDetails] != null && ((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId.ToString();
                }
                string culture = ReturnCultureInfo();
                SearchRequestEntity searchreq = new SearchRequestEntity();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                ManageContent omngcontent = new ManageContent();
                searchreq = omngcontent.GetSearchRequestDirectory(request, userId, directoryId);
                if (searchreq != null)
                {
                    Session[SessionConstant.SearchRequest] = searchreq;
                    Session[SessionConstant.RefineRequest] = searchreq;
                    traceLog.AppendLine(" & End: LocateProviderController, LoadSearchCriteriaDirectory Method");
                    return Json(true);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, LoadSearchCriteriaDirectory Method");
                    return Json(false);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// load search directory
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult LoadTaggedDirectory(string directoryId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, LoadTaggedDirectory Method with Param directoryId: " + directoryId);
                string userId = null;
                if ((UserDetails)Session[Constants.UserDetails] != null && ((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId.ToString();
                }
                string culture = ReturnCultureInfo();
                List<string> searchreq = new List<string>();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                ManageContent omngcontent = new ManageContent();
                searchreq = omngcontent.GetTaggedProvidersDirectory(request, userId, directoryId);
                if (searchreq != null)
                {
                    Session[SessionConstant.TaggedProvider] = searchreq;
                    traceLog.AppendLine(" & End: LocateProviderController, LoadTaggedDirectory Method");
                    return Json(true);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, LoadTaggedDirectory Method");
                    return Json(false);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// delete directory
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult DeleteProviderDirectory(string directoryId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, DeleteProviderDirectory Method with Param directoryId: " + directoryId);
                string userId = null;
                if ((UserDetails)Session[Constants.UserDetails] != null && ((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId.ToString();
                }
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                ManageContent omngcontent = new ManageContent();
                bool returnValue = omngcontent.DeleteProviderDirectory(request, userId, directoryId);
                traceLog.AppendLine(" & End: LocateProviderController, DeleteProviderDirectory Method");
                return Json(returnValue);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }


        }


        /// <summary>
        /// Get provider name for auto suggestion
        /// Edited By NAB-IT on 4 march 2018 to encode the input paramenter
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetProviderName(string query)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetProviderName Method with Param query: " + query);
                SearchRequestEntity searchRequest = new SearchRequestEntity();

                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (!new CommonHelper().Validate(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }

                if (query != null)
                {
                    searchRequest.ProviderName = AntiXssEncoder.HtmlEncode(query, false);
                }
                SearchResult searchResult = new SearchResult();
                ManageContent contentManager = new ManageContent();

                if (searchRequest != null)
                {
                    string culture = ReturnCultureInfo();
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));
                    searchRequest.StartIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.StartIndexForRecordDisplay);
                    searchRequest.LastIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    searchRequest.SortColumn = AppSettingHelper.GetAppSettingValue("RefineNameSortCol");
                    searchRequest.SortOrder = AppSettingHelper.GetAppSettingValue(VariableConstant.SortOrder);
                    searchResult = contentManager.GetRefinedProvidersName(searchRequest, request);
                    searchRequest.ProviderName = null;
                    if (searchResult.Providers != null)
                    {

                        var assetName = (from s in searchResult.Providers select s.ProviderName.LongName).Distinct().ToList();
                        traceLog.AppendLine(" & End: LocateProviderController, GetProviderName Method");
                        return Json(assetName, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, GetProviderName Method");
                        return null;

                    }

                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetProviderName Method");
                    return null;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// Get all list of Provider Language Spoken for refine criteria in search result page
        /// </summary>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public JsonResult GetProviderLanguageSpoken()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetProviderLanguageSpoken Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetProviderLanguageSpoken Method");
                    return Json(ApplicationConstants.SelectNetworkTypeAction);
                }
                SearchRequestEntity refineRequest = new SearchRequestEntity();
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                refineRequest = Session[SessionConstant.RefineRequest] as SearchRequestEntity;
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;

                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));

                if (refineRequest != null)
                {
                    RefineProvider refineProvider = new RefineProvider();
                    SearchResult searchResult = new SearchResult();
                    ManageContent contentManager = new ManageContent();
                    List<string> languageList = new List<string>();
                    List<SpecialtyEntity> specialtyList = new List<SpecialtyEntity>();
                    List<FocusEntity> focusList = new List<FocusEntity>();
                    List<ECPEntity> ECPList = new List<ECPEntity>();
                    searchRequest.StartIndexForRecordDisplay = null;
                    searchRequest.LastIndexForRecordDisplay = null;
                    searchResult = contentManager.GetRefinedProvidersName(searchRequest, request);

                    if (searchResult.Providers != null && searchResult.Providers.Count > 0)
                    {
                        languageList = searchResult.Providers.Select(m => m.LanguagesSpoken).ToList();
                        languageList = languageList.SelectMany(n => n.Split(',')).Distinct().Select(m => m.Trim()).OrderBy(m => m).ToList();
                        languageList = languageList.Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
                    }
                    if (refineRequest.SpecialtyCodes == null || refineRequest.SpecialtyCodes.Count == 0)
                    {
                        if (searchResult.Providers != null && searchResult.Providers.Count > 0)
                        {
                            var engSpecialty = searchResult.Providers.Select(m => m.Speciality.SpecialtyName).SelectMany(n => n.Split('#')).ToList();
                            var spnSpecialty = searchResult.Providers.Select(m => m.Speciality.SpecialtyCode).SelectMany(n => n.Split('#')).ToList();

                            for (int i = 0; i < engSpecialty.Count; i++)
                            {
                                specialtyList.Add(new SpecialtyEntity { SpecialtyName = i < engSpecialty.Count ? engSpecialty[i].Trim() : null, SpecialtySpanish = i < spnSpecialty.Count ? spnSpecialty[i].Trim() : null });
                            }
                            specialtyList = specialtyList.Where(m => !string.IsNullOrWhiteSpace(m.SpecialtyName) && !string.IsNullOrWhiteSpace(m.SpecialtySpanish)).ToList();

                            if (culture == "en-us")
                            {
                                specialtyList = specialtyList.GroupBy(x => x.SpecialtyName).Select(x => x.First()).ToList();
                                specialtyList = specialtyList.OrderBy(m => m.SpecialtyName).ToList();
                            }
                            else
                            {
                                specialtyList = specialtyList.GroupBy(x => x.SpecialtySpanish).Select(x => x.First()).ToList();
                                specialtyList = specialtyList.OrderBy(m => m.SpecialtySpanish).ToList();
                            }
                        }
                    }
                    else
                    {
                        specialtyList = refineRequest.SpecialtyCodes;
                    }

                    if (refineRequest.FocusCodes == null || refineRequest.FocusCodes.Count == 0)
                    {
                        if (searchResult.Providers != null && searchResult.Providers.Count > 0)
                        {

                            var focus = searchResult.Providers.Select(m => m.Focus).SelectMany(n => n.Split('#')).ToList();

                            for (int i = 0; i < focus.Count; i++)
                            {
                                focusList.Add(new FocusEntity { FocusName = i < focus.Count ? focus[i].Trim() : null, FocusSpanish = i < focus.Count ? focus[i].Trim() : null });
                            }
                            focusList = focusList.Where(m => !string.IsNullOrWhiteSpace(m.FocusName) && !string.IsNullOrWhiteSpace(m.FocusSpanish)).ToList();

                            if (culture == "en-us")
                            {
                                focusList = focusList.GroupBy(x => x.FocusName).Select(x => x.First()).ToList();
                                focusList = focusList.OrderBy(m => m.FocusName).ToList();
                            }
                            else
                            {
                                focusList = focusList.GroupBy(x => x.FocusSpanish).Select(x => x.First()).ToList();
                                focusList = focusList.OrderBy(m => m.FocusSpanish).ToList();
                            }
                        }
                    }
                    else
                    {
                        focusList = refineRequest.FocusCodes;
                    }
                    //For ECP
                    if (refineRequest.ECPCodes == null || refineRequest.ECPCodes.Count == 0)
                    {
                        if (searchResult.Providers != null && searchResult.Providers.Count > 0)
                        {
                            var ecplist = searchResult.Providers.Where(e => !string.IsNullOrWhiteSpace(e.ECP.ECPCode)).Select(e => e.ECP.ECPCode).SelectMany(n => n.Split(',')).ToList();
                            ecplist = ecplist.Select(m => m.Trim()).Distinct().ToList();
                            var ecpDesc = searchResult.Providers.Where(e => !string.IsNullOrWhiteSpace(e.ECP.ECPDescription)).Select(e => e.ECP.ECPDescription).SelectMany(n => n.Split(',')).ToList();
                            ecpDesc = ecpDesc.Select(m => m.Trim()).Distinct().ToList();
                            var ecpListFinal = ecplist.Zip(ecpDesc, (s, i) => new { Value = s, Text = i }).ToList();

                            for (int i = 0; i < ecpListFinal.Count; i++)
                            {
                                ECPList.Add(new ECPEntity
                                {
                                    ECPCode = ecpListFinal[i].Value,
                                    ECPDescription = ecpListFinal[i].Text
                                });
                            }
                        }
                    }
                    else
                    {
                        ECPList = refineRequest.ECPCodes;
                    }

                    refineProvider.LanguageSpoken = languageList;
                    refineProvider.SpecialtyList = specialtyList;
                    refineProvider.FocusList = focusList;
                    refineProvider.ECPList = ECPList;
                    traceLog.AppendLine(" & End: LocateProviderController, GetProviderLanguageSpoken Method");
                    return Json(refineProvider, JsonRequestBehavior.AllowGet);


                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetProviderLanguageSpoken Method");
                    return null;

                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get auto suggest provider name
        /// </summary>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public JsonResult GetProviderNameSearchCriteria(SearchRequestEntity searchRequest)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetProviderNameSearchCriteria Method with Param searchRequest: " + searchRequest);
                List<PhysicanFacilityName> searchResult = new List<PhysicanFacilityName>();
                ManageContent contentManager = new ManageContent();

                if (searchRequest != null)
                {
                    if (!new CommonHelper().Validate(searchRequest))
                    {
                        throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                    }
                    string culture = ReturnCultureInfo();
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));
                    searchRequest.StartIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.StartIndexForRecordDisplay);
                    searchRequest.LastIndexForRecordDisplay = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    searchRequest.SortColumn = AppSettingHelper.GetAppSettingValue("NameSuggestionCol");
                    searchRequest.SortOrder = AppSettingHelper.GetAppSettingValue(VariableConstant.SortOrder);

                    searchResult = contentManager.GetAutoSuggestProvidersName(searchRequest, request);
                    traceLog.AppendLine(" & End: LocateProviderController, GetProviderNameSearchCriteria Method");
                    return Json(searchResult, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetProviderNameSearchCriteria Method");
                    return null;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }


        /// <summary>
        /// sends mail of provider details
        /// </summary>
        /// <param name="email"></param>
        /// <param name="phoneNumberCarrier"></param>
        /// <param name="providerNumber"></param>
        /// <param name="captchaResponse"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public JsonResult SendingMail(string email, string phoneNumberCarrier, string phoneNumber, string providerNumber, string captcha)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, SendingMail Method with Param email: " + email + "and with Param phoneNumberCarrier: " + phoneNumberCarrier + "and with Param phoneNumber: " + phoneNumber + "and with Param providerNumber: " + providerNumber + "and with Param captcha: " + captcha);
                if (providerNumber == null)
                {
                    throw new ArgumentNullException(VariableConstant.ProviderNumber);
                }
                if (!string.IsNullOrWhiteSpace(phoneNumber))
                {
                    phoneNumber = phoneNumber.Replace("-", "");
                }
                string smsGateway = string.Empty;
                if (phoneNumberCarrier != null)
                {
                    if (!(string.IsNullOrEmpty(phoneNumber)))
                    {
                        smsGateway = phoneNumberCarrier.Replace(VariableConstant.CarrierNumber, phoneNumber + VariableConstant.Character);
                    }
                }
                char[] splitchar = { ApplicationConstants.SplitString };
                string[] providerNumberIndex = providerNumber.Split(splitchar);
                Aetna.ProviderContracts.DataContracts.Provider provider = new Aetna.ProviderContracts.DataContracts.Provider();
                if (!CommonHelper.ValidateEmail(email))
                {
                    throw new System.Exception(ExceptionMessageConstant.Email);
                }

                string errorMessage = string.Empty;
                if (!ValidateCaptcha(captcha, out errorMessage))
                {
                    traceLog.AppendLine(" & End: LocateProviderController, SendingMail Method");
                    return Json(errorMessage);
                }
                else
                {
                    SearchRequestEntity searchRequest = new SearchRequestEntity();
                    searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                    if (searchRequest == null)
                    {
                        TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                        traceLog.AppendLine(" & End: LocateProviderController, SendingMail Method");
                        return Json("sessionTimeOut");
                    }
                    if (!new CommonHelper().Validate(searchRequest))
                    {
                        throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                    }
                    bool send = false;
                    string culture = ReturnCultureInfo();

                    string errorLogSenderEmail;

                    if (Session[NABWebsite.Helper.SessionConstant.SearchRequest] != null)
                    {
                        NABWebsite.DTO.SearchRequestEntity searchRequest1 = new NABWebsite.DTO.SearchRequestEntity();

                        searchRequest = Session[NABWebsite.Helper.SessionConstant.SearchRequest] as NABWebsite.DTO.SearchRequestEntity;
                        if (searchRequest.NetworkType.NetworkId == "1")
                        {
                            errorLogSenderEmail = ConfigurationManager.AppSettings["FromCofinityReportInfo"];
                            send = EmailSendHelper.SendMail(provider, searchRequest, Server, email, smsGateway, providerNumberIndex, culture, errorLogSenderEmail);
                            TempData["SendSuccess"] = VariableConstant.Success;
                            traceLog.AppendLine(" & End: LocateProviderController, SendingMail Method");
                            return Json(send);
                        }
                        else
                        {
                            errorLogSenderEmail = ConfigurationManager.AppSettings["LocateProviderSendFrom"];
                            send = EmailSendHelper.SendMail(provider, searchRequest, Server, email, smsGateway, providerNumberIndex, culture, errorLogSenderEmail);
                            TempData["SendSuccess"] = VariableConstant.Success;
                            traceLog.AppendLine(" & End: LocateProviderController, SendingMail Method");
                            return Json(send);
                        }

                    }
                    traceLog.AppendLine(" & End: LocateProviderController, SendingMail Method");
                    return Json(send);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Fetches details of tagged providers
        /// </summary>
        /// <returns></returns>
        private SearchResult GetTaggedProviders()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetTaggedProviders Method");
                Session[SessionConstant.ExpandedProviders] = null;
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (!new CommonHelper().Validate(searchRequest))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }
                ManageContent contentManager = new ManageContent();
                List<string> sessionTag = Session[SessionConstant.TaggedProvider] as List<string>;
                if (!CommonHelper.ValidateTaggedProviderList(sessionTag))
                {
                    throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                }

                if (sessionTag.Count > 0)
                {
                    List<ProviderSelector> pList = new List<ProviderSelector>();
                    foreach (var item in sessionTag)
                    {
                        ProviderSelector obj = new ProviderSelector();
                        obj.ProvLocationID = item.Split('_')[1].Replace("-", "/");
                        obj.ProvNum = item.Split('_')[0];
                        obj.ProvTaxId = item.Split('_')[2];

                        pList.Add(obj);
                    }
                    int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                    string culture = ReturnCultureInfo();
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, networkId);
                    SearchResult searchResult = contentManager.GetMultipleProviders(pList, searchRequest.ZipCode, request);
                    traceLog.AppendLine(" & End: LocateProviderController, GetTaggedProviders Method");
                    return searchResult;
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetTaggedProviders Method");
                    return null;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        /// <summary>
        /// Storing sorting paging information in session for my list page
        /// </summary>
        /// <param name="sortingPagingInfo"></param>
        [AjaxValidateAntiForgeryToken]
        [HttpPost]
        public void SaveTaggedSortingPagingInfoToSession(SortingPagingInfo sortingPagingInfo)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, SaveTaggedSortingPagingInfoToSession Method with Param sortingPagingInfo: " + sortingPagingInfo);
                Session[SessionConstant.TaggedSortingPagingInfo] = sortingPagingInfo;
                traceLog.AppendLine(" & End: LocateProviderController, SaveTaggedSortingPagingInfoToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Checks validity of entered client codes
        /// </summary>
        /// <param name="clientCode"></param>
        /// <returns></returns>
        /// 
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public bool CheckClientCode(string clientCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, CheckClientCode Method with Param clientCode: " + clientCode);
                if (!CommonHelper.ValidateGenericValue(clientCode))
                    throw new ArgumentNullException(VariableConstant.ClientCode, VariableConstant.InvalidClientCode);
                bool check = false;
                ManageContent contentManager = new ManageContent();
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                check = contentManager.ValidateClientCode(clientCode, request);
                traceLog.AppendLine(" & End: LocateProviderController, CheckClientCode Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Checks validity of entered zip codes
        /// </summary>
        /// <param name="txtZip"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        public bool CheckZipCode(string txtZip)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, CheckZipCode Method with Param txtZip: " + txtZip);
                bool check = false;
                ManageContent contentManager = new ManageContent();
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                check = contentManager.GetZipCodeValue(request, txtZip);
                traceLog.AppendLine(" & End: LocateProviderController, CheckZipCode Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get provider direction from javascript MapQuest api call
        /// </summary>
        /// <param name="direction"></param>
        /// <param name="emailAddress"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetDirection(List<ProviderDirectionPath> direction, string emailAddress, string carrier, string phoneNumber, string captcha, string providerNumber, string providerNameDegree, string providerAddress)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetDirection Method with Param direction: " + direction + "and with Param emailAddress: " + emailAddress + "and with Param carrier: " + carrier + "and with Param phoneNumber: " + phoneNumber + "and with Param captcha: " + captcha + "and with Param providerNumber: " + providerNumber + "and with Param providerNameDegree: " + providerNameDegree + "and with Param providerAddress: " + providerAddress);
                if (providerNumber == null)
                    throw new ArgumentNullException(VariableConstant.ProviderNumber);
                if (direction == null)
                    throw new ArgumentNullException(VariableConstant.Direction);

                if (!string.IsNullOrWhiteSpace(phoneNumber))
                {
                    phoneNumber = phoneNumber.Replace("-", "");
                }

                string smsGateway = string.Empty;
                if (carrier != null)
                {
                    if (!(string.IsNullOrEmpty(phoneNumber)))
                    {
                        smsGateway = carrier.Replace(VariableConstant.CarrierNumber, phoneNumber + VariableConstant.Character);
                        if (!CommonHelper.ValidateEmail(smsGateway))
                        {
                            throw new System.Exception(ExceptionMessageConstant.Email);
                        }
                    }
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                Aetna.ProviderContracts.DataContracts.Provider provider = new Aetna.ProviderContracts.DataContracts.Provider();
                if (!CommonHelper.ValidateEmail(emailAddress))
                {
                    throw new System.Exception(ExceptionMessageConstant.Email);
                }

                char[] splitchar = { ApplicationConstants.SplitString };
                string[] providerNumberIndex = providerNumber.Split(splitchar);

                string errorMessage = string.Empty;
                if (!ValidateCaptcha(captcha, out errorMessage))
                {
                    traceLog.AppendLine(" & End: LocateProviderController, GetDirection Method");
                    return Json(errorMessage);
                }
                else
                {
                    bool send = false;
                    string culture = ReturnCultureInfo();

                    string errorLogSenderEmail;

                    if (Session[NABWebsite.Helper.SessionConstant.SearchRequest] != null)
                    {
                        NABWebsite.DTO.SearchRequestEntity searchRequest1 = new NABWebsite.DTO.SearchRequestEntity();

                        searchRequest = Session[NABWebsite.Helper.SessionConstant.SearchRequest] as NABWebsite.DTO.SearchRequestEntity;

                        if (searchRequest.NetworkType.NetworkId == "1")
                        {
                            errorLogSenderEmail = ConfigurationManager.AppSettings["FromCofinityReportInfo"];
                            send = EmailSendHelper.ReturnMapDetails(searchRequest, direction, provider, emailAddress, smsGateway, providerNumberIndex, providerNameDegree, providerAddress, culture, errorLogSenderEmail);
                            TempData["SendSuccess"] = VariableConstant.Success;
                            traceLog.AppendLine(" & End: LocateProviderController, GetDirection Method");
                            return Json(send);

                        }
                        else
                        {
                            errorLogSenderEmail = ConfigurationManager.AppSettings["LocateProviderSendFrom"];
                            send = EmailSendHelper.ReturnMapDetails(searchRequest, direction, provider, emailAddress, smsGateway, providerNumberIndex, providerNameDegree, providerAddress, culture, errorLogSenderEmail);
                            TempData["SendSuccess"] = VariableConstant.Success;
                            traceLog.AppendLine(" & End: LocateProviderController, GetDirection Method");
                            return Json(send);

                        }
                    }
                    traceLog.AppendLine(" & End: LocateProviderController, GetDirection Method");
                    return Json(send);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Sending Text Without MapQuest api call
        /// </summary>
        /// <param name="direction"></param>
        /// <param name="emailAddress"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult MapDetailsSendText(string email, string phoneNumberCarrier, string phoneNumber, string captcha, string providerNumber, string providerNameDegree, string providerAddress)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, MapDetailsSendText Method with Param email: " + email + "and with Param phoneNumberCarrier: " + phoneNumberCarrier + "and with Param phoneNumber: " + phoneNumber + "and with Param captcha: " + captcha + "and with Param providerNumber: " + providerNumber + "and with Param providerNameDegree: " + providerNameDegree + "and with Param providerAddress: " + providerAddress);

                if (providerNumber == null)
                {
                    throw new ArgumentNullException(VariableConstant.ProviderNumber);
                }
                if (!string.IsNullOrWhiteSpace(phoneNumber))
                {
                    phoneNumber = phoneNumber.Replace("-", "");
                }
                string smsGateway = string.Empty;
                if (phoneNumberCarrier != null)
                {
                    if (!(string.IsNullOrEmpty(phoneNumber)))
                    {
                        smsGateway = phoneNumberCarrier.Replace(VariableConstant.CarrierNumber, phoneNumber + VariableConstant.Character);
                    }
                }
                char[] splitchar = { ApplicationConstants.SplitString };
                string[] providerNumberIndex = providerNumber.Split(splitchar);
                Aetna.ProviderContracts.DataContracts.Provider provider = new Aetna.ProviderContracts.DataContracts.Provider();
                if (!CommonHelper.ValidateEmail(email))
                {
                    throw new System.Exception(ExceptionMessageConstant.Email);
                }

                string errorMessage = string.Empty;
                if (!ValidateCaptcha(captcha, out errorMessage))
                {
                    traceLog.AppendLine(" & End: LocateProviderController, MapDetailsSendText Method");
                    return Json(errorMessage);
                }
                else
                {
                    SearchRequestEntity searchRequest = new SearchRequestEntity();
                    searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                    if (searchRequest == null)
                    {
                        TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                        traceLog.AppendLine(" & End: LocateProviderController, MapDetailsSendText Method");
                        return Json("sessionTimeOut");
                    }
                    if (!new CommonHelper().Validate(searchRequest))
                    {
                        throw new System.Exception(ExceptionMessageConstant.SearchRequest);
                    }
                    bool send = false;
                    string culture = ReturnCultureInfo();
                    send = EmailSendHelper.ReturnMapDetailsSendText(searchRequest, provider, email, smsGateway, providerNumberIndex, providerNameDegree, providerAddress, culture);
                    TempData["SendSuccess"] = "Success";
                    traceLog.AppendLine(" & End: LocateProviderController, MapDetailsSendText Method");
                    return Json(send);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Get value of current culture
        /// </summary>
        /// <returns></returns>
        private string ReturnCultureInfo()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, ReturnCultureInfo Method");
                string culture = AppSettingHelper.GetAppSettingValue(CookieConstant.InitialCulture);
                //HttpCookie cookie = Request.Cookies[CookieConstant.Culture];
                var cookie = Session[CookieConstant.Culture];
                if (cookie != null)
                {
                    if (cookie.ToString() == AppSettingHelper.GetAppSettingValue(CookieConstant.CheckCulture))
                    {
                        culture = AppSettingHelper.GetAppSettingValue(CookieConstant.NewCulture);
                    }
                }
                traceLog.AppendLine(" & End: LocateProviderController, ReturnCultureInfo Method");
                return culture;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Fetches count of current tagged provider's count
        /// </summary>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetTaggedProviderCount()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetTaggedProviderCount Method");
                int countOfTagged = 0;
                List<string> sessionTag = Session[SessionConstant.TaggedProvider] as List<string>;
                if (sessionTag != null)
                {
                    countOfTagged = sessionTag.Count();
                }
                traceLog.AppendLine(" & End: LocateProviderController, GetTaggedProviderCount Method");
                return Json(countOfTagged);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Make session of searchcriteria object null and Navigate to search criteria page  for fresh search
        /// </summary>
        /// <returns></returns>
        public ActionResult NavigateNewLocateProviderSearch()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, NavigateNewLocateProviderSearch Method");
                Session[SessionConstant.TaggedComparedProvider] = null;
                Session[SessionConstant.ComparedProvider] = null;
                Session[SessionConstant.TaggedProvider] = null;
                Session[SessionConstant.SortingPagingInfo] = null;
                Session[SessionConstant.TaggedSortingPagingInfo] = null;
                Session[SessionConstant.SearchRequest] = null;
                traceLog.AppendLine(" & End: LocateProviderController, NavigateNewLocateProviderSearch Method");
                return RedirectToAction(ApplicationConstants.LocateProviderSearchAction);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// set values of current controller and action
        /// </summary>
        /// <param name="controller"></param>
        /// <param name="actionMethod"></param>
        void SetActiveControllerToSession(string controller, string actionMethod)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, SetActiveControllerToSession Method with Param controller: " + controller + "and with Param actionMethod: " + actionMethod);
                if (Session[SessionConstant.CurrentController] != null && Session[SessionConstant.CurrentAction] != null)
                {
                    if (!(Session[SessionConstant.CurrentController].ToString().Equals(controller) && Session[SessionConstant.CurrentAction].ToString().Equals(actionMethod)))
                    {
                        Session[SessionConstant.CurrentController] = controller;
                        Session[SessionConstant.CurrentAction] = actionMethod;
                    }
                }
                else
                {
                    Session[SessionConstant.CurrentController] = controller;
                    Session[SessionConstant.CurrentAction] = actionMethod;
                }
                traceLog.AppendLine(" & End: LocateProviderController, SetActiveControllerToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// download file for external link
        /// Edited by NAB-IT on 10 April 2018 to encode the input parameter
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult ProviderFileDownload(string id)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, ProviderFileDownload Method with Param id: " + id);
                id = id.Replace("\\", "").Replace("..", "");//Added on 19-Jul-18 to fix Path Traversal
                string filePath = ConfigurationManager.AppSettings["ProviderPdfForEmail"];
                string dFilName = string.Empty;
                Byte[] cover = System.IO.File.ReadAllBytes(filePath + "\\" + AntiXssEncoder.HtmlEncode(id, false));
                var cd = new System.Net.Mime.ContentDisposition
                {
                    FileName = id + ".pdf",
                    Inline = true,
                };
                Response.AppendHeader("Content-Disposition", cd.ToString());
                traceLog.AppendLine(" & End: LocateProviderController, ProviderFileDownload Method");
                return File(cover, "application/pdf");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// download file for external link for email
        /// Edited by NAB-IT on 10 April 2018 to encode the input parameter
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult ProviderFileDownloadForEmail(string id)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, ProviderFileDownloadForEmail Method with Param id: " + id);
                id = id.Replace("\\", "").Replace("..", "");//Added on 19-Jul-18 to fix Path Traversal
                string filePath = ConfigurationManager.AppSettings["DirectoryPath"];
                string dFilName = string.Empty;
                Byte[] cover = System.IO.File.ReadAllBytes(filePath + "\\" + AntiXssEncoder.HtmlEncode(id, false));
                var cd = new System.Net.Mime.ContentDisposition
                {
                    FileName = id + ".pdf",
                    Inline = true,
                };
                Response.AppendHeader("Content-Disposition", cd.ToString());
                traceLog.AppendLine(" & End: LocateProviderController, ProviderFileDownloadForEmail Method");
                return File(cover, "application/pdf");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Return Custom network name
        /// </summary>
        /// <param name="clientCode"></param>
        /// <returns></returns>
        [CustomOutputCacheAttribute("CacheDuration1800_All")]
        private string GetNetworkNameFromCode(string clientCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, GetNetworkNameFromCode Method with Param clientCode: " + clientCode);
                if (!CommonHelper.ValidateGenericValue(clientCode))
                    throw new ArgumentNullException(VariableConstant.ClientCode, VariableConstant.InvalidClientCode);
                string network = "";
                ManageContent contentManager = new ManageContent();
                RequestHeader request = new CommonHelper().GetRequestHeader(string.Empty, defaultSourceId);
                network = contentManager.GetNetworkNameFromCode(clientCode, request);
                traceLog.AppendLine(" & End: LocateProviderController, GetNetworkNameFromCode Method");
                return network;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion


        #region Implementation of IDisposable

        // some fields that require cleanup
        private bool disposed = false; // to detect redundant calls
        /// <summary>
        /// GC clean up
        /// </summary>
        public void Dispose()
        {
            StringBuilder traceLog = new StringBuilder();

            try
            {
                traceLog.AppendLine("Start: LocateProviderController, Dispose Method");
                Console.WriteLine("Dispose");
                Dispose(true);
                GC.SuppressFinalize(this);
                traceLog.AppendLine(" & End: LocateProviderController, Dispose Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// The bulk of the clean-up code is implemented in Dispose(bool)
        /// </summary>
        /// <param name="disposing"></param>

        protected override void Dispose(bool disposing)
        {
            StringBuilder traceLog = new StringBuilder();

            try
            {
                traceLog.AppendLine("Start: LocateProviderController, Dispose Method with Param disposing: " + disposing);
                if (!disposed)
                {
                    if (disposing)
                    {
                        //left blank as there is no managed resources
                    }
                    disposed = true;
                }
                traceLog.AppendLine(" & End: LocateProviderController, Dispose Method");
                base.Dispose(disposing);

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                // throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion

        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Renders My AssociatedProvider page
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult AssociatedProvider()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderController, AssociatedProvider Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderController, AssociatedProvider Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (searchRequest == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, AssociatedProvider Method");
                        return RedirectToAction(ApplicationConstants.CustomPage);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderController, AssociatedProvider Method");
                        return RedirectToAction(ApplicationConstants.SelectNetworkTypeAction);
                    }
                }
 
                LocateProviderSearchResultViewModel locateProviderSearchResultViewModel = new LocateProviderSearchResultViewModel();
                SortingPagingInfo sortingPagingInfo = new SortingPagingInfo();
                sortingPagingInfo.SortField = AppSettingHelper.GetAppSettingValue(VariableConstant.SortField);
                sortingPagingInfo.SortDirection = AppSettingHelper.GetAppSettingValue(VariableConstant.SortDirection);
                SearchResult searchResult = GetTaggedProviders();
                if (searchResult != null)
                {

                    if (Session[SessionConstant.TaggedSortingPagingInfo] != null)
                    {
                        sortingPagingInfo = Session[SessionConstant.TaggedSortingPagingInfo] as SortingPagingInfo;
                        sortingPagingInfo.TotalRecords = searchResult.ProviderMatchCount;
                    }
                    else
                    {
                        sortingPagingInfo.CurrentPageIndex = 0;
                        sortingPagingInfo.PageSize = AppSettingHelper.ReturnValue(VariableConstant.PageSize);
                    }
                    sortingPagingInfo.TotalRecords = searchResult.ProviderMatchCount;
                    sortingPagingInfo.PageCount = (Convert.ToInt32(locateProviderSearchResultViewModel.SearchResult.ProviderMatchCount) / 20) + 1;
                    ViewBag.SortingPagingInfo = sortingPagingInfo;
                    SetActiveControllerToSession(ApplicationConstants.LocateProviderController, ApplicationConstants.TaggedProvidersAction);
                    traceLog.AppendLine(" & End: LocateProviderController, AssociatedProvider Method");
                    return View(locateProviderSearchResultViewModel);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderController, AssociatedProvider Method");
                    return RedirectToAction(ApplicationConstants.LocateProviderSearchAction, ApplicationConstants.LocateProviderController);
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private List<TXFacilityProvider> GetTXFacilityProviders(string specialityId, string providerInfo)
        {


            char[] splitchar = { ApplicationConstants.SplitString };
            string[] providerNumberIndex = providerInfo.Split(splitchar);
            var providerNum = providerNumberIndex[0];
            var locationId = providerNumberIndex[1].Replace("-", "/");

            ManageContent contentManager = new ManageContent();
            SearchRequestEntity searchRequest = new SearchRequestEntity();
            var facilityProvider = new List<TXFacilityProvider>();
            searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
            if (!string.IsNullOrEmpty(specialityId))
            {
                var specId = Convert.ToInt32(specialityId);
                int networkId = Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture);
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, networkId);

                facilityProvider = contentManager.GetFacilityProvider(request, providerNum, locationId, specId).ToList();
            }
            return facilityProvider;
        }
    }
}
