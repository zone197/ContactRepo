﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace NABWebsite.Models
{
    public class UserRegistration
    {
        public IEnumerable<RegistrationNetworkList> NetworkListRef { get; set; }
        public string NetworkSelected { get; set; }
       public string CustomerTypeChosen { get; set; }
       public IEnumerable<RegistrationCustomerTypeList> CustomerTypeList { get; set; }
       public IEnumerable<RegistrationNetworkAccessList> NetworkAccessListRef { get; set; }
       public string NetworkAccessSelected { get; set; }
       public string ProviderTypeSelected { get; set; }
       public string Tins { get; set; }
       public string PracticeEmailAddress { get; set; }
       public string PayerNames { get; set; }
        public string FirstName { get; set; }
        public string MiddleInitial { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public string EmailAddress { get; set; }
        public string CompanyName { get; set; }
        public string DivisionMailstop { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyCity { get; set; }
        public string CompanyState { get; set; }
        public IEnumerable<SelectListItem> CompanyStateDropDown { get; set; }
        public string ZipCode { get; set; }
        public string BusinessPhone { get; set; }
        public string Ext { get; set; }
        public string NetworkContactName { get; set; }
        public string Comments { get; set; }
        public IEnumerable<string> UserNameList { get; set; }
        public string UserName { get; set; }
        public bool AgreeCheck { get; set; }
        public string Signature { get; set; }
        public string Prd { get; set; }// Updated on 18-Jul-18 to Fix Heap Inspection
        public string ConfirmPrd { get; set; }// Updated on 19-Jul-18 to Fix Heap Inspection
        public IEnumerable<SelectListItem> SecurityQuestion1List { get; set; }
        public IEnumerable<SelectListItem> SecurityQuestion2List { get; set; }
        public IEnumerable<SelectListItem> SecurityQuestion3List { get; set; }
        public string SecurityQuestion1Selected { get; set; }
        public string SecurityQuestion2Selected { get; set; }
        public string SecurityQuestion3Selected { get; set; }
        public string SecurityAnswer1 { get; set; }
        public string SecurityAnswer2 { get; set; }
        public string SecurityAnswer3 { get; set; }
        public string RecaptchaPublicKey { get; set; }
        public string GoogleRecaptchaAPIAddressSingle { get; set; }
        public string Hosturl { get; set; }
        public string LinkId { get; set; }

    }

    public class RegistrationNetworkList
    {
        public bool NetworkChosenType { get; set; }
        public string NetworkChosenValue { get; set; }
        public string NetworkChosenDisplay { get; set; }

    }

    public class RegistrationCustomerTypeList
    {
        public string CustomerChosenValue { get; set; }
        public string CustomerChosenDisplay { get; set; }

    }

    

    public class RegistrationNetworkAccessList
    {
        public bool NetworkAccessChosenType { get; set; }
        public string NetworkAccessChosenValue { get; set; }
    }
}

