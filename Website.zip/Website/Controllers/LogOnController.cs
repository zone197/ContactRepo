﻿using Aetna.Cofinity.Admin.Entities.Response;
using CofinityEncryption;
using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Helper;
using NABWebsite.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.SessionState;
using Utilities;


namespace NABWebsite.Controllers
{
    public class LogOnController : Controller
    {
        LogOnBLL bllObj = new LogOnBLL();
        private int fromNumber;
        private int toNumber;
        private int numberOfRandomNumbersRequired;

        private bool bypassADAuthentication
        {
            get
            {
                bool returnValue = false;
                string bypassAD = ConfigurationManager.AppSettings["BypassADAuthentication"];
                if (!bool.TryParse(bypassAD, out returnValue))
                    bypassAD = "false";

                return returnValue;
            }
        }

        // GET: Login
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            LayoutViewModel modelObject = new LayoutViewModel();
            UserImageCheck userImage = new UserImageCheck();
            
            try
            {
                traceLog.AppendLine("Start: LogonController, Index Method");
            if (((UserDetails)Session[Constants.UserDetails]).UserId == null)
            {
                    traceLog.AppendLine(" & End: LogonController, Index Method");
                return RedirectToAction("Index", "Home");
            }
            if (((UserDetails)Session[Constants.UserDetails]).UserId != null)
            {
                userImage = bllObj.CheckForUserSecureImage(((UserDetails)Session[Constants.UserDetails]).UserId.ToString(), ConfigurationManager.AppSettings[Constants.Site]);
            }
            if (!string.IsNullOrEmpty(userImage.Userid))
            {
                Session["InvalidUser"] = null;
                modelObject.SelectedImageId = userImage.SecureImage;
                modelObject.ImageCaption = userImage.SecureImageTitle;
                if (!string.IsNullOrEmpty(modelObject.ImageCaption) && modelObject.SelectedImageId != 0)
                {
                    modelObject.SecureImage = bllObj.GetSecureImageById(modelObject.SelectedImageId);
                }
                else
                {
                    modelObject.SkipCount = Convert.ToInt32((userImage.SecureImageTitle == "") ? "0" : userImage.SecureImageTitle);
                    modelObject.SecureImageListRef = bllObj.FetchImageList().ToList();
                }
            }
            else
            {
                Session["InvalidUser"] = "Invalid User";
                int invalidImageCount = bllObj.FetchInvalidImageCount();
                List<int> randomnumbers = GetRandomNumber(1, invalidImageCount, 1);
                modelObject.SecureImage = bllObj.GetSecureInvalidImage(randomnumbers[0]);
                modelObject.ImageCaption = modelObject.SecureImage.ImageTitle;
            }
            traceLog.AppendLine(" & End: LogonController, Index Method");
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
           
            return View(modelObject);

            
        }

        public ActionResult FetchImage(LayoutViewModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LogonController, FetchImage Method with Param modelObject: " + modelObject);
            if (modelObject != null)
            {
                modelObject.SecureImageListRef = bllObj.FetchImageList().ToList();
            }
                traceLog.AppendLine(" & End: LogonController, FetchImage Method");
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            
            return PartialView("_ImageList", modelObject);
        }

        public ActionResult ForgotPassword()
        {
            return View();
        }

        private List<int> GetRandomNumber(int fromNumberValue, int toNumberValue, int numberOfRandomNumbers)
        {
            StringBuilder traceLog = new StringBuilder();
            List<int> randomNumbers = new List<int>();
            try
            {
                traceLog.AppendLine("Start: LogonController, GetRandomNumber Method with Param fromNumberValue: " + fromNumberValue + " and with Param toNumberValue: " + toNumberValue + " and with Param numberOfRandomNumbers: " + numberOfRandomNumbers);
            this.fromNumber = fromNumberValue;
            this.toNumber = toNumberValue;
            this.numberOfRandomNumbersRequired = numberOfRandomNumbers;
            for (int i = 0; i < numberOfRandomNumbersRequired; i++)
            {
                int rnumber = CommonHelper.GetSecureRandom(fromNumber, toNumber);//Added on 24 Sept, 2018 to fix Weak PRNG
                if (!randomNumbers.Contains(rnumber))
                {
                    randomNumbers.Add(rnumber);
                }
                else
                {
                    numberOfRandomNumbersRequired = numberOfRandomNumbersRequired + 1;
                }
            }
                traceLog.AppendLine(" & End: LogonController, GetRandomNumber Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return randomNumbers;

        }

        /// <summary>
        /// Create the UserDetails Session and store the UserId to be used futher
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns>success = true and failure = false</returns>
        public JsonResult SaveUserId(String UserId)
        {

            StringBuilder traceLog = new StringBuilder();
            traceLog.AppendLine(" SaveUserId start");
            UserId = Microsoft.Security.Application.Encoder.LdapFilterEncode(UserId);//Added on 20-Jul-18 to fix LDAP
            string message = string.Empty;
            try
            {
                traceLog.AppendLine("Start: LogonController, SaveUserId Method with Param UserId: " + UserId);

                UserDetails userDetails = new UserDetails();
                userDetails.UserId = UserId;
                Session[Constants.UserDetails] = userDetails;
                userDetails = null;

                if (!bypassADAuthentication)
                {
                    bllObj.ValidateReset(UserId, out message);
                    if (message == "")
                    {
                        message = "";
                    }
                    else if (message == "ACCOUNTNEEDSCHANGEPASSWORD")
                    {
                        message = "3";
                    }
                    else
                        message = "2";
                }
                else
                    message = "2";

                traceLog.AppendLine(" & End: LogonController, SaveUserId Method");
            }
            catch (Exception ex)
            {
                message = string.Empty;
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }


            return Json(message, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Authenticate the userid/pwd. 
        /// Success: Load the userdetail in the session. Failure: Log the invalid attempt in user DB
        /// Then send to home page to show invalid userid/pwd
        /// </summary>
        /// <returns></returns>        
        
        [AjaxValidateAntiForgeryToken]        
        public JsonResult LogOn(LayoutViewModel layoutObject, String prd)
        {

            StringBuilder traceLog = new StringBuilder();
            traceLog.AppendLine(" Logon Method start");
            //prd = Microsoft.Security.Application.Encoder.LdapFilterEncode(prd);//Added on 20-Jul-18 to fix LDAP
            Boolean isUserAuthenticated = false;
            String message = String.Empty;
            String SamAccountName = String.Empty;
            
            try
            {
                traceLog.AppendLine("Start: LogonController, LogOn Method with Param layoutObject: " + layoutObject + "and Param prd: " + prd);
                //Authenticate userid/pwd and on successfull authentication load user data
                //If UserId is invalid in AD then return InvalidUserIdPassword message. Also increase the invalid attempt count in session variable.
                //else
                if (Session["InvalidUser"] != null)
                {
                    traceLog.AppendLine("LogOn Method : check if user is invalid or not");
                    if (Session["InvalidUser"].ToString() == "Invalid User")
                    {
                        traceLog.AppendLine("LogOn Method :  if user is invalid");
                        isUserAuthenticated = false;
                    }
                        
                }
                else
                {
                    traceLog.AppendLine("LogOn Method : if user is valid");
                    if (bypassADAuthentication) // validate with AD Auth only if explicitly set so in config
                    {
                        traceLog.AppendLine("LogOn Method : validating Ad Authentication and set userAuthenticated to true");
                        isUserAuthenticated = true;
                    }                        
                    else
                    {
                        traceLog.AppendLine("LogOn Method : Call isAdAuthenticated method and get Authentication status with message");
                        isUserAuthenticated = isADAuthenticated(Helper.AESEncrypt.DecryptStringAES(prd), out message);
                        
                        Helper.AESEncrypt.RandNum = string.Empty;
                    }
                }
                bool ImageValidity = checkImageValidity(layoutObject);
                traceLog.AppendLine("LogOn Method : Checked that if user is authenticated or not");

                if (isUserAuthenticated && ImageValidity)
                {
                    traceLog.AppendLine("LogOn Method : if user is authenticate and set the userdetail as authenticated"); 
                    //Set the UserDetails as authenticated
                    ((UserDetails)Session[Constants.UserDetails]).IsAuthenticated = isUserAuthenticated;
                    
                    //Load the userdetail in the session.
                    AuthorizeResponse authorizeResponse = bllObj.LoadUserDetails(((UserDetails)Session[Constants.UserDetails]).UserId);
                    if (authorizeResponse.UserData != null)
                    {
                        traceLog.AppendLine("LogOn Method : if userData is not null then update user data in session");
                        ((UserDetails)Session[Constants.UserDetails]).UserData = authorizeResponse.UserData;
                    }

                    bool validUser = false;
                    
                    Session[Constants.FairCostAccess] = false;
                    if (authorizeResponse.Roles != null && authorizeResponse.Roles.FirstOrDefault() != null)
                    {
                        traceLog.AppendLine("LogOn Method : if Roles are not null then set the  roles in session");
                         ((UserDetails)Session[Constants.UserDetails]).UserRoles = authorizeResponse.Roles;
                        foreach (var role in authorizeResponse.Roles)
                        {
                            if (role.Functions != null && role.Functions.Count() > 0)
                            {
                                if (role.FunctionSensors.ContainsKey("FairCost QPA Assist(Payer)"))
                                {
                                   Session[Constants.FairCostAccess] = true;
                                }
                                
                                validUser = true;
                                break;
                            }
                        }
                    }
                    traceLog.AppendLine("LogOn Method : Checked that if user is valid or not");
                    if (validUser)
                    {
                        traceLog.AppendLine("LogOn Method : if user is valid then set the active menu and active pages if attributeName is ISACTIVE");
                        // Edited by NAB-IT to fill the list of deactivepages
                        List<string> activePages = new List<string>();
                        List<SensorType> activemenu = new List<SensorType>();
                        List<SensorType> ProviderActiveMenu = new List<SensorType>();
                        foreach (var roles in authorizeResponse.Roles)
                        {
                            foreach (var functionsensors in roles.FunctionSensors)
                            {
                                foreach (var attributes in functionsensors.Value)
                                {
                                    if (attributes.SensorGroupName.ToUpper().Equals(("Page-" + functionsensors.Key).ToUpper()))
                                    {
                                        foreach (var attribute in attributes.AttributesList)
                                        {
                                            if (attribute.AttributeName.ToUpper() == "ISACTIVE" && attribute.AttributeValue.ToUpper() == "TRUE")
                                            {
                                                activePages.Add(functionsensors.Key);
                                                foreach (var functions in roles.Functions)
                                                {
                                                    if (functions.SensorGroupName.ToUpper().Equals(("menu-" + functionsensors.Key).ToUpper()))
                                                    {

                                                        if (roles.RoleName.ToUpper().Equals("PROVIDER"))
                                                        {
                                                            ProviderActiveMenu.Add(functions);
                                                            Session["ProviderActiveMenuList"] = ProviderActiveMenu;
                                                        }
                                                        else
                                                        {
                                                            activemenu.Add(functions);
                                                            Session["ActiveMenuList"] = activemenu;
                                                        }
                                                    }
                                                }
                                                Session["ACTIVEPAGELIST"] = activePages;
                                            }
                                        }
                                    }

                                }
                            }
                        }

                        //Set USer first log in image
                        UserRegistrationBLL user = new UserRegistrationBLL();
                        user.InsertLoggedUser(Session.SessionID, ((UserDetails)Session[Constants.UserDetails]).UserId, ConfigurationManager.AppSettings[Constants.website], this.Request.UserHostAddress);
                        traceLog.AppendLine("LogOn Method : details of logged in user is inserted in the class");
                        loginAudit();
                        if (layoutObject.RemindMeLater)
                        {
                            traceLog.AppendLine("LogOn Method : if remind me later variable is true then set the image caption by skiping first and update security image details");
                            string imageCaption = (layoutObject.SkipCount + 1).ToString();
                            int imageId = layoutObject.SelectedImageId;
                            bllObj.UpdateSecurityImageDetails(((UserDetails)Session[Constants.UserDetails]).UserId, ConfigurationManager.AppSettings[Constants.Site], imageId, imageCaption, Constants.No);
                        }
                        else
                        {
                            traceLog.AppendLine("LogOn Method : if set first image is false");
                            if (layoutObject.SetFirstImage)
                            {
                                traceLog.AppendLine("LogOn Method : if set first image is true then set the image caption and update security image details");
                                int imageId = layoutObject.SelectedImageId;
                                string imageCaption = layoutObject.ImageCaption;
                                bllObj.UpdateSecurityImageDetails(((UserDetails)Session[Constants.UserDetails]).UserId, ConfigurationManager.AppSettings[Constants.Site], imageId, imageCaption, Constants.Yes);
                            }
                        }
                     
                        if (Session.SessionID != Request.Cookies["ASP.NET_SessionId"].Value)
                        {
                            Session.Clear();
                            Session.Abandon();
                            Session.RemoveAll();
                            Session[Constants.Userid] = null;
                            Session[Constants.SessionPrd] = null;
                            Session[Constants.LoggedUserid] = null;
                            Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                            Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddDays(-1);
                            Response.Cookies.Add(new System.Web.HttpCookie("ASP.NET_SessionId"));
                        }
                        else
                        {
                            SessionIDManager manager = new SessionIDManager();
                            string newSessionId = manager.CreateSessionID(System.Web.HttpContext.Current);
                            Session[Constants.SessionId] = newSessionId;
                            Request.Cookies["ASP.NET_SessionId"].Value = newSessionId;
                            traceLog.AppendLine("LogOn Method : a new Session Id is created ");
                            Session[Constants.LogOnAttemptCount] = null;
                            Session["InvalidUser"] = null;
                        }
                    }
                    else
                    {
                        traceLog.AppendLine("LogOn Method : if User is invalid");
                        if (message != Constants.AccountNeedsChangePrd)
                        {
                            traceLog.AppendLine("LogOn Method : if account is not need to change the password then increment the deny attempt count");
                            TempData[Constants.InvalidLogOn] = Constants.InvalidUserIdPrd;
                            Session[Constants.UserDetails] = null;
                            incrementDenyAttemptCount();
                            message = Constants.InvalidUserIdPrd;
                            if (isMaxAttempt())
                            {
                                traceLog.AppendLine("LogOn Method : if maximum login attempt exceeded then abandon the session");
                                Session.Abandon();
                                message = "Max Attempt exceeded";
                            }
                        }
                    }
                }
                else
                {
                    traceLog.AppendLine("LogOn Method : if user is not authenticated");
                    //Log the invalid attempt in user DB
                    //Clear the Session[UserDetails] for next attempt
                    if (message != Constants.AccountNeedsChangePrd)
                    {
                        traceLog.AppendLine("LogOn Method : if account is not need to change the password then increment the deny attempt count");
                        TempData[Constants.InvalidLogOn] = Constants.IncorrectPrd;
                        incrementDenyAttemptCount();
                        message = Constants.InvalidUserIdPrd;
                        if (isMaxAttempt())
                        {
                            traceLog.AppendLine("LogOn Method : if maximum attempt exceeded");
                            message = "Max Attempt exceeded";
                        }
                    }
                }
                traceLog.AppendLine(" & End: LogonController, LogOn Method");
            }

            catch (Exception ex)
            {
                Session.Abandon();
                TempData[Constants.InvalidLogOn] = Constants.IncorrectPrd;
                incrementDenyAttemptCount();
                message = Constants.InvalidUserIdPrd;
                if (isMaxAttempt())
                {
                    message = "Max Attempt exceeded";
                }
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

            return Json(message, JsonRequestBehavior.AllowGet);
        }

        //Checking the Image and Image Id for login
        public bool checkImageValidity(LayoutViewModel layoutObject)
        {
            UserImageCheck userImage = new UserImageCheck();
            userImage = bllObj.CheckForUserSecureImage(((UserDetails)Session[Constants.UserDetails]).UserId.ToString(), ConfigurationManager.AppSettings[Constants.Site]);
           if ((userImage.SecureImage == 0) || (userImage.SecureImageTitle == layoutObject.ImageCaption && userImage.SecureImage == layoutObject.SelectedImageId))
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }
        public ActionResult ChangePassword()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LogonController, ChangePassword Method: ");
                MyProfileModel modelObj = new MyProfileModel();
                modelObj.MyProfile = new MyProfile();
                traceLog.AppendLine(" & End: LogonController, ChangePassword Method: ");
                return View(modelObj);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }
        }

        [HttpPost]
        public ActionResult SaveChangePassword(MyProfileModel modelObj)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LogonController, SaveChangePassword Method with Param modelObj: " + modelObj);
                string message = string.Empty;
                string userId = string.Empty;
                string userType = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site].ToString()))
                    userType = ConfigurationManager.AppSettings[Constants.Site].ToString();
                if (modelObj != null && !string.IsNullOrEmpty(userId))
                {
                    modelObj.MyProfile.OldPrd = Helper.AESEncrypt.DecryptStringAES(modelObj.MyProfile.OldPrd);
                    modelObj.MyProfile.NewPrd = Helper.AESEncrypt.DecryptStringAES(modelObj.MyProfile.NewPrd);
                    modelObj.MyProfile.NewPrdAgain = Helper.AESEncrypt.DecryptStringAES(modelObj.MyProfile.NewPrdAgain);
                    Helper.AESEncrypt.RandNum = string.Empty;

                    modelObj.MyProfile.Userid = userId;
                    modelObj.MyProfile.UserType = userType;
                    if (validatePassword(modelObj))
                    {
                        if (updatePassword(modelObj, out message))
                        {
                            sendMail(modelObj.MyProfile.Userid, modelObj.MyProfile.UserType);
                            return Content(Constants.ContentPrdChanged);
                        }
                        else
                            return Content("<script type='text/javascript'>  alert('" + message + "'); window.location='/Home/Index';</script>");
                    }
                }
                traceLog.AppendLine(" & End: LogonController, SaveChangePassword Method");

                return Content(Constants.ContentInvalidUser);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// update password
        /// </summary>
        /// <param name="modelObj"></param>
        /// <returns></returns>
        private bool updatePassword(MyProfileModel modelObj, out string message)
        {
            StringBuilder traceLog = new StringBuilder();
            message = string.Empty;
            bool check = false;
            try
            {
                traceLog.AppendLine("Start: LogonController, updatePassword Method with Param modelObj: " + modelObj);
                LogOnBLL objBll = new LogOnBLL();
                MyProfileBLL bllObj = new MyProfileBLL();
                modelObj.MyProfile.OldPrd = NABEncryption.Encrypt(modelObj.MyProfile.OldPrd);
                modelObj.MyProfile.NewPrd = NABEncryption.Encrypt(modelObj.MyProfile.NewPrd);

                if (ConfigurationManager.AppSettings[Constants.Site].ToUpperInvariant() == Constants.External.ToUpperInvariant())
                    check = objBll.UpdateExternalUserPassword(modelObj.MyProfile.Userid, modelObj.MyProfile.OldPrd, modelObj.MyProfile.NewPrd, out message);
                else if (ConfigurationManager.AppSettings[Constants.Site].ToUpperInvariant() == Constants.Internal.ToUpperInvariant())
                    check = objBll.UpdateInternalUserPassword(modelObj.MyProfile.Userid, modelObj.MyProfile.OldPrd, modelObj.MyProfile.NewPrd, out message);

                if (check)
                    check = check && bllObj.UpdateSecurityPassword(modelObj.MyProfile);
                traceLog.AppendLine(" & End: LogonController, updatePassword Method");
            }
            catch (Exception ex)
            {
                check = false;
                LogManager.WriteErrorLog(ex);
            }

            finally
            {
                traceLog.Append(message.ToString());
                LogManager.WriteTraceLog(traceLog);
            }
            return check;
        }

        /// <summary>
        /// validates th password
        /// </summary>
        /// <param name="modelObj"></param>
        /// <returns></returns>
        private bool validatePassword(MyProfileModel modelObj)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LogonController, validatePassword Method with Param modelObj: " + modelObj);

                if (string.IsNullOrEmpty(modelObj.MyProfile.OldPrd) || modelObj.MyProfile.NewPrd != modelObj.MyProfile.NewPrdAgain
                    || modelObj.MyProfile.NewPrd.Length < 8 || !modelObj.MyProfile.NewPrd.Any(char.IsLower)
                    || !modelObj.MyProfile.NewPrd.Any(char.IsUpper) || !modelObj.MyProfile.NewPrd.Any(char.IsNumber))
                {
                    traceLog.AppendLine(" & End: LogonController, validatePassword Method");
                    return false;
                }
                else
                {
                    traceLog.AppendLine(" & End: LogonController, validatePassword Method");
                return true;
            }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// send mail to user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userType"></param>
        private void sendMail(string userId, string userType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LogonController, sendMail Method with Param userId: " + userId + " and with Param userType: " + userType);
                MyProfileBLL bllObj = new MyProfileBLL();
                User objUser = new User();
                objUser = bllObj.GetUserDetails(userId, userType);
                if (objUser != null)
                {
                    string profileUserName = objUser.FirstName + " " + objUser.LastName;
                    string[] email = new string[1];
                    email[0] = objUser.Email;
                    string subject = Constants.EmailProfileSubject;
                    string body = getEmailBody(profileUserName);
                    bllObj.SendMail(email, subject, body);
                }
                traceLog.AppendLine(" & End: LogonController, sendMail Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Generate email message content
        /// </summary>
        /// <param name="UserName"></param>
        /// <returns></returns>
        private string getEmailBody(string userName)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LogonController, getEmailBody Method with Param userName: " + userName);
                StringBuilder mailBody = new StringBuilder();
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.TableHeader);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.EmailProfileHeader);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.ContactImmediatelyText);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.SubmittedBy);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.EmailProfileName + userName);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.EmailProfileDate + System.DateTime.Now.Date.ToShortDateString());
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.TableEnd);

                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);

                mailBody.Append(Constants.TableHeader);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.EmailProfileThankYou);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.CofinityLabel);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.RowStart);
                mailBody.Append(Constants.EmailProfileFooter);
                mailBody.Append(Constants.RowEnd);
                mailBody.Append(Constants.TableEnd);
                traceLog.AppendLine(" & End: LogonController, getEmailBody Method with Param userName: " + userName);
                return mailBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Autheticate if the user has a valid AD entry
        /// </summary>
        /// <param name="logonModel"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        private Boolean isADAuthenticated(String password, out String message)
        {
            StringBuilder traceLog = new StringBuilder();
            message = string.Empty;
            Boolean authenticationStatus = false;
            try
            {
                traceLog.AppendLine("Start: LogonController, isADAuthenticated Method with param password:" + password);
                message = string.Empty;
                //call BLL to validate from AD directory
                if (((UserDetails)Session[Constants.UserDetails]) != null && !(String.IsNullOrEmpty(password)))
                {
                    string userId = Microsoft.Security.Application.Encoder.LdapFilterEncode(((UserDetails)Session[Constants.UserDetails]).UserId);
                    authenticationStatus = bllObj.ValidateUser(userId, NABEncryption.Encrypt(password), out message);
                } 
                traceLog.AppendLine(" & End: LogonController, isADAuthenticated Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                traceLog.Append(message.ToString());
                LogManager.WriteTraceLog(traceLog);
            }
            return authenticationStatus;
        }

        private void loginAudit()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LogonController, loginAudit Method");
            LogonActivity activity = new LogonActivity();
            activity.ApplicationName = ConfigurationManager.AppSettings[Constants.website];
            activity.userType = ConfigurationManager.AppSettings[Constants.Site];
            activity.Userid = ((UserDetails)Session[Constants.UserDetails]).UserId;
            activity.UserName = ((UserDetails)Session[Constants.UserDetails]).UserId;
            activity.Roleid = 1;
            activity.RoleGroupid = 1;
            activity.SessionID = Session.SessionID;
            activity.hostAddress = Request.UserHostAddress;
            UserRegistrationBLL user = new UserRegistrationBLL();
            user.LoginAudit(activity);
                traceLog.AppendLine(" & End: LogonController, loginAudit Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private void incrementDenyAttemptCount()
        {
            StringBuilder traceLog = new StringBuilder();
            int delay = 0;
            int attemptMade = 0;

            try
            {
                traceLog.AppendLine("Start: LogonController, incrementDenyAttemptCount Method");
            if (Session[Constants.LogOnAttemptCount] == null)
            {
                attemptMade = 1;
                Session[Constants.LogOnAttemptCount] = 1;
            }
            else
            {
                attemptMade = Convert.ToInt32(Session[Constants.LogOnAttemptCount]) + 1;
                Session[Constants.LogOnAttemptCount] = attemptMade;
            }

            delay = attemptMade * 6000;

            if (delay > 0)
                System.Threading.Thread.Sleep(delay);

                traceLog.AppendLine(" & End: LogonController, incrementDenyAttemptCount Method");
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private bool isMaxAttempt()
        {
            StringBuilder traceLog = new StringBuilder();
            int maxAttempt = Convert.ToInt32(ConfigurationManager.AppSettings["AllowedMaxAttempt"]);
            try
            {
                traceLog.AppendLine("Start: LogonController, isMaxAttempt Method");
            if (Session[Constants.LogOnAttemptCount] != null)
            {
                int attemptMade = Convert.ToInt32(Session[Constants.LogOnAttemptCount]);
                if (attemptMade >= maxAttempt)
                    return true;
                else
                    return false;
            }
                traceLog.AppendLine(" & End: LogonController, isMaxAttempt Method");
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

             finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return false;
        }
    }
}