﻿using System;
using System.Text;
using System.Web.Mvc;
using Utilities;

namespace NABWebsite
{

    public static class HtmlExtensions
    {
        
        public static MvcHtmlString Image(this HtmlHelper html, byte[] image, string imgmap)   //Todo: use param to filter image whetater with imgmap or not
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HtmlExtensions, Image Method with Param html: " + html + " and with Param image: " + image+" and with Param imgmap: "+imgmap);
                var img = String.Format("data:image/jpg;base64,{0}", Convert.ToBase64String(image));
                var imgsrc = "<img src='" + img + "' width='100%'  usemap='#logo' alt='Cofinity' />";
                if (!string.IsNullOrEmpty(imgmap))
                { imgsrc = "<img src='" + img + "' width='100%'  usemap='#logo' alt='Cofinity' />"; }
                else
                { imgsrc = "<img src='" + img + "' width='100%' alt='Cofinity'  />"; }
                traceLog.AppendLine(" & End: HtmlExtensions, Image Method");
                return new MvcHtmlString(imgsrc);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        public static MvcHtmlString Image(this HtmlHelper html, byte[] image)   //Todo: use param to filter image whetater with imgmap or not
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HtmlExtensions, Image Method with Param html: "+html+" and with Param image: "+image);
                var img = String.Format("data:image/jpg;base64,{0}", Convert.ToBase64String(image));
                traceLog.AppendLine(" & End: HtmlExtensions, Image Method");
                return new MvcHtmlString(img);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
    
    }
}