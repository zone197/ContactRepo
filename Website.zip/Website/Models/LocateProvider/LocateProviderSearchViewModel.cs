﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;
using Aetna.ProviderContracts.DataContracts;
using System.Collections.ObjectModel;

namespace NABWebsite.Models.LocateProvider
{
    public class LocateProviderSearchViewModel
    {
       public List<ProviderType> ListProviderType { get; set; }
       public List<State> ListState { get; set; }
       public List<Condition> ListCondition { get; set; }
        public List<Specialty> ListSpecialty { get; set; }
        public List<Focus> ListFocus { get; set; }
        public ProviderTypes ProviderType { get; set; }
        public List<City> CityList { get; set; }
        public List<County> CountyList { get; set; }
        public int SearchNetworkId { get; set; }
        public SearchRequestEntity SearchRequest { get; set; }
        public SearchRequestEntity RefineRequest { get; set; }
        private List<string> zipCodeList = new List<string>();
        public List<string> ZipCodeList { get { return zipCodeList; } }
        public string ZipLookupSiteUrl { get; set; }
        public string AcceptingNewpatients { get; set; }
    }
}