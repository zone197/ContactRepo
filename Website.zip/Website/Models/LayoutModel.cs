﻿using NABWebsite.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NABWebsite.Models
{
    public class LayoutModel
    {
        [AllowHtml]
        //public HeaderClass HeaderComponents { get; set; }
        //public List<MenuClass> Menus { get; set; }
        //public FooterClass FooterInfo { get; set; }
        public string hosturl { get; set; }
        public List<StateDisclaimerEntity> StateDisclaimerList { get; set; }
        public List<UserManualEntity> UserManualList { get; set; }
    }
}