﻿$(function () {
    $("#detailedProvider").tabs();
});