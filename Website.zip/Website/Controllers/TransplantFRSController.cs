﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System.Collections;
using System.Configuration;
using System.Collections.ObjectModel;
using System.Data;
using System.Globalization;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using System.ServiceModel;
using System.Text;
using Utilities;

namespace NABWebsite.Controllers
{
    public class FacilityRateSummaryController : Controller
    {
        TransplantBusinessLayer objTransplantBll = null;
        private string ageGroup;
        private string transplantType;
        private string pin;
        private string zipCode;
        private int radius;
        private int pageNumber;
        private int displaySize;
        private string selectedStates;
        private string transplantTypeId;
        private string selectedFields;
        DataTable dtChild = new DataTable();
        DataTable resultDataTableChild = new DataTable();
        //StringBuilder traceLog = new StringBuilder();

        public FacilityRateSummaryController()
        {
            resultDataTableChild.Locale = CultureInfo.InvariantCulture;
            dtChild.Locale = CultureInfo.InvariantCulture;
            
        }
        /// <summary>
        /// Facility Rate Summary lookup
        /// </summary>
        /// <returns></returns>
        [CheckAccess(Function = "Facility-rate summary")]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, Index Method");
                TransplantFacilityModel modelObject = new TransplantFacilityModel();
                modelObject.PayerFacilityRateSummary = (IEnumerable<PayerFacilityRateSummary>)TransplantBusinessLayer.PayerFacilityRateSummary();
                Session[Constants.SelectedListIdForExportOption] = null;
                Session[Constants.SelectedListValueForExportOption] = null;
                traceLog.AppendLine(" & End: FacilityRateSummaryController, Index Method");
                return View("PayerFacilityRatesummary", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// To Populate facility rate summary selection criteria view
        /// </summary>
        /// <returns></returns>   
        [CheckAccess(Function = "Facility-rate summary")]
        public ActionResult PayerFacilityRateSummary()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, PayerFacilityRateSummary Method");
                TransplantFacilityModel modelObject = new TransplantFacilityModel();
                modelObject.PayerFacilityRateSummary = (IEnumerable<PayerFacilityRateSummary>)TransplantBusinessLayer.PayerFacilityRateSummary();
                if (modelObject.PayerFacilityRateSummary == null)
                    throw new FaultException(Constants.ApplicationError);
                Session[Constants.SelectedListIdForExportOption] = null;
                Session[Constants.SelectedListValueForExportOption] = null;
                traceLog.AppendLine(" & End: FacilityRateSummaryController, PayerFacilityRateSummary Method");
                return View("PayerFacilityRatesummary", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// To Populate facility rate summary result -zipsearch
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AjaxValidateAntiForgeryToken]        
        public ActionResult SearchResult(string ageGroupValue, string transplantTypeValue, string zipCodeValue, int pageNumberValue, int displaySizeValue,string formMenu)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, SearchResult Method with Param ageGroupValue: " + ageGroupValue + " and with Param transplantTypeValue: " + transplantTypeValue + " and with Param zipCodeValue: " + zipCodeValue + " and with Param pageNumberValue: " + pageNumberValue + " and with Param  displaySizeValue:" + displaySizeValue + " and with Param formMenu: " + formMenu);
                this.ageGroup = ageGroupValue;
                this.transplantType = transplantTypeValue;
                this.zipCode = zipCodeValue;
                this.pageNumber = pageNumberValue;
                this.displaySize = displaySizeValue;
                this.radius = Convert.ToInt32(ConfigurationManager.AppSettings[Constants.Radius], CultureInfo.CurrentCulture);
                if (!string.IsNullOrEmpty(formMenu))
                {
                    Session[Constants.SelectedListIdForExportOption] = null;
                    Session[Constants.SelectedListValueForExportOption] = null;
                }
                TransplantFacilityModel modelObject = new TransplantFacilityModel();
                objTransplantBll = new TransplantBusinessLayer();
                modelObject.SearchResultParameter = new SearchResultFilterValue();
                if (pageNumber == 0)
                    modelObject.SearchResultParameter.PageNo = Constants.OneCount;
                else
                    modelObject.SearchResultParameter.PageNo = pageNumber;

                ZipCodeDetailsList result = (ZipCodeDetailsList)objTransplantBll.SearchResult(ageGroup, transplantType == Constants.BMT ? NABResources.Resources.BMT_PSCT : transplantType, zipCode, radius, pageNumber, displaySize);
                modelObject.FacilityRate = new TransplantFacilityRateSummary();
                modelObject.FacilityRate.CriteriaSelected = transplantType + Constants.CommaWithSpace + ageGroup + Constants.CommaWithSpace + zipCode;

                if (result.ZipSearchResults != null)
                {
                    if (result.ZipSearchResults.Count() > 0)
                    {
                        modelObject.ZipSearchResults = result.ZipSearchResults;
                        modelObject.SearchResultParameter.TotalPages = result.TotalPages == 0 ? 1 : result.TotalPages;
                    }
                }
                else
                    modelObject.Message = result.ErrorMessage;

                modelObject.FacilityRate.AgeGroup = ageGroup;
                modelObject.FacilityRate.SelectedTransplantType = transplantType;
                modelObject.FacilityRate.ZipCode = zipCode;
                modelObject.DisplaySize = displaySize.ToString(CultureInfo.CurrentCulture);
                modelObject.FacilityRate.LocationBy = Constants.Zipcode;
                traceLog.AppendLine(" & End: FacilityRateSummaryController, SearchResult Method");
                return PartialView("MapSearchResult", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// To load maps with states based on the age group and selected transplant type selection made bn user
        /// </summary>
        /// <param name="ageGroup"></param>
        /// <param name="selectedTransplantType"></param>
        /// <returns></returns>
        [HttpPost]
        [AjaxValidateAntiForgeryToken]        
        public ActionResult LoadMapStates(string ageGroupValue, string selectedTransplantType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, LoadMapStates Method with Param ageGroupValue: " + ageGroupValue + " and with Param selectedTransplantType: " + selectedTransplantType);
                this.ageGroup = ageGroupValue;
                this.transplantType = selectedTransplantType;
                objTransplantBll = new TransplantBusinessLayer();
                IEnumerable<StateName> stateChecked = objTransplantBll.FetchAllStates(ageGroup, transplantType.Equals(Constants.BMT) ? NABResources.Resources.BMT_PSCT : transplantType);
                List<String> stateCheckedList = new List<string>();
                if (stateChecked != null)
                {
                    foreach (var StateName in stateChecked)
                    {
                        stateCheckedList.Add(StateName.State);
                    }
                    string stringStates = Constants.Quotetion + String.Join(Constants.CommaWithQuotetion, stateCheckedList.ToArray()) + Constants.Quotetion;
                    stringStates = stringStates.Replace(Constants.Quotetion, Constants.QuotetionWithSlash);
                    Session[Constants.States] = stringStates;
                }
                else
                    Session[Constants.States] = null;
                traceLog.AppendLine(" & End: FacilityRateSummaryController, LoadMapStates Method");
                return PartialView();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Show page when report is successfully generated through IOE service 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [AjaxValidateAntiForgeryToken]        
        public int IndividualCompareReports(string compareFields, string ageGroupValue, string transplantTypeValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, IndividualCompareReports Method with Param compareFields: " + compareFields + " and with Param ageGroupValue: " + ageGroupValue + " and with Param transplantTypeValue: " + transplantTypeValue);
                int success = 0;
                if (!string.IsNullOrEmpty(compareFields) && !string.IsNullOrEmpty(ageGroupValue) &&
                    !string.IsNullOrEmpty(transplantTypeValue))
                {
                    FacilityListSplit(compareFields);
                    IEnumerable<PayerFacilityRateSummary> result = TransplantBusinessLayer.PayerFacilityRateSummary();
                    string selectedTransplantId = (result).FirstOrDefault(m => m.Description == transplantTypeValue).CategoryId;
                    objTransplantBll = new TransplantBusinessLayer();
                    success = objTransplantBll.IndividualSummaryReport(ageGroupValue, ((UserDetails)Session[Constants.UserDetails]).UserId.ToString(), pin, selectedTransplantId);
                }
                traceLog.AppendLine(" & End: FacilityRateSummaryController, IndividualCompareReports Method");
                return success;
            }
            catch (Exception )
            {
                
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Prepare the comparison report
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [AjaxValidateAntiForgeryToken]        
        public int ComparisonGrid(string compareFields, string ageGroupValue, string transplantTypeValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, ComparisonGrid Method with Param compareFields: " + compareFields + " and with Param ageGroupValue: " + ageGroupValue + " and with Param transplantTypeValue: " + transplantTypeValue);
                int success = 0;
                if (!string.IsNullOrEmpty(compareFields) && !string.IsNullOrEmpty(ageGroupValue) &&
                    !string.IsNullOrEmpty(transplantTypeValue))
                {
                    FacilityListSplit(compareFields);
                    string selectedTransplantId = ((IEnumerable<PayerFacilityRateSummary>)TransplantBusinessLayer.PayerFacilityRateSummary()).FirstOrDefault(m => m.Description == transplantTypeValue).CategoryId;
                    objTransplantBll = new TransplantBusinessLayer();
                    success = objTransplantBll.ComparisonGrid(ageGroupValue, ((UserDetails)Session[Constants.UserDetails]).UserId.ToString(), pin, selectedTransplantId);
                }
                traceLog.AppendLine(" & End: FacilityRateSummaryController, ComparisonGrid Method");
                return success;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private void FacilityListSplit(string compareFields)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, FacilityListSplit Method with Param compareFields: " + compareFields);
                string[] facilityListSplit = compareFields.Substring(0, compareFields.Length - 1).Split(Constants.Comma);
                for (int i = 0; i <= facilityListSplit.Length - 1; i++)
                {
                    string[] OrganPinSplit = facilityListSplit[i].Split(Constants.SplitWithHyphen);
                    if (OrganPinSplit.Length >= 2)
                    {
                        for (int j = 0; j <= OrganPinSplit.Length - 1; j++)
                        {
                            if (i == 0)
                            {
                                pin = OrganPinSplit[0];
                                break;
                            }
                            else
                            {
                                pin = pin + Constants.CommaWithoutSpace + OrganPinSplit[0];
                                break;
                            }
                        }
                    }
                }
                traceLog.AppendLine(" & End: FacilityRateSummaryController, FacilityListSplit Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        
        /// <summary>
        /// To load states in session
        /// </summary>
        /// <param name="selectedRows"></param>
        /// <param name="pageNumber"></param>
        [AjaxValidateAntiForgeryToken]
        public void SessionData(int pageNumber, string selectedRowsId, string selectedRowsValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, SessionData Method with Param pageNumber: " + pageNumber + " and with Param selectedRowsId: " + selectedRowsId + " and with Param selectedRowsValue: " + selectedRowsValue);
                Dictionary<int, string> selectedId = (Dictionary<int, string>)Session[Constants.SelectedListIdForExportOption];
                Dictionary<int, string> selectedValue = (Dictionary<int, string>)Session[Constants.SelectedListValueForExportOption];
                if (selectedId == null)
                    selectedId = new Dictionary<int, string>();
                if (selectedValue == null)
                    selectedValue = new Dictionary<int, string>();
                if (pageNumber > 0)
                {
                    if (selectedId.ContainsKey(pageNumber))
                    {
                        selectedId.Remove(pageNumber);
                    }
                    if (selectedValue.ContainsKey(pageNumber))
                    {
                        selectedValue.Remove(pageNumber);
                    }
                    if (!string.IsNullOrEmpty(selectedRowsId) && !string.IsNullOrEmpty(selectedRowsValue))
                    {
                        selectedId.Add(pageNumber, selectedRowsId);
                        selectedValue.Add(pageNumber, selectedRowsValue);
                    }
                }
                Session[Constants.SelectedListIdForExportOption] = selectedId;
                Session[Constants.SelectedListValueForExportOption] = selectedValue;
                traceLog.AppendLine(" & End: FacilityRateSummaryController, SessionData Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// check selected states
        /// </summary>
        /// <param name="pageNumber"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult CheckStateValues(int pageNumber)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, CheckStateValues Method with Param pageNumber: " + pageNumber);
                Dictionary<int, string> selected = (Dictionary<int, string>)Session[Constants.SelectedListIdForExportOption];
                string loadSelectedStates = string.Empty;
                string[] selectedStates = null;
                if (selected != null)
                {
                    if (selected.ContainsKey(pageNumber))
                    {
                        loadSelectedStates = selected[pageNumber];
                    }
                    if (!string.IsNullOrEmpty(loadSelectedStates))
                    {
                        selectedStates = loadSelectedStates.Substring(0, loadSelectedStates.Length - 1).Split(Constants.Comma);
                    }
                }
                traceLog.AppendLine(" & End: FacilityRateSummaryController, CheckStateValues Method");
                return Json(selectedStates, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Load session data
        /// </summary>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]        
        public string LoadSession()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, LoadSession Method");
                Dictionary<int, string> selected = (Dictionary<int, string>)Session[Constants.SelectedListValueForExportOption];
                int key = 0;
                StringBuilder selectedStates = new StringBuilder();

                if (selected != null && selected.Count > 0)
                {
                    key = selected.Keys.Max();
                    for (int i = 0; i <= key; i++)
                    {
                        if (selected.ContainsKey(i))
                        {
                            selectedStates.Append(selected[i].Substring(0, selected[i].Length - 1) + Constants.Comma);
                        }
                    }
                }
                traceLog.AppendLine(" & End: FacilityRateSummaryController, CheckStateValues Method");
                return selectedStates.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// A generic error page for failed in export reports
        /// </summary>
        /// <returns></returns>        
        public ActionResult GenericReportPage()
        {
            return View();
        }
        /// <summary>
        /// To Populate facility rate summary result -StateMap Search
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AjaxValidateAntiForgeryToken]
        public ActionResult MapSearchResult(string ageGroupValue, string transplantTypeValue, string selectedStatesValue, int pageNumberValue, int displaySizeValue, string formMenu)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, MapSearchResult Method with Param ageGroupValue: " + ageGroupValue + " and with Param transplantTypeValue: " + transplantTypeValue + " and with Param selectedStatesValue: " + selectedStatesValue + " and with Param pageNumberValue: " + pageNumberValue + " and with Param displaySizeValue: " + displaySizeValue + "and with Param formMenu: " + formMenu);
                this.ageGroup = ageGroupValue;
                this.transplantType = transplantTypeValue;
                this.selectedStates = selectedStatesValue;
                this.pageNumber = pageNumberValue;
                this.displaySize = displaySizeValue;
                if (!string.IsNullOrEmpty(formMenu))
                {
                    Session[Constants.SelectedListIdForExportOption] = null;
                    Session[Constants.SelectedListValueForExportOption] = null;
                }
                TransplantFacilityModel modelObject = new TransplantFacilityModel();
                modelObject.SearchResultParameter = new SearchResultFilterValue();

                if (pageNumber == 0)
                    modelObject.SearchResultParameter.PageNo = Constants.OneCount;
                else
                    modelObject.SearchResultParameter.PageNo = pageNumber;
                objTransplantBll = new TransplantBusinessLayer();
                StateDetailsList result = (StateDetailsList)objTransplantBll.MapSearchResult(ageGroup, transplantType == Constants.BMT ? NABResources.Resources.BMT_PSCT : transplantType, selectedStates, pageNumber, displaySize);

                modelObject.FacilityRate = new TransplantFacilityRateSummary();
                modelObject.FacilityRate.CriteriaSelected = transplantType + Constants.CommaWithSpace + ageGroup + Constants.CommaWithSpace + selectedStates;
                if (result != null)
                {
                    modelObject.ZipSearchResults = result.MapSearchResults;
                    modelObject.SearchResultParameter.TotalPages = result.TotalPages == 0 ? 1 : result.TotalPages;
                }
                else
                {
                    modelObject.Message = NABResources.Resources.lblNoDataFound;
                }
                modelObject.DisplaySize = displaySize.ToString(CultureInfo.CurrentCulture);
                modelObject.FacilityRate.AgeGroup = ageGroup;
                modelObject.FacilityRate.SelectedTransplantType = transplantType;
                modelObject.FacilityRate.SubmittedStatesValue = selectedStates;
                modelObject.FacilityRate.LocationBy = Constants.MapId;
                traceLog.AppendLine(" & End: FacilityRateSummaryController, MapSearchResult Method");

                return PartialView("MapSearchResult", modelObject);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        /// <summary>
        /// To load all state Regions
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AjaxValidateAntiForgeryToken]        
        public ActionResult LoadStateRegion()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, LoadStateRegion Method");
                TransplantFacilityModel FacilityModel = null;
                Dictionary<string, List<StateRegion>> finalList = null;
                IEnumerable<StateRegion> stateChecked = TransplantBusinessLayer.FetchStateRegion();
                if (stateChecked != null)
                {
                    FacilityModel = new TransplantFacilityModel();
                    finalList = new Dictionary<string, List<StateRegion>>();
                    //Form the groups based on regions
                    finalList = (from t in stateChecked
                                 group t by t.RegionDescription
                                     into groupedStateList
                                     select groupedStateList).ToDictionary(gsl => gsl.Key, gsl => gsl.ToList());
                }
                FacilityModel.StateRegionResult = finalList;
                traceLog.AppendLine(" & End: FacilityRateSummaryController, LoadStateRegion Method");
                return PartialView(FacilityModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Navigates to the CustomizeOnline page where user can customize the fileds
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AjaxValidateAntiForgeryToken]        
        public ActionResult CustomizeOnline(string criteriaSelected,string compareFields, 
            string ageGroup,string selectedTransplantType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, CustomizeOnline Method with Param criteriaSelected: " + criteriaSelected + " and with Param compareFields: " + compareFields + " and with Param ageGroup: " + ageGroup + "and with Param selectedTransplantType: " + selectedTransplantType);
                TransplantFacilityModel modelObjectValue = new TransplantFacilityModel();
                modelObjectValue = BindFieldsData();
                if (modelObjectValue == null)
                    throw new FaultException(Constants.ApplicationError);
                modelObjectValue.FacilityRate = new TransplantFacilityRateSummary();
                if (string.IsNullOrEmpty(criteriaSelected)
                    || string.IsNullOrEmpty(compareFields)
                    || string.IsNullOrEmpty(ageGroup)
                    || string.IsNullOrEmpty(selectedTransplantType))
                {
                    throw new FaultException(Constants.ApplicationError);
                }
                modelObjectValue.FacilityRate.CriteriaSelected = criteriaSelected;
                modelObjectValue.CompareFields = compareFields;
                modelObjectValue.FacilityRate.AgeGroup = ageGroup;
                modelObjectValue.FacilityRate.SelectedTransplantType = selectedTransplantType;
                traceLog.AppendLine(" & End: FacilityRateSummaryController, CustomizeOnline Method");
                return PartialView("CustomizeOnlinePartialView", modelObjectValue);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// CustomizeOnline Report
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]        
        public ActionResult CustomizeOnlineReport(TransplantFacilityModel modelObject)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, CustomizeOnlineReport Method with Param modelObject: " + modelObject);
                TransplantFacilityModel modelObjectValue = new TransplantFacilityModel();
                modelObjectValue.FacilityRate = new TransplantFacilityRateSummary();
                if (modelObject != null)
                {
                    CustomizeOnlineList specifiedList = new JavaScriptSerializer().Deserialize<CustomizeOnlineList>(modelObject.SelectedOptionsCustomize);
                    CustomizeOnlineList OptionalList = new JavaScriptSerializer().Deserialize<CustomizeOnlineList>(modelObject.OptionsAvailable);
                    string _selectField = GetListItemsReport(specifiedList, Constants.TextWord);
                    string _fieldsSelected = GetListItemsReport(OptionalList, Constants.TextWord);
                    string[] facilityListSplit = modelObject.CompareFields.Substring(0, modelObject.CompareFields.Length - 1).Split(Constants.Comma);//modelObject.CompareFields[0].Split(Constants.Comma);
                    for (int i = 0; i <= facilityListSplit.Length - 1; i++)
                    {
                        string[] OrganPinSplit = facilityListSplit[i].Split(Constants.SplitWithHyphen);
                        if (OrganPinSplit.Length >= 2)
                        {
                            for (int j = 0; j <= OrganPinSplit.Length - 1; j++)
                            {
                                if (i == 0)
                                {
                                    pin = OrganPinSplit[0];
                                    transplantType = OrganPinSplit[1];
                                    break;
                                }
                                else
                                {
                                    pin = pin + Constants.CommaWithoutSpace + OrganPinSplit[0];
                                    break;
                                }
                            }
                        }
                    }
                    this.ageGroup = modelObject.FacilityRate.AgeGroup;
                    modelObjectValue.FacilityRate.CriteriaSelected = modelObject.FacilityRate.SelectedTransplantType + Constants.CommaWithSpace + modelObject.FacilityRate.AgeGroup;
                    modelObjectValue.FacilityRate.AgeGroup = modelObject.FacilityRate.AgeGroup;
                    modelObjectValue.FacilityRate.SelectedTransplantType = modelObject.FacilityRate.SelectedTransplantType;
                    modelObjectValue.PinSelected = pin;
                    modelObjectValue.OrgansSelected = transplantType;
                    modelObjectValue.OptionsAvailable = _fieldsSelected;
                    modelObjectValue.SelectedOptionsCustomize = _selectField;
                    objTransplantBll = new TransplantBusinessLayer();
                    IEnumerable<TransplantTypeCombined> transplantTypeCombined = objTransplantBll.GetAllTransplantTypes(ageGroup, transplantType, pin);
                    Collection<SelectListItem> transplantList = new Collection<SelectListItem>();
                    if (transplantTypeCombined != null)
                    {
                        foreach (var organ in transplantTypeCombined)
                        {
                            SelectListItem list = new SelectListItem();
                            list.Text = organ.Description;
                            list.Value = organ.Combined;
                            transplantList.Add(list);
                        }
                    }
                    modelObjectValue.TransplantType = transplantList;
                    string[] splitSelectedOrgan = null;
                    if (modelObjectValue.TransplantType != null)
                    {
                        foreach (var SelectedOrgan in modelObjectValue.TransplantType)
                        {
                            splitSelectedOrgan = SelectedOrgan.Value.Split(Constants.SplitWithOr);
                            break;
                        }
                    }
                    if (splitSelectedOrgan != null)
                    {
                        pin = splitSelectedOrgan[0];
                        transplantType = splitSelectedOrgan[1].Trim();
                    }
                    DataTable resultTable = objTransplantBll.GetAllTransplantRateSheetRep(ageGroup, transplantType, pin, _selectField);
                    if (resultTable == null || resultTable.Rows.Count <= 0)
                        throw new FaultException(Constants.ApplicationError);
                    DataTable flipTable = objTransplantBll.FlipDataTable(resultTable);
                    if (flipTable == null || flipTable.Rows.Count <= 0)
                        throw new FaultException(Constants.ApplicationError);
                    modelObjectValue.ResultTable = flipTable;
                    if (modelObjectValue.FacilityRate.SelectedTransplantType.Equals(Constants.BMT))
                    {
                        this.transplantTypeId = Constants.Two;
                    }
                    else { this.transplantTypeId = Constants.One; }
                    for (int j = 0; j <= flipTable.Rows.Count - 1; j++)
                    {
                        string strUserSelect = flipTable.Rows[j][0].ToString();
                        for (int i = 1; i <= flipTable.Columns.Count - 1; i++)
                        {
                            if (strUserSelect.Equals(Constants.Evaluation) || strUserSelect.Equals(Constants.PreTransplantCandidacy) || strUserSelect.Equals(Constants.TransplantEvent) || strUserSelect.Equals(Constants.FollowUpCare))
                            {
                                dtChild = objTransplantBll.GetChildStub(strUserSelect, pin.ToString(), transplantTypeId);
                                if (resultDataTableChild.Columns.Count == 0)
                                {
                                    resultDataTableChild = dtChild.Clone();
                                }
                                foreach (DataRow dr in dtChild.Rows)
                                {
                                    resultDataTableChild.Rows.Add(dr.ItemArray);
                                }
                                break;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    if (resultDataTableChild.Rows.Count > 0)
                    { modelObjectValue.ChildTable = resultDataTableChild; }

                    modelObjectValue.CopyrightsInformation = TransplantBusinessLayer.FetchDescription();
                }
                traceLog.AppendLine(" & End: FacilityRateSummaryController, CustomizeOnlineReport Method");
                return View(modelObjectValue);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        
        private string GetListItemsReport(CustomizeOnlineList list, string fieldType)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, GetListItemsReport Method with Param list: " + list + " and with Param fieldType: " + fieldType);
                selectedFields = string.Empty;
                if (list != null && !string.IsNullOrEmpty(fieldType))
                {
                    foreach (CustomizeOptions FieldType in list.Data)
                    {
                        if (fieldType.Equals(Constants.ValueWord))
                        {
                            selectedFields += FieldType.Value.TrimStart().TrimEnd() + Constants.CommaWithoutSpace;
                        }
                        else if (fieldType.Equals(Constants.TextWord))
                        {
                            selectedFields += FieldType.Text.TrimStart().TrimEnd() + Constants.CommaWithSpace;
                        }
                    }
                }
                if (!string.IsNullOrEmpty(selectedFields))
                {
                    traceLog.AppendLine(" & End: FacilityRateSummaryController, GetListItemsReport Method");
                    return selectedFields = selectedFields.TrimEnd().TrimEnd(Constants.Comma);
                }
                else
                {
                    traceLog.AppendLine(" & End: FacilityRateSummaryController, GetListItemsReport Method");
                    return selectedFields;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        
        private static TransplantFacilityModel BindFieldsData()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, BindFieldsData Method" );
            TransplantFacilityModel modelObject = new TransplantFacilityModel();
            Collection<SelectListItem> SpecificList = new Collection<SelectListItem>();
            Collection<SelectListItem> OptionalList = new Collection<SelectListItem>();
            String[] specificArrayList = TransplantBusinessLayer.PopulateRequiredSpecificList();
            if (specificArrayList != null)
            {
                for (int i = 0; i <= specificArrayList.Length - 1; i++)
                {
                    SelectListItem field = new SelectListItem();
                    String[] splitArrReq = specificArrayList[i].ToString().Split(new char[] { Constants.SplitWithOr });
                    field.Text = splitArrReq[0].ToString();
                    field.Value = splitArrReq[1].ToString();
                    SpecificList.Add(field);
                }
            }
            modelObject.SpecificFieldList = SpecificList;
            String[] optionalArrayList = TransplantBusinessLayer.PopulateRequiredOptionalList();
            if (optionalArrayList != null)
            {
                for (int i = 0; i <= optionalArrayList.Length - 1; i++)
                {
                    SelectListItem field = new SelectListItem();
                    String[] splitArrOpt = optionalArrayList[i].ToString().Split(new char[] { Constants.SplitWithOr });
                    field.Text = splitArrOpt[0].ToString();
                    field.Value = splitArrOpt[1].ToString();
                    OptionalList.Add(field);
                }
            }
            modelObject.OptionalFieldList = OptionalList;
            traceLog.AppendLine(" & End: FacilityRateSummaryController, BindFieldsData Method");
            return modelObject;
        }
        catch (Exception ex)
        {
            LogManager.WriteErrorLog(ex);
            throw;
        }
        finally
        {
            LogManager.WriteTraceLog(traceLog);
        }
        }
        
        /// <summary>
        /// Get reports file content
        /// </summary>
        /// <param name="fileId"></param>
        /// <returns></returns>
        [CheckAccess(Function = "My Downloads")]
        public ActionResult DownloadSecuredFileContent(int fileId, string fileName)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: FacilityRateSummaryController, DownloadSecuredFileContent Method with Param fileId: " + fileId + " and with Param fileName: " + fileName);
                objTransplantBll = new TransplantBusinessLayer();
                ClientSecureDocumentFileContent result = null;
                if (fileId > 0 && !String.IsNullOrEmpty(fileName))
                {
                    result = objTransplantBll.DownloadSecuredFileContent(fileId);
                }
                if (result == null)
                    throw new FaultException(Constants.ApplicationError);
                traceLog.AppendLine(" & End: FacilityRateSummaryController, DownloadSecuredFileContent Method");
                return File(result.FileContent, "application/octet-stream", fileName);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

    }
}