﻿using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Helper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Script.Serialization;
using CofinityEncryption;

namespace NABWebsite
{
    public class MvcApplication : System.Web.HttpApplication
    {
        private const string blockIPAdr = "BlockIPAddress";

        private string clientIPAddress
        {
            get
            {
                string forwardedFor = "HTTP_X_FORWARDED_FOR", remoteAdr = "REMOTE_ADDR", nonStdLocalIP = "::1", stdIP = "127.0.0.1";
                string clientIp = (Request.ServerVariables[forwardedFor] ?? Request.ServerVariables[remoteAdr]).Split(',')[0].Trim();
                if (clientIp == nonStdLocalIP)
                    clientIp = stdIP;
                return clientIp;
            }
        }

        //Added by NAB-IT on 22May2018 for Cacheable HTTPS (SSL) Response
        protected void Application_BeginRequest()
        {
            HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.Cache.SetNoStore();
            Response.Cache.SetExpires(DateTime.Now);
            Response.Cache.SetValidUntilExpires(true);

            Response.Headers.Remove("Server");
            Response.Headers.Remove("X-AspNet-Version");
            Response.Headers.Remove("X-AspNetMvc-Version");

        }

        //Added by NAB-IT on 22May2018 for Security Related Directives Not Set On Session Cookies
        protected void Application_EndRequest()
         {
             string authCookie = System.Web.Security.FormsAuthentication.FormsCookieName;
             foreach (string sCookie in Response.Cookies)
             {
                 if (sCookie == authCookie || sCookie == "ASP.NET_SessionId")
                 {
                     if (System.Environment.Version.Major < 2)
                     {
                         // Force HttpOnly to be added to the cookie header under 1.x
                         Response.Cookies[sCookie].Path += ";HttpOnly";
                     }
                 }
                 //Force all cookies to SSL regardless of web.config settings!
                 Response.Cookies[sCookie].Secure = Convert.ToBoolean(ConfigurationManager.AppSettings["SSLSecurityValue"]);
             }
        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            Application["AllowCustomURlFlag"] = Convert.ToString(ConfigurationManager.AppSettings["AllowCustomURlFlag"]);
            MvcHandler.DisableMvcResponseHeader = true; //this line is to hide mvc header
        }

        void Session_Start(object sender, EventArgs e)
        {
            #region Check blocked IP
            Session[SessionConstant.CookiePlanCode] = null;
            Session[SessionConstant.CustomHeader] = null;
            Session[SessionConstant.FullUrl] = null;
            Session["RelayUserName"] = NABEncryption.Decrypt(ConfigurationManager.AppSettings["RelayUserName"]);
            Session["RelayPassWord"] = NABEncryption.Decrypt(ConfigurationManager.AppSettings["RelayPassWord"]);
            Session["ReportRelayServiceUser"] = NABEncryption.Decrypt(ConfigurationManager.AppSettings["ReportRelayServiceUser"]);
            Session["ReportRelayServicePassword"] = NABEncryption.Decrypt(ConfigurationManager.AppSettings["ReportRelayServicePassword"]);
            bool checkIPFilter = Convert.ToBoolean(ConfigurationManager.AppSettings[blockIPAdr].ToString());
            if (checkIPFilter)
            {
                System.Net.ServicePointManager.ServerCertificateValidationCallback +=
                    (se, cert, chain, sslerror) =>
                    {
                        return true;
                    };

                (new ManageContent()).CheckBlockedIP(clientIPAddress, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()); // either this will return fine or will throw an exception which will get caught by Application_Error event
            }
            HttpContext.Current.Session[SessionConstant.FullUrl] = Convert.ToString(ConfigurationManager.AppSettings["HomeUrl_FH"]);
            Application["AllowCustomURlFlag"] = Convert.ToString(ConfigurationManager.AppSettings["AllowCustomURlFlag"]);
            
            SetDefaultCulture();
            #endregion
        }

        protected void Session_End(object sender, EventArgs e)
        {
            var homePage = Convert.ToString(ConfigurationManager.AppSettings["HomeUrl_FH"]);
            Response.Redirect(homePage + "Home/Index");
        }


        //<summary>
        //log error within application and redirect to custom error page
        //</summary>
        //<param name="sender"></param>
        //<param name="e"></param>
        protected void Application_Error(object sender, EventArgs e)
        {
            Exception ex = Server.GetLastError();
            HttpContextWrapper contextWrapper = new HttpContextWrapper(this.Context);

            if (ex != null) // this is to prevent a potential 2nd round event-triggering after HandleException does a Response.Redirect
            {
                bool terminateRequest = HandleException(ex);
                if (terminateRequest)
                {
                    Response.End();
                    return;
                }
            }
        }

        private bool HandleException(Exception e)
        {
            bool returnValue = false;
            try
            {


                LogError logerr = new LogError();
                logerr.LogTime = DateTime.Now.ToString();
                logerr.ErrorMessage = e.Message + "\n" + e.StackTrace;
                logerr.IP = clientIPAddress;
                logerr.ErrorType = Response.StatusCode.ToString();
                logerr.ErrorSource = e.Source.ToString();
                logerr.ErrorDbcon = ConfigurationManager.ConnectionStrings["appErrorLogDB"].ConnectionString.ToString();

                if (e != null)
                {
                    bool isBlockedIP = e.Data["TerminateRequest"] != null; // this will be true only in case of CheckBlockedIP method call
                    if (isBlockedIP)
                    {
                        logerr.ActionType = new List<ErrorAction>(new ErrorAction[] { ErrorAction.LogInDB, ErrorAction.SendMail });
                    }
                    else
                    {
                        logerr.ActionType = new List<ErrorAction>(new ErrorAction[] { ErrorAction.LogInDB });
                    }

                    // local logging
                    string enablelocalLogging = ConfigurationManager.AppSettings["EnableLocalLogging"];
                    if (!string.IsNullOrEmpty(enablelocalLogging) && enablelocalLogging.ToLower() == "true")
                        CommonHelper.LogErrorInTextFile(e);

                    LogApplicationException(Response, e, logerr);

                    // clear error on server
                    Server.ClearError();
                    returnValue = true;
                    if (isBlockedIP) // for blocked IP case
                    {
                        //Fixed Checkmarx issue of XSHM on dated 24-Sep-2018
                        string consonant = "a0b1c2d3e4f5g6h7i8j9klmnopqrstvuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

                        int length2 = CommonHelper.GetSecureRandom(1, 62);                        
                        Response.Redirect("~/AccessDenied.html?r=" + consonant.Substring(length2, 1));
                        //returnValue = true;
                    }
                    else // for all other exceptions
                    {
                        bool isAjaxCall = string.Equals("XMLHttpRequest", Context.Request.Headers["x-requested-with"], StringComparison.OrdinalIgnoreCase);
                        Context.ClearError();
                        if (isAjaxCall)
                        {
                            Context.Response.ContentType = "application/json";
                            Context.Response.StatusCode = 200;
                            Context.Response.Write(
                                new JavaScriptSerializer().Serialize(
                                    new { error = NABResources.Resources.lblApplicationErrorMessage }
                                )
                            );
                        }
                        else
                        {
                            //Fixed Checkmarx issue of XSHM on dated 24-Sep-2018
                            string consonant = "a0b1c2d3e4f5g6h7i8j9klmnopqrstvuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

                            int length2 = CommonHelper.GetSecureRandom(1, 62);                            
                            this.Response.Redirect("/Error/Index?r=" + consonant.Substring(length2, 1));
                        }
                    }
                }

                return returnValue;
            }
            catch (Exception ex)
            {
                return returnValue;
            }
        }

        /// <summary>
        /// log exception 
        /// </summary>
        /// <param name="response"></param>
        /// <param name="exception"></param>
        private static void LogApplicationException(HttpResponse response, Exception exception, LogError logerr)
        {
            Logger log = new Logger();

            log.logError(logerr);
        }

        protected void SetDefaultCulture()
        {
            string culture = "en-us";
            HttpContext.Current.Session[CookieConstant.Culture] = culture;
        }
    }

    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
    public sealed class NoCacheAttribute : FilterAttribute, IResultFilter
    {
        public void OnResultExecuting(ResultExecutingContext filterContext)
        {
        }

        public void OnResultExecuted(ResultExecutedContext filterContext)
        {
            HttpContext.Current.Response.Cache.SetExpires(DateTime.UtcNow.AddDays(-1));
            HttpContext.Current.Response.Cache.SetValidUntilExpires(false);
            HttpContext.Current.Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches);
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.Cache.AppendCacheExtension("private");
            HttpContext.Current.Response.Cache.AppendCacheExtension("no-cache=Set-Cookie");
            HttpContext.Current.Response.Cache.SetProxyMaxAge(TimeSpan.Zero);
            HttpContext.Current.Response.Cache.SetNoStore();

        }
    }
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class AjaxValidateAntiForgeryTokenAttribute : FilterAttribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationContext filterContext)
        {
            try
            {
                if (filterContext.HttpContext.Request.IsAjaxRequest()) // if it is ajax request.
                {
                    this.ValidateRequestHeader(filterContext.HttpContext.Request); // run the validation.
                }
                else
                {
                    AntiForgery.Validate();
                }
            }
            catch (HttpAntiForgeryException e)
            {
                throw new HttpAntiForgeryException("Anti forgery token not found");
            }
        }

        private void ValidateRequestHeader(HttpRequestBase request)
        {
            string cookieToken = string.Empty;
            string formToken = string.Empty;
            string tokenValue = request.Headers["VerificationToken"]; // read the header key and validate the tokens.
            if (!string.IsNullOrEmpty(tokenValue))
            {
                string[] tokens = tokenValue.Split(',');
                if (tokens.Length == 2)
                {
                    cookieToken = tokens[0].Trim();
                    formToken = tokens[1].Trim();
                }
            }

            AntiForgery.Validate(cookieToken, formToken); // this validates the request token.
        }
    }
}
