﻿using Aetna.ProviderContracts.DataContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NABWebsite.Models.LocateProvider
{
    public class MyDirectoryViewModel
    {
        public List<ProviderDirectory> Directories {get;set;}
    }
}