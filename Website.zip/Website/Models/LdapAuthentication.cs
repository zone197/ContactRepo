﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.DirectoryServices;
using System.Configuration;
using System.Web;
using System.Xml;
using System.Net;
using System.Net.NetworkInformation;
using ActiveDs;
using NABWebsite.DTO;
using System.Globalization;

namespace NABWebsite.Models
{
    public class LdapAuthentication
    {

        #region ADConnection

        public static string ADCheck = ConfigurationManager.AppSettings["ADCheck"].ToString();

        public static XmlNode LDAPNode = (XmlNode)ConfigurationManager.GetSection("LDAP");
        public static String domainName = LDAPNode.SelectSingleNode("domain").InnerText + @"\";
        public static String domainUserName = LDAPNode.SelectSingleNode("userid").InnerText;
        public static String domainPassword = LDAPNode.SelectSingleNode("password").InnerText;

        private String _ADTopPath = String.Empty;
        private String _Controller = String.Empty;

        #endregion

        public LdapAuthentication()
        {
            _ADTopPath = ConfigurationManager.ConnectionStrings["ADExternalTop"].ConnectionString;
            String[] controllers = LDAPNode.SelectSingleNode("server").InnerText.Split('|');
            foreach (String controller in controllers)
            {
                String status = String.Empty;
                try
                {
                    using (Ping ping = new Ping())
                    {
                        PingReply pr = ping.Send(controller);
                        status = pr.Status.ToString();
                    }

                }
                catch (Exception ex)
                {
                    status = "Failed";
                }
                if (status.ToUpper(CultureInfo.InvariantCulture) == "SUCCESS")
                {
                    _Controller = controller;
                    _ADTopPath = ConfigurationManager.ConnectionStrings["ADExternalTop"].ConnectionString.Replace(ConfigurationManager.AppSettings["ExternalControllerFiller"].ToString(), _Controller);
                    break;
                }
            }

            HttpContext.Current.Session["Path"] = _ADTopPath;
        }

        public LdapAuthentication(string path)
        {
            HttpContext.Current.Session["Path"] = path;
        }

        public enum ActiveDirectoryUserFlag
        {
            ACCOUNTDISABLE = 2, // 0x2   
            LOCKOUT = 16,  // 0x10   
            DONT_EXPIRE_PASSWD = 0x10000,
            ADS_UF_PASSWORD_EXPIRED = 0x800000

        }

        public bool IsAuthenticated(DirectoryEntry directoryEntry, string userName)
        {
            try
            {
                HttpContext.Current.Session["ChangePwd"] = null;
                bool acDisabled = false;
                bool acLocked = false;
                //Bind to the native AdsObject to force authentication.
                object obj = directoryEntry.NativeObject;

                DirectorySearcher search = new DirectorySearcher(directoryEntry);

                search.Filter = "(&(objectCategory=user)(SAMAccountName=" + userName + "))";
                //search.PropertiesToLoad.Add("cn");
                //SearchResult result = search.FindOne();
                search.SearchScope = SearchScope.Subtree;
                SearchResult result = search.FindOne();

                if (null == result)
                {
                    HttpContext.Current.Session["Path"] = null;
                    HttpContext.Current.Session["dayLeft"] = null;
                    return false;
                }
                else
                {
                    HttpContext.Current.Session["Path"] = result.Path;

                    if (result.GetDirectoryEntry().Properties["userAccountControl"].Count > 0)
                    {
                        int userAccountFlags = (int)result.GetDirectoryEntry().Properties["userAccountControl"].Value;
                        // Account Setting Flags   
                        if (((userAccountFlags & (int)LdapAuthentication.ActiveDirectoryUserFlag.ACCOUNTDISABLE) == (int)LdapAuthentication.ActiveDirectoryUserFlag.ACCOUNTDISABLE))
                        {
                            acDisabled = true;
                            HttpContext.Current.Session["Path"] = null;
                            HttpContext.Current.Session["dayLeft"] = null;
                            return false;
                        }

                        if ((bool)result.GetDirectoryEntry().InvokeGet("IsAccountLocked") == true)
                        {
                            acLocked = true;
                            HttpContext.Current.Session["Path"] = null;
                            HttpContext.Current.Session["dayLeft"] = null;
                            return false;
                        }

                    }

                    if (acDisabled == false && acLocked == false)
                    {
                        DirectoryEntry deChk = new DirectoryEntry(result.Path, domainName + domainUserName, domainPassword);
                        object nvObj = deChk.NativeObject;
                        long ticks = GetInt64(deChk, "pwdLastSet");
                        //user must change password at next login


                        if (ticks == 0)
                        {
                            HttpContext.Current.Session["tempChangeUserId"] = HttpContext.Current.Session[Constants.UnloggedUserID];
                            HttpContext.Current.Session["ChangePwd"] = "true";
                            HttpContext.Current.Session["Path"] = result.Path;
                            HttpContext.Current.Session["dayLeft"] = null;
                            return false;
                        }
                        else
                        {

                            LargeInteger liPwdExpiration = deChk.Properties["maxPwdAge"].Value as LargeInteger;

                            if (liPwdExpiration != null && liPwdExpiration.LowPart > 0)
                            {
                                long datePwdExpiration = (((long)(liPwdExpiration.HighPart) << 32) + (long)liPwdExpiration.LowPart);

                                if (datePwdExpiration > 0)
                                {
                                    DateTime dtPwdExpiration = DateTime.FromFileTime(datePwdExpiration);
                                    DateTime dtNow = DateTime.Now;
                                    TimeSpan time;
                                    time = dtPwdExpiration - dtNow;

                                    HttpContext.Current.Session["dayLeft"] = time.Days.ToString(CultureInfo.InvariantCulture);
                                }
                                else
                                    HttpContext.Current.Session["dayLeft"] = null;
                            }
                            else
                                HttpContext.Current.Session["dayLeft"] = null;

                            return true;
                        }
                    }
                    else
                    {
                        HttpContext.Current.Session["dayLeft"] = null;
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                HttpContext.Current.Session["dayLeft"] = null;
                //CommonHelper.WriteError(ex.ToString());
                //if (ex.InnerException != null)
                //{
                //    CommonHelper.WriteError(ex.InnerException.Message);
                //}
                return false;
            }
        }

        public bool IsAuthenticatedForgotPassword(DirectoryEntry directoryEntry, string userName)
        {
            try
            {
                HttpContext.Current.Session["ChangePwd"] = null;
                bool acDisabled = false;
                bool acLocked = false;
                //Bind to the native AdsObject to force authentication.
                object obj = directoryEntry.NativeObject;

                DirectorySearcher search = new DirectorySearcher(directoryEntry);

                search.Filter = "(&(objectCategory=user)(SAMAccountName=" + userName + "))";
                //search.PropertiesToLoad.Add("cn");
                //SearchResult result = search.FindOne();
                search.SearchScope = SearchScope.Subtree;
                SearchResult result = search.FindOne();

                if (null == result)
                {
                    HttpContext.Current.Session["Path"] = null;
                    return false;
                }
                else
                {
                    HttpContext.Current.Session["Path"] = result.Path;

                    if (result.GetDirectoryEntry().Properties["userAccountControl"].Count > 0)
                    {
                        int userAccountFlags = (int)result.GetDirectoryEntry().Properties["userAccountControl"].Value;
                        // Account Setting Flags   
                        if (((userAccountFlags & (int)LdapAuthentication.ActiveDirectoryUserFlag.ACCOUNTDISABLE) == (int)LdapAuthentication.ActiveDirectoryUserFlag.ACCOUNTDISABLE))
                        {
                            acDisabled = true;
                            HttpContext.Current.Session["Path"] = null;
                            return false;
                        }

                        if ((bool)result.GetDirectoryEntry().InvokeGet("IsAccountLocked") == true)
                        {
                            acLocked = true;
                            HttpContext.Current.Session["Path"] = null;
                            return false;
                        }
                    }

                    if (acDisabled == false && acLocked == false)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                //CommonHelper.WriteError(ex.ToString());
                //if (ex.InnerException != null)
                //{
                //    CommonHelper.WriteError(ex.InnerException.Message);
                //}

                return false;
            }
        }

        private Int64 GetInt64(DirectoryEntry entry, string attr)
        {
            //we will use the marshaling behavior of
            //the searcher
            DirectorySearcher ds = new DirectorySearcher(entry, String.Format(CultureInfo.InvariantCulture,"({0}=*)", attr), new string[] { attr }, SearchScope.Base);
            SearchResult sr = ds.FindOne();

            if (sr != null)
            {
                if (sr.Properties.Contains(attr))
                {
                    return (Int64)sr.Properties[attr][0];
                }
            }
            return -1;
        }

        public static string GeneratePassword()
        {
            Random rnd = new Random();
            int nLength = rnd.Next(16, 22);
            System.Text.StringBuilder password = new System.Text.StringBuilder();
            string consonant = "a0b1c2d3e4f5g6h7i8j9klmnopqrstvuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            for (int i = 0; i < nLength; i++)
            {
                int length2 = rnd.Next(1, 62);
                password.Append(consonant.Substring(length2, 1));
            }

            if (Validation.IsAlpha(password.ToString()))
            {
                int length3 = rnd.Next(1, 9);
                password.Append(length3);
            }

            return password.ToString();
        }

        public static bool ResetPassword(string newPassword)
        {
            bool retValue = false;
            DirectoryEntry changeEntry = new DirectoryEntry(HttpContext.Current.Session["Path"].ToString(), domainName + domainUserName, domainPassword, AuthenticationTypes.Secure);
            try
            {


                changeEntry.Invoke("SetPassword", new object[] { newPassword });
                //changeEntry.Properties["LockOutTime"].Value = 0; //unlock account
                changeEntry.Properties["pwdLastSet"].Value = 0;
                changeEntry.CommitChanges();
                changeEntry.Close();
                retValue = true;
            }
            catch (Exception ex)
            {
                changeEntry.Close();
                //CommonHelper.WriteError(ex.ToString());
                //if (ex.InnerException != null)
                //{
                //    CommonHelper.WriteError(ex.InnerException.Message);
                //}

                retValue = false;
            }

            return retValue;
        }

        public bool Authenticate(string userName, string password, string domain)
        {
            bool authentic = false;
            try
            {
                if (!string.IsNullOrEmpty(domain))
                {
                    using (DirectoryEntry entry = new DirectoryEntry(domain, domainName + userName, password))
                    {
                        object nativeObject = entry.NativeObject;
                        authentic = true;
                    }
                }

            }
            catch (Exception de)
            {
                //CommonHelper.WriteError(de.ToString());
                //if (de.InnerException != null)
                //{
                //    CommonHelper.WriteError(de.InnerException.Message);
                //}
            }
            return authentic;
        }
    }
}
