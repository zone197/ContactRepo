﻿using Aetna.ProviderContracts.DataContracts;
using NABWebsite.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NABWebsite.Models.LocateProvider
{
    public class RefineProvider
    {
        public List<string> LanguageSpoken { get; set; }
        public List<SpecialtyEntity> SpecialtyList { get; set; }
        public List<FocusEntity> FocusList { get; set; }
        public List<ECPEntity> ECPList { get; set; }

    }
}