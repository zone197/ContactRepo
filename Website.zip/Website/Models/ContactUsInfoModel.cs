﻿using System.Collections.Generic;
using NABWebsite.DTO;

namespace NABWebsite.Models
{
    public class ContactUsInfoModel
    {
        public string GroupDivisionName { get; set; }
        public List<ContactUsGroups> ListOfGroups { get; set; }
    }
}
