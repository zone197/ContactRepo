﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NABWebsite.Models
{
    public class FileDetailModel
    {
        public string LinkType { get; set; }
        public string TargetLink { get; set; }
        public int FilefId { get; set; }
        public string Name { get; set; }
        public string FileType { get; set; }
        public int SourceLinkId { get; set; }
        public byte[] Content { get; set; }
    }
}