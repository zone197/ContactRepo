﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NABWebsite.DTO;

namespace NABWebsite.Models
{
    public class SiteMapNodes
    {

        public SiteMapNodes()
        {
        }
        public SiteMapNodes(SitemapDetail sitemapDetail)
        {
            this.NodeId = sitemapDetail.SiteMapId.ToString();
            this.NodeName = sitemapDetail.DisplayText;
            this.LinkType = sitemapDetail.LinkType;
            this.TargetLink = sitemapDetail.TargetLink;
        }
        public string NodeId { get; set; }
        public string NodeName { get; set; }
        public List<SiteMapNodes> Children { get; set; }
        public string LinkType { get; set; }
        public string TargetLink { get; set; }
    }
}