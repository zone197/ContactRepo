﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using NABWebsite.Models;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System.Configuration;
using System.DirectoryServices;
using System.Text;
using Microsoft.Security.Application;
using NABWebsite.Helper;
using Utilities;

namespace NABWebsite.Controllers
{
    public class ForgotPasswordController : Controller
    {
        MyProfileBLL bllObj = new MyProfileBLL();
        LogOnBLL objBll = new LogOnBLL();
        MyProfile dtoObj = new MyProfile();
        MyProfileModel objMyProfileModel = new MyProfileModel();
        //StringBuilder traceLog = new StringBuilder();
        // GET: ForgotPassword
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotPasswordController, Index Method");
                traceLog.AppendLine(" & End: ForgotPasswordController, Index Method");
                return View();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }

        }
        [AjaxValidateAntiForgeryToken]
        public ActionResult FetchQuestions(string userId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {

                traceLog.AppendLine("Start: ForgotPasswordController, FetchQuestions Method with Param userId: " + userId);
                userId = Microsoft.Security.Application.Encoder.LdapFilterEncode(userId);//Added on 20-Jul-18 to fix LDAP
                if (userId != null)
                {
                    if (objBll.IsAdValidated(userId))
                    {
                        Session[Constants.Userid] = userId;
                        List<string> question = new List<string>();
                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.General).ToList();
                        dtoObj.SecurityQuestion1 = question != null ? question.ElementAt(0) : string.Empty;
                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.Family).ToList();
                        dtoObj.SecurityQuestion2 = question != null ? question.ElementAt(0) : string.Empty;
                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.Favourite).ToList();
                        dtoObj.SecurityQuestion3 = question != null ? question.ElementAt(0) : string.Empty;
                        objMyProfileModel.MyProfile = dtoObj;
                    }
                    else
                    {
                        List<SelectListItem> generalQuestion = new List<SelectListItem>();
                        List<SelectListItem> familyQuestion = new List<SelectListItem>();
                        List<SelectListItem> favoriteQuestion = new List<SelectListItem>();
                        SelectListItem selectOne = new SelectListItem() { Text = Constants.SelectOne, Value = Constants.SelectOne };

                        generalQuestion.AddRange(bllObj.GetSecurityQuestionByCategory(Constants.General).ToList());
                        familyQuestion.AddRange(bllObj.GetSecurityQuestionByCategory(Constants.Family).ToList());
                        favoriteQuestion.AddRange(bllObj.GetSecurityQuestionByCategory(Constants.Favourite).ToList());

                        List<int> location = new List<int>();
                        location = GetRandomNumber(1, generalQuestion.Count, 1);
                        dtoObj.SecurityQuestion1 = generalQuestion.ElementAt(location[0]).Text;
                        location = GetRandomNumber(1, familyQuestion.Count, 1);
                        dtoObj.SecurityQuestion2 = familyQuestion.ElementAt(location[0]).Text;
                        location = GetRandomNumber(1, favoriteQuestion.Count, 1);
                        dtoObj.SecurityQuestion3 = favoriteQuestion.ElementAt(location[0]).Text;
                        objMyProfileModel.MyProfile = dtoObj;
                    }
                }
                traceLog.AppendLine(" & End: ForgotPasswordController, FetchQuestions Method");
                return PartialView("_QuestionPanel", objMyProfileModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        
        private List<int> GetRandomNumber(int fromNumber, int toNumber, int numberOfRandomNumbersRequired)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotPasswordController, GetRandomNumber Method with Param fromNumber: " + fromNumber + "with Param toNumber: " + toNumber + "with Param numberOfRandomNumbersRequired: " + numberOfRandomNumbersRequired);
                List<int> randomNumbers = new List<int>();
               // Random random = new Random(System.DateTime.Now.Millisecond);
                for (int i = 0; i < numberOfRandomNumbersRequired; i++)
                {
                    //int rnumber = random.Next(fromNumber, toNumber);
                    int rnumber = CommonHelper.GetSecureRandom(fromNumber, toNumber);//Added on 27-Jul-18 to fix Weak PRNG 
                    if (!randomNumbers.Contains(rnumber))
                    {
                        randomNumbers.Add(rnumber);
                    }
                    else
                    {
                        numberOfRandomNumbersRequired = numberOfRandomNumbersRequired + 1;
                    }
                }
                traceLog.AppendLine(" & End: ForgotPasswordController, GetRandomNumber Method");
                return randomNumbers;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }
        }

        
        [AjaxValidateAntiForgeryToken]
        public bool CheckQuestion(string question1, string question2, string question3, string answer1, string answer2, string answer3)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotPasswordController, CheckQuestion Method with Param answer1: " + answer1 + "with Param answer2: " + answer2 + "with Param answer3: " + answer3);
              
                string userId = Session[Constants.Userid] != null ? Session[Constants.Userid].ToString() : string.Empty;
                userId = Microsoft.Security.Application.Encoder.LdapFilterEncode(userId);
                bool checkValidity = false;
                if (userId != null)
                {
                    if (objBll.IsAdValidated(userId))
                    {
                        List<string> question = new List<string>();
                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.General).ToList();
                        string modelAnswer1 = question != null ? question.ElementAt(1) : string.Empty;
                        string modelQuestion1 = question != null ? question.ElementAt(0) : string.Empty;

                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.Family).ToList();
                        string modelAnswer2 = question != null ? question.ElementAt(1) : string.Empty;
                        string modelQuestion2 = question != null ? question.ElementAt(0) : string.Empty;

                        question = bllObj.GetSecurityQuestionByUserid(userId, Constants.Favourite).ToList();
                        string modelAnswer3 = question != null ? question.ElementAt(1) : string.Empty;
                        string modelQuestion3 = question != null ? question.ElementAt(0) : string.Empty;

                        if (modelQuestion1.ToLower() == question1.ToLower() && modelQuestion2.ToLower() == question2.ToLower() && modelQuestion3.ToLower() == question3.ToLower() && modelAnswer1.ToLower() == answer1.ToLower() && modelAnswer2.ToLower() == answer2.ToLower() && modelAnswer3.ToLower() == answer3.ToLower())
                        {
                            checkValidity = true;
                        }

                    }
                }
                traceLog.AppendLine(" & End: ForgotPasswordController, CheckQuestion Method");
                return checkValidity;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }
        }
        private void SendMailToUser(string password)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotPasswordController, SendMailToUser Method with Param password: " + password);
                string userId = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                }
                string userType = string.Empty;

                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                {
                    userType = ConfigurationManager.AppSettings[Constants.Site];
                }
                string subject = Constants.CofinityLabel;
                string body = GetEmailBody(password);

                User temp = new User();
                temp = bllObj.GetUserDetails(userId, userType);
                List<string> toEmail = new List<string>();
                toEmail.Add(temp.Email);
                bllObj.SendMail(toEmail.ToArray(), subject, body);
                traceLog.AppendLine(" & End: ForgotPasswordController, SendMailToUser Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }


        }

        private string GetEmailBody(string password)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                StringBuilder mailBody = new StringBuilder();
                traceLog.AppendLine("Start: ForgotPasswordController, GetEmailBody Method with Param password: " + password);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ForgotPrdMailLine1);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ForgotPrdMailLine2);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ForgotPrdMailLine3 + ConfigurationManager.AppSettings[Constants.WebAddress] + Constants.SecureMailBodyline3Part2);
                mailBody.Append(Constants.Bold + ConfigurationManager.AppSettings[Constants.WebAddress] + Constants.MessageEnd);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ForgotPrdMailLine4);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ForgotPrdMailLine5);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.PrdMailLabel + CofinityEncryption.NABEncryption.Decrypt(password));
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.ResetMailLabel + DateTime.Now.ToString());
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.CofinityWebService);
                mailBody.Append(Constants.BreakLine);
                mailBody.Append(Constants.DoNotReply);
                traceLog.AppendLine(" & End: ForgotPasswordController, GetEmailBody Method");
                return mailBody.ToString();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        [AjaxValidateAntiForgeryToken]
        public bool UpdatePassword()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotPasswordController, UpdatePassword Method");
                bool check = false;
                string prd = CofinityEncryption.NABEncryption.Encrypt(GeneratePassword());// Updated on 18-Jul-18 to Fix Heap Inspection
                string userId = string.Empty;
                if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                {
                    userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                }
                if (objBll.ResetUserPassword(userId,prd))
                {
                    MyProfile tempProfile = new MyProfile();
                    tempProfile.Userid = userId;
                    tempProfile.NewPrd = prd;
                    check = bllObj.UpdateSecurityPassword(tempProfile);
                    if(check) SendMailToUser(prd);
                }
                traceLog.AppendLine(" & End: ForgotPasswordController, UpdatePassword Method");
                return check;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private string GeneratePassword()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ForgotPasswordController, GeneratePassword Method");
                Random rnd = new Random();
            int nLength = CommonHelper.GetSecureRandom(16, 22);//Added on 27-Jul-18 to fix Weak PRNG
            System.Text.StringBuilder prd = new System.Text.StringBuilder();// Updated on 18-Jul-18 to Fix Heap Inspection
            
            string consonant = "a0b1c2d3e4f5g6h7i8j9klmnopqrstvuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            for (int i = 0; i < nLength; i++)
            {
                int length2 = CommonHelper.GetSecureRandom(1, 62);//Added on 27-Jul-18 to fix Weak PRNG
                prd.Append(consonant.Substring(length2, 1));
            }

            if (Validation.IsAlpha(prd.ToString()))
            {
                int length3 = CommonHelper.GetSecureRandom(1, 9);//Added on 27-Jul-18 to fix Weak PRNG
                prd.Append(length3);
            }
                traceLog.AppendLine(" & End: ForgotPasswordController, Index Method");
            return prd.ToString();
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        
    }
}