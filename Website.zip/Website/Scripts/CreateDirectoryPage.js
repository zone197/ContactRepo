﻿
$(document).ready(function () {
    $("#DirectoryName").change(function () {
        $('#errorMessageForDirectoryName').empty();
    })
    //display the pdf for viewing the directory
    
   
        $('#directoryDiv').hide();
        $('#directoryDetails').hide();
        $('#yourCriteria').hide();
        $('#directoryOption').hide();
        $('#emailDiv').hide();
        $('#messageModal').modal('hide');
        $('input[type=radio]').attr('checked', false);
        $("#emailConfirmation").empty();
        $('#EmailId1').change(function () {
            $('#errorDiv').empty();
            $("#emailConfirmation").empty();
        })
        $('#EmailId2').change(function () {
            $('#errorDiv').empty();
            $("#emailConfirmation").empty();
        })
        $('#EmailId3').change(function () {
            $('#errorDiv').empty();
            $("#emailConfirmation").empty();
        })
});
function DeletePdf()
{
    ////debugger;
    var forgeryId = $("#forgeryToken").val();
    var returnValue;
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/DeleteProviderReportFile',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
}
function DisplayProviderReport() {
    window.open($("#hdnhost").val() + "LocateProvider/PdfDisplayForDirectory", "_blank");
}
function GetResources(key) {
    var forgeryId = $("#forgeryToken").val();
    var returnValue;
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/GetResources',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        async: false,
        data: JSON.stringify({ key: key }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            ////debugger;
            returnValue = result;

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
    ////debugger;
    return returnValue;
}

    
// remove the email entered from the textbox and all the error messages
function RemovEmailValidation(id) {
    ////debugger;
    if (id == 2)
    {
        $('#emailDiv').hide();
        $('#errorDiv').empty();
        $('#directoryErrorMsg').empty();
        $('#EmailId1').val("");
        $('#EmailId2').val("");
        $('#EmailId3').val("");

    }
    else {

        $('#emailDiv').show();
        $('#errorDiv').empty();
        $('#directoryErrorMsg').empty();
        $('#EmailId1').val("");
        $('#EmailId2').val("");
        $('#EmailId3').val("");
    }
}
        

//}


function ValidateCaptchaCreateDir(event, CaptchaVerify,Visibility) {
    //debugger
    try {
        if (Visibility == 'invisible') {
            if (CaptchaVerify == "false")
                ShowErrorPopupWait(true)
            else {
                event.preventDefault();
                grecaptcha.reset();
                grecaptcha.execute();
            }
        }
        else {            
                ShowErrorPopupWait("")
        }
    }
    catch (ex) {

    } 
}

// display an appropriate popup message if the entered criteria is valid else display an error
function ShowErrorPopupWait(captchaResponse) {
    $('#errorMessageForDirectoryName').empty();
    $('#errorDiv').empty();
    $('#directoryErrorMsg').empty();
    var forgeryId = $("#forgeryToken").val();
    value = $('input[name=DirectoryCreationType]:checked').val();
    var val1 = $('#EmailId1').val();
    var val2 = $('#EmailId2').val();
    var val3 = $('#EmailId3').val();    
       
    var directoryName = $("#DirectoryName").val().trim();
    if (directoryName == null || directoryName == "") {
        var errorDirectoryName = GetResources('lblDirectoryNameRequired');
        $('#errorMessageForDirectoryName').html(errorDirectoryName);
        $('#DirectoryName').focus();
    }
    else {
        if (value == 1) {
            if (val1 || val2 || val3) {
            }
            else {
                var errorEmailAddressMandatory = GetResources("lblEmailAddressMandatory");
                var errorEnterEmail = GetResources("lblEnterAtleastOneEmailAddress");
                $('#errorDiv').html(errorEnterEmail);
                $("#EmailId1").focus();
                //$('#directoryErrorMsg').html(errorEmailAddressMandatory);
            }
        }
        else if (value === undefined) {            
            var errorlblDirectoryCreationType = GetResources("lblDirectoryCreationType");
            $('#errorDiv').html(errorlblDirectoryCreationType);
            $('input[name=DirectoryCreationType]').focus();
        }
    }
    var form = $("#directoryForm");
    $.validator.unobtrusive.parse(form);
    form.validate();
    if (val1 || val2 || val3 || value == 2) {
        $('#errorDiv').empty();
        $('#directoryErrorMsg').empty();
        if (form.valid()) {
            //var captchaResponse = $("#g-recaptcha-response").val();
            //if (CaptchaVerify == "false")
            //    captchaResponse = "true";
            if (captchaResponse) {              
                $('#CreateDirProgressDialog').modal('show');
                $('#CreateDirProgressDialog').modal({
                    backdrop: 'static',
                    keyboard: false
                });
                var CreateDriectoryViewModel = new Object();
                CreateDriectoryViewModel.DirectoryType = $('input[name=DirectoryType]:checked').val();
                CreateDriectoryViewModel.DirectoryName = $("#DirectoryName").val();
                CreateDriectoryViewModel.DirectoryCreationType = $('input[name=DirectoryCreationType]:checked').val();
                CreateDriectoryViewModel.EmailId1 = $("#EmailId1").val();
                CreateDriectoryViewModel.EmailId2 = $("#EmailId2").val();
                CreateDriectoryViewModel.EmailId3 = $("#EmailId3").val();
                CreateDriectoryViewModel.IncludeIndex = $("#IncludeListItemIncludeIndex").is(":checked");
                CreateDriectoryViewModel.IncludeTOC = $("#IncludeListItemIncludeTOC").is(":checked");
                //debugger;
                $.ajax({
                    type: 'POST',
                    url: '/LocateProvider/CreateDirectory',
                    contentType: "application/json; charset=utf-8",
                    datatype: 'json',
                    data: JSON.stringify({ model: CreateDriectoryViewModel, captcha: captchaResponse }),
                    headers: {
                        'VerificationToken': forgeryId
                    },
                    success: function (result) {
                        // alert(result);
                        grecaptcha.reset();
                        $('#CreateDirProgressDialog').modal('hide');
                        if (result == "false") {
                            $('#messageModal').modal('show');
                            $('#messageModal').modal({
                                backdrop: 'static',
                                keyboard: false
                            });
                            var msgFindDirectoryAttached = GetResources("lblFindDirectoryAttachedInMail");
                            $('#messagecontent').html(msgFindDirectoryAttached);
                            $('#EmailId1').val('');
                            $('#EmailId2').val('');
                            $('#EmailId3').val('');

                        }
                        else if (result == "5 hours") {
                            $('#messageModal').modal('show');
                            $('#messageModal').modal({
                                backdrop: 'static',
                                keyboard: false
                            });
                            var msgLinkSentInFiveHours = GetResources("lblLinkSentInFiveHours");
                            $('#messagecontent').html(msgLinkSentInFiveHours);
                            $('#EmailId1').val('');
                            $('#EmailId2').val('');
                            $('#EmailId3').val('');
                        }
                        else if (result == "24 hours") {
                            $('#messageModal').modal('show');
                            $('#messageModal').modal({
                                backdrop: 'static',
                                keyboard: false
                            });
                            var msgLinkSentInTwentyfourHours = GetResources("lblLinkSentInTwentyFourHours");
                            $('#messagecontent').html(msgLinkSentInTwentyfourHours);
                            $('#EmailId1').val('');
                            $('#EmailId2').val('');
                            $('#EmailId3').val('');
                        }
                        else if(result == "5 minutes")
                        {
                            $('#CreateDirDialog').modal('show');
                        }
                        else if (result == "sessionTimeOut") {
                            window.location.href = '/LocateProvider/SelectNetworkType/';
                        }
                        else if (result == "ZeroMyList") {
                            $('#messagecontentForZeroTag').modal('show');
                        }
                        else if (result == "15 minutes") {
                            var lblLinkSentInFifteenMin = GetResources("lblLinkSentInFifteenMin");
                            $('#messagecontent').html(lblLinkSentInFifteenMin);                            
                            $('#messageModal').modal('show');
                            $('#messageModal').modal({
                                backdrop: 'static',
                                keyboard: false
                            });
                            $('#EmailId1').val('');
                            $('#EmailId2').val('');
                            $('#EmailId3').val('');
                        }
                        else {
                            var errorCaptchaValidation = GetResources("lblErrorCaptchaValidation");
                            $("#emailConfirmation").html(errorCaptchaValidation);
                            $('#EmailId1').val('');
                            $('#EmailId2').val('');
                            $('#EmailId3').val('');
                            
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        $('#CreateDirProgressDialog').modal('hide');
                        grecaptcha.reset();
                    }
                });
            }
            else {
                $('#error_message').slideDown({ opacity: "show" }, "slow")
                setTimeout(function () {
                    $('#error_message').fadeOut(1500);
                }, 5000);
            }
        }
    }
    //else {
    //    var errorEnterEmail = GetResources("lblEnterAtleastOneEmailAddress");
    //    var errorEmailMandatory = GetResources("lblEmailAddressMandatory");
    //    $('#errorDiv').html(errorEnterEmail);
    //    //$('#directoryErrorMsg').html(errorEmailMandatory);
    //    $("#EmailId1").focus();
    //}
           
}

function saveDirectory() {
    $('#errorDiv').empty();
    var forgeryId = $("#forgeryToken").val();
    value = $('input[name=DirectoryCreationType]:checked').val();
    var directoryName = $("#DirectoryName").val();
    if (directoryName != null && directoryName != "") {
        $('#errorMessageForDirectoryName').empty();
            var CreateDriectoryViewModel = new Object();
            CreateDriectoryViewModel.DirectoryType = $('input[name=DirectoryType]:checked').val();
            CreateDriectoryViewModel.DirectoryName = $("#DirectoryName").val();
            CreateDriectoryViewModel.DirectoryCreationType = $('input[name=DirectoryCreationType]:checked').val();
            CreateDriectoryViewModel.EmailId1 = $("#EmailId1").val();
            CreateDriectoryViewModel.EmailId2 = $("#EmailId2").val();
            CreateDriectoryViewModel.EmailId3 = $("#EmailId3").val();
        CreateDriectoryViewModel.IncludeIndex = $("#IncludeListItemIncludeIndex").is(":checked");
                CreateDriectoryViewModel.IncludeTOC = $("#IncludeListItemIncludeTOC").is(":checked");
            $.ajax({
                type: 'POST',
                url: '/LocateProvider/SaveDirectory',
                contentType: "application/json; charset=utf-8",
                datatype: 'json',
                data: JSON.stringify({ model: CreateDriectoryViewModel }),
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {
                    ////debugger;
                    if(result == true)
                    {
                        $('#SaveDirDialog').modal('show');
                        $("#messagecontentForSaveDirectory").html(GetResources("DirectoryCreationSuccess"));
                    }
                    else if(result==false) {
                        $('#SaveDirDialog').modal('show');
                        $('#messagecontentForSaveDirectory').html(GetResources("DirectoryCreationError"));
                    }
                    else if (result == "sessionTimeOut") {
                        window.location.href = '/LocateProvider/SelectNetworkType/';
                    }

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                }
            });
        }
   else {
       var errorDirectoryName = GetResources('lblDirectoryNameRequired');
       $('#errorMessageForDirectoryName').html(errorDirectoryName);
       $('#DirectoryName').focus();
    }

   


}
   