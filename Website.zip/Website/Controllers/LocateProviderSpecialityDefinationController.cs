﻿using Aetna.ProviderContracts.DataContracts;
using NABWebsite.Models.LocateProvider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using NABWebsite.BLL;
using System.Globalization;
using NABWebsite.Helper;
using NABWebsite.DTO;
using System.ServiceModel;
using System.Configuration;
using System.Web.Security.AntiXss;
using System.Text;
using Utilities;

namespace NABWebsite.Controllers
{
    [NoCache]
    public class LocateProviderSpecialityDefinationController : BaseController
    {
        //int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);

        /// <summary>
        /// specialty definition page
        /// </summary>
        /// <returns></returns>
        [NoCache]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderSpecialityDefinationController, Index Method");
                if (Session[CookieConstant.Culture] == null)
                {
                    traceLog.AppendLine(" & End: LocateProviderSpecialityDefinationController, Index Method");
                    return RedirectToAction("IndexSession", "Error");
                }
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (searchRequest == null || searchRequest.ProviderType == null)
                {
                    TempData["sessionTimeOut"] = VariableConstant.SessionTimeout;
                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]) == true)
                    {
                        traceLog.AppendLine(" & End: LocateProviderSpecialityDefinationController, Index Method");
                        return RedirectToAction(ApplicationConstants.CustomPage);
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: LocateProviderSpecialityDefinationController, Index Method");
                        return RedirectToAction(ApplicationConstants.SelectNetworkTypeAction);
                    }
                }

                if (!CommonHelper.ValidateProviderNumber(searchRequest.ProviderType.ProviderTypeId.ToString()))
                    throw new System.Exception(ExceptionMessageConstant.ProviderNumber);
                string alphaConfig = AppSettingHelper.GetAppSettingValue("Alphabets");
                string[] alphaConfigArray = alphaConfig.Split(',');
                List<string> alphatest = alphaConfigArray.ToList();
                List<Specialty> speciality = new List<Specialty>();
                ManageContent contentManager = new ManageContent();
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));
                speciality = contentManager.GetSpecialtiesLocateProvider(searchRequest.ProviderType.ProviderTypeId.ToString(), request).ToList();
                SpecialityDefination specialityDefination = new SpecialityDefination();

                var grouped = speciality
                    .GroupBy(s => s.SpecialtyName.Substring(0, 1))
                    .Select(group => new { Word = group.Key, Count = group.Count() }).ToList();
                foreach (var item in grouped)
                {
                    specialityDefination.AlphaCount.Add(new AlphaCount { Word = item.Word, Count = item.Count });
                }
                specialityDefination.ListSpecialty = speciality;
                specialityDefination.AlphaTest = alphatest;
                specialityDefination.ProviderType = searchRequest.ProviderType.ProviderTypeId.ToString();
                SetActiveControllerToSession(ApplicationConstants.LocateProviderSpecialtyDefinition, ApplicationConstants.IndexActionForSpecialtyDefinition);
                traceLog.AppendLine(" & End: LocateProviderSpecialityDefinationController, Index Method");
                return View(specialityDefination);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// get list of specialties by specialty id
        /// Edited By NAB-IT on 4 march 2018 to encode the input paramenter
        /// </summary>
        /// <param name="specialtyId"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult GetSpecialtiesBySpecialtyId(string specialtyId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderSpecialityDefinationController, GetSpecialtiesBySpecialtyId Method with Param specialtyId: " + specialtyId);
                SearchRequestEntity searchRequest = new SearchRequestEntity();
                searchRequest = Session[SessionConstant.SearchRequest] as SearchRequestEntity;
                if (searchRequest != null && searchRequest.NetworkType != null && searchRequest.NetworkType.NetworkId != null)
                {
                    List<string> specialtyDescriptionList = new List<string>();
                    string culture = ReturnCultureInfo();
                    string specialtyDescription = string.Empty;
                    RequestHeader request = new CommonHelper().GetRequestHeader(culture, Convert.ToInt32(searchRequest.NetworkType.NetworkId, CultureInfo.InvariantCulture));
                    ManageContent contentManager = new ManageContent();
                    specialtyDescriptionList = contentManager.GetSpecialtyDescriptionByID(AntiXssEncoder.HtmlEncode(specialtyId, false), request).ToList();
                    if (specialtyDescriptionList != null && specialtyDescriptionList.Count() > 0)
                    {
                        specialtyDescription = specialtyDescriptionList[0];
                    }
                    traceLog.AppendLine(" & End: LocateProviderSpecialityDefinationController, GetSpecialtiesBySpecialtyId Method");
                    return Json(specialtyDescription);
                }
                else
                {
                    traceLog.AppendLine(" & End: LocateProviderSpecialityDefinationController, GetSpecialtiesBySpecialtyId Method");
                    return null;
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// get the culture information
        /// </summary>
        /// <returns></returns>
        protected string ReturnCultureInfo()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderSpecialityDefinationController, ReturnCultureInfo Method");
                string culture = AppSettingHelper.GetAppSettingValue(CookieConstant.InitialCulture);
                //HttpCookie cookie = Request.Cookies[CookieConstant.Culture];
                var cookie = Session[CookieConstant.Culture];
                if (cookie != null)
                {
                    if (cookie.ToString() == AppSettingHelper.GetAppSettingValue(CookieConstant.CheckCulture))
                    {
                        culture = AppSettingHelper.GetAppSettingValue(CookieConstant.NewCulture);
                    }
                }
                traceLog.AppendLine(" & End: LocateProviderSpecialityDefinationController, ReturnCultureInfo Method");
                return culture;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// set values of current controller and action
        /// </summary>
        /// <param name="controller"></param>
        /// <param name="actionMethod"></param>
        void SetActiveControllerToSession(string controller, string actionMethod)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: LocateProviderSpecialityDefinationController, SetActiveControllerToSession Method with Param controller: " + controller + "and with Param actionMethod: " + actionMethod);
                if (Session[SessionConstant.CurrentController] != null && Session[SessionConstant.CurrentAction] != null)
                {
                    if (!(Session[SessionConstant.CurrentController].ToString().Equals(controller) && Session[SessionConstant.CurrentAction].ToString().Equals(actionMethod)))
                    {
                        Session[SessionConstant.CurrentController] = controller;
                        Session[SessionConstant.CurrentAction] = actionMethod;
                    }
                }
                else
                {
                    Session[SessionConstant.CurrentController] = controller;
                    Session[SessionConstant.CurrentAction] = actionMethod;
                }
                traceLog.AppendLine(" & End: LocateProviderSpecialityDefinationController, SetActiveControllerToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

    }
}