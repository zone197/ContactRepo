﻿$(function () {

    var $cbox = $('#comState[role="combobox"]');
    var $input = $('#textbox[role="textbox"]', $cbox);
    var $togglebutt = $('#btnToggle.toggle');
    var $clearbutt = $('#btnClear.clear');
    var $lbox = $('#ulState[role="listbox"]');
    var $countCounty = 0;
    var $countCity = 0;
    
    //Init
    $('#textbox').text($('#comState[role="combobox"]').attr('aria-label'));
    $('#textbox1').text($('#comCounty[role="combobox"]').attr('aria-label'));
    $('#textbox2').text($('#comCity[role="combobox"]').attr('aria-label'));


    function isOpen() {
        if ($cbox.attr('aria-expanded') == 'true') { return true; } else { return false; }
    }
    function openLB() {
        $('.divBox').hide();
        $('#comState[role="combobox"]').attr('aria-expanded', 'false');
        $('#comCounty[role="combobox"]').attr('aria-expanded', 'false');
        $('#comCity[role="combobox"]').attr('aria-expanded', 'false');

        $cbox.attr('aria-expanded', 'true');              
        $cbox.next().next().next().show();
    }
    function closeLB() {
        $cbox.attr('aria-expanded', 'false');
        $cbox.next().next().next().hide();
        clearActiveDescendant();
    }
    function toggleLB() {
        if (isOpen()) {
            closeLB();
            $cbox.focus();
        } else {
            openLB();
        }
    }
    function getActiveDescendant() {
        if ($lbox.attr('aria-activedescendant')) {
            return $('#' + $lbox.attr('aria-activedescendant'), $lbox);
        }
    }
    function setActiveDescendant($option) {
        if (getActiveDescendant()) {
            getActiveDescendant().removeClass('activedescendant');
        }
        $lbox.attr('aria-activedescendant', $option.attr('id'));
        $('#' + $lbox.attr('aria-activedescendant'),$lbox).attr('class', 'activedescendant');
    }
    function clearActiveDescendant() {
        if (getActiveDescendant()) {
            getActiveDescendant().removeClass('activedescendant');
        }
        $lbox.attr('aria-activedescendant', '');
    }
    function getSelectedOptionsStr() {
        var options_str = '';
        var $selectedOptions = $('li[aria-selected="true"]', $lbox);
        if ($selectedOptions.length > 0) {
            $selectedOptions.each(function () {
                options_str += $(this).text() + ', ';
            });
            options_str = options_str.slice(0, -2);
            $cbox.addClass('selections');
            //$togglebutt.hide();
            //$clearbutt.show();
        } else {
            options_str = $cbox.attr('aria-label');
            $cbox.removeClass('selections');
            $clearbutt.hide();
            $togglebutt.show();
        }
        return options_str;
    }
    function clearSelectedOptions() {
        $input.text($cbox.attr('aria-label'));
        $('li[aria-selected="true"]', $lbox).removeClass('activedescendant');
        $('li[aria-selected="true"]', $lbox).attr('aria-selected', 'false');
        $cbox.removeClass('selections');
        $clearbutt.hide();
        $togglebutt.show();
        if (isOpen()) { closeLB(); }
        $cbox.focus();
    }
    function toggleSelection($option) {
        if ($option.attr('aria-selected') == 'false') {
            $option.attr('aria-selected', 'true');
        } else {
            $option.attr('aria-selected', 'false');
        }
        $input.text(getSelectedOptionsStr());
    }
    function getDefaultOption() {
        if ($('li[aria-selected="true"]', $lbox).length > 0) {
            return $('li[aria-selected="true"]', $lbox).eq(0);
        } else {
            return $('li:visible:first', $lbox);
        }
    }
    function getNextOption() {
        if (getActiveDescendant()) {
            var ad_index = getActiveDescendant().nextAll("li:visible").eq(0).index();
            if (ad_index == -1) {
                return $('li:visible:first', $lbox);
            } else {
                return $('li', $lbox).eq(ad_index);
            }
        } else {
            return getDefaultOption();
        }
    }
    function getPreviousOption() {
        if (getActiveDescendant()) {
            var ad_index = getActiveDescendant().prevAll("li:visible").eq(0).index();
            if (ad_index == -1) {
                return $('li:visible:last', $lbox);
            } else {
                return $('li', $lbox).eq(ad_index);
            }
        } else {
            return getDefaultOption();
        }
    }

    //Events
    $('#comState[role="combobox"]').on('click', function (e) {

        $cbox = $('#comState[role="combobox"]');
        $input = $('#textbox[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle.toggle');
        $clearbutt = $('#btnClear.clear');
        $lbox = $('#ulState[role="listbox"]');
       
       
        toggleLB();
        $lbox.scrollTop(0);
        $('.dropdown-search').focus();
        e.stopPropagation();
    });

    $('#comCounty[role="combobox"]').on('click', function (e) {

        $cbox = $('#comCounty[role="combobox"]');
        $input = $('#textbox1[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle1.toggle');
        $clearbutt = $('#btnClear1.clear');
        $lbox = $('#ulCounty[role="listbox"]');
        
       
        toggleLB();
        $lbox.scrollTop(0);
        $('.dropdown-search').focus();
        e.stopPropagation();
    });

    $('#comCity[role="combobox"]').on('click', function (e) {

        $cbox = $('#comCity[role="combobox"]');
        $input = $('#textbox2[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle2.toggle');
        $clearbutt = $('#btnClear2.clear');
        $lbox = $('#ulCity[role="listbox"]');

       
        toggleLB();
        $lbox.scrollTop(0);
        $('.dropdown-search').focus();
        e.stopPropagation();
    });

    $('.dropdown-search').on('keydown', function (e) {
        switch (e.which) {
            case 40:
                setActiveDescendant($('li:visible:first', $lbox));
                $lbox.focus();
                $lbox.scrollTop(0);
                return false;
                break;
            default:
                return true;
        }
    })
   

    $('#comState[role="combobox"]').on('onfocus', function (e) {
        $cbox = $('#comState[role="combobox"]');
        $input = $('#textbox[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle.toggle');
        $clearbutt = $('#btnClear.clear');
        $lbox = $('#ulState[role="listbox"]');
    });

    $('#comCounty[role="combobox"]').on('onfocus', function (e) {
        $cbox = $('#comCounty[role="combobox"]');
        $input = $('#textbox1[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle1.toggle');
        $clearbutt = $('#btnClear1.clear');
        $lbox = $('#ulCounty[role="listbox"]');
      
    });

    $('#comCity[role="combobox"]').on('onfocus', function (e) {

        $cbox = $('#comCity[role="combobox"]');
        $input = $('#textbox2[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle2.toggle');
        $clearbutt = $('#btnClear2.clear');
        $lbox = $('#ulCity[role="listbox"]');

    });

    var altPressed = false;
    $('#comState[role="combobox"]').on('keydown', function (e) {
        $cbox = $('#comState[role="combobox"]');
        $input = $('#textbox[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle.toggle');
        $clearbutt = $('#btnClear.clear');
        $lbox = $('#ulState[role="listbox"]');
     
        switch (e.which) {
            case 18:
                altPressed = true;
                break;
            case 9:
                if (isOpen()) {
                    closeLB();
                }
                break;
            case 13:
            case 32:
                toggleLB();
                $lbox.scrollTop(0);
                if (isOpen()) {
                    $lbox.focus();                  
                    setActiveDescendant(getDefaultOption());
                }
                e.preventDefault();
                break;
            case 38:
                if (altPressed == true) {
                    closeLB();
                } else if (!isOpen()) {
                    openLB();
                    $lbox.scrollTop(0);
                    $lbox.focus();                 
                    setActiveDescendant(getDefaultOption());
                    e.preventDefault();
                }
                break;
            case 40:
                if (!isOpen()) {
                    openLB();
                }
                $lbox.scrollTop(0);
                $lbox.focus();
                $('.dropdown-search').focus();               
                setActiveDescendant(getDefaultOption());
                e.preventDefault();
                break;
            default:
                return true;
        }
    });
    $('#comState[role="combobox"]').on('keyup', function (e) {
        $cbox = $('#comState[role="combobox"]');
        $input = $('#textbox[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle.toggle');
        $clearbutt = $('#btnClear.clear');
        $lbox = $('#ulState[role="listbox"]');
        if (e.which == 18) {
            altPressed = false;
        }
    }); 
    $('#ulState[role="listbox"]').on('keydown', function (e) {
        //debugger
        switch (e.which) {
            case 18:
                altPressed = true;
                break;
            case 9:
                if (isOpen()) {
                    closeLB();
                }
                break;
            case 27:
                if (isOpen()) {
                    closeLB();
                    $cbox.focus();
                }
                break;
            case 13:
                //clearSelectedOptions();
                $('li[aria-selected="true"]', $lbox).attr('aria-selected', 'false');
                toggleSelection($('#ulState li.activedescendant'));
                //setActiveDescendant($('#ulState li.activedescendant'))
                //toggleSelection(getActiveDescendant());
                var stateCode = $('#ulState li.activedescendant').attr('id');
                changeState(stateCode);
                closeLB();
                $cbox.focus();
                break;
            case 32:
                //clearSelectedOptions();
                $('li[aria-selected="true"]', $lbox).attr('aria-selected', 'false');
                toggleSelection($('#ulState li.activedescendant'));
                var stateCode = $('#ulState li.activedescendant').attr('id');
                changeState(stateCode);
                //setActiveDescendant($('#ulState li.activedescendant'))
                //toggleSelection(getActiveDescendant());
                e.preventDefault();
                break;
            case 38:
                if (altPressed == true) {
                    closeLB();
                    $cbox.focus();
                } else {
                    setActiveDescendant(getPreviousOption());                  
                    $lbox.animate({ scrollTop: $('.activedescendant', $lbox).offset().top - $lbox.offset().top + $lbox.scrollTop(), scrollLeft: 0 }, 200);
                    e.preventDefault();
                }
                break;
            case 40:
                setActiveDescendant(getNextOption());
                $lbox.animate({ scrollTop: $('.activedescendant', $lbox).offset().top - $lbox.offset().top + $lbox.scrollTop(), scrollLeft: 0 }, 200);
                //$lbox.scrollTop($lbox.height());
                //$lbox.scrollTop($('.activedescendant', $lbox).offset().top - ($lbox.height() - 50));
                e.preventDefault();
                break;
            default:
                return true;
        }
    });
    $('#ulState[role="listbox"]').on('keyup', function (e) {
        if (e.which == 18) {
            altPressed = false;
        }      
    });
    $('#btnToggle.toggle').on('click', function (e) {
        $cbox = $('#comState[role="combobox"]');
        $input = $('#textbox[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle.toggle');
        $clearbutt = $('#btnClear.clear');
        $lbox = $('#ulState[role="listbox"]');

        toggleLB();
        $cbox.focus();
        e.stopPropagation();
    });
    $('#btnClear.clear').on('click', function (e) {
        $cbox = $('#comState[role="combobox"]');
        $input = $('#textbox[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle.toggle');
        $clearbutt = $('#btnClear.clear');
        $lbox = $('#ulState[role="listbox"]');
        clearSelectedOptions();
        $('#selectedCounty').empty();
        $('#selectedCity').empty();
         $countCounty = 0;
         $countCity = 0;

        $('#textbox1[role="textbox"]', $('#comCounty[role="combobox"]')).text($('#comCounty[role="combobox"]').attr('aria-label'));
        $('li[aria-selected="true"]', $('#ulCounty[role="listbox"]')).attr('aria-selected', 'false');
        $('#comCounty[role="combobox"]').removeClass('selections');
        $('#btnClear1.clear').hide();
        $('#btnToggle1.toggle').show();
       

        $('#textbox2[role="textbox"]', $('#comCity[role="combobox"]')).text($('#comCity[role="combobox"]').attr('aria-label'));
        $('li[aria-selected="true"]', $('#ulCity[role="listbox"]')).attr('aria-selected', 'false');
        $('#comCity[role="combobox"]').removeClass('selections');
        $('#btnClear2.clear').hide();
        $('#btnToggle2.toggle').show();
       


        $('#divCountySearch').hide();
        $('#divCitySearch').hide();

        $('#ulCounty').empty();
        $('#ulCity').empty();

        $('#lstCounty').addClass('disabledDropdown');
        $('#lstCity').addClass('disabledDropdown');

        e.stopPropagation();
    });

    $('#comCounty[role="combobox"]').on('keydown', function (e) {
        $cbox = $('#comCounty[role="combobox"]');
        $input = $('#textbox1[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle1.toggle');
        $clearbutt = $('#btnClear1.clear');
        $lbox = $('#ulCounty[role="listbox"]');
        //debugger
        switch (e.which) {
            case 18:
                altPressed = true;
                break;
            case 9:
                if (isOpen()) {
                    closeLB();
                }
                break;
            case 13:
            case 32:
                toggleLB();
                $lbox.scrollTop(0);
                if (isOpen()) {
                    $lbox.focus();
                    setActiveDescendant(getDefaultOption());
                }
                e.preventDefault();
                break;
            case 38:
                if (altPressed == true) {
                    closeLB();
                } else if (!isOpen()) {
                    openLB();
                    $lbox.scrollTop(0);
                    $lbox.focus();
                    setActiveDescendant(getDefaultOption());
                    e.preventDefault();
                }
                break;
            case 40:
                if (!isOpen()) {
                    openLB();
                }
                $lbox.scrollTop(0);
                $lbox.focus();
                $('.dropdown-search').focus();
                setActiveDescendant(getDefaultOption());
                e.preventDefault();
                break;
            default:
                return true;
        }
    });
    $('#comCounty[role="combobox"]').on('keyup', function (e) {
        $cbox = $('#comCounty[role="combobox"]');
        $input = $('#textbox1[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle1.toggle');
        $clearbutt = $('#btnClear1.clear');
        $lbox = $('#ulCounty[role="listbox"]');
        if (e.which == 18) {
            altPressed = false;
        }
    }); 
    $('#ulCounty[role="listbox"]').on('keydown', function (e) {
        //debugger
        switch (e.which) {
            case 18:
                altPressed = true;
                break;
            case 9:
                if (isOpen()) {
                    closeLB();
                }
                break;
            case 27:
                if (isOpen()) {
                    closeLB();
                    $cbox.focus();
                }
                break;
            case 13:
                $countCounty = $('li[aria-selected="true"]', $('#ulCounty')).length;
                if ($countCounty > 6 && $('#' + $('#ulCounty[role="listbox"]').attr('aria-activedescendant'), $('#ulCounty[role="listbox"]')).attr('aria-selected') == 'false') {
                    return false;
                }
                toggleSelection(getActiveDescendant());
                var options_str = '';
                var $selectedOptions = $('li[aria-selected="true"]', $('#ulCounty'));
                $countCounty = $selectedOptions.length;
                if ($selectedOptions.length > 0) {
                    $selectedOptions.each(function () {
                        options_str += $(this).text() + ', ';
                    });
                    options_str = options_str.slice(0, -2);                  
                }
                var selectedCounty = [];
                if (options_str != '') {
                    selectedCounty = options_str.split(",").map(function (item) {
                        return item.trim();
                    })
                };
                $('#selectedCounty').empty();
                $.each(selectedCounty, function (index, County) { $("#selectedCounty").append('<span class="tab">' + County + '</span>'); });
                closeLB();
                $cbox.focus();
                break;
            case 32:
                $countCounty = $('li[aria-selected="true"]', $('#ulCounty')).length;
               if ($countCounty > 6 && $('#' + $('#ulCounty[role="listbox"]').attr('aria-activedescendant'), $('#ulCounty[role="listbox"]')).attr('aria-selected') == 'false') {
                    return false;
                }
                toggleSelection(getActiveDescendant());
                var options_str = '';
                var $selectedOptions = $('li[aria-selected="true"]', $('#ulCounty'));
                $countCounty = $selectedOptions.length;
                if ($selectedOptions.length > 0) {
                    $selectedOptions.each(function () {
                        options_str += $(this).text() + ', ';
                    });
                    options_str = options_str.slice(0, -2);
                }
                var selectedCounty = [];
                if (options_str != '') {
                    selectedCounty = options_str.split(",").map(function (item) {
                        return item.trim();
                    })
                };
                $('#selectedCounty').empty();
                $.each(selectedCounty, function (index, County) { $("#selectedCounty").append('<span class="tab">' + County + '</span>'); });
                e.preventDefault();
                break;
            case 38:
                if (altPressed == true) {
                    closeLB();
                    $cbox.focus();
                } else {
                    setActiveDescendant(getPreviousOption());
                    //$lbox.scrollTop($lbox.height());
                    //$lbox.scrollTop($('.activedescendant', $lbox).offset().top - ($lbox.height() - 50));
                    $lbox.animate({ scrollTop: $('.activedescendant', $lbox).offset().top - $lbox.offset().top + $lbox.scrollTop(), scrollLeft: 0 }, 200);
                    e.preventDefault();
                }
                break;
            case 40:
                setActiveDescendant(getNextOption());
                //$lbox.scrollTop($lbox.height());
                //$lbox.scrollTop($('.activedescendant', $lbox).offset().top - ($lbox.height() - 50));
                $lbox.animate({ scrollTop: $('.activedescendant', $lbox).offset().top - $lbox.offset().top + $lbox.scrollTop(), scrollLeft: 0 }, 200);
                e.preventDefault();
                break;
            default:
                return true;
        }
    });
    $('#ulCounty[role="listbox"]').on('keyup', function (e) {
        if (e.which == 18) {
            altPressed = false;
        }
    });
    $('#btnToggle1.toggle').on('click', function (e) {
        $cbox = $('#comCounty[role="combobox"]');
        $input = $('#textbox1[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle1.toggle');
        $clearbutt = $('#btnClear1.clear');
        $lbox = $('#ulCounty[role="listbox"]');

        toggleLB();
        $cbox.focus();
        e.stopPropagation();
    });
    $('#btnClear1.clear').on('click', function (e) {
        $cbox = $('#comCounty[role="combobox"]');
        $input = $('#textbox1[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle1.toggle');
        $clearbutt = $('#btnClear1.clear');
        $lbox = $('#ulCounty[role="listbox"]');
        clearSelectedOptions();
        $('#selectedCounty').empty();
        $countCounty = 0;
        e.stopPropagation();
    });

    $('#comCity[role="combobox"]').on('keydown', function (e) {
        $cbox = $('#comCity[role="combobox"]');
        $input = $('#textbox2[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle2.toggle');
        $clearbutt = $('#btnClear2.clear');
        $lbox = $('#ulCity[role="listbox"]');
        //debugger
        switch (e.which) {
            case 18:
                altPressed = true;
                break;
            case 9:
                if (isOpen()) {
                    closeLB();
                }
                break;
            case 13:
            case 32:
                toggleLB();
                $lbox.scrollTop(0);
                if (isOpen()) {
                    $lbox.focus();
                    setActiveDescendant(getDefaultOption());
                }
                e.preventDefault();
                break;
            case 38:
                if (altPressed == true) {
                    closeLB();
                } else if (!isOpen()) {
                    openLB();
                    $lbox.scrollTop(0);
                    $lbox.focus();
                    setActiveDescendant(getDefaultOption());
                    e.preventDefault();
                }
                break;
            case 40:
                if (!isOpen()) {
                    openLB();
                }
                $lbox.scrollTop(0);
                $lbox.focus();
                $('.dropdown-search').focus();
                setActiveDescendant(getDefaultOption());
                e.preventDefault();
                break;
            default:
                return true;
        }
    });
    $('#comCity[role="combobox"]').on('keyup', function (e) {
        $cbox = $('#comCity[role="combobox"]');
        $input = $('#textbox2[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle2.toggle');
        $clearbutt = $('#btnClear2.clear');
        $lbox = $('#ulCity[role="listbox"]');
        if (e.which == 18) {
            altPressed = false;
        }
    });
    $('#ulCity[role="listbox"]').on('keydown', function (e) {
        //debugger
        switch (e.which) {
            case 18:
                altPressed = true;
                break;
            case 9:
                if (isOpen()) {
                    closeLB();
                }
                break;
            case 27:
                if (isOpen()) {
                    closeLB();
                    $cbox.focus();
                }
                break;
            case 13:
                $countCity = $('li[aria-selected="true"]', $('#ulCity')).length;
                if ($countCity > 6 && $('#' + $('#ulCity[role="listbox"]').attr('aria-activedescendant'), $('#ulCity[role="listbox"]')).attr('aria-selected') == 'false') {
                    return false;
                }
                toggleSelection(getActiveDescendant());
                var options_str = '';
                var $selectedOptions = $('li[aria-selected="true"]', $('#ulCity'));
                $countCity = $selectedOptions.length;
                if ($selectedOptions.length > 0) {
                    $selectedOptions.each(function () {
                        options_str += $(this).text() + ', ';
                    });
                    options_str = options_str.slice(0, -2);                   
                }
                var selectedCity = [];
                if (options_str != '') {
                    selectedCity = options_str.split(",")
                };
                $('#selectedCity').empty();
                $.each(selectedCity, function (index, city) { $("#selectedCity").append('<span class="tab">' + city + '</span>'); });
                closeLB();
                $cbox.focus();
                break;
            case 32:
                $countCity = $('li[aria-selected="true"]', $('#ulCity')).length;
                if ($countCity > 6 && $('#' + $('#ulCity[role="listbox"]').attr('aria-activedescendant'), $('#ulCity[role="listbox"]')).attr('aria-selected') == 'false') {
                    return false;
                }
                toggleSelection(getActiveDescendant());
                var options_str = '';
                var $selectedOptions = $('li[aria-selected="true"]', $('#ulCity'));
                $countCity = $selectedOptions.length;
                if ($selectedOptions.length > 0) {
                    $selectedOptions.each(function () {
                        options_str += $(this).text() + ', ';
                    });
                    options_str = options_str.slice(0, -2);
                }
                var selectedCity = [];
                if (options_str != '') {
                    selectedCity = options_str.split(",")
                };
                $('#selectedCity').empty();
                $.each(selectedCity, function (index, city) { $("#selectedCity").append('<span class="tab">' + city + '</span>'); });
                e.preventDefault();
                break;
            case 38:
                if (altPressed == true) {
                    closeLB();
                    $cbox.focus();
                } else {
                    setActiveDescendant(getPreviousOption());
                    $lbox.animate({ scrollTop: $('.activedescendant', $lbox).offset().top - $lbox.offset().top + $lbox.scrollTop(), scrollLeft: 0 }, 200);                    
                    //$lbox.scrollTop($lbox.height());
                    //$lbox.scrollTop($('.activedescendant', $lbox).offset().top - ($lbox.height() - 50));
                    e.preventDefault();
                }
                break;
            case 40:
                setActiveDescendant(getNextOption());
                $lbox.animate({ scrollTop: $('.activedescendant', $lbox).offset().top - $lbox.offset().top + $lbox.scrollTop(), scrollLeft: 0 }, 200);
                //$lbox.scrollTop($lbox.height());
                //$lbox.scrollTop($('.activedescendant', $lbox).offset().top - ($lbox.height() - 50));
                e.preventDefault();
                break;
            default:
                return true;
        }
    });
    $('#ulCity[role="listbox"]').on('keyup', function (e) {
        if (e.which == 18) {
            altPressed = false;
        }
    });
    $('#btnToggle2.toggle').on('click', function (e) {
        $cbox = $('#comCity[role="combobox"]');
        $input = $('#textbox2[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle2.toggle');
        $clearbutt = $('#btnClear2.clear');
        $lbox = $('#ulCity[role="listbox"]');
        toggleLB();
        $cbox.focus();
        e.stopPropagation();
    });
    $('#btnClear2.clear').on('click', function (e) {
        $cbox = $('#comCity[role="combobox"]');
        $input = $('#textbox2[role="textbox"]', $cbox);
        $togglebutt = $('#btnToggle2.toggle');
        $clearbutt = $('#btnClear2.clear');
        $lbox = $('#ulCity[role="listbox"]');
        clearSelectedOptions();
        $('#selectedCity').empty();
        $countCity = 0;
        e.stopPropagation();
    });

    $('html').on('click', function () {
        if (isOpen()) {
            closeLB();
        }
    });
    $('html').on('keydown', function (e) {
        if (e.which == 27 && isOpen()) {
            closeLB();
        }
    });
  
    //State drop down
    $('#lstState')
    .on('click', 'input', function (e) {
        e.stopPropagation();       
    })
    .on('input', '.dropdown-search', function (e) {       
        var target = $(this);
        var search = target.val().toLowerCase();

        if (!search) {
            $('#ulState li').show();
            return false;
        }
        $('#ulState li').each(function () {
            var text = $(this).text().toLowerCase();
            var match = text.indexOf(search) > -1;
            $(this).toggle(match);
        });
    })
    .on('click', '#ulState li', function (e) {
        clearSelectedOptions();
        toggleSelection($(this));
        setActiveDescendant($(this));
        e.stopPropagation();
    });

    //County drop down
    $('#lstCounty')
    .on('click', 'input', function (e) {
        e.stopPropagation();
    })
    .on('input', '.dropdown-search', function () {
        var target = $(this);
        var search = target.val().toLowerCase();

        if (!search) {
            $('#ulCounty li').show();
            return false;
        }
        $('#ulCounty li').each(function () {
            var text = $(this).text().toLowerCase();
            var match = text.indexOf(search) > -1;
            $(this).toggle(match);
        });
    })
    .on('click', '#ulCounty li', function (e) {

        $countCounty = $('li[aria-selected="true"]', $('#ulCounty')).length;
        if ($countCounty > 6 && $(this).attr('aria-selected') == 'false') {
            return false;
        }
        toggleSelection($(this));
        setActiveDescendant($(this));
        e.stopPropagation();
        var options_str = '';
        var $selectedOptions = $('li[aria-selected="true"]', $('#ulCounty'));
        $countCounty = $selectedOptions.length;
        if ($selectedOptions.length > 0) {
            $selectedOptions.each(function () {
                options_str += $(this).text() + ', ';
            });
            options_str = options_str.slice(0, -2);
            $cbox.addClass('selections');
            $togglebutt.hide();
            $clearbutt.show();
        }
       
        var selectedCounty = [];
        if (options_str != '') {
            selectedCounty = options_str.split(",").map(function (item) {
                return item.trim();
            })
        };
        $('#selectedCounty').empty();
        $.each(selectedCounty, function (index, County) { $("#selectedCounty").append('<span class="tab">' + County + '</span>'); });
        
        //$('#lstCounty').off('click');
        //$('#ulCounty[role="listbox"]').off('keydown');
        
        //$("#ulCounty").off();
        var stateCode = $('#ulCounty li').attr('name');
        CountyChange(stateCode, selectedCounty)
    });

    //City drop down
    $('#lstCity')
    .on('click', 'input', function (e) {
        e.stopPropagation();
    })
    .on('input', '.dropdown-search', function () {
        var target = $(this);
        var search = target.val().toLowerCase();

        if (!search) {
            $('#ulCity li').show();
            return false;
        }

        $('#ulCity li').each(function () {
            var text = $(this).text().toLowerCase();
            var match = text.indexOf(search) > -1;
            $(this).toggle(match);
        });
    })
    .on('click', '#ulCity li', function (e) {
        $countCity = $('li[aria-selected="true"]', $('#ulCity')).length;
        if ($countCity > 6 && $(this).attr('aria-selected') == 'false') {
            return false;
        }
        toggleSelection($(this));
        setActiveDescendant($(this));
        e.stopPropagation();

        var options_str = '';
        var $selectedOptions = $('li[aria-selected="true"]', $('#ulCity'));
        $countCity = $selectedOptions.length;
        if ($selectedOptions.length > 0) {
            $selectedOptions.each(function () {
                options_str += $(this).text() + ', ';
            });
            options_str = options_str.slice(0, -2);
            $cbox.addClass('selections');
            $togglebutt.hide();
            $clearbutt.show();
        }
        var selectedCity = [];
        if (options_str != '') {
            selectedCity = options_str.split(",")
        };
        $('#selectedCity').empty();
        $.each(selectedCity, function (index, city) { $("#selectedCity").append('<span class="tab">' + city + '</span>'); });
        
    });

    $("#rbByState").change(function () {
       
        var forgeryId = $("#forgeryToken").val();
        $('#lstState').removeClass('disabledDropdown');
        $('#txtZipCode').val('');
        $('#txtRadiusValue').val('10');
        $("#RadiusSlider").slider({
            value: $('#txtRadiusValue').val()
        });
        $("#ErrorMessageForSearchNow").empty();
        $('#btnAddRemoveError').empty();
        $("#errorMsgZipState").empty();
        $("#headingErrorMsg").empty();
        $("#ErrorMessageForInfo").empty();
        $("#errorMsgProviderType").empty();

        $("#zipDiv").hide();
        $("#stateDiv").show();

        var networkId = $('input[name=NetworkType]:checked').val();
        var cutomerType = $('input[name=UserType]:checked').val();
        

        //populate state
        $.ajax({
            type: 'POST',
            url: '/LocateProvider/GetState',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ networkId: networkId, cutomerType: cutomerType }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                // template
                var stateTemplate = _.template(
                    '<li id="<%= StateCode %>" role="option" aria-selected="false" onclick="changeState(' + "'<%= StateCode %>'" + ')">'
                       + '<%= capName %>' +
                    '</li>'
                );
                // Populate list with states
                _.each(result, function (s) {
                    s.capName = s.StateName;                  
                    $('#ulState').append(stateTemplate(s));
                });
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        });
    })

});

function changeState(stateCode) {
    try {
        $('#lstCounty').removeClass('disabledDropdown');
        $('#lstCity').removeClass('disabledDropdown');
        $('.dropdown-search').val('');
        $("#ErrorMessageForInfo").empty();
        $("#ErrorMessageForSearchNow").empty();
        $("#errorMsgProviderType").empty();
        $("#errorMsgUserType").empty();
        $("#headingErrorMsg").empty();
        $("#errorMsgZipState").empty();
        $("#selectedCounty").empty();
        $("#selectedCity").empty();
        //var stateCode = $('#SearchState').val();
        $countCounty = 0;
        $countCity = 0;

        $('#textbox1[role="textbox"]', $('#comCounty[role="combobox"]')).text($('#comCounty[role="combobox"]').attr('aria-label'));
        $('li[aria-selected="true"]', $('#ulCounty[role="listbox"]')).attr('aria-selected', 'false');
        $('#comCounty[role="combobox"]').removeClass('selections');
        $('#btnClear1.clear').hide();
        $('#btnToggle1.toggle').show();


        $('#textbox2[role="textbox"]', $('#comCity[role="combobox"]')).text($('#comCity[role="combobox"]').attr('aria-label'));
        $('li[aria-selected="true"]', $('#ulCity[role="listbox"]')).attr('aria-selected', 'false');
        $('#comCity[role="combobox"]').removeClass('selections');
        $('#btnClear2.clear').hide();
        $('#btnToggle2.toggle').show();

        $('#divCountySearch').hide();
        $('#divCitySearch').hide();

        $('#ulCounty').empty();
        $('#ulCity').empty();

        GetCountiesByState(stateCode)
        GetCitiesByState(stateCode)
    }
    catch (e) {
        console.log(e.message);
    }
};

function GetCountiesByState(stateCode) {
    try {
        var forgeryId = $("#forgeryToken").val();
        $.ajax({
            type: 'POST',
            url: '/LocateProvider/GetCountiesByState',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ stateCode: stateCode }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {        
                // template
                var CountyTemplate = _.template(
                    '<li id="<%= CountyName %>" name="<%= StateCode %>"  role="option" aria-selected="false"><span class="check" aria-hidden="true"></span>'
                        + '<%= capName %>' +
                    '</li>'
                );
                //Populate list with County
                _.each(result, function (s) {
                    s.capName = s.CountyName;
                    s.CountyName = s.CountyName.split(" ").join("");
                    $('#ulCounty').append(CountyTemplate(s));
                });
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

function GetCitiesByState(stateCode) {
    try {
        var forgeryId = $("#forgeryToken").val();
        $.ajax({
            type: 'POST',
            url: '/LocateProvider/GetCitiesByState',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ stateCode: stateCode }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {

                // template
                var CityTemplate = _.template(
                    '<li id="<%= CityName %>" role="option" aria-selected="false"><span class="check" aria-hidden="true"></span>'
                        + '<%= capName %>' +
                    '</li>'
                );
                //Populate list with City
                _.each(result, function (s) {
                    s.capName = s.CityName;
                    s.CityName = s.CityName.split(" ").join("");
                    $('#ulCity').append(CityTemplate(s));
                });
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

function CountyChange(stateCode, county) {
    $('#divCitySearch').hide();
    $('#ulCity').empty();
    $('#textbox2[role="textbox"]', $('#comCity[role="combobox"]')).text($('#comCity[role="combobox"]').attr('aria-label'));
    $('li[aria-selected="true"]', $('#ulCity[role="listbox"]')).attr('aria-selected', 'false');
    $('#comCity[role="combobox"]').removeClass('selections');
    $('#btnClear2.clear').hide();
    $('#btnToggle2.toggle').show();
    $('#selectedCity').empty();
    var forgeryId = $("#forgeryToken").val();
    if (county.length > 0) {       
        $.ajax({
            type: 'POST',
            url: '/LocateProvider/GetCitiesByStateAndCounty',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ stateCode: stateCode, county: county }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                // <li> template
                var CityTemplate = _.template(
                    '<li id="<%= CityName %>" role="option" aria-selected="false"><span class="check" aria-hidden="true"></span>'
                        + '<%= capName %>' +
                    '</li>'
                );
                // Populate list with City
                _.each(result, function (s) {
                    s.capName = s.CityName;
                    s.CityName = s.CityName.split(" ").join("");
                    $('#ulCity').append(CityTemplate(s));
                });               
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        });
    }
    else {
        //var stateCode = $('#SearchState').val();
        if (stateCode != null && stateCode != "") {
            GetCitiesByState(stateCode)          
        }
    }
}