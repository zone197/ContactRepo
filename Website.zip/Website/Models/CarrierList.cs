﻿using NABWebsite.BLL;
using NABWebsite.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NABWebsite.Models
{
    public class CarrierList
    {

        //public List<SelectListItem> Carriers { get; set; }

        //public CarrierList GetCarrierList(UserPhoneNumber UserPhoneNumber)
        //{
        //    CarrierList carr = new CarrierList();
        //    ManageContent mc = new ManageContent();
        //    CarrierData objectAll = mc.GetCarrierDataList();
        //    carr.Carriers = new List<SelectListItem>();
        //    List<SelectListItem> li = new List<SelectListItem>();

        //    foreach (var item in objectAll.CarriersList)
        //    {
        //        li.Add(new SelectListItem { Text = item.CarrierName, Value = item.CarrierCode });

        //    }
        //    carr.Carriers = li;
        //    return carr;

        //}
    }
}