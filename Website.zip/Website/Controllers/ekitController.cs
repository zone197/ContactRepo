﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models;
using NABWebsite.DTO;
using NABWebsite.BLL;
using Newtonsoft.Json;
using System.IO;
using System.Linq.Expressions;
using System.Reflection;



namespace NABWebsite.Controllers
{
    public class ekitController : BaseController
    {
        //// GET: ekit
        //public ActionResult Index()
        //{
        //    return View();
        //}
        public ActionResult Index()
        {
            e_Kit ekitModel = new e_Kit();
            List<SelectListItem> itemsEIN = new List<SelectListItem>();

            itemsEIN.Add(new SelectListItem { Text = "CMS", Value = "CMS" });
            itemsEIN.Add(new SelectListItem { Text = "UB", Value = "UB" });
            itemsEIN.Add(new SelectListItem { Text = "Dental", Value = "Dental" });

            List<SelectListItem> itemsClient = new List<SelectListItem>();

            itemsClient.Add(new SelectListItem { Text = "ADVENTIST RISK MANAGEMENT", Value = "ADVENTIST RISK MANAGEMENT" });
            itemsClient.Add(new SelectListItem { Text = "AMERIBEN", Value = "AMERIBEN" });
            itemsClient.Add(new SelectListItem { Text = "MEMORIAL MEDICAL NETWORK", Value = "MEMORIAL MEDICAL NETWORK" });

            List<SelectListItem> itemsSubClient = new List<SelectListItem>();

            itemsSubClient.Add(new SelectListItem { Text = "CAMERA CRAFT SHOP", Value = "CAMERA CRAFT SHOP" });
            itemsSubClient.Add(new SelectListItem { Text = "CENTENNIAL MEDICAL", Value = "CENTENNIAL MEDICAL" });
            itemsSubClient.Add(new SelectListItem { Text = "ASSOCIATES IN BUILDING", Value = "ASSOCIATES IN BUILDING" });

            List<SelectListItem> itemsKeyMode = new List<SelectListItem>();

            itemsKeyMode.Add(new SelectListItem { Text = "Manual", Value = "Manual" });
            itemsKeyMode.Add(new SelectListItem { Text = "OCR", Value = "OCR" });

            Session[Constants.CurrentController] = "ekit";
            Session[Constants.CurrentAction] = "Index";
            Session[Constants.Header] = "e-Kit";

            ekitModel.KeyMode = itemsKeyMode;
            ekitModel.FormType = itemsEIN;
            ekitModel.ClientList = itemsClient;
            ekitModel.SubClientList = itemsSubClient;
            return View("ClaimKeyInitial", ekitModel);

        }
        [HttpPost]
        public ActionResult Index(e_Kit e)
        {
            ViewClaim prod = new ClaimInquiryBL().Initials("");
            List<SelectListItem> itemsCity = new List<SelectListItem>();
            itemsCity.Add(new SelectListItem { Text = "--Select--", Value = "--Select--", Selected = true });
            itemsCity.Add(new SelectListItem { Text = "New York", Value = "New York" });
            itemsCity.Add(new SelectListItem { Text = "Senfield", Value = "Senfield" });

            List<SelectListItem> itemsState = new List<SelectListItem>();
            itemsState.Add(new SelectListItem { Text = "--Select--", Value = "--Select--", Selected = true });
            itemsState.Add(new SelectListItem { Text = "New Jersey", Value = "New Jersey" });
            itemsState.Add(new SelectListItem { Text = "Michigan", Value = "Michigan" });

            prod.States = itemsState;
            prod.City = itemsCity;
            return View("CMSEkit", prod);

        }
        [HttpPost]
        public ActionResult CMSEkit()
        {
            ViewClaim prod = new ClaimInquiryBL().Initials("");
            List<SelectListItem> itemsCity = new List<SelectListItem>();

            itemsCity.Add(new SelectListItem { Text = "New York", Value = "New York" });
            itemsCity.Add(new SelectListItem { Text = "Senfield", Value = "Senfield" });

            List<SelectListItem> itemsState = new List<SelectListItem>();

            itemsState.Add(new SelectListItem { Text = "New Jersey", Value = "New Jersey" });
            itemsState.Add(new SelectListItem { Text = "Michigan", Value = "Michigan" });

            prod.States = itemsState;
            prod.City = itemsCity;
            Session[Constants.CurrentController] = "ekit";
            Session[Constants.CurrentAction] = "CMSEkit";
            Session[Constants.Header] = "e-Kit";
            return View(prod);
        }

        
        public ActionResult UBEkit() 
        {
            UBView prod = new ClaimInquiryBL().InitialsUB("");
            List<SelectListItem> itemsCity = new List<SelectListItem>();

            itemsCity.Add(new SelectListItem { Text = "Yes", Value = "Yes" });
            itemsCity.Add(new SelectListItem { Text = "No", Value = "No" });
            List<SelectListItem> itemsChoice = new List<SelectListItem>();

            itemsChoice.Add(new SelectListItem { Text = "Yes", Value = "Yes" });
            itemsChoice.Add(new SelectListItem { Text = "No", Value = "No" });
            List<SelectListItem> itemsState = new List<SelectListItem>();

            itemsState.Add(new SelectListItem { Text = "New Jersey", Value = "New Jersey" });
            itemsState.Add(new SelectListItem { Text = "Michigan", Value = "Michigan" });
            prod.Choice = itemsChoice;
            prod.States = itemsState;
           // prod.City = itemsCity;
            Session[Constants.CurrentController] = "ekit";
            Session[Constants.CurrentAction] = "CMSEkit";
            Session[Constants.Header] = "e-Kit";
            //UBView prod = new UBView();
            return View("UBEkit",prod);

        }
        public int CountAttachement(string kitTrackerId)
        {
            List<ViewClaim> downloadList = new ClaimInquiryBL().ViewAttachement(kitTrackerId);

            var records = downloadList.Count;
            return records;
        }

        [HttpPost]
        public JsonResult ClientAuto(string clientName, string productLine)
        {
            int total = 3;
            List<string> productDetails = new ClaimInquiryBL().ClientBasedOnProduct(clientName, productLine);


            productDetails = productDetails.FindAll(m => SortHelper.Contains(m.ToString(), clientName, StringComparison.OrdinalIgnoreCase)).ToList();
            var records = productDetails;

            return Json(records, JsonRequestBehavior.AllowGet);

            //return Json(new { filteredItems }, JsonRequestBehavior.AllowGet);

        }
        [HttpPost]
        public JsonResult SubClientAuto(string clientName, string subClientName)
        {
            int total = 3;
            List<string> productDetails = new ClaimInquiryBL().SubClientBasedOnClient(clientName, subClientName);


            productDetails = productDetails.FindAll(m => SortHelper.Contains(m.ToString(), subClientName, StringComparison.OrdinalIgnoreCase)).ToList();
            var records = productDetails;

            return Json(records, JsonRequestBehavior.AllowGet);

            //return Json(new { filteredItems }, JsonRequestBehavior.AllowGet);

        }
        public JsonResult SearchProviderDetails(string TaxId,string Name)
        {
            string taxid = "12345";
            //"Delivery"
            List<string> Provider = new List<string>() { "Apple", "BAMR", "Custom" };
            var records = new List<string>();
            if (taxid == TaxId)
            {
                records = Provider.FindAll(m => SortHelper.Contains(m.ToString(), Name, StringComparison.OrdinalIgnoreCase)).ToList();
                if (records.Count == 0)
                {
                    Name = "d";
                    records = Provider.FindAll(m => SortHelper.Contains(m.ToString(), Name, StringComparison.OrdinalIgnoreCase)).ToList();
                    if (records.Count == 0)
                    {
                        records = null;
                    }
                    else
                    {
                        records = new List<string>() { "Others" };
                    }
                }
                
            }
            return Json(records, JsonRequestBehavior.AllowGet);
        }
        public string Upload(string KitTrackerId, string exisAttachmentId)
        {

            List<ViewClaim> listUpload = new List<ViewClaim>();
            for (int i = 0; i < Request.Files.Count; i++)
            {
                ViewClaim fileInput = new ViewClaim();
                HttpPostedFileBase file = Request.Files[i]; //Uploaded file
                //Use the following properties to get file's name, size and MIMEType
                byte[] fileContent = null;
                string mimeType = file.ContentType;
                var fileName = Path.GetFileName(file.FileName);
                using (var memoryStream = new MemoryStream())
                {
                    file.InputStream.CopyTo(memoryStream);
                    fileContent = memoryStream.ToArray();
                }
                fileInput.Attachment = fileContent;
                fileInput.AttachmentDocType = mimeType;
                fileInput.AttachmentFileName = fileName;
                fileInput.BarCode = "";
                fileInput.UserIdCreated = "N630112";
                fileInput.KITTrackerID = "KCP1524564";

                listUpload.Add(fileInput);
                int fileSize = file.ContentLength;

                
               

                listUpload.Add(fileInput);


            }

            int output = new ClaimInquiryBL().UploadAttachment(listUpload, exisAttachmentId);


            //return View("Powerstep_GH", model);
            if (output == 0)

                return "success";
            else
                return "error";

        }
        public List<ViewClaim> GetBillLineFromString(string billSave)
        {

            var DeserializedModelBilling = new ViewClaim();
            var billList = new List<ViewClaim>();
            billSave = billSave.Substring(1, billSave.Length - 2);
            string[] Bill = billSave.Split(new[] { "}," }, StringSplitOptions.None);

            for (int i = 0; i < Bill.Length; i++)
            {
                if (i < Bill.Length - 1)
                {
                    Bill[i] = Bill[i] + "}";
                }
                DeserializedModelBilling = JsonConvert.DeserializeObject<ViewClaim>(Bill[i]);

                billList.Add(DeserializedModelBilling);
            }
            return billList;

        }
        [HttpPost]
        public double Update(string updateData)
        {
            var records = new List<ViewClaim>();

            string DecodedNewData = Server.UrlDecode(updateData);
            var previousData = Session["PreviousData"] as List<ViewClaim>;
            var DeserializedModel = GetBillLineFromString(DecodedNewData);
            int id = 0;
            double sumCharges = 0;
            if (previousData != null)
            {
                for (int i = 0; i < previousData.Count; i++)
                {
                    if (previousData[i].ID == DeserializedModel[0].ID)
                    {
                        previousData[i] = DeserializedModel[0];
                    }
                    if (previousData[i].Charges != "" && previousData[i].Charges != null)
                        sumCharges += Convert.ToDouble(previousData[i].Charges);
                }

                Session["PreviousData"] = previousData;
            }
            return sumCharges;
        }
        [OutputCache(Duration = 0)]
        public JsonResult FetchGrid(int? page, int? limit, string sortBy, string direction)
        {
            int total = 0;
            var records = new List<ViewClaim>();
            //int currentPage = 0;
            Session["Limit"] = limit;
            if (Session["PreviousData"] != null)
            {
                records = Session["PreviousData"] as List<ViewClaim>;
                total = records.Count;
                for (int i = 0; i < records.Count; i++)
                {
                    records[i].ID = i + 1;
                }
                if (page.HasValue && limit.HasValue)
                {
                    //int start = 0;
                    if (records.Count > limit.Value)
                    {
                        int start = (page.Value - 1) * limit.Value;
                        records = records.Skip(start).Take(limit.Value).ToList();
                    }
                    else
                    {
                        //page = 1;

                        //records = null;

                    }

                    //if (records .Count> limit.Value)


                }
                if (records.Count == 0) records = null;
            }
            else
            {
                records = null;
            }
           
            return Json(new { records, total }, JsonRequestBehavior.AllowGet);

        }
        [OutputCache(Duration = 0)]
        [HttpPost]
        public double AddToGrid(int? page, int? limit, string sortBy, string direction, string add)
        {
            //int total = 0;
            var records = new List<ViewClaim>();

            string DecodedNewData = Server.UrlDecode(add);
            ViewClaim test = new ViewClaim();
            var previousData = Session["PreviousData"] as List<ViewClaim>;
            var DeserializedModel = GetBillLineFromString(DecodedNewData);
            if (previousData == null)
            {
                Session["PreviousData"] = DeserializedModel;
                test.LineTestJson = DeserializedModel;
                double sumCharges = 0;

                for (int i = 0; i < DeserializedModel.Count; i++)
                {
                    if (DeserializedModel[i].Charges != "" && DeserializedModel[i].Charges != null)
                        sumCharges += Convert.ToDouble(DeserializedModel[i].Charges);
                }

                return Math.Round(sumCharges, 2);

            }
            else
            {
                //if (DeserializedModel[0].ID != previousData[previousData.Count-1].ID)
                //{
                var AllBillData = previousData.Concat(DeserializedModel).ToList();
                Session["PreviousData"] = AllBillData;
                // }
                test.LineTestJson = AllBillData;
                double sumCharges = 0;

                for (int i = 0; i < AllBillData.Count; i++)
                {
                    if (AllBillData[i].Charges != "" && AllBillData[i].Charges != null)
                        sumCharges += Convert.ToDouble(AllBillData[i].Charges);
                }

                return Math.Round(sumCharges, 2);
                //return Json(new { test.LineTestJson }, JsonRequestBehavior.AllowGet);
            }

        }
        [HttpPost]
        public string Remove(int id)
        {
            var AllBillData = Session["PreviousData"] as List<ViewClaim>;
            
            string DisButton = "";
            int limit = 0;
            int output = 1;
            if (Session["Limit"] != null)
            {
                limit = (int)Session["Limit"];
            }

            //var RemoveId = DeletedData[0].ID;
            if (AllBillData != null)
            {
                //if (AllBillData.Count >= RemoveId)
                //{
                if (limit != 0)
                {
                    if (id % limit == 0)
                    {
                        output = id / limit;
                        DisButton = "N";
                    }
                    if (id % limit > 0)
                    {
                        output = id / limit + 1;
                        DisButton = "N";
                    }
                    if (id == AllBillData[AllBillData.Count - 1].ID)
                    {
                        if (id % limit == 1)
                        {
                            output = (id - 1) / limit;
                            DisButton = "Y";
                        }
                    }
                }
                var item = AllBillData.First(x => x.ID == id);
                AllBillData.Remove(item);
                //}
                //records = AllBillData;
                //for (int i = 0; i < records.Count; i++)
                //{
                //    records[i].ID = i + 1;
                //}
                //total = records.Count;
            }
            Session["PreviousData"] = AllBillData;
            double sumCharges = 0;
            if (AllBillData != null)
            {
                for (int i = 0; i < AllBillData.Count; i++)
                {
                    if (AllBillData[i].Charges != "" && AllBillData[i].Charges != null)
                        sumCharges += Convert.ToDouble(AllBillData[i].Charges);
                }

            }


            DisButton = sumCharges.ToString() + "," + DisButton;

            return DisButton;
        }
    }
    public static class SortHelper
    {

        public static IOrderedQueryable<T> OrderBy<T>(this IQueryable<T> source, string property)
        {
            return ApplyOrder<T>(source, property, "OrderBy");
        }
        public static IOrderedQueryable<T> OrderByDescending<T>(this IQueryable<T> source, string property)
        {
            return ApplyOrder<T>(source, property, "OrderByDescending");
        }
        public static IOrderedQueryable<T> ThenBy<T>(this IOrderedQueryable<T> source, string property)
        {
            return ApplyOrder<T>(source, property, "ThenBy");
        }
        public static IOrderedQueryable<T> ThenByDescending<T>(this IOrderedQueryable<T> source, string property)
        {
            return ApplyOrder<T>(source, property, "ThenByDescending");
        }
        static IOrderedQueryable<T> ApplyOrder<T>(IQueryable<T> source, string property, string methodName)
        {
            string[] props = property.Split('.');
            Type type = typeof(T);
            ParameterExpression arg = Expression.Parameter(type, "x");
            Expression expr = arg;
            foreach (string prop in props)
            {
                // use reflection (not ComponentModel) to mirror LINQ 
                PropertyInfo pi = type.GetProperty(prop);
                expr = Expression.Property(expr, pi);
                type = pi.PropertyType;
            }
            Type delegateType = typeof(Func<,>).MakeGenericType(typeof(T), type);
            LambdaExpression lambda = Expression.Lambda(delegateType, expr, arg);

            object result = typeof(Queryable).GetMethods().Single(
                    method => method.Name == methodName
                            && method.IsGenericMethodDefinition
                            && method.GetGenericArguments().Length == 2
                            && method.GetParameters().Length == 2)
                    .MakeGenericMethod(typeof(T), type)
                    .Invoke(null, new object[] { source, lambda });
            return (IOrderedQueryable<T>)result;
        }
        public static bool Contains(this string target, string value, StringComparison comparison)
        {
            return target.StartsWith(value, comparison);
        }

    }
}