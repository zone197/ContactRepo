﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.DTO;
using System.IO;
using NABWebsite.BLL;
using System.Configuration;
using NABWebsite.Helper;
using System.Web.Mail;
using System.Net.Mail;
using System.Net.Mime;

namespace NABWebsite.Controllers
{
    public class ProviderTINRequestController : Controller
    {
        // GET: ProviderTINRequest
        public ActionResult Index()
        {
            try
            {
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ProviderTINRequestHeader;
                return View();
            }
            catch (Exception ex)
            {
                throw;
            }

        }
        [HttpPost]
        public ActionResult ProviderTin(ProviderTINRequestForm formData)
        {
            try
            {
                var val = Convert.ToInt32(ConfigurationManager.AppSettings["pdfFileContentLength"]);
                Boolean success;
                string FileName = "";
                byte[] binData = null;
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ProviderTINRequestHeader;

                if (ModelState.IsValid)
                {
                    if (formData.Files != null)
                    {
                        if (formData.Files.ContentType.Contains("pdf"))
                        {
                            if (formData.Files.ContentLength < Convert.ToInt32(ConfigurationManager.AppSettings["pdfFileContentLength"]))
                            {

                                FileName = Path.GetFileName(formData.Files.FileName);
                                //Improper Resource Shutdown or release Security Vulnerability issue fix on 14-Mar-2019
                                using(BinaryReader b = new BinaryReader(formData.Files.InputStream))
                                {
                                    try
                                    {
                                        binData = b.ReadBytes(formData.Files.ContentLength);
                                    }
                                    catch(Exception ex)
                                    {
                                        throw;
                                    }
                                    finally
                                    {
                                        if(b!=null)
                                        {
                                            b.Close();
                                            b.Dispose();
                                        }
                                    }
                                } 
                            }
                            else
                            {
                                ModelState.AddModelError("Files", "Please upload document of size less than 10MB");
                                return View("Index", formData);
                            }
                        }
                        else
                        {
                            ModelState.AddModelError("Files", "Please upload document in pdf format only");
                            return View("Index", formData);
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("Files", "A completed W-9 and request on business letterhead are required");
                        return View("Index", formData);
                    }
                    string body = string.Empty;

                    using (StreamReader reader = new StreamReader(Server.MapPath("~/Views/ProviderTINRequest/EmailTemplate.html")))
                    {
                        body = reader.ReadToEnd();
                    }

                    body = body.Replace("{TINNum}", formData.TINNum);
                    body = body.Replace("{TypeOfTinChange}", formData.TypeOfTinChange);
                    body = body.Replace("{ReasonForTINChange}", formData.ReasonForTINChange);
                    body = body.Replace("{ProviderName}", formData.ProviderName);
                    body = body.Replace("{NPI}",formData.NPI);
                    body = body.Replace("{OffLoc}", formData.officeLocation);
                    body = body.Replace("{CPDID}", string.IsNullOrEmpty(formData.CPDID) ? "N/A" : formData.CPDID);
                    body = body.Replace("{ContactName}", formData.ContactName);
                    body = body.Replace("{ContactNum}", formData.ContactNum);
                    body = body.Replace("{ContactEmail}", string.IsNullOrEmpty(formData.ContactEmail) ? "N/A" : formData.ContactEmail);

                    ManageContent contentManager = new ManageContent();
                    string[] emailAddresses;
                    var email = "";
                    email = ConfigurationManager.AppSettings["FromProviderTINRequestFormInfo"];
                    List<string> emailAddressesList = new List<string>();
                    if (!string.IsNullOrEmpty(email)) emailAddressesList.Add(email);
                    emailAddresses = emailAddressesList.ToArray();
                    success = contentManager.SendMailProviderTINRequestFormInfo(body, emailAddresses, VariableConstant.ProviderTINRequestFormInfoSubject, formData.concatRequest, binData, FileName);
                    if (success == true)
                    {
                        return Content("<script type='text/javascript'>alert('Your form has been submitted.');window.location.href='/ProviderTINRequest/Index';</script>");
                    }
                    else
                    {
                        return Content("<script type='text/javascript'>alert('Your form cannot be submitted due to an error.');window.location.href='/ProviderTINRequest/Index';</script>");
                    }
                }
                else
                {
                    return View("Index");
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }
    }
}