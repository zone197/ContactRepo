﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Models;
using System.Configuration;
using System.Dynamic;
using NABWebsite.Helper;
using System.Web;
using System.Web.SessionState;
using System.Threading;
using System.Text.RegularExpressions;
using Aetna.ProviderContracts.DataContracts;
using System.Globalization;
using System.Net;
using Aetna.Cofinity.Admin.Entities.Response;
using System.Web.Security.AntiXss;
using CofinityEncryption;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Utilities;

namespace NABWebsite
{
    public class HomeController : BaseController
    {
        #region Declaration
        private static Dictionary<string, string> _cacheHostUrl;
        private static Dictionary<string, int> _cachePageids;
        private const string CONST_SUCCESS = "Success";
        private static int CacheDuration = Convert.ToInt32(ConfigurationManager.AppSettings["CacheDuration"]);
        #endregion

        // will assign by lang selection
        int langcode = Convert.ToInt32(ConfigurationManager.AppSettings["langCode"], CultureInfo.InvariantCulture);
        int defaultSourceId = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultSourceId"], CultureInfo.InvariantCulture);
        private string clientIPAddress
        {
            get
            {
                string forwardedFor = "HTTP_X_FORWARDED_FOR", remoteAdr = "REMOTE_ADDR", nonStdLocalIP = "::1", stdIP = "127.0.0.1";
                string clientIp = (Request.ServerVariables[forwardedFor] ?? Request.ServerVariables[remoteAdr]).Split(',')[0].Trim();
                if (clientIp == nonStdLocalIP)
                    clientIp = stdIP;
                return clientIp;
            }
        }

        #region Page Layout

        /// <summary>
        /// Method responsible for populating the content page navigation
        /// </summary>
        /// <param name="PageId"></param>
        /// <returns></returns>
       
        public ActionResult Index(string PageId = "1000")
        {
            StringBuilder traceLog = new StringBuilder();
            traceLog.AppendLine("Start: HomeController, Index Method with Params PageId: " + PageId);
            // Set default language to english and save to cookie 
            string culture = AppSettingHelper.GetAppSettingValue(CookieConstant.InitialCulture);
            string userId = null;


            //clear all session of locate provider
            Session[SessionConstant.ComparedProvider] = null;
            Session[SessionConstant.TaggedProvider] = null;
            Session[SessionConstant.SortingPagingInfo] = null;
            Session[SessionConstant.TaggedSortingPagingInfo] = null;
            Session[SessionConstant.SearchRequest] = null;
            Session[SessionConstant.ClientListDetails] = null;
            Session[Constants.Header] = null;
            //navigation for custom URLs //NABIT golive comment

            if (RedirectToCustomURL(PageId))
                return RedirectToAction("CustomPage", "LocateProvider");
            var homePage = Convert.ToString(ConfigurationManager.AppSettings["HomeUrl_FH"]);
            string siteName = ConfigurationManager.AppSettings["Site"];
            if (siteName == "External" && Request.Url != null && !Request.Url.ToString().Contains(homePage))
            {
                var redirectHome = homePage + "Home/Index";
                return Redirect(redirectHome);
            }

            traceLog.AppendLine("Start: HomeController, GoHome Method with Params PageId: " + PageId);
            //Culture is set to english for content pages bydefault because no language change is for content page
            Session["_culture"] = "en-us";

            Session[Constants.Site] = ConfigurationManager.AppSettings[Constants.Site];
            ViewBag.Title = "First Health and Confinity ";
            int pageId = 0;
            PageId = PageId.Replace(" ", "").Replace("/", "").Replace("-", "").Replace("&", "");
            try
            {

                int id;
                if (int.TryParse(PageId, out id))
                {
                    pageId = Convert.ToInt32(id);
                    pageId = GetpageIds("", id);
                    if (id != pageId)
                    {
                        pageId = 1000;
                    }
                }
                else
                {
                    pageId = GetpageIds(PageId, 0);
                    pageId = 1000; //rediret to home if parsing fail
                }
                traceLog.AppendLine(" & End: HomeController, Index Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
                traceLog.Clear();
            }
            try
            {
               
                traceLog.AppendLine("Start: HomeController, Index Method with Params PageId: " + PageId);
                Session[Constants.CurrentController] = "Home";
                Session[Constants.CurrentAction] = "Index";
                IndexViewModel indexViewModel = new IndexViewModel();
                RightSectionGenericContainer objRightSectionGenContainer = null;
                RightSectionNewsContainer objRightSectionNewsContainer = null;
                List<RightSectionGenericContainer> ListRightGeneric = new List<RightSectionGenericContainer>();
                List<RightSectionNewsContainer> ListNews = new List<RightSectionNewsContainer>();

                // Get page information from service
                ManageContent manageContent = new ManageContent();
                PageInfo pageInfo = new PageInfo();
                pageInfo = manageContent.GetPagContent(pageId, langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                
                var ListGenericContainer = new List<PageSection>();

                if ((UserDetails)Session[Constants.UserDetails] != null)
                {
                    UserDetails userDetails = (UserDetails)Session[Constants.UserDetails];
                    var userRole = userDetails.UserRoles != null ? userDetails.UserRoles.First().RoleName : null;
                    if (userDetails.SelectedRole != null && ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                    {
                        if (Session[Constants.FairCostAccess] != null)
                        {
                            if (Convert.ToBoolean(Session[Constants.FairCostAccess]) == false)
                                ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
                            else
                                ListGenericContainer = pageInfo.PageSections;
                        }
                        else
                            ListGenericContainer = pageInfo.PageSections;
                    }
                    else if (userRole != null && userRole.ToUpper() == "PAYER" && userDetails.SelectedRole == null)
                    {
                        if (Session[Constants.FairCostAccess] != null)
                        {
                            if (Convert.ToBoolean(Session[Constants.FairCostAccess]) == false)
                                ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
                            else
                                ListGenericContainer = pageInfo.PageSections;
                        }
                        else
                        {
                            ListGenericContainer = pageInfo.PageSections;
                        }
                    }
                    else
                    {
                        ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
                    }
                }
                else
                {
                    ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
                }

                // Content section model
                ContentViewModel contentViewModel = new ContentViewModel();
                contentViewModel.Title = pageInfo.Content.Heading;
                contentViewModel.Contents = pageInfo.Content.ContentText; //Encode the html
                contentViewModel.ID = pageInfo.Content.PageId;
                //NABIT strip out

                // Top linked section belonging to current page
                var ListLinkedSections = pageInfo.LinkedSections.FirstOrDefault();
                if (ListLinkedSections != null)
                {
                    TopLeftSectionViewModel topLeftSection = new TopLeftSectionViewModel(ListLinkedSections);
                    contentViewModel.TopLeftSection = topLeftSection;
                }
                indexViewModel.Content = contentViewModel;

                //Populate model for Right generic section
                foreach (var ob in ListGenericContainer)
                {
                    objRightSectionGenContainer = new RightSectionGenericContainer();
                    objRightSectionGenContainer.ImageId = ob.ImageId;
                    objRightSectionGenContainer.ImageName = ob.ImageName;
                    objRightSectionGenContainer.ImageContent = ob.ImageContent;
                    objRightSectionGenContainer.LinkId = ob.LinkId;
                    objRightSectionGenContainer.LinkType = ob.LinkType;
                    objRightSectionGenContainer.LinkUrl = ob.LinkUrl;
                    objRightSectionGenContainer.TargetPageId = ob.TargetPageId;
                    objRightSectionGenContainer.Title = ob.Title;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.GroupType = ob.GroupType;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.SectionOrder = ob.SectionOrder;
                    ListRightGeneric.Add(objRightSectionGenContainer);
                }

                ViewBag.RightFirstContainer = ListRightGeneric;

                //Populate model for Right group/news section
                foreach (var ob in pageInfo.GroupedSections)
                {
                    objRightSectionNewsContainer = new RightSectionNewsContainer();
                    objRightSectionNewsContainer.ItemId = ob.ItemId;
                    objRightSectionNewsContainer.str_ItemId =
                        "'" + NABEncryption.Encrypt(Convert.ToString(ob.ItemId)) + "'";
                    objRightSectionNewsContainer.ImageId = ob.ImageId;
                    objRightSectionNewsContainer.ImageName = ob.ImageName;
                    objRightSectionNewsContainer.ImageContent = ob.ImageContent;
                    objRightSectionNewsContainer.LinkId = ob.LinkId;
                    objRightSectionNewsContainer.Title = ob.Title;
                    objRightSectionNewsContainer.SubType = ob.SubType;
                    objRightSectionNewsContainer.DetailText = ob.DetailText;
                    objRightSectionNewsContainer.SectionId = ob.SectionId;
                    objRightSectionNewsContainer.GroupType = ob.GroupType;
                    objRightSectionNewsContainer.SectionId = ob.SectionId;
                    objRightSectionNewsContainer.SectionOrder = ob.SectionOrder;
                    objRightSectionNewsContainer.IsClickable = ob.IsClickable;
                    objRightSectionNewsContainer.NewsEventDate = ob.NewsEventDate;
                    objRightSectionNewsContainer.NewsEventDuration = ob.NewsEventDuration;
                    objRightSectionNewsContainer.hosturl = GetHostUrl("HOSTURL");

                    ListNews.Add(objRightSectionNewsContainer);
                }


                if (ListRightGeneric != null && ListRightGeneric.Count > 0)
                    indexViewModel.ListGenContainer = ListRightGeneric;

                if (ListRightGeneric != null && ListNews.Count > 0)
                    indexViewModel.ListNewsContainer = ListNews;
                //check if page is realted with executive view or normal view
                if (pageInfo.Content.Heading.Contains("Executive"))
                {
                    traceLog.AppendLine(" & End: HomeController, Index Method");
                    return View("~/views/home/ExecutiveProfile.cshtml", indexViewModel);
                }
                else
                {
                    traceLog.AppendLine(" & End: HomeController, Index Method");
                    return View(indexViewModel);
                }


            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        public ActionResult FooterIndex(string PageId = "0")
        {
            // Set default language to english and save to cookie 
            string culture = AppSettingHelper.GetAppSettingValue(CookieConstant.InitialCulture);
            SetCulture(culture);
            Session[SessionConstant.ComparedProvider] = null;
            Session[SessionConstant.TaggedProvider] = null;
            Session[SessionConstant.SortingPagingInfo] = null;
            Session[SessionConstant.TaggedSortingPagingInfo] = null;
            Session[SessionConstant.SearchRequest] = null;
            //navigation for custom URLs //NABIT golive comment


            Session[Constants.Site] = ConfigurationManager.AppSettings[Constants.Site];
            ViewBag.Title = "First Health and Confinity ";
            StringBuilder traceLog = new StringBuilder();
            try
            {

                traceLog.AppendLine("Start: HomeController, FooterIndex Method");
                Session[Constants.CurrentController] = "Home";
                Session[Constants.CurrentAction] = "FooterIndex";
                IndexViewModel indexViewModel = new IndexViewModel();
                RightSectionGenericContainer objRightSectionGenContainer = null;
                RightSectionNewsContainer objRightSectionNewsContainer = null;
                List<RightSectionGenericContainer> ListRightGeneric = new List<RightSectionGenericContainer>();
                List<RightSectionNewsContainer> ListNews = new List<RightSectionNewsContainer>();

                // Get page information from service
                ManageContent manageContent = new ManageContent();
                PageInfo pageInfo = new PageInfo();
                if (ReturnCultureInfo() == "en-us")
                {
                    langcode = 1;
                }
                else
                {
                    langcode = 2;
                }
                pageInfo = manageContent.GetPagContent(Convert.ToInt32(PageId), langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                var ListGenericContainer = new List<PageSection>();


                if ((UserDetails)Session[Constants.UserDetails] != null)
                {
                    UserDetails userDetails = (UserDetails)Session[Constants.UserDetails];
                    var userRole = userDetails.UserRoles != null ? userDetails.UserRoles.First().RoleName : null;
                    if (userDetails.SelectedRole != null && ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                    {
                        ListGenericContainer = pageInfo.PageSections;
                    }
                    else if (userRole != null && userRole.ToUpper() == "PAYER" && userDetails.SelectedRole == null)
                    {
                        ListGenericContainer = pageInfo.PageSections;
                    }
                    else
                    {
                        ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
                    }
                }
                else
                {
                    ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
                }
                // Content section model
                ContentViewModel contentViewModel = new ContentViewModel();
                contentViewModel.Title = pageInfo.Content.Heading;
                contentViewModel.Contents = pageInfo.Content.ContentText;
                contentViewModel.ID = pageInfo.Content.PageId;
                //NABIT strip out

                // Top linked section belonging to current page
                var ListLinkedSections = pageInfo.LinkedSections.FirstOrDefault();
                if (ListLinkedSections != null)
                {
                    TopLeftSectionViewModel topLeftSection = new TopLeftSectionViewModel(ListLinkedSections);
                    contentViewModel.TopLeftSection = topLeftSection;
                }
                indexViewModel.Content = contentViewModel;

                //Populate model for Right generic section
                foreach (var ob in ListGenericContainer)
                {
                    objRightSectionGenContainer = new RightSectionGenericContainer();
                    objRightSectionGenContainer.ImageId = ob.ImageId;
                    objRightSectionGenContainer.ImageName = ob.ImageName;
                    objRightSectionGenContainer.ImageContent = ob.ImageContent;
                    objRightSectionGenContainer.LinkId = ob.LinkId;
                    objRightSectionGenContainer.LinkType = ob.LinkType;
                    objRightSectionGenContainer.LinkUrl = ob.LinkUrl;
                    objRightSectionGenContainer.TargetPageId = ob.TargetPageId;
                    objRightSectionGenContainer.Title = ob.Title;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.GroupType = ob.GroupType;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.SectionOrder = ob.SectionOrder;
                    ListRightGeneric.Add(objRightSectionGenContainer);
                }

                ViewBag.RightFirstContainer = ListRightGeneric;

                //Populate model for Right group/news section
                foreach (var ob in pageInfo.GroupedSections)
                {
                    objRightSectionNewsContainer = new RightSectionNewsContainer();
                    objRightSectionNewsContainer.ItemId = ob.ItemId;
                    objRightSectionNewsContainer.str_ItemId = "'" + NABEncryption.Encrypt(Convert.ToString(ob.ItemId)) + "'";
                    objRightSectionNewsContainer.ImageId = ob.ImageId;
                    objRightSectionNewsContainer.ImageName = ob.ImageName;
                    objRightSectionNewsContainer.ImageContent = ob.ImageContent;
                    objRightSectionNewsContainer.LinkId = ob.LinkId;
                    objRightSectionNewsContainer.Title = ob.Title;
                    objRightSectionNewsContainer.SubType = ob.SubType;
                    objRightSectionNewsContainer.DetailText = ob.DetailText;
                    objRightSectionNewsContainer.SectionId = ob.SectionId;
                    objRightSectionNewsContainer.GroupType = ob.GroupType;
                    objRightSectionNewsContainer.SectionId = ob.SectionId;
                    objRightSectionNewsContainer.SectionOrder = ob.SectionOrder;
                    objRightSectionNewsContainer.IsClickable = ob.IsClickable;
                    objRightSectionNewsContainer.NewsEventDate = ob.NewsEventDate;
                    objRightSectionNewsContainer.NewsEventDuration = ob.NewsEventDuration;
                    objRightSectionNewsContainer.hosturl = GetHostUrl("HOSTURL");
                    ListNews.Add(objRightSectionNewsContainer);
                }

                if (ListRightGeneric != null && ListRightGeneric.Count > 0)
                    indexViewModel.ListGenContainer = ListRightGeneric;

                if (ListRightGeneric != null && ListNews.Count > 0)
                    indexViewModel.ListNewsContainer = ListNews;
                traceLog.AppendLine(" & End: HomeController, FooterIndex Method");
                return View("~/Views/Home/Index.cshtml", indexViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
       
        public Boolean LoggedUser()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, LoggedUser Method");
                UserRegistrationBLL user = new UserRegistrationBLL();
                UserDetails userDetails = (UserDetails)Session[Constants.UserDetails];
                string session = Session.SessionID;
                if (userDetails != null && userDetails.IsAuthenticated)
                {
                    int count = user.GetLoggedUserCount(session, userDetails.UserId, ConfigurationManager.AppSettings[Constants.website]);
                    if (count > 0)
                    {
                        traceLog.AppendLine(" & End: HomeController, LoggedUser Method");
                        return true;
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: HomeController, LoggedUser Method");
                        return false;
                    }
                }
                else
                {
                    traceLog.AppendLine(" & End: HomeController, LoggedUser Method");
                    return true;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        public ActionResult MultipleUser()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, MultipleUser Method");
                Session.Clear();
                Session.Abandon();
                Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
                traceLog.AppendLine(" & End: HomeController, MultipleUser Method");
                return View();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        public ActionResult RightContainer()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, RightContainer Method");
                ManageContent manageContent = new ManageContent();
                PageInfo pageInfo = manageContent.GetPagContent(1031, 1, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                RightSectionGenericContainer objRightSectionGenContainer = null;
                List<RightSectionGenericContainer> ListRightGeneric = new List<RightSectionGenericContainer>();
                //Populate model for Right generic section
                foreach (var ob in pageInfo.PageSections)
                {
                    objRightSectionGenContainer = new RightSectionGenericContainer();
                    objRightSectionGenContainer.ImageId = ob.ImageId;
                    objRightSectionGenContainer.ImageName = ob.ImageName;
                    objRightSectionGenContainer.ImageContent = ob.ImageContent;
                    objRightSectionGenContainer.LinkId = ob.LinkId;
                    objRightSectionGenContainer.LinkType = ob.LinkType;
                    objRightSectionGenContainer.LinkUrl = ob.LinkUrl;
                    objRightSectionGenContainer.TargetPageId = ob.TargetPageId;
                    objRightSectionGenContainer.Title = ob.Title;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.GroupType = ob.GroupType;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.SectionOrder = ob.SectionOrder;
                    ListRightGeneric.Add(objRightSectionGenContainer);
                }
                traceLog.AppendLine(" & End: HomeController, RightContainer Method");
                return PartialView("_RightGenericContainer", ListRightGeneric);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        public ActionResult Home(LayoutViewModel modelObject, string submitButton)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, Home Method with Param modelObject: " + modelObject + " and with Param submitButton: " + submitButton);
                if (submitButton == Constants.UserLogOn)
                {
                    if ((UserDetails)Session[Constants.UserDetails] == null)
                    {
                        traceLog.AppendLine(" & End: HomeController, Home Method");
                        return RedirectToAction("Index");
                    }
                    ((UserDetails)Session[Constants.UserDetails]).SelectedRole = modelObject.selectedRole;
                }
                else
                {
                    LoginAudit();
                    Session.Clear();
                    Session.Abandon();
                    Session.RemoveAll();
                    Session[Constants.Userid] = null;
                    Session[Constants.SessionPrd] = null;
                    Session[Constants.LoggedUserid] = null;
                    Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                    Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId"));

                }
                traceLog.AppendLine(" & End: HomeController, Home Method");
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        private void LoginAudit()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, LoginAudit Method");
                if (((UserDetails)Session[Constants.UserDetails]) != null)
                {
                    LogonActivity activity = new LogonActivity();
                    activity.ApplicationName = ConfigurationManager.AppSettings[Constants.website];
                    activity.userType = ConfigurationManager.AppSettings[Constants.Site];
                    activity.Userid = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    activity.UserName = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    activity.Roleid = 1;
                    activity.RoleGroupid = 1;
                    activity.SessionID = Session.SessionID;
                    activity.hostAddress = Request.UserHostAddress;
                    UserRegistrationBLL user = new UserRegistrationBLL();
                    user.LoginAudit(activity);
                }
                traceLog.AppendLine(" & End: HomeController, LoginAudit Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Get Menus for layout
        /// </summary>
           public ActionResult GetMenus()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetMenus Method");
                ManageContent manageContent = new ManageContent();
                List<Menu> Menus = null;
                List<int> includeRole = new List<int>();
                List<int> ProviderIncludeRole = new List<int>();
                //Non logged in menu details removed
                if (((UserDetails)Session[Constants.UserDetails]) == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    Menus = manageContent.GetMenuDetails(langcode, includeRole, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()).FindAll(x => x.MenuID != Convert.ToInt32(ConfigurationManager.AppSettings[Constants.FirstHealthMenu]));
                }
                else
                {
                    if (((UserDetails)Session[Constants.UserDetails]).UserRoles != null && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                    {
                        foreach (var role in ((UserDetails)Session[Constants.UserDetails]).UserRoles)
                        {
                            if (role.RoleName == ((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                            {
                                if (role.RoleName.ToUpper().Equals("PROVIDER"))
                                {
                                    if (Session["ProviderActiveMenuList"] != null)
                                    {
                                        foreach (var sensorType in ((List<SensorType>)Session["ProviderActiveMenuList"]))
                                        {
                                            if (sensorType.SensorGroupName == "Menu-Attachment Inquiry")
                                            {
                                                //get selected role
                                                Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(r => r.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                                                //get the network for selcted function
                                                List<Network> networkList = new List<Network>();
                                                if (selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuAttachment, StringComparison.OrdinalIgnoreCase)) != null)
                                                {
                                                    networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuAttachment, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList<Network>();
                                                    foreach (var item in networkList)
                                                    {
                                                        if (item.SrcSystemId == 1) //Work only for Cofinity.
                                                        {
                                                            foreach (var menu in sensorType.ControlsList)
                                                            {
                                                                ProviderIncludeRole.Add(Convert.ToInt32(menu.ControlName));
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                foreach (var menu in sensorType.ControlsList)
                                                {
                                                    ProviderIncludeRole.Add(Convert.ToInt32(menu.ControlName));
                                                }
                                            }
                                        }
                                        Menus = manageContent.GetMenuDetails(langcode, ProviderIncludeRole, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                                    }
                                    else
                                    {
                                        Menus = manageContent.GetMenuDetails(langcode, ProviderIncludeRole, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()).FindAll(x => x.MenuID != Convert.ToInt32(ConfigurationManager.AppSettings[Constants.FirstHealthMenu]));
                                    }
                                    break;
                                }
                                else
                                {
                                    if (Session["ActiveMenuList"] != null)
                                    {
                                        foreach (var sensorType in ((List<SensorType>)Session["ActiveMenuList"]))
                                        {
                                            if (sensorType.SensorGroupName == "Menu-Attachment Inquiry")
                                            {
                                                //get selected role
                                                Aetna.Cofinity.Admin.Entities.Response.Role selectedRole = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(r => r.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault();
                                                //get the network for selcted function
                                                List<Network> networkList = new List<Network>();
                                                if (selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuAttachment, StringComparison.OrdinalIgnoreCase)) != null)
                                                {
                                                    networkList = selectedRole.FunctionNetworks.Where(function => function.Key.Equals(Constants.MenuAttachment, StringComparison.OrdinalIgnoreCase)).FirstOrDefault().Value.ToList<Network>();
                                                    foreach (var item in networkList)
                                                    {
                                                        if (item.SrcSystemId == 1) //Work only for Cofinity.
                                                        {
                                                            foreach (var menu in sensorType.ControlsList)
                                                            {
                                                                includeRole.Add(Convert.ToInt32(menu.ControlName));
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                foreach (var menu in sensorType.ControlsList)
                                                {
                                                    includeRole.Add(Convert.ToInt32(menu.ControlName));
                                                }
                                            }
                                        }
                                        Menus = manageContent.GetMenuDetails(langcode, includeRole, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                                    }
                                    else
                                    {
                                        Menus = manageContent.GetMenuDetails(langcode, includeRole, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()).FindAll(x => x.MenuID != Convert.ToInt32(ConfigurationManager.AppSettings[Constants.FirstHealthMenu]));
                                    }
                                    break;
                                }
                            }
                            else
                            {
                                Menus = manageContent.GetMenuDetails(langcode, includeRole, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()).FindAll(x => x.MenuID != Convert.ToInt32(ConfigurationManager.AppSettings[Constants.FirstHealthMenu]));
                            }
                        }
                    }
                    else
                    {
                        Menus = manageContent.GetMenuDetails(langcode, includeRole, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString()).FindAll(x => x.MenuID != Convert.ToInt32(ConfigurationManager.AppSettings[Constants.FirstHealthMenu]));
                    }
                }
                traceLog.AppendLine(" & End: HomeController, GetMenus Method");
                return PartialView("_Menu", Menus);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Renders Headers as part of layout
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ChildActionOnly]
        
        public ActionResult Header(string id)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, Header Method with Param id: " + id);
                LayoutViewModel layoutmodel = new LayoutViewModel();
                
                // CARBundling Code Start  
                ManageContent omngcontent = new ManageContent();
                layoutmodel.HeaderComponents = omngcontent.GetHeaderInfo(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                layoutmodel.hosturl = GetHostUrl("HOSTURL");
                // CARBundling Code End

                // Lab code changes Start
                layoutmodel = GetLayoutData();
                List<SelectListItem> items = new List<SelectListItem>();
                // Lab code changes END
                 //Add selectitems from Session Roles List
                if (((UserDetails)Session[Constants.UserDetails]) != null)
                {
                    if (((UserDetails)Session[Constants.UserDetails]).UserRoles != null)
                    {
                        foreach (var role in ((UserDetails)Session[Constants.UserDetails]).UserRoles)
                        {
                            items.Add(new SelectListItem { Text = role.RoleName, Value = role.RoleName });
                        }
                        layoutmodel.userroles = items;
                        if (((UserDetails)Session[Constants.UserDetails]).SelectedRole == null)
                        {
                            ((UserDetails)Session[Constants.UserDetails]).SelectedRole = items.FirstOrDefault().Value;
                        }
                        else
                        {
                            layoutmodel.selectedRole = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                        }
                    }

                }

                return PartialView("~/views/shared/header.cshtml", layoutmodel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        
        /// <summary>
        /// Render footer part of layout
        /// </summary>
        /// <returns></returns>
        [ChildActionOnly]
       public ActionResult Footer()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, Footer Method");
                LayoutViewModel layoutmodel = new LayoutViewModel();
                // Code from bundling start
                ManageContent omngcontent = new ManageContent();
                string culture = ReturnCultureInfo();
                if (culture == "en-us")
                {
                    langcode = 1;
                }
                else
                {
                    langcode = 2;
                }
                layoutmodel.FooterInfo = omngcontent.GetFooterInfo(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                layoutmodel.hosturl = GetHostUrl("HOSTURL");
                // Code from bundling End 
                // Code from Lab start
                layoutmodel = GetLayoutData();
                // Code from Lab End
                traceLog.AppendLine(" & End: HomeController, Footer Method");
                return PartialView("~/views/shared/footer.cshtml", layoutmodel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// Footer specifically fro LocateProvider network selection
        /// </summary>
        /// <returns></returns>
        [ChildActionOnly]
        public ActionResult FooterLocateProviderIndex()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, FooterLocateProviderIndex Method");
                LayoutViewModel layoutmodel = new LayoutViewModel();

                // Code from car bundling start
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                ManageContent omngcontent = new ManageContent();
                if (culture == "en-us")
                {
                    langcode = 1;
                }
                else
                {
                    langcode = 2;
                }

                layoutmodel.FooterInfo = omngcontent.GetFooterInfo(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                
                layoutmodel.hosturl = GetHostUrl("HOSTURL");

                // Code from lab start
                layoutmodel = GetLayoutDataLocateProvider();
                // Code from lab END
                traceLog.AppendLine(" & End: HomeController, FooterLocateProviderIndex Method");
                return PartialView("~/views/shared/FooterLocateProviderIndex.cshtml", layoutmodel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Footer specifically fro LocateProvider other pages
        /// </summary>
        /// <returns></returns>
        [ChildActionOnly]
        public ActionResult FooterLocateProviderRest()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, FooterLocateProviderRest Method");
                LayoutViewModel layoutmodel = new LayoutViewModel();
                // Code from car bundling start
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                ManageContent omngcontent = new ManageContent();
                if (culture == "en-us")
                {
                    langcode = 1;
                }
                else
                {
                    langcode = 2;
                }

                layoutmodel.FooterInfo = omngcontent.GetFooterInfo(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
               
                layoutmodel.hosturl = GetHostUrl("HOSTURL");
                // Code from car lab start
                layoutmodel = GetLayoutDataLocateProvider();
                // Code from car lab end
                traceLog.AppendLine(" & End: HomeController, FooterLocateProviderRest Method");
                return PartialView("~/views/shared/FooterLocateProviderRest.cshtml", layoutmodel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Footer specifically for LocateProvider SearchResult pages
        /// </summary>
        /// <returns></returns>
        [ChildActionOnly]
        public ActionResult FooterLocateProviderSearchResult()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, FooterLocateProviderSearchResult Method");
                LayoutViewModel layoutmodel = new LayoutViewModel();
                layoutmodel = GetLayoutDataLocateProvider();
                traceLog.AppendLine(" & End: HomeController, FooterLocateProviderSearchResult Method");
                return PartialView("~/views/shared/FooterLocateProviderSearchResult.cshtml", layoutmodel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Footer Function
        /// </summary>
        /// <returns></returns>
        [ChildActionOnly]
        [OutputCache(Duration = int.MaxValue, VaryByParam = "none")]
        public ActionResult FooterFunction()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, FooterFunction Method");
                LayoutViewModel layoutmodel = new LayoutViewModel();
                layoutmodel = GetLayoutDataLocateProvider();
                traceLog.AppendLine(" & End: HomeController, FooterFunction Method");
                return PartialView("~/views/shared/Footerfunction.cshtml", layoutmodel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Added ny N645289-Kamalesh Das
        /// Renders pahse 2 state disclaimers page
        /// </summary>
        /// <returns></returns>
        public ActionResult StateDisclaimers()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, StateDisclaimers Method");
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                request.Functionality = AppSettingHelper.GetAppSettingValue(VariableConstant.StateDisclaimerKey);
                LayoutModel layoutmodel = new LayoutModel();
                ManageContent omngcontent = new ManageContent();
                layoutmodel.StateDisclaimerList = omngcontent.GetStateDisclaimers(request).ToList();
                SetActiveControllerToSession(ApplicationConstants.HomeController, ApplicationConstants.StateDisclaimersAction);
                traceLog.AppendLine(" & End: HomeController, StateDisclaimers Method");
                return View("~/views/shared/LocateProvider/StateDisclaimers.cshtml", layoutmodel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// set values of current controller and action
        /// </summary>
        /// <param name="controller"></param>
        /// <param name="actionMethod"></param>
        void SetActiveControllerToSession(string controller, string actionMethod)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, SetActiveControllerToSession Method with Param controller: " + controller + " and with Param actionMethod: " + actionMethod);
                if (Session[SessionConstant.CurrentController] != null && Session[SessionConstant.CurrentAction] != null)
                {
                    if (!(Session[SessionConstant.CurrentController].ToString().Equals(controller) && Session[SessionConstant.CurrentAction].ToString().Equals(actionMethod)))
                    {
                        Session[SessionConstant.CurrentController] = controller;
                        Session[SessionConstant.CurrentAction] = actionMethod;
                    }
                }
                else
                {
                    Session[SessionConstant.CurrentController] = controller;
                    Session[SessionConstant.CurrentAction] = actionMethod;
                }
                traceLog.AppendLine(" & End: HomeController, SetActiveControllerToSession Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Building the final layout to render
        /// </summary>
        /// <returns></returns>
        private LayoutViewModel GetLayoutData()
        {
            StringBuilder traceLog = new StringBuilder();
            LayoutViewModel layoutmodel = new LayoutViewModel();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetLayoutData Method");
                ManageContent omngcontent = new ManageContent();
                if (ReturnCultureInfo() == "en-us")
                {
                    langcode = 1;
                }
                else
                {
                    langcode = 2;
                }
                layoutmodel.FooterInfo = omngcontent.GetFooterInfo(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                langcode = Convert.ToInt32(ConfigurationManager.AppSettings["langCode"], CultureInfo.InvariantCulture);
                layoutmodel.HeaderComponents = omngcontent.GetHeaderInfo(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                layoutmodel.hosturl = GetHostUrl("HOSTURL");
                traceLog.AppendLine(" & End: HomeController, GetLayoutData Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return layoutmodel;
        }
        /// <summary>
        /// Added by N645289-Kamalesh Das
        /// Renders phase 2 locate provider different layout
        /// </summary>
        /// <returns></returns>
        [CustomOutputCacheAttribute("CacheDuration1800_none")]
        private LayoutViewModel GetLayoutDataLocateProvider()
        {
            StringBuilder traceLog = new StringBuilder();
            LayoutViewModel layoutmodel = new LayoutViewModel();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetLayoutDataLocateProvider Method");
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                ManageContent omngcontent = new ManageContent();
                if (ReturnCultureInfo() == "en-us")
                {
                    langcode = 1;
                }
                else
                {
                    langcode = 2;
                }

                layoutmodel.FooterInfo = omngcontent.GetFooterInfo(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                langcode = Convert.ToInt32(ConfigurationManager.AppSettings["langCode"], CultureInfo.InvariantCulture);
                layoutmodel.hosturl = GetHostUrl("HOSTURL");
                traceLog.AppendLine(" & End: HomeController, GetLayoutDataLocateProvider Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw ex;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return layoutmodel;
        }
        #endregion

        #region Contact us info
        /// <summary>
        /// Renders contact us info from db
        /// </summary>
        /// <returns></returns>
        [ChildActionOnly]
        public ActionResult ContactUsPopup()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, ContactUsPopup Method");
                //creating model object
                List<ContactUsInfoModel> lstcontactusInfo = new List<ContactUsInfoModel>();

                List<ContactUsInfo> lst = new List<ContactUsInfo>();

                if (ReturnCultureInfo() == "en-us")
                {
                    langcode = 1;
                }
                else
                {
                    langcode = 2;
                }
                ManageContent manageContent = new ManageContent();

                lst = manageContent.getcontactusinfo(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                foreach (ContactUsInfo item in lst)
                {
                    ContactUsInfoModel Div = new ContactUsInfoModel();

                    if (langcode == 2 && item.GroupDivisionName == "Contact First Health")
                        Div.GroupDivisionName = @NABResources.Resources.lblGroupDivisionName;

                    else if (langcode == 2 && item.GroupDivisionName == "Contact Cofinity")
                        Div.GroupDivisionName = @NABResources.Resources.lblCofinityGroupDivisionName;

                    else if (item.GroupDivisionName == "Contact First Choice")
                        Div.GroupDivisionName = @NABResources.Resources.lblFComGroupDivisionName;

                    else if (item.GroupDivisionName == "Intermediary sales")
                        Div.GroupDivisionName = @NABResources.Resources.lblSalesGroupDivisionName;
                    else
                        Div.GroupDivisionName = item.GroupDivisionName;

                    List<ContactUsGroups> lstofgrps = new List<ContactUsGroups>();

                    foreach (ContactUsGroups group in item.ListOfGroups)
                    {
                        ContactUsGroups grp = new ContactUsGroups();
                        if (langcode == 2 && group.DisplayTime != null && group.DisplayTime == "8am – 8pm ET")
                            group.DisplayTime = @NABResources.Resources.lblDisplayTime;
                        else if (langcode == 2 && group.DisplayTime != null && group.DisplayTime == "8am – 5pm ET")
                            group.DisplayTime = @NABResources.Resources.lblDisplayTime2;
                        grp = group;

                        lstofgrps.Add(grp);

                    }
                    Div.ListOfGroups = lstofgrps;
                   
                    lstcontactusInfo.Add(Div);
                }
                langcode = Convert.ToInt32(ConfigurationManager.AppSettings["langCode"], CultureInfo.InvariantCulture);
                traceLog.AppendLine(" & End: HomeController, ContactUsPopup Method");
                return PartialView("~/views/shared/contactuspopup.cshtml", lstcontactusInfo);

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Contact us form render
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Contactuspage()
        {
            return PartialView("~/views/shared/ContactUsPage.cshtml");
        }

        [AjaxValidateAntiForgeryToken]
        public JsonResult VerifyContactUsTokenValue(string secureToken)
        {
            string errorMessage = string.Empty;
            WebClient client = new WebClient();
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, VerifyContactUsTokenValue Method");
                string response = secureToken;
                string secret = AppSettingHelper.GetAppSettingValue(VariableConstant.PrivateKey);
                bool isSuccess = true;

                string captchaErrorMessage = string.Empty;

                var reply = client.DownloadString(string.Format(CultureInfo.CurrentCulture, AppSettingHelper.GetAppSettingValue(VariableConstant.GoogleRecaptchaVerificationURL), secret, response));
                var jobj = JObject.Parse(reply);
                isSuccess = (bool)jobj.SelectToken("success");
                if (!isSuccess)
                {
                    captchaErrorMessage = (string)jobj.SelectToken("error-codes");
                    switch (captchaErrorMessage)
                    {
                        case ("missing-input-secret"):
                            errorMessage = Constants.CaptchaParameterMissing;
                            break;
                        case ("invalid-input-secret"):
                            errorMessage = Constants.CaptchaParameterInvalid;
                            break;

                        case ("missing-input-response"):
                            errorMessage = Constants.ResponseParameterMissing;
                            break;
                        case ("invalid-input-response"):
                            errorMessage = Constants.ResponseParameterInvalid;
                            break;

                        default:
                            errorMessage = Constants.CaptchaError;
                            break;
                    }

                }
                else
                {
                    errorMessage = String.Empty;
                }

            }
            catch (Exception ex)
            {

                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                client.Dispose();
                LogManager.WriteTraceLog(traceLog);
            }
            traceLog.AppendLine(" & End: HomeController, VerifyContactUsTokenValue Method");
            return Json(errorMessage);
        }

            /// <summary>
            /// Save Contact us Information to database
            /// </summary>
            /// <param name="UserContactForm"></param>
            /// <returns></returns>
            [AjaxValidateAntiForgeryToken]
        public JsonResult ContactUsUserDetails(ContactUsPage UserContactForm)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, ContactUsUserDetails Method with Param UserContactForm: " + UserContactForm);
                // success signal from database
                int success = 0;

                ContactUsPage Userinfo = new ContactUsPage();
                string IsValidContactInfo = ValidateContactUsInfo(UserContactForm);
                if (!IsValidContactInfo.Equals(CONST_SUCCESS))
                {
                    traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                    return Json(IsValidContactInfo);
                }

                ContactUsUserInfo(UserContactForm, Userinfo);

                string body = string.Empty;

                using (StreamReader reader = new StreamReader(Server.MapPath("~/Views/Home/EmailTemplate.html")))
                {
                    body = reader.ReadToEnd();
                }
                body = body.Replace("{FirstName}", Userinfo.FirstName);
                body = body.Replace("{Secondname}", Userinfo.SecondName);
                body = body.Replace("{ContactMeBy}", Userinfo.ContactMeBy);
                body = body.Replace("{Email}", string.IsNullOrEmpty(Userinfo.Email) ? "N/A" : Userinfo.Email);
                body = body.Replace("{PhoneNo}", string.IsNullOrEmpty(Userinfo.PhoneNo) ? "N/A" : Userinfo.PhoneNo);
                body = body.Replace("{RequestRegarding}", Userinfo.RequestRegarding);
                body = body.Replace("{Query}", WebUtility.HtmlDecode(Userinfo.UserQuery));


                if (ModelState.IsValid)
                {
                    ManageContent managecontent = new ManageContent();
                    //Redirected to service method
                    var errors = ModelState.SelectMany(x => x.Value.Errors.Select(z => z.Exception));
                    string clientIp = (Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ?? Request.ServerVariables["REMOTE_ADDR"]).Split(',')[0].Trim();
                    success = managecontent.SaveContactInfo(Userinfo, body, clientIp, null, null, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());

                    if (success > 0)
                    {
                        traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                        return Json("Success");
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                        return Json("Failed");
                    }

                }
                else
                {
                    var modelStateErrors = this.ModelState.Values.SelectMany(m => m.Errors);
                    var errorlist = modelStateErrors.ToList();
                    traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                    return Json(errorlist);
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [AjaxValidateAntiForgeryToken]
        public JsonResult SendContactAttachment()
        {
            StringBuilder traceLog = new StringBuilder();
            byte[] attachedFile = null;
            string fileError = string.Empty;
            string fileName = string.Empty;
            try
            {
                traceLog.AppendLine("Start: HomeController, SendContactAttachment Method with Param UserContactForm");
                // success signal from database
                int success = 0;
                ContactUsPage Userinfo = new ContactUsPage();
                ContactUsPage userContactForm = new ContactUsPage();
                var request = Request.Form;

                var requestDictionary = request.AllKeys
                    .Where(p => request[p] != "null")
                    .ToDictionary(p => p, p => request[p]);
                string jsonRequest = JsonConvert.SerializeObject(requestDictionary);
                userContactForm = JsonConvert.DeserializeObject<ContactUsPage>(jsonRequest);

                if (ModelState.IsValid)
                {
                    ManageContent managecontent = new ManageContent();

                    //GET FILE
                    if (Request.Files.Count > 0)
                    {
                        HttpPostedFileBase file = Request.Files[0];

                        if (file != null && file.ContentType.Contains("pdf"))
                        {
                            if (file.ContentLength <
                                Convert.ToInt32(ConfigurationManager.AppSettings["pdfFileContentLength"]))
                            {
                                fileName = Path.GetFileName(file.FileName);
                                //Improper Resource Shutdown or release Security Vulnerability issue fix on 14-Mar-2019
                                using (BinaryReader b = new BinaryReader(file.InputStream))
                                {
                                    try
                                    {
                                        attachedFile = b.ReadBytes(file.ContentLength);
                                    }
                                    catch (Exception ex)
                                    {
                                        throw;
                                    }
                                    finally
                                    {
                                        if (b != null)
                                        {
                                            b.Close();
                                            b.Dispose();
                                        }
                                    }
                                }

                                string IsValidContactInfo = ValidateContactUsInfo(userContactForm);
                                if (!IsValidContactInfo.Equals(CONST_SUCCESS))
                                {
                                    traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                                    return Json(IsValidContactInfo);
                                }

                                ContactUsUserInfo(userContactForm, Userinfo);

                                string body = string.Empty;

                                using (StreamReader reader =
                                    new StreamReader(Server.MapPath("~/Views/Home/EmailTemplate.html")))
                                {
                                    body = reader.ReadToEnd();
                                }
                                body = body.Replace("{FirstName}", Userinfo.FirstName);
                                body = body.Replace("{Secondname}", Userinfo.SecondName);
                                body = body.Replace("{ContactMeBy}", Userinfo.ContactMeBy);
                                body = body.Replace("{Email}",
                                    string.IsNullOrEmpty(Userinfo.Email) ? "N/A" : Userinfo.Email);
                                body = body.Replace("{PhoneNo}",
                                    string.IsNullOrEmpty(Userinfo.PhoneNo) ? "N/A" : Userinfo.PhoneNo);
                                body = body.Replace("{RequestRegarding}", Userinfo.RequestRegarding);
                                body = body.Replace("{Query}", WebUtility.HtmlDecode(Userinfo.UserQuery));


                                //Redirected to service method
                                var errors = ModelState.SelectMany(x => x.Value.Errors.Select(z => z.Exception));
                                string clientIp =
                                (Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ??
                                 Request.ServerVariables["REMOTE_ADDR"]).Split(',')[0].Trim();
                                success = managecontent.SaveContactInfo(Userinfo, body, clientIp, attachedFile,fileName, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());

                                if (success > 0)
                                {
                                    traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                                    return Json(new { result = "Success", showErr = false },
                                        JsonRequestBehavior.AllowGet);
                                }
                                else
                                {
                                    traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                                    return Json(new { result = "Failed", showErr = false }, JsonRequestBehavior.AllowGet);
                                }


                            }
                            else
                            {
                                fileError = "Please upload document of size less than 10MB";
                                traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                                return Json(new { result = fileError, showErr = true }, JsonRequestBehavior.AllowGet);
                            }
                        }
                        else
                        {
                            fileError = "Please upload document in pdf format only";
                            traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                            return Json(new { result = fileError, showErr = true }, JsonRequestBehavior.AllowGet);
                        }
                    }
                    else
                    {

                        fileError = "Please upload valid document ";
                        traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                        return Json(new { result = fileError, showErr = true }, JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    var modelStateErrors = this.ModelState.Values.SelectMany(m => m.Errors);
                    var errorlist = modelStateErrors.ToList();
                    traceLog.AppendLine(" & End: HomeController, ContactUsUserDetails Method");
                    return Json(new { result = errorlist, showErr = false }, JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Contact us user information
        /// </summary>
        /// <param name="UserContactForm"></param>
        /// <param name="Userinfo"></param>
        private void ContactUsUserInfo(ContactUsPage UserContactForm, ContactUsPage Userinfo)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, ContactUsUserInfo Method with Param UserContactForm: " + UserContactForm + " and with Param Userinfo: " + Userinfo);
                Userinfo.FirstName = AntiXssEncoder.HtmlEncode(UserContactForm.FirstName, false);
                Userinfo.SecondName = AntiXssEncoder.HtmlEncode(UserContactForm.SecondName, false);
                Userinfo.ContactMeBy = AntiXssEncoder.HtmlEncode(UserContactForm.ContactMeBy, false);
                Userinfo.Email = AntiXssEncoder.HtmlEncode(UserContactForm.Email, false);
                Userinfo.PhoneNo = AntiXssEncoder.HtmlEncode(UserContactForm.PhoneNo, false);
                Userinfo.RequestRegarding = AntiXssEncoder.HtmlEncode(UserContactForm.RequestRegarding, false);
                Userinfo.UserQuery = AntiXssEncoder.HtmlEncode(UserContactForm.UserQuery, false);
                Userinfo.ContactPreference = AntiXssEncoder.HtmlEncode(UserContactForm.ContactPreference, false);
                Userinfo.concatRequest = AntiXssEncoder.HtmlEncode(UserContactForm.concatRequest, false);
                Userinfo.IpAddress = clientIPAddress;
                traceLog.AppendLine(" & End: HomeController, ContactUsUserInfo Method");
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        #endregion Contact us info

        #region Sitemap
        /// <summary>
        /// Sitemap
        /// </summary>
        /// <returns></returns>
        public ActionResult Sitemap()
        {
            return View();
        }
        /// <summary>
        /// Render sitemap
        /// </summary>
        /// <returns></returns>
        public JsonResult GetSiteMap()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetSiteMap Method");
                List<SiteMapNodes> lstSiteMapNodes = new List<SiteMapNodes>();

                if (ReturnCultureInfo() == "en-us")
                    lstSiteMapNodes = GetSitemapDetails(1);
                else
                    lstSiteMapNodes = GetSitemapDetails(2);
                traceLog.AppendLine(" & End: HomeController, GetSiteMap Method");
                return Json(lstSiteMapNodes, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
       
        [CustomOutputCacheAttribute("CacheDuration1800_langcode")]
        public List<SiteMapNodes> GetSitemapDetails(int langcode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetSitemapDetails Method with Param langcode: " + langcode);
                ManageContent manageContent = new ManageContent();
                List<SitemapDetail> siteMaplst = manageContent.GetSitemapDetails(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());

                List<SiteMapNodes> nodeList = new List<SiteMapNodes>();

                var rootNodes = siteMaplst.FindAll(_item => _item.ParentId == 0);

                foreach (SitemapDetail node in rootNodes)
                {
                    var nodeItem = CreateNode(node, siteMaplst);
                    nodeList.Add(nodeItem);
                }
                traceLog.AppendLine(" & End: HomeController, GetSitemapDetails Method");
                return nodeList;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Generate sitemap Nodes
        /// </summary>
        /// <param name="node"></param>
        /// <param name="nodelst"></param>
        /// <returns></returns>
        public SiteMapNodes CreateNode(SitemapDetail node, List<SitemapDetail> nodelst)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, CreateNode Method with Param node: " + node + " and with Param nodelst: " + nodelst);
                SiteMapNodes nodeItem = new SiteMapNodes();
                //  nodeItem.NodeId = node. SiteMapId.ToString();
                nodeItem.NodeId = node.PageId.ToString();
                nodeItem.NodeName = node.DisplayText.Split('#').Last();
                nodeItem.Children = childNodes(node, nodelst);
                nodeItem.LinkType = node.LinkType;
                nodeItem.TargetLink = node.TargetLink;
                traceLog.AppendLine(" & End: HomeController, CreateNode Method");
                return nodeItem;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Generate sitemap child nodes
        /// </summary>
        /// <param name="parentNode"></param>
        /// <param name="lstChild"></param>
        /// <returns></returns>
        public List<SiteMapNodes> childNodes(SitemapDetail parentNode, List<SitemapDetail> lstChild)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, childNodes Method with Param parentNode: " + parentNode + " and with Param lstChild: " + lstChild);
                List<SiteMapNodes> childlst = new List<SiteMapNodes>();
                var children = lstChild.FindAll(_item => _item.ParentId == parentNode.SiteMapId);
                if (children != null)
                {
                    foreach (var item in children)
                    {
                        SiteMapNodes _node = new SiteMapNodes();
                        if (item.LinkType == "_locate")
                            _node.NodeId = "1";
                        else
                            _node.NodeId = item.PageId.ToString();
                        _node.NodeName = item.DisplayText.Split('#').Last();
                        _node.LinkType = item.LinkType;
                        _node.TargetLink = item.TargetLink;
                        _node.Children = childNodes(item, lstChild);
                        childlst.Add(_node);
                    }
                }
                traceLog.AppendLine(" & End: HomeController, childNodes Method");
                return childlst;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion Sitemap

        #region Feedback
        /// <summary>
        /// Feedback form
        /// </summary>
        /// <returns></returns>
        public ActionResult Feedback()
        {
            return PartialView("~/views/shared/_FeedBack.cshtml");
        }


        /// <summary>
        /// Save feedback info
        /// </summary>
        /// <param name="FeedbackForm"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult FeedbackDetails(FeedbackDetails FeedbackForm)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, FeedbackDetails Method with Param FeedbackForm: " + FeedbackForm);
                ManageContent manageContent = new ManageContent();
                int success = 0;
                string IsValidFeedBackInfo = ValidateFeedBackInfo(FeedbackForm);
                if (!IsValidFeedBackInfo.Equals(CONST_SUCCESS))
                {
                    return Json(IsValidFeedBackInfo);
                }
                FeedbackForm.JustificationComment = AntiXssEncoder.HtmlEncode(FeedbackForm.JustificationComment, false);
                FeedbackForm.Comments = AntiXssEncoder.HtmlEncode(FeedbackForm.Comments, false);
                success = manageContent.SaveFeedbackInfo(FeedbackForm, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                if (success > 0)
                {
                    traceLog.AppendLine(" & End: HomeController, FeedbackDetails Method");
                    return Json("Success");
                }
                else
                {
                    traceLog.AppendLine(" & End: HomeController, FeedbackDetails Method");
                    return Json("Failed");
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion Feedback

        #region Helper methods


        /// <summary>
        /// Renders pdf for usermanual
        /// </summary>
        /// <param name="stateDisclaimersCode"></param>
        /// <returns></returns>
        public ActionResult GetUserManualFunction(string functionality)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetUserManualFunction Method with Param functionality: " + functionality);
                if (functionality == null)
                    throw new ArgumentNullException("GetUserManualPdf");
                MemoryStream workStream = new MemoryStream();
                if (!CommonHelper.ValidDisclaimersId(functionality))
                    throw new ArgumentNullException(VariableConstant.StateDisclaimersCode);
                string culture = ReturnCultureInfo();
                RequestHeader request = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                ManageContent omngcontent = new ManageContent();
                request.Functionality = functionality;
                List<UserManualEntity> userManual = omngcontent.GetUserManual(request).ToList();
                if (userManual != null && userManual.Count > 0)
                {
                    var cd = new System.Net.Mime.ContentDisposition
                    {
                        FileName = userManual[0].FileName + "." + userManual[0].FileType,
                        Inline = false,
                    };
                    if (userManual[0].FileType.ToUpper().Trim() == "PDF")
                        cd.Inline = true;

                    Response.AppendHeader("Content-Disposition", cd.ToString());
                    traceLog.AppendLine(" & End: HomeController, GetUserManualFunction Method");
                    return File(userManual[0].FileContent, "application/" + userManual[0].FileType);
                }
                else
                {
                    traceLog.AppendLine(" & End: HomeController, GetUserManualFunction Method");
                    return null;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }

        private string GetHostUrl(string keyname)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetHostUrl Method with Param keyname: " + keyname);
                string strhosturl = "";

                ManageContent objManage = new ManageContent();
                Dictionary<string, string> dictionary = new Dictionary<string, string>();
                if (_cacheHostUrl == null)
                {
                    strhosturl = Convert.ToString(ConfigurationManager.AppSettings["HOSTURL"]);
                    dictionary.Add("HOSTURL", strhosturl);
                    _cacheHostUrl = dictionary;
                }
                _cacheHostUrl.TryGetValue(keyname.ToUpper(), out strhosturl);
                traceLog.AppendLine(" & End: HomeController, GetHostUrl Method");
                return strhosturl;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private int GetpageIds(string keyname, int keyvalue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetpageIds Method with Param keyname: " + keyname + " and with Param keyvalue: " + keyvalue);
                int pageid = 1000;

                ManageContent objManage = new ManageContent();
                Dictionary<string, int> dictionary = new Dictionary<string, int>();
                if (this.HttpContext.Cache["pagesid"] == null)
                {
                    _cachePageids = objManage.GetPageIds(Convert.ToInt32(pageid));
                    this.HttpContext.Cache["pagesid"] = _cachePageids;
                }
                else
                {
                    _cachePageids = (Dictionary<string, int>)this.HttpContext.Cache["pagesid"];
                }
                if (_cachePageids == null)
                {
                    _cachePageids = objManage.GetPageIds(Convert.ToInt32(pageid)); //get All pagesid
                }

                if (Convert.ToInt32(keyvalue) > 0)
                {
                    pageid = _cachePageids.FirstOrDefault(x => x.Value == keyvalue).Value;
                }
                else
                {
                    _cachePageids.TryGetValue(keyname.ToLower(), out pageid);
                }
                traceLog.AppendLine(" & End: HomeController, GetpageIds Method");
                return pageid;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [CustomOutputCacheAttribute("CacheDuration1800_linkId")]
        public ActionResult RetrieveFile(int linkId)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {

                traceLog.AppendLine("Start: HomeController, RetrieveFile Method with Param linkId: " + linkId);
                int roleId = 0;
                UserDetails userDetails = (UserDetails)Session[Constants.UserDetails];
                if (userDetails != null && userDetails.UserRoles != null)
                {
                    string selectedRole = userDetails.SelectedRole;
                    var roles = userDetails.UserRoles.Where(role => role.RoleName.Equals(selectedRole)).FirstOrDefault();
                    if (roles != null)
                    {
                        roleId = Convert.ToInt32(roles.RoleId);
                    }

                }
                ManageContent manageContent = new ManageContent();
                var fileDetail = manageContent.GetFileContentByLinkId(linkId, langcode, roleId, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                string contentType = GetContentType("." + fileDetail.FileType);
                Byte[] cover = fileDetail.Content;
                var cd = new System.Net.Mime.ContentDisposition
                {
                    FileName = fileDetail.Name + "." + fileDetail.FileType,
                    Inline = false,
                };
                if (fileDetail.FileType.ToUpper().Trim() == "PDF")
                    cd.Inline = true;

                Response.AppendHeader("Content-Disposition", cd.ToString());
                traceLog.AppendLine(" & End: HomeController, RetrieveFile Method");
                return File(cover, contentType);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Fetch the list of pdf documents for a link
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [CustomOutputCacheAttribute("CacheDuration1800_Id")]
        public ActionResult FetchPopUpData(int Id)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                //temporary code. TODO :use actual role id
                traceLog.AppendLine("Start: HomeController, FetchPopUpData Method with Param Id: " + Id);
                int roleId = 0;
                UserDetails userDetails = (UserDetails)Session[Constants.UserDetails];
                if (userDetails != null && userDetails.UserRoles != null)
                {
                    string selectedRole = userDetails.SelectedRole;
                    var roles = userDetails.UserRoles.Where(role => role.RoleName.Equals(selectedRole)).FirstOrDefault();
                    if (roles != null)
                    {
                        roleId = Convert.ToInt32(roles.RoleId);
                    }

                }

                ManageContent manage = new ManageContent();
                List<FileDetails> fileDetailsList = manage.GetFileListByLinkId(Id, langcode, roleId, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                List<PopUpViewModel> popUpViewModelList = new List<PopUpViewModel>();
                foreach (FileDetails file in fileDetailsList)
                {
                    PopUpViewModel popUp = new PopUpViewModel();
                    popUp.Content = file.Title;
                    popUp.LinkId = file.LinkId;
                    popUpViewModelList.Add(popUp);
                }
                traceLog.AppendLine(" & End: HomeController, FetchPopUpData Method");
                return PartialView("~/Views/Shared/_PopUpView.cshtml", popUpViewModelList);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Based on file extention return content type
        /// </summary>
        /// <param name="fileExt"></param>
        /// <returns></returns>
        private string GetContentType(string fileExt)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetContentType Method with Param fileExt: " + fileExt);
                string ext = fileExt.ToLower();
                string type = string.Empty;

                if (!String.IsNullOrEmpty(ext))
                {
                    switch (ext)
                    {
                        case ".doc": //this .doc for 97 to 2003 Ms-Word format
                            type = "Application/msword";
                            break;
                        case ".docx": //this .docx for 2003 to 2007 Ms-word format
                            type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                            break;
                        case ".xls"://this .xls for 97 to 2003 Ms-Excel format
                            type = "Application/x-msexcel";
                            break;
                        case ".xlsx"://this .xlsx for 2003 to 2007 Ms-Excel format   
                            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                            break;
                        case ".pptx":   //Ms Power Point-2007 Files
                            type = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
                            break;
                        case ".ppt":   //Ms Power Point-2003 Files
                            type = "application/vnd.ms-powerpoint";
                            break;
                        case ".pdf": //Pdf Format
                            type = "application/pdf";
                            break;
                        case ".txt":   //txt Files
                            type = "text/plain";
                            break;
                        case ".rar":   //Zip Files and Sql File and exe files
                            type = "application/octet-stream";
                            break;
                        case ".jpg":   //image jpg files
                            type = "image/jpg";
                            break;
                        case ".png":   //image jpg files
                            type = "image/png";
                            break;
                        case ".gif":   //image jpg files
                            type = "image/gif";
                            break;
                        case ".htm":
                        case ".html":   //Html files
                            type = "text/html";
                            break;
                        case ".csv":
                            type = "application/csv";
                            break;
                    }
                }
                traceLog.AppendLine(" & End: HomeController, GetContentType Method");
                return type;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private bool RedirectToCustomURL(string PageId)

        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, RedirectToCustomURL Method with Param PageId: " + PageId + " and with Param Request.Url: " + Request.Url + " and with Param AllowCustomURlFlag: " + Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]));
                bool customUrl = false;
                if (Request.Url != null)
                {
                    string planCode = string.Empty;
                    planCode = Request.Url.ToString().Replace("http://", "").Replace("https://", "").Replace("www.", "");
                    traceLog.AppendLine("with Param planCode: " + planCode);
                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]))
                    {
                        string controllerName = string.Empty;
                        int lengthFirst = planCode.IndexOf("/");
                        int lengthSecond = planCode.IndexOf("/", lengthFirst + 1);
                        if (lengthFirst != -1)
                        {
                            if (lengthSecond == -1)
                            {
                                lengthSecond = planCode.Length;
                            }
                            controllerName = planCode.Substring(lengthFirst + 1, lengthSecond - lengthFirst - 1);
                        }
                        if (!string.IsNullOrWhiteSpace(controllerName))
                        {
                            if (!ConfigurationManager.AppSettings["ExcludeController"].ToLower().Contains(controllerName.ToLower()))
                            {
                                traceLog.AppendLine(" controllerName : " + controllerName + "is not null");
                                string str = Request.Url.ToString();
                                var resultPlanCode = str.Substring(str.LastIndexOf('/') + 1).ToLower(); ;
                                planCode = GetPlanCodeURl(); //comment this line to emulate custom url
                                                             //planCode = "providerlocator.firsthealth.com/QuestTravel"; //uncomment this line to emulate custom url
                                customUrl = ValidCustomUrl(planCode);
                                if (customUrl)
                                {
                                    Session[SessionConstant.CookiePlanCode] = planCode;
                                    Session[SessionConstant.CustomHeader] = Constants.Yes;
                                    Session[SessionConstant.FullUrl] = Convert.ToString(AppSettingHelper.GetAppSettingValue("RedirectURL")) + resultPlanCode;
                                }
                            }

                        }
                        else // comes when there is no controller name 
                        {
                            Session[SessionConstant.CookiePlanCode] = null;
                            Session[SessionConstant.CustomHeader] = null;
                            Session[SessionConstant.FullUrl] = Convert.ToString(ConfigurationManager.AppSettings["HomeUrl_FH"]);
                            planCode = GetPlanCodeURl(); //comment this line to emulate custom url
                                                         //planCode = "providerlocator.firsthealth.com/QuestTravel"; //uncomment this line to emulate custom url

                            customUrl = ValidCustomUrl(planCode);
                            if (customUrl)
                            {
                                Session[SessionConstant.CustomHeader] = Constants.Yes;
                                Session[SessionConstant.FullUrl] = Request.Url;
                                Session[SessionConstant.CookiePlanCode] = planCode;
                                customUrl = true;
                            }
                        }
                    }
                }
                traceLog.AppendLine(" & End: HomeController, RedirectToCustomURL Method with ReturnValu: " + customUrl);
                return customUrl;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Edited By NAB-IT on 4 march 2018 to encode the input paramenter
        /// </summary>
        /// <returns> string </returns>
        public string GetPlanCodeURl()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetPlanCodeURl Method");
                string planCode = string.Empty;
                if (Request.Url != null)
                {
                    planCode = AntiXssEncoder.HtmlEncode(Request.Url.ToString().Replace("http://", "").Replace("https://", "").Replace("www.", ""), false);
                    traceLog.AppendLine("with Param plancode: " + planCode);
                    if (Convert.ToBoolean(HttpContext.Application["AllowCustomURlFlag"]))
                    {
                        string controllerName = string.Empty;
                        int lengthFirst = planCode.IndexOf("/");
                        int lengthSecond = planCode.IndexOf("/", lengthFirst + 1);
                        if (lengthFirst != -1)
                        {
                            if (lengthSecond == -1)
                            {
                                lengthSecond = planCode.Length;
                            }
                            controllerName = planCode.Substring(lengthFirst + 1, lengthSecond - lengthFirst - 1);
                        }
                        if (!string.IsNullOrWhiteSpace(controllerName))
                        {
                            if (!ConfigurationManager.AppSettings["ExcludeController"].ToLower().Contains(controllerName.ToLower()))
                            {
                                string str = AntiXssEncoder.HtmlEncode(Request.Url.ToString(), false);
                                var resultPlanCode = str.Substring(str.LastIndexOf('/') + 1).ToLower(); ;
                                planCode = Convert.ToString(AppSettingHelper.GetAppSettingValue("CustomHOSTURL")) + resultPlanCode;
                                traceLog.AppendLine("with Param plancode: " + planCode + " for controllerName: " + controllerName);
                            }

                        }

                    }
                }
                traceLog.AppendLine(" & End: HomeController, GetPlanCodeURl Method");
                return planCode;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        public bool ValidCustomUrl(string planCode)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, ValidCustomUrl Method");
                ManageContent contentManager = new ManageContent();
                string culture = ReturnCultureInfo();
                RequestHeader requestForNetworkType = new CommonHelper().GetRequestHeader(culture, defaultSourceId);
                HeaderInfo locateProviderHeaderInfo = contentManager.GetHeaderInfoForLocateProvider(planCode, requestForNetworkType);
                var boolValid = false;
                if (locateProviderHeaderInfo.HeaderText != null && locateProviderHeaderInfo.logo != null)
                {
                    boolValid = true;
                }
                traceLog.AppendLine(" & End: HomeController, ValidCustomUrl Method with ReturnValue: " + boolValid + "and locateProviderHeaderInfo.HeaderText: " + locateProviderHeaderInfo.HeaderText + " and locateProviderHeaderInfo.logo: " + locateProviderHeaderInfo.logo);
                return boolValid;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        #endregion


        /// <summary>
        /// Set Culture for the application in cookie
        /// </summary>
        /// <param name="culture"></param>
        /// <returns></returns>
        protected void SetCulture(string culture)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, SetCulture Method");
                string cultureCookie = Session["_culture"] as string;
                if (cultureCookie != null)
                { culture = cultureCookie.ToString(); }

                // Validate input
                culture = CultureHelper.GetImplementedCulture(culture);
                // Save culture in a cookie
                Session[CookieConstant.Culture] = culture;
                traceLog.AppendLine(" & End: HomeController, SetCulture Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        public JsonResult GetSitemapImages()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, GetSitemapImages Method");
                SiteMapImages ObjSiteMapImages = new SiteMapImages();
                ManageContent manageContent = new ManageContent();
                System.Data.DataTable SitaMapImages = manageContent.GetSitemapImages(Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());

                if (SitaMapImages != null && SitaMapImages.Rows.Count > 0)
                {
                    ObjSiteMapImages.BookCloseSiteImage = String.Format("data:image/gif;base64,{0}", Convert.ToBase64String((byte[])SitaMapImages.Rows[0]["ImageContent"]));
                    ObjSiteMapImages.FileSiteImage = String.Format("data:image/gif;base64,{0}", Convert.ToBase64String((byte[])SitaMapImages.Rows[1]["ImageContent"]));
                    ObjSiteMapImages.BookOpenSiteImage = String.Format("data:image/gif;base64,{0}", Convert.ToBase64String((byte[])SitaMapImages.Rows[2]["ImageContent"]));
                    ObjSiteMapImages.TreeSiteImage = String.Format("data:image/gif;base64,{0}", Convert.ToBase64String((byte[])SitaMapImages.Rows[3]["ImageContent"]));
                    ObjSiteMapImages.TreeLineImage = String.Format("data:image/gif;base64,{0}", Convert.ToBase64String((byte[])SitaMapImages.Rows[4]["ImageContent"]));
                }
                var jsonResult = Json(ObjSiteMapImages, JsonRequestBehavior.AllowGet);
                jsonResult.MaxJsonLength = int.MaxValue;
                traceLog.AppendLine(" & End: HomeController, GetSitemapImages Method");
                return jsonResult;


            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Validate Contactus form on server side before submitting
        /// </summary>
        /// <param name="contactUsPage"></param>
        /// <returns></returns>
        private string ValidateContactUsInfo(ContactUsPage contactUsPage)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, ValidateContactUsInfo Method");
                if (string.IsNullOrEmpty(contactUsPage.ContactPreference))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblContactUsNetworkSelectionRequired;
                }
                if (string.IsNullOrEmpty(contactUsPage.FirstName))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblContactUsFirstNameRequired;
                }
                if (!IsAlphaNumeric(contactUsPage.FirstName))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblAlphaNumericFirstNameValidationMessage;
                }
                if (string.IsNullOrEmpty(contactUsPage.SecondName))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblContactUsSecondNameRequired;
                }
                if (!IsAlphaNumeric(contactUsPage.SecondName))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblAlphaNumericLastNameValidationMessage;
                }
                if (string.IsNullOrEmpty(contactUsPage.ContactMeBy))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblContactUsContactByRequired;
                }
                if (contactUsPage.ContactMeBy == "Email" && string.IsNullOrEmpty(contactUsPage.Email))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblContactUsEmailRequired;
                }
                if (!string.IsNullOrEmpty(contactUsPage.Email) && IsValidEmail(contactUsPage.Email) == false)
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblEmailValidationMessage;
                }
                if (contactUsPage.ContactMeBy == "Phone" && string.IsNullOrEmpty(contactUsPage.PhoneNo))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblContactUsPhoneRequired;
                }
                if (!string.IsNullOrEmpty(contactUsPage.PhoneNo) && IsValidPhone(contactUsPage.PhoneNo) == false)
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblPhoneValidationMessage;
                }
                if (string.IsNullOrEmpty(contactUsPage.RequestRegarding))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblContactUsRequestRegardingRequired;
                }
                if (string.IsNullOrEmpty(contactUsPage.UserQuery))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblContactUsQueryRequired;
                }
                else
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return CONST_SUCCESS;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Validate feedbackform before submitting
        /// </summary>
        /// <param name="FeedbackForm"></param>
        /// <returns></returns>
        private string ValidateFeedBackInfo(FeedbackDetails FeedbackForm)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, ValidateFeedBackInfo Method");
                if (FeedbackForm.OverallRating.Equals(null) || FeedbackForm.OverallRating < 1)
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return NABResources.Resources.lblfeedbackErrorMassage;
                }
                else
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateContactUsInfo Method");
                    return CONST_SUCCESS;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Validate email
        /// </summary>
        /// <param name="strEmail"></param>
        /// <returns></returns>
        private bool IsValidEmail(string strEmail)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, IsValidEmail Method with Param strEmail: " + strEmail);
                string pattern = string.Empty;
                pattern = "^([\\w\\.\\-]+)@([\\w\\-]+)((\\.(\\w){2,3})+)$";
                if (Regex.IsMatch(strEmail, pattern))
                {
                    traceLog.AppendLine(" & End: HomeController, IsValidEmail Method");
                    return true;
                }
                else
                {
                    traceLog.AppendLine(" & End: HomeController, IsValidEmail Method");
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// validate phone number
        /// </summary>
        /// <param name="strPhone"></param>
        /// <returns></returns>
        private bool IsValidPhone(string strPhone)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, IsValidPhone Method with Param strPhone: " + strPhone);
                string pattern = string.Empty;
                pattern = @"^\d{10}$";
                if (Regex.IsMatch(strPhone, pattern))
                {
                    traceLog.AppendLine(" & End: HomeController, IsValidPhone Method");
                    return true;
                }
                else
                {
                    traceLog.AppendLine(" & End: HomeController, IsValidPhone Method");
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Validate alphanumeric
        /// </summary>
        /// <param name="strToCheck"></param>
        /// <returns></returns>
        public bool IsAlphaNumeric(string strToCheck)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, IsAlphaNumeric Method with Param strToCheck: " + strToCheck);
                Regex rg = new Regex(@"^[a-zA-Z0-9]+$");
                traceLog.AppendLine(" & End: HomeController, IsAlphaNumeric Method");
                return rg.IsMatch(strToCheck);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Validate alphanumeric
        /// </summary>
        /// <param name="strToCheck"></param>
        /// <returns></returns>
        public bool IsAlphaNumericRep(string strToCheck)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, IsAlphaNumericRep Method with Param strToCheck: " + strToCheck);
                Regex rg = new Regex(@"^[a-zA-Z0-9\s]+$");
                traceLog.AppendLine(" & End: HomeController, IsAlphaNumericRep Method");
                return rg.IsMatch(strToCheck);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        protected string ReturnCultureInfo()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, ReturnCultureInfo Method");
                string culture = AppSettingHelper.GetAppSettingValue(CookieConstant.InitialCulture);
                var cookie = Session[CookieConstant.Culture];
                if (cookie != null)
                {
                    if (cookie.ToString() == AppSettingHelper.GetAppSettingValue(CookieConstant.CheckCulture))
                    {
                        culture = AppSettingHelper.GetAppSettingValue(CookieConstant.NewCulture);
                    }
                }
                traceLog.AppendLine(" & End: HomeController, ReturnCultureInfo Method");
                return culture;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private void IncrementDenyAttemptCount()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, IncrementDenyAttemptCount Method");
                int delay = 0;
                int attemptMade = 0;

                if (Session[Constants.LogOnAttemptCount] == null)
                {
                    attemptMade = 1;
                    Session[Constants.LogOnAttemptCount] = 1;
                }
                else
                {
                    attemptMade = Convert.ToInt32(Session[Constants.LogOnAttemptCount]) + 1;
                    Session[Constants.LogOnAttemptCount] = attemptMade;
                }

                delay = attemptMade * 6000;

                if (delay > 0)
                    System.Threading.Thread.Sleep(delay);
                traceLog.AppendLine(" & End: HomeController, IncrementDenyAttemptCount Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        private bool IsMaxAttempt()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, IsMaxAttempt Method");
                int maxAttempt = Convert.ToInt32(ConfigurationManager.AppSettings["AllowedMaxAttempt"]);

                if (Session[Constants.LogOnAttemptCount] != null)
                {
                    int attemptMade = Convert.ToInt32(Session[Constants.LogOnAttemptCount]);
                    if (attemptMade >= maxAttempt)
                        return true;
                    else
                        return false;
                }
                traceLog.AppendLine(" & End: HomeController, IsMaxAttempt Method");
                return false;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        #region Report Incorrect info
        /// <summary>
        /// Contact us form render add by maneesh
        /// </summary>
        /// <returns></returns>
        public ActionResult ReportICInfo()
        {
            return PartialView("~/views/shared/ReportICInfo.cshtml");
        }

        /// <summary>
        /// Report  Incorrect info For mobile form render add by maneesh
        /// </summary>
        /// <returns></returns>
        public ActionResult MobileReportICInfo()
        {
            return PartialView("~/views/shared/MobileReportICInfo.cshtml");
        }



        /// <summary>
        /// Save Report Incorrect Information to database
        /// </summary>
        /// <param name="UserContactForm"></param>
        /// <returns></returns>
        [AjaxValidateAntiForgeryToken]
        public JsonResult ReportInfoDetails(ReportInfo UserContactForm)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, ReportInfoDetails Method");
                //Reflected XSS change on 03/10/2018
                UserContactForm.concatRequest = AntiXssEncoder.HtmlEncode(UserContactForm.concatRequest, true);
                UserContactForm.ContactIAmA = AntiXssEncoder.HtmlEncode(UserContactForm.ContactIAmA, true);
                UserContactForm.ContactMeBy = AntiXssEncoder.HtmlEncode(UserContactForm.ContactMeBy, true);
                UserContactForm.ContactPreference = AntiXssEncoder.HtmlEncode(UserContactForm.ContactPreference, true);
                UserContactForm.Email = AntiXssEncoder.HtmlEncode(UserContactForm.Email, true);

                UserContactForm.FirstName = AntiXssEncoder.HtmlEncode(UserContactForm.FirstName, true);
                UserContactForm.PFAddress = AntiXssEncoder.HtmlEncode(UserContactForm.PFAddress, true);

                UserContactForm.PFCity = AntiXssEncoder.HtmlEncode(UserContactForm.PFCity, true);
                UserContactForm.PFName = AntiXssEncoder.HtmlEncode(UserContactForm.PFName, true);

                UserContactForm.PFPhoneNo = AntiXssEncoder.HtmlEncode(UserContactForm.PFPhoneNo, true);
                UserContactForm.PFState = AntiXssEncoder.HtmlEncode(UserContactForm.PFState, true);
                UserContactForm.PFZip = AntiXssEncoder.HtmlEncode(UserContactForm.PFZip, true);
                UserContactForm.PhoneNo = AntiXssEncoder.HtmlEncode(UserContactForm.PhoneNo, true);
                UserContactForm.SecondName = AntiXssEncoder.HtmlEncode(UserContactForm.SecondName, true);

                UserContactForm.TexasProviderFlag = AntiXssEncoder.HtmlEncode(UserContactForm.TexasProviderFlag, true);
                UserContactForm.UserQuery = AntiXssEncoder.HtmlEncode(UserContactForm.UserQuery, true);


                // success signal from database
                Boolean success;

                ReportInfo Userinfo = new ReportInfo();
                string IsValidContactInfo = ValidateReportInfo(UserContactForm);
                if (!IsValidContactInfo.Equals(CONST_SUCCESS))
                {
                    traceLog.AppendLine(" & End: HomeController, ReportInfoDetails Method");
                    return Json(IsValidContactInfo);
                }

                ReportUserInfo(UserContactForm, Userinfo);

                string body = string.Empty;

                using (StreamReader reader = new StreamReader(Server.MapPath("~/Views/Home/ReportIncorrectInfo.html")))
                {
                    body = reader.ReadToEnd();
                }
                if (Userinfo.ContactIAmA != null)
                {
                    body = body.Replace("{ContactIAmA}", Userinfo.ContactIAmA);
                }
                else
                    body = body.Replace("{ContactIAmA}", "-");
                body = body.Replace("{ContactPreference}", Userinfo.concatRequest);
                body = body.Replace("{FirstName}", Userinfo.FirstName);
                body = body.Replace("{Secondname}", Userinfo.SecondName);
                body = body.Replace("{ContactMeBy}", Userinfo.ContactMeBy);
                body = body.Replace("{Email}", string.IsNullOrEmpty(Userinfo.Email) ? "N/A" : Userinfo.Email);
                body = body.Replace("{PhoneNo}", string.IsNullOrEmpty(Userinfo.PhoneNo) ? "N/A" : Userinfo.PhoneNo);
                body = body.Replace("{FacilityName}", WebUtility.HtmlDecode(Userinfo.PFName));
                body = body.Replace("{FacilityPhoneNo}", Userinfo.PFPhoneNo);
                body = body.Replace("{PFAddress}", WebUtility.HtmlDecode(Userinfo.PFAddress));
                body = body.Replace("{PfCity}", Userinfo.PFCity);
                body = body.Replace("{PfState}", Userinfo.PFState);
                body = body.Replace("{PFZip}", Userinfo.PFZip);
                body = body.Replace("{Query}", WebUtility.HtmlDecode(Userinfo.UserQuery));



                ManageContent contentManager = new ManageContent();
                string[] emailAddresses;
                var email = "";
                if (Userinfo.concatRequest.Trim() == NABResources.Resources.lbl_CofNetwork)
                {
                    email = ConfigurationManager.AppSettings["FromCofinityReportInfo"];
                }
                else
                {
                    email = ConfigurationManager.AppSettings["FromReportInfo"];
                }

                List<string> emailAddressesList = new List<string>();
                if (!string.IsNullOrEmpty(email)) emailAddressesList.Add(email);
                emailAddresses = emailAddressesList.ToArray();
                //Redirected to service method
                success = contentManager.SendMailRCInfo(body, emailAddresses, VariableConstant.ReportICInfoSubject, Userinfo.concatRequest);
                if (success == true)
                {
                    traceLog.AppendLine(" & End: HomeController, ReportInfoDetails Method");
                    return Json("Success");
                }
                else
                {
                    traceLog.AppendLine(" & End: HomeController, ReportInfoDetails Method");
                    return Json("Failed");
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Validate Report Incorrect Information  form on server side before submitting
        /// </summary>
        /// <param name="contactUsPage"></param>
        /// <returns></returns>
        private string ValidateReportInfo(ReportInfo contactUsPage)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, ValidateReportInfo Method with Param contactUsPage: " + contactUsPage);
                if (string.IsNullOrEmpty(contactUsPage.FirstName))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblContactUsFirstNameRequired;
                }
                if (string.IsNullOrEmpty(contactUsPage.FirstName))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblContactUsFirstNameRequired;
                }
                if (!IsAlphaNumericRep(contactUsPage.FirstName))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblAlphaNumericFirstNameValidationMessage;
                }
                if (string.IsNullOrEmpty(contactUsPage.SecondName))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblContactUsSecondNameRequired;
                }
                if (!IsAlphaNumericRep(contactUsPage.SecondName))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblAlphaNumericLastNameValidationMessage;
                }
                if (string.IsNullOrEmpty(contactUsPage.ContactMeBy))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblContactUsContactByRequired;
                }
                if (contactUsPage.ContactMeBy == "Email" && string.IsNullOrEmpty(contactUsPage.Email))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblContactUsEmailRequired;
                }
                if (!string.IsNullOrEmpty(contactUsPage.Email) && IsValidEmail(contactUsPage.Email) == false)
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblEmailValidationMessage;
                }
                if (contactUsPage.ContactMeBy == "Phone" && string.IsNullOrEmpty(contactUsPage.PhoneNo))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblContactUsPhoneRequired;
                }
                if (string.IsNullOrEmpty(contactUsPage.PFName))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblPfRequestRegardingRequired;
                }

                if (string.IsNullOrEmpty(contactUsPage.PFAddress))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblPFAddressRegardingRequired;
                }
                if (string.IsNullOrEmpty(contactUsPage.PFCity))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblPfCityRegardingRequired;
                }
                if (string.IsNullOrEmpty(contactUsPage.PFState))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblPfStateRegardingRequired;
                }

                if (string.IsNullOrEmpty(contactUsPage.PFZip))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblZipMand;
                }


                if (string.IsNullOrEmpty(contactUsPage.UserQuery))
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return NABResources.Resources.lblContactUsQueryRequired;
                }
                else
                {
                    traceLog.AppendLine(" & End: HomeController, ValidateReportInfo Method");
                    return CONST_SUCCESS;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        /// Report Incorrect Information  user information
        /// </summary>
        /// <param name="UserContactForm"></param>
        /// <param name="Userinfo"></param>
        private void ReportUserInfo(ReportInfo UserContactForm, ReportInfo Userinfo)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: HomeController, ReportUserInfo Method with Param UserContactForm: " + UserContactForm + " and with Param Userinfo: " + Userinfo);
                Userinfo.ContactIAmA = AntiXssEncoder.HtmlEncode(UserContactForm.ContactIAmA, false);
                Userinfo.FirstName = AntiXssEncoder.HtmlEncode(UserContactForm.FirstName, false);
                Userinfo.SecondName = AntiXssEncoder.HtmlEncode(UserContactForm.SecondName, false);
                Userinfo.ContactMeBy = AntiXssEncoder.HtmlEncode(UserContactForm.ContactMeBy, false);
                Userinfo.Email = AntiXssEncoder.HtmlEncode(UserContactForm.Email, false);
                Userinfo.PhoneNo = AntiXssEncoder.HtmlEncode(UserContactForm.PhoneNo, false);
                Userinfo.UserQuery = AntiXssEncoder.HtmlEncode(UserContactForm.UserQuery, false);
                Userinfo.ContactPreference = AntiXssEncoder.HtmlEncode(UserContactForm.ContactPreference, false);
                Userinfo.concatRequest = AntiXssEncoder.HtmlEncode(UserContactForm.concatRequest, false);
                Userinfo.PFName = AntiXssEncoder.HtmlEncode(UserContactForm.PFName, false);
                Userinfo.PFPhoneNo = AntiXssEncoder.HtmlEncode(UserContactForm.PFPhoneNo, false);
                Userinfo.PFAddress = AntiXssEncoder.HtmlEncode(UserContactForm.PFAddress, false);
                Userinfo.PFCity = AntiXssEncoder.HtmlEncode(UserContactForm.PFCity, false);
                Userinfo.PFState = AntiXssEncoder.HtmlEncode(UserContactForm.PFState, false);
                Userinfo.PFZip = AntiXssEncoder.HtmlEncode(UserContactForm.PFZip, false);
                traceLog.AppendLine(" & End: HomeController, ReportUserInfo Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        #endregion Report Incorrect info

    }
}