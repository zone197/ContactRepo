﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Aetna.ProviderContracts.DataContracts;
using System.ComponentModel.DataAnnotations;
using NABWebsite.DTO;

namespace NABWebsite.Models.LocateProvider
{
    public class ProviderDetailedInfoViewModel
    {
        public Aetna.ProviderContracts.DataContracts.Provider ProviderDetailedInfo { get; set; }
        public string MapQuestUrl { get; set; }
        public UserEmailAddress UserEmailAddress { get; set; }
        public UserPhoneNumber UserPhoneNumber { get; set; }
        public SearchRequestEntity SearchRequest { get; set; }
        public string PublicKey { get; set; }
        public string GoogleRecaptchaAPIAddressSingle { get; set; }
        public List<Hours> Hours { get; set; }
        public List<GATXSpecialty> GATXSpecialty { get; set; }
    }

}