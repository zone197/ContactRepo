﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NABWebsite.Models.LocateProvider
{
    [Serializable()]
    public class SendProviderDetails
    {

        public UserEmailAddress UserEmailAddress { get; set; }
        public UserPhoneNumber UserPhoneNumber { get; set; }
        public string SelectedCarrier { get; set; }
        public string SelectedCarrierName { get; set; }
        public string ProviderUIN { get; set; }
        public string AddressLine1 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string LongName { get; set; }
        public string SelectedMailOption { get; set; }
        public string PublicKey { get; set; }
        public string GoogleRecaptchaAPIAddressSingle { get; set; }
        public string CaptchaResponse { get; set; }

    }
}