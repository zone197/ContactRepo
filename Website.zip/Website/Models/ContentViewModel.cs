﻿using System.Web.Mvc;


namespace NABWebsite.Models
{
    public class ContentViewModel
    {
        public int ID { get; set; }
        public string Title { get; set; }
        [AllowHtml]
        public string Contents { get; set; }
        public byte[] Image { get; set; }
        public TopLeftSectionViewModel TopLeftSection { get; set; }
        public string Role { get; set; }
    }
}