﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Aetna.ProviderContracts.DataContracts;
using System.ComponentModel.DataAnnotations;
using NABWebsite.DTO;
using NABResources;

namespace NABWebsite.Models.LocateProvider
{
    public class LocateProviderSearchResultViewModel
    {
        public SearchResult SearchResult { get; set; }
        public SearchRequestEntity SearchRequest { get; set; }
        public SearchRequestEntity RefineRequest { get; set; }
        public int TaggedProvidersCount { get; set; }
        public List<CompareProvider> ProvidersForComparison { get; set; }
        public List<string> TaggedProviderNumbers { get; set; }
        public List<State> ListState { get; set; }
        private List<Condition> listCondition = new List<Condition>();
        public List<Condition> ListCondition { get { return listCondition; } }
        public List<ProviderType> ListProviderType { get; set; }
        public List<Specialty> ListSpecialty { get; set; }
        public List<Focus> ListFocus { get; set; }
        public List<GATXSpecialty> GATXSpecialty { get; set; }
        //public List<string> ListLanguageSpoken { get; set; }
        //public List<string> ListSpecialtyRefine { get; set; }
        public string ActiveTab { get; set; }
        //public UserEmailAddress UserEmailAddress { get; set; }
        //public UserPhoneNumber UserPhoneNumber { get; set; }
        public List<City> CityList { get; set; }
        public List<County> CountyList { get; set; }
        public string MapQuestUrl { get; set; }
        public ProviderDetailsModel ProviderDetails { get; set; }
        public string ZipLookupSiteUrl { get; set; }
        public bool SearchByStateCityCounty { get; set; }

        public string PublicKey { get; set; }
        public string GoogleRecaptchaAPIAddressSingle { get; set; }
        public string GoogleRecaptchaAPIAddressMultiple { get; set; }
        public List<Hours> Hours { get; set; }

        public SendProviderDetails SendProviderDetails { get; set; }

    }

    public class Hours
    {
        public string Day { get; set; }
        public string Time { get; set; }
        public string TimePM { get; set; }
    }
    public class ProviderDetailsModel
    {
        public Aetna.ProviderContracts.DataContracts.Provider ProviderData { get; set; }
        public string TaxId { get; set; }
        public string LocationId { get; set; }
    }

    public class FacilityProviderModel
    {
        public List<TXFacilityProvider> FacilityProvider { get; set; }
        public string ProviderDetail { get; set; }
        public string FullAddress { get; set; }
        public string HospitalName { get; set; }
        public string HospitalAddress { get; set; }
        public string HospitalPhone { get; set; }
    }

    [Serializable()]
    public class UserEmailAddress
    {
        [EmailAddress(ErrorMessageResourceType = typeof(NABResources.Resources),
              ErrorMessageResourceName = "lblInvalidEmailAddress", ErrorMessage = null)]
        [RegularExpression(@"^([\w-\.'-]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,8}|[0-9]{1,3})(\]?)$", ErrorMessageResourceType = typeof(Resources),
              ErrorMessageResourceName = "lblInvalidEmailAddress", ErrorMessage = null)]
        public string EmailAddress1 { get; set; }
    }
    [Serializable()]
    public class UserPhoneNumber
    {
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^[1-9]{1}[0-9]{2}-?[0-9]{3}-?[0-9]{4}$", ErrorMessageResourceType = typeof(Resources),
              ErrorMessageResourceName = "lblNotValidPhoneNumber", ErrorMessage = null)]
        public string PhoneNumber { get; set; }
        public List<Carrier> ListCarrier { get; set; }

    }
}