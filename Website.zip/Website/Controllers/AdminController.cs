﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using NABWebsite.BLL;
using NABWebsite.DTO;
using System.Text;
using Utilities;
//using Microsoft.Security.Application;

namespace NABWebsite.Controllers
{
    [HandleError]
    public class AdminController : BaseController
    {
        //
        // GET: /Admin/

        public ActionResult Index()
        { StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: AdminController, Index Method");
                traceLog.AppendLine(" & End: AdminController, Index Method");
                return View("~/views/Admin/pageEditor.cshtml");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [HandleError]
        [ValidateInput(false)]
        //[ValidateAntiForgeryToken]
        public JsonResult SaveEditor(PageContent fc)
        {
            StringBuilder traceLog = new StringBuilder();
            int isucess = 0;
            try
            {
                traceLog.AppendLine("Start: AdminController, SaveEditor Method with Param Pagecontent: " + fc);
                string strContent = string.Empty;

                ManagerAdmin objManageAdmin = new ManagerAdmin();
                PageContent opage = new PageContent();
                opage.PageId = fc.PageId;
                opage.Heading = fc.Heading;//Encoder.HtmlEncode
                opage.ContentText = fc.ContentText; //enode dat

                isucess = objManageAdmin.SavePageContent(opage); //save into DB
                traceLog.AppendLine(" & End: AdminController, SaveEditor Method");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

            return Json("OK");
        }


        [HandleError]
        public JsonResult pagecontent(string pageid)
        {
            StringBuilder traceLog = new StringBuilder();
            ManageContent objManage = new ManageContent();
            PageContent opage = new PageContent();
            try
            {
                traceLog.AppendLine("Start: AdminController, pagecontent Method with Param pageid: " + pageid);
                opage = objManage.GetPageText(Convert.ToInt32(pageid));
                if (opage != null)
                {
                }
                traceLog.AppendLine(" & End: AdminController, pagecontent Method");
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return Json(opage);

            //return Json("", JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Pagelist(int pageid)
        {StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: AdminController, Pagelist Method with Param pageid: " + pageid);
                traceLog.AppendLine(" & End: AdminController, Pagelist Method");
                var stateList = Getpagenames(pageid);
                return Json(stateList);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

            //, JsonRequestBehavior.AllowGet
        }

        private List<PageContent> Getpagenames(int pageid)
        {
            StringBuilder traceLog = new StringBuilder();
            List<PageContent> lstpg = new List<PageContent>();

            //ManageContent objManage = new ManageContent();
            //Dictionary<string, int> dictionary = new Dictionary<string, int>();
            //dictionary = objManage.GetPageIds(Convert.ToInt32(pageid));
            //foreach (KeyValuePair<string, int> pageitem in dictionary)
            //{
            //    PageContent obpage = new PageContent();
            //    obpage.PageId = pageitem.Value;
            //    obpage.Heading = pageitem.Key;
            //    lstpg.Add(obpage);
            //}
            //
            List<Menu> lstmneu = new List<Menu>();

            try
            {
                traceLog.AppendLine("Start: AdminController, Getpagenames Method with Param pageid: " + pageid);
                lstmneu = GetMenus();
                foreach (Menu RootMenu in lstmneu)
                {
                    foreach (Menu FirstLevelMenu in RootMenu.ChildMenus)
                    {
                        PageContent obpage = new PageContent();
                        obpage.PageId = Convert.ToInt32(FirstLevelMenu.PageId);
                        obpage.Heading = FirstLevelMenu.DisplayText;
                        lstpg.Add(obpage);
                    }

                }
                traceLog.AppendLine(" & End: AdminController, Getpagenames Method");
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return lstpg;
        }

        public List<Menu> GetMenus()
        {
            StringBuilder traceLog = new StringBuilder();
            List<Menu> Menus = null;
            try
            {
                //int langcode = 2;//
                ManageContent manageContent = new ManageContent();
                traceLog.AppendLine("Start: AdminController, GetMenus Method");
                if (this.HttpContext.Cache["Menus"] == null)
                {
                    this.HttpContext.Cache["Menus"] = Menus;
                }
                else
                {
                    Menus = (List<Menu>)this.HttpContext.Cache["Menus"];
                }
                traceLog.AppendLine(" & End: AdminController, GetMenus Method");

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }

            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return Menus;
        }

    }
}