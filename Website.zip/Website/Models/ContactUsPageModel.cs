﻿
using System.ComponentModel.DataAnnotations;
namespace NABWebsite.Models
{
    public class ContactUsPageModel
    {
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string SecondName { get; set; }
        [Required]
        public string ContactMeBy { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }

        public string RequestRegarding { get; set; }

        public string UserQuery { get; set; }
        public string IpAddress { get; set; }
        public contactusLabels Contactuslabels { get; set; }
    }

    public class contactusLabels
    {
      
        //[Display(Name = "ChooseYourNetwork",
        //ResourceType = typeof(ViewResources))] 
        public string ChooseYourNetwork { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Contactmeby { get; set; }
        public string Email { get; set; }
        public string Phoneno { get; set; }
        public string RequestRegarding { get; set; }
        public string howmayhelpyou { get; set; }

    }
}