﻿$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip();
       // $("#ProvidersSelectedForComparision").empty();
      //  $('input[name="compareProviders"]').prop('checked', false);
        $('#errrorMessageForProviders').empty();
        var forgeryId = $("#forgeryToken").val();
        //calculating the number of providers selected for comparison
        $('#btnCompare').click(function () {
            $.ajax({
                type: 'POST',
                url: '/LocateProvider/GetTaggedComparedProvidersCount',
                contentType: "application/json; charset=utf-8",
                datatype: 'json',
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {
                    if (result >= 2) {
                        $('#errrorMessageForProviders').empty();
                        window.location.href = '/LocateProvider/TaggedCompareResult/';
                    }
                    else {
                        var errorSelectTwoProviders = GetResources("lblSelectAtleastTwoProvidersForComparison");
                        $('#errrorMessageForProviders').html(errorSelectTwoProviders);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                }
            });

        });

        //arranging the result set based on the sort criteria selected by the user
      
        $("#SelectSortCriteria").change(function (evt) {
            var forgeryId = $("#forgeryToken").val();
            $("#CurrentPageIndex").val(0);
            var sortField = $("#SelectSortCriteria").val();
            var sortDirection = $("#SelectSortCriteria").find(':selected').data('direction')
            var sortingPagingInfo = new Object();
            sortingPagingInfo.SortField = sortField;
            sortingPagingInfo.SortDirection = sortDirection;
            sortingPagingInfo.PageSize = $("#PageSize").val();
            sortingPagingInfo.PageCount = $("#PageCount").val();
            sortingPagingInfo.CurrentPageIndex = $("#CurrentPageIndex").val();


            $.ajax({
                type: 'POST',
                url: '/LocateProvider/SaveTaggedSortingPagingInfoToSession',
                contentType: "application/json; charset=utf-8",
                datatype: 'json',
                data: JSON.stringify({ sortingPagingInfo: sortingPagingInfo }),
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {
                    window.location.href = '/LocateProvider/TaggedProviders/';
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    ////debugger;
                }
            });
        })

        $("#txtGotoPage").keydown(function (e) {
            // Allow: backspace, delete, tab, escape, enter and .
            if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
                // Allow: Ctrl+A, Command+A
                (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                // Allow: home, end, left, right, down, up
                (e.keyCode >= 35 && e.keyCode <= 40)) {
                // let it happen, don't do anything
                return;
            }
            // Ensure that it is a number and stop the keypress
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                e.preventDefault();
            }
        });
    // go the particular page selected by the user and sort the result set accordingly
        $("#txtGotoPage").on('keydown', function (e) {
            if (e.keyCode == 13) {
                var pageindex = parseInt($("#txtGotoPage").val() - 1);
                if (pageindex + 1 > 0 && pageindex + 1 <= $("#PageCount").val()) {
                    var forgeryId = $("#forgeryToken").val();
                    $("#CurrentPageIndex").val(pageindex);
                    var sortingPagingInfo = new Object();
                    sortingPagingInfo.SortField = $("#SortField").val();
                    sortingPagingInfo.SortDirection = $("#SortDirection").val();
                    sortingPagingInfo.PageSize = $("#PageSize").val();
                    sortingPagingInfo.PageCount = $("#PageCount").val();
                    sortingPagingInfo.CurrentPageIndex = $("#CurrentPageIndex").val();


                    $.ajax({
                        type: 'POST',
                        url: '/LocateProvider/SaveTaggedSortingPagingInfoToSession',
                        contentType: "application/json; charset=utf-8",
                        datatype: 'json',
                        data: JSON.stringify({ sortingPagingInfo: sortingPagingInfo }),
                        headers: {
                            'VerificationToken': forgeryId
                        },
                        success: function (result) {
                            window.location.href = '/LocateProvider/TaggedProviders/';
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                        }
                    });
                } else alert("Invalid Page Number");
            }
        });
        // displaying result according to the page selected
        $(".pager").click(function (evt) {
            var forgeryId = $("#forgeryToken").val();
            var pageindex = $(evt.target).data("pageindex");
            $("#CurrentPageIndex").val(pageindex);
            var sortingPagingInfo = new Object();
            sortingPagingInfo.SortField = $("#SortField").val();
            sortingPagingInfo.SortDirection = $("#SortDirection").val();
            sortingPagingInfo.PageSize = $("#PageSize").val();
            sortingPagingInfo.PageCount = $("#PageCount").val();
            sortingPagingInfo.CurrentPageIndex = $("#CurrentPageIndex").val();


            $.ajax({
                type: 'POST',
                url: '/LocateProvider/SaveTaggedSortingPagingInfoToSession',
                contentType: "application/json; charset=utf-8",
                datatype: 'json',
                data: JSON.stringify({ sortingPagingInfo: sortingPagingInfo }),
                headers: {
                    'VerificationToken': forgeryId
                },
                success: function (result) {
                    window.location.href = '/LocateProvider/TaggedProviders/';
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                }
            });
        });
        //accordion for comapred providers
        $("#CompareListAccordionTagged").accordion({
            collapsible: true,
            autoFill: true,
            autoHeight: false,
            heightStyle: "content"
        });
});

function GetResources(key) {
    var forgeryId = $("#forgeryToken").val();
    var returnValue;
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/GetResources',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        async: false,
        data: JSON.stringify({ key: key }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            ////debugger;
            returnValue = result;

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
    ////debugger;
    return returnValue;
}
//remove all the providers selected for comparison
function RemoveAllProviders(action) {
    var forgeryId = $("#forgeryToken").val();
    $.ajax({
        type: 'POST',
        url: '/LocateProvider/RemoveTaggedCompareProvidersFromSession',
        contentType: "application/json; charset=utf-8",
        datatype: 'json',
        data: JSON.stringify({ action: action }),
        headers: {
            'VerificationToken': forgeryId
        },
        success: function (result) {
            window.location.href = '/LocateProvider/TaggedProviders/';
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
    $("#ProvidersSelectedForComparision").empty();
    $('input[name="compareProviders"]').prop('checked', false);
    $('#errrorMessageForProviders').empty();
}
   
function CompareProviders(ProviderNum, NameAndSpecialty, ProviderId, ProviderName) {
    var forgeryId = $("#forgeryToken").val();
    $('#CompareListAccordion').accordion("option", "active", 0);
    try {

        var compareProvider = new Object();
        var providerType = new Object();
        compareProvider.ProviderNumber = ProviderNum;
        compareProvider.NameAndSpecialty = NameAndSpecialty;
        providerType.ProviderTypeID = ProviderId;
        providerType.ProviderTypeName = ProviderName;
        compareProvider.ProviderType = providerType;
        $.ajax({
            type: 'POST',
            url: '/LocateProvider/ManageTaggedComparedProviders',
            contentType: "application/json; charset=utf-8",
            datatype: 'json',
            data: JSON.stringify({ compareProvider: compareProvider }),
            headers: {
                'VerificationToken': forgeryId
            },
            success: function (result) {
                if (result == "true") {
                    if ($("#ProvidersSelectedForComparision #" + ProviderNum).length) {
                        $("#ProvidersSelectedForComparision #" + ProviderNum).remove();
                        $('#chkComp' + ProviderNum + '.compareProvider').prop('checked', false);

                    }
                    else {
                        $('#ProvidersSelectedForComparision').append('<li style="font-size:smaller;" id=' + "'" + ProviderNum + "'" + '> <span aria-hidden="true" style="cursor:pointer"><img tabindex="0" style="width:15px;height:15px;" src="/Content/Images/1453205617_Erase.png" onkeypress="CompareImageKeyHandler(event,' + "'" + ProviderNum + "'" + ',' + "'" + NameAndSpecialty + "'" + ',' + "'" + ProviderId + "'" + ',' + "'" + ProviderName + "'" + ');"  onclick="CompareProviders(' + "'" + ProviderNum + "'" + ',' + "'" + NameAndSpecialty + "'" + ',' + "'" + ProviderId + "'" + ',' + "'" + ProviderName + "'" + ');"/>&nbsp;&nbsp;</span>' + NameAndSpecialty + ' </li>')
                    }
                    $("#errrorMessageForProviders").empty();
                }
                else if (result == "false") {
                    $('#chkComp' + ProviderNum + '.compareProvider').prop('checked', false);
                    var errorAtmostThreeProvidersToBeCompared = GetResources("lblNoMoreThanThreeProvidersSelected");
                    $("#errrorMessageForProviders").html(errorAtmostThreeProvidersToBeCompared);
                    $('html,body').animate({
                        scrollTop: $("#CompareListAccordion").offset().top
                    },
                    'slow');

                }
                else if (result == "Not compared") {
                    $('#chkComp' + ProviderNum + '.compareProvider').prop('checked', false);
                    var errorSelectSimilarProvider = GetResources("lblSelectAnotherSimilarProviderForComparison");
                    alert(errorSelectSimilarProvider);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                ////debugger;
            }
        });

    }
    catch (ex) {

    }


}
function CompareImageKeyHandler(event, NumberLocationIdTaxId, NameAndSpecialty, ProviderId, ProviderName) {
    if (event.which === 13 ) {
        //event.stopPropagation;
        return CompareProviders(NumberLocationIdTaxId, NameAndSpecialty, ProviderId, ProviderName);
    }
    return true;
}
function ShowMoreDetailsHandler(event, data, activeTab, visibility) {
    if (event.which === 13 ) {
        //event.stopPropagation;
        return ShowHideDetails(data, activeTab, visibility);
    }
    return true;
}

function TagProviderHandler(event, providerUIN) {
    if (event.which === 13) {
        if ($("#chkTag" + providerUIN).prop('checked') == true) {
            $("#chkTag" + providerUIN).prop('checked', false);
        }
        else {
            $("#chkTag" + providerUIN).prop('checked', true);
        }
        //event.stopPropagation;
        return TagProviders(providerUIN);
    }

    return true;
}

//without captcha validation
function SendProviderDetails(ProviderNumber, address1, city, state, zip, providerNameDegree) {
    var providerNumber = ProviderNumber;
    var email = $("#emailIdForDetails" + ProviderNumber).val();
    var phoneNumber = $("#phoneNumberId" + ProviderNumber).val();
    var phoneNumberCarrierValue = $('#CarrierData option:selected').val();
    var phoneNumberCarrier = $('#CarrierData option:selected').text();
    var ProviderMapDeatails = $('input[name="ProviderMapDeatails' + ProviderNumber + '"]:checked').val();

    var form = $('#FormSendProviderDetails' + ProviderNumber);
    $.validator.unobtrusive.parse(form);
    form.validate();
    if (phoneNumberCarrier || email) {
        if (form.valid()) {
            $("#hiddenAddressLine1").val(address1);
            $("#hiddenCity").val(city);
            $("#hiddenLongName").val(providerNameDegree);
            $("#hiddenProviderUIN").val(ProviderNumber);
            $("#hiddenSelectedCarrier").val(phoneNumberCarrierValue);
            $("#hiddenSelectedMailOption").val(ProviderMapDeatails);
            $("#hiddenState").val(state);
            $("#hiddenZipCode").val(zip);
            $("#hiddenSelectedCarrierName").val(phoneNumberCarrier);
            form.submit();

        }
        else {
            var errrorValidEmailIdAndPhone = GetResources("lblProvideValidIdOrPhoneNumber");
            $("#errorMessage_" + ProviderNumber).html(errrorValidEmailIdAndPhone);

        }
    }

    else {
        var errorEnterEmailOrPhone = GetResources("lblEnterIdOrPhoneNumber");
        $("#errorMessage_" + ProviderNumber).html(errorEnterEmailOrPhone);
    }
}
//function SendProviderDetails(ProviderNumber, address1, city, state, zip, providerNameDegree) {
//    var forgeryId = $("#forgeryToken").val();
//    var captchaResponse = $("#captchaResponse_" + ProviderNumber).val();
//    var address = address1 + " " + city + " " + state + " " + zip;
//    var providerNumber = ProviderNumber;
//    var email = $("#emailIdForDetails" + ProviderNumber).val();
//    var phoneNumber = $("#phoneNumberId" + ProviderNumber).val();
//    var carrierId = [];
//    if ($('#CarrierData').val() != null) {

//        carrierId[0] = $('#CarrierData').val();

//    }
//    var phoneNumberCarrier = carrierId[0];
//    var form = $('#FormSendProviderDetails' + ProviderNumber);
//    $.validator.unobtrusive.parse(form);
//    form.validate();
//    if (phoneNumberCarrier || email) {
//        if (form.valid()) {
//            if (captchaResponse) {
//                //call mail sending function

//                var ProviderMapDeatails = $('input[name="ProviderMapDeatails' + ProviderNumber + '"]:checked').val();
//                if (ProviderMapDeatails == 'ProviderDetails') {
//                    $.ajax({
//                        type: 'POST',
//                        url: '/LocateProvider/SendingMail',
//                        contentType: "application/json; charset=utf-8",
//                        datatype: 'json',
//                        data: JSON.stringify({ email: email, phoneNumberCarrier: phoneNumberCarrier, phoneNumber: phoneNumber, providerNumber: providerNumber, captcha: captchaResponse }),
//                        headers: {
//                            'VerificationToken': forgeryId
//                        },
//                        success: function (result) {
//                            if (result == true) {
//                                $("#emailSearchResult_" + ProviderNumber).html("Email sent successfully");
//                                $("#emailIdForDetails" + ProviderNumber).val("");
//                                $("#captchaResponse_" + ProviderNumber).val("");
//                                grecaptcha.reset();
//                            }
//                            else if (result == false) {
//                                $("#emailSearchResult_" + ProviderNumber).html("Email not sent");
//                                $("#emailIdForDetails" + ProviderNumber).val("");
//                                $("#captchaResponse_" + ProviderNumber).val("");
//                                grecaptcha.reset();
//                            }
//                            else {
//                                $("#emailSearchResult_" + ProviderNumber).html(result + " Email not sent! Error occured while validating captcha");
//                                $("#emailIdForDetails" + ProviderNumber).val("");
//                                $("#captchaResponse_" + ProviderNumber).val("");
//                                grecaptcha.reset();
//                            }
//                        },
//                        error: function (XMLHttpRequest, textStatus, errorThrown) {
//                            $("#captchaResponse_" + ProviderNumber).val("");
//                            grecaptcha.reset();
//                        }
//                    });
//                }
//                else if (ProviderMapDeatails == 'MapDirections') {
//                    getLocation(email, phoneNumberCarrier, phoneNumber, address, captchaResponse, ProviderNumber, providerNameDegree, forgeryId);
//                    // ShowPositionTest(email,phoneNumberCarrier,phoneNumber,address,captchaResponse,ProviderNumber,providerNameDegree,forgeryId);

//                }
//            }
//            else {
//                $("#emailSearchResult_" + ProviderNumber).html("Please fill the captcha!");
//            }
//        }
//        else {

//            $("#errorMessage_" + ProviderNumber).html("Please provide a valid EmailId or PhoneNumber");

//        }
//    }

//    else {

//        $("#errorMessage_" + ProviderNumber).html("Please enter Email Id or Phone number");
//    }
//}
