﻿using System;

namespace NABWebsite.Models
{
    public class RightSectionNewsContainer
    {
        public int ItemId { get; set; }
        public int SectionId { get; set; }
        public string Title { get; set; }
        public string str_ItemId { get; set; }
        public string DetailText { get; set; }
        public string GroupType { get; set; }
        public bool IsClickable { get; set; }
        public bool IsActive { get; set; }
        public string SubType { get; set; } // News or Event
        public int GroupItemsOrder { get; set; }
        public int ImageId { get; set; }
        public int LinkId { get; set; }
        public DateTime NewsEventDate { get; set; }
        public string NewsEventDuration { get; set; }
        public string ImageName { get; set; }
        public string ImageTitle { get; set; }
        public byte[] ImageContent { get; set; }
        public string ImageString { get; set; }
        public int SectionOrder { get; set; }
        public string hosturl { get; set; }
    }
}