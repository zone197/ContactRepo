﻿using Aetna.ProviderContracts.DataContracts;
using NABWebsite.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NABWebsite.Models.LocateProvider
{
    [Serializable()]
    public class CompareProvider
    {
        public string ProviderNumber { get; set; }
        public string NameAndSpecialty { get; set; }
        public string LocationId { get; set; }
        public string TaxId { get; set; }
        public ProviderTypes ProviderType { get; set; } 
        public string NumberLocationIdTaxId { get; set; }


    }
}