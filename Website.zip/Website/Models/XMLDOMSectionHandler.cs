﻿using System;
using System.Xml;
using System.Configuration;

namespace System.Configuration
{
    public class XMLDOMSectionHandler : IConfigurationSectionHandler
    {
        public XMLDOMSectionHandler()
        { }

        public object Create(object parent, object context, XmlNode section)
        {
            return section;
        }
    }
}
