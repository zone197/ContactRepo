﻿using System.Web.Configuration;
using System.Web.Mvc;

namespace NABWebsite.Helper
{
    public class CustomOutputCacheAttribute : OutputCacheAttribute
    {
        public CustomOutputCacheAttribute(string cacheProfile)
        {
            var settings = (OutputCacheSettingsSection)WebConfigurationManager.GetSection("system.web/caching/outputCacheSettings");
            var profile = settings.OutputCacheProfiles[cacheProfile];
            Duration = profile.Duration;
            VaryByParam = profile.VaryByParam;
            VaryByCustom = profile.VaryByCustom;
        }
    }
}