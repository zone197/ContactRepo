﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NABWebsite.Models;
using NABWebsite.BLL;
using NABWebsite.DTO;
using Microsoft.Security.Application;
using NABWebsite.Helper;
using System.IO;
using System.Configuration;
using System.Text;
using Utilities;
using System.Web.Security.AntiXss;


namespace NABWebsite.Controllers
{
    public class DownloadController : Controller
    {
        FileDownloadBLL objBll = new FileDownloadBLL();
        // GET: Download
        [CheckAccess(Function = "My Downloads")]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: DownloadController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: DownloadController, Index Method");
                    return RedirectToAction("Index", "Home");                    
                }
                else
                {
                    Session[Constants.Header] = "My downloads";
                    string userId = string.Empty;
                    if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId))
                    {
                        userId = ((UserDetails)Session[Constants.UserDetails]).UserId;
                    }
                    string appName = ConfigurationManager.AppSettings["ApplicationName"].ToString();
                    FileDownloadModel obj = new FileDownloadModel();

                    obj.FileDetails = objBll.GetFileDetails(userId, appName);
                    traceLog.AppendLine(" & End: DownloadController, Index Method");
                    return View(obj);

                }
            }
            catch (Exception ex)
            {

                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult DownloadFile(string fileName)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: DownloadController, DownloadFile Method with Param fileName: " + fileName);
                fileName = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(fileName, true);//Added on 24-Jul-18 to fix Reflected XSS
                fileName = fileName.Replace("\\", "").Replace("..", "");//Added on 24-Sept-18 to fix Path Traversal
                if (!string.IsNullOrEmpty(fileName))
                {
                    if(fileName.Substring(fileName.LastIndexOf('.')+1).ToUpperInvariant()!="ZIP")
                    {
                        var user = (UserDetails)Session[Constants.UserDetails];
                        var userId = user.UserId;

                        byte[] reportData = null;
                        reportData = objBll.DownloadClaimReport(fileName, userId);
                        traceLog.AppendLine(" & End: DownloadController, DownloadFile Method");
                        return File(reportData,"application/octet-stream",fileName);
                    }
                    else
                    {
                        string filePath = ConfigurationManager.AppSettings["ProviderFileDownloadPath"].ToString();

                        filePath = filePath + fileName;

                        filePath = filePath.Replace("/", "\\");


                        FileExistServer fileExistObject = objBll.FileExistDetails(filePath);
                        byte[] readerObject = null;

                        if (fileExistObject != null)
                        {
                            readerObject = objBll.ReadFile(fileExistObject);
                        }

                        Response.Clear();
                        Response.ClearContent();
                        Response.ClearHeaders();

                        string fileExtn = Path.GetExtension(fileExistObject.FilePath);
                        if (!fileName.Contains("\n"))//Added on 24-Sept-18 to fix HTTP Response Splitting 
                        {
                        Response.AddHeader(Constants.ContentDisposition, "attachment; filename=" + fileName);
                        Response.AppendHeader("Content-Length", readerObject.Length.ToString());
                        }
                       

                        if (fileExtn.ToUpperInvariant() == Constants.ExtensionZip.ToUpperInvariant())
                        {
                            Response.ContentType = Constants.ApplicationOctetStream;
                        }

                        //Response.TransmitFile(filePath);
                        Response.BufferOutput = true;
                        Response.BinaryWrite(readerObject);
                        Response.End();
                        traceLog.AppendLine(" & End: DownloadController, DownloadFile Method");
                        return View("DownloadFile");
                    }
                 
                }
                else
                {
                    String AlterMsg = Constants.MyDownloadMessage + ConfigurationManager.AppSettings["CustServicePh"].ToString() + ".";
                    traceLog.AppendLine(" & End: DownloadController, DownloadFile Method");
                    return Content(Constants.MyDownloadReturnPart1 + AlterMsg + Constants.MyDownloadReturnPart2);
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
    }
}