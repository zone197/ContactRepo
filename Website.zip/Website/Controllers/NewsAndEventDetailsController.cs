﻿using NABWebsite.BLL;
using NABWebsite.DTO;
using NABWebsite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Mvc;
using System.Configuration;
using CofinityEncryption;
using Utilities;
using System.Linq;

namespace NABWebsite.Controllers
{
    public class NewsAndEventDetailsController : BaseController
    {
        int langcode = Convert.ToInt32(ConfigurationManager.AppSettings["langCode"]);
        //StringBuilder traceLog = new StringBuilder();
        // GET: NewsAndEventDetails
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: NewsAndEventDetailsController, Index Method");
                ManageContent manageContent = new ManageContent();

                // Currently pageId is hard coded with Dental
                PageInfo pageInfo = manageContent.GetPagContent(1000, langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());

                var ListGenericContainer = ReturnListGenericContainer(pageInfo);

                ContentViewModel contentViewModel = new ContentViewModel();
                contentViewModel.Title = pageInfo.Content.Heading;
                contentViewModel.Contents = pageInfo.Content.ContentText;

                IndexViewModel indexViewModel = new IndexViewModel();
                indexViewModel.Content = contentViewModel;

                //Create Right generic section
                RightSectionGenericContainer objRightSectionGenContainer = null;


                List<RightSectionGenericContainer> ListRightGeneric = new List<RightSectionGenericContainer>();
                List<RightSectionNewsContainer> ListNews = new List<RightSectionNewsContainer>();

                foreach (var ob in ListGenericContainer)
                {
                    objRightSectionGenContainer = new RightSectionGenericContainer();
                    objRightSectionGenContainer.ImageId = ob.ImageId;
                    objRightSectionGenContainer.ImageName = ob.ImageName;
                    objRightSectionGenContainer.ImageContent = ob.ImageContent;
                    objRightSectionGenContainer.LinkId = ob.LinkId;
                    objRightSectionGenContainer.LinkType = ob.LinkType;
                    objRightSectionGenContainer.LinkUrl = ob.LinkUrl;
                    objRightSectionGenContainer.TargetPageId = ob.TargetPageId;
                    objRightSectionGenContainer.Title = ob.Title;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.GroupType = ob.GroupType;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.SectionOrder = ob.SectionOrder;
                    ListRightGeneric.Add(objRightSectionGenContainer);
                }

                if (ListRightGeneric != null && ListRightGeneric.Count > 0)
                    indexViewModel.ListGenContainer = ListRightGeneric;


                traceLog.AppendLine(" & End: NewsAndEventDetailsController, Index Method");
                return View(indexViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// News to display
        /// </summary>
        /// <returns></returns>
        public JsonResult GetNews()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: NewsAndEventDetailsController, GetNews Method");
                ManageContent content = new ManageContent();
                List<GroupSection> lstNews = content.GetNewsandEvents(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                lstNews = lstNews.FindAll(_item => _item.SubType == "News");
                List<RightSectionNewsContainer> ListNews = new List<RightSectionNewsContainer>();

                RightSectionNewsContainer objNews = null;

                if (lstNews != null)
                {
                    foreach (var ob in lstNews)
                    {
                        objNews = new RightSectionNewsContainer();
                        objNews.ItemId = ob.ItemId;
                        objNews.str_ItemId = NABEncryption.Encrypt(Convert.ToString(ob.ItemId));
                        objNews.ImageId = ob.ImageId;
                        objNews.ImageName = ob.ImageName;
                        objNews.ImageString = Convert.ToBase64String(ob.ImageContent);
                        objNews.LinkId = ob.LinkId;
                        objNews.Title = ob.Title;
                        objNews.SectionId = ob.SectionId;
                        objNews.GroupType = ob.GroupType;
                        objNews.SectionId = ob.SectionId;
                        objNews.SectionOrder = ob.SectionOrder;
                        objNews.NewsEventDate = ob.NewsEventDate;
                        objNews.NewsEventDuration = ob.NewsEventDuration;
                        objNews.DetailText = ob.DetailText;
                        ListNews.Add(objNews);

                    }
                }
                traceLog.AppendLine(" & End: NewsAndEventDetailsController, GetNews Method");
                return Json(ListNews, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult NewsDetail(string id)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: NewsAndEventDetailsController, NewsDetail Method");
                ManageContent manageContent = new ManageContent();

                // Currently pageId is hard coded with Dental
                PageInfo pageInfo = manageContent.GetPagContent(1000, langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());

                var ListGenericContainer = ReturnListGenericContainer(pageInfo);

                ContentViewModel contentViewModel = new ContentViewModel();
                contentViewModel.Title = pageInfo.Content.Heading;
                contentViewModel.Contents = pageInfo.Content.ContentText;

                IndexViewModel indexViewModel = new IndexViewModel();
                indexViewModel.Content = contentViewModel;

                //Create Right generic section
                RightSectionGenericContainer objRightSectionGenContainer = null;


                List<RightSectionGenericContainer> ListRightGeneric = new List<RightSectionGenericContainer>();
                List<RightSectionNewsContainer> ListNews = new List<RightSectionNewsContainer>();

                foreach (var ob in ListGenericContainer)
                {
                    objRightSectionGenContainer = new RightSectionGenericContainer();
                    objRightSectionGenContainer.ImageId = ob.ImageId;
                    objRightSectionGenContainer.ImageName = ob.ImageName;
                    objRightSectionGenContainer.ImageContent = ob.ImageContent;
                    objRightSectionGenContainer.LinkId = ob.LinkId;
                    objRightSectionGenContainer.LinkType = ob.LinkType;
                    objRightSectionGenContainer.LinkUrl = ob.LinkUrl;
                    objRightSectionGenContainer.TargetPageId = ob.TargetPageId;
                    objRightSectionGenContainer.Title = ob.Title;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.GroupType = ob.GroupType;
                    objRightSectionGenContainer.SectionId = ob.SectionId;
                    objRightSectionGenContainer.SectionOrder = ob.SectionOrder;

                    ListRightGeneric.Add(objRightSectionGenContainer);
                }
                if (ListRightGeneric != null && ListRightGeneric.Count > 0)
                    indexViewModel.ListGenContainer = ListRightGeneric;



                //return View(indexViewModel);

                String[] sp = id.Split(new char[] { ',' });
                ViewData["NewsId"] = sp[0];
                ViewData["Page_Title"] = NABResources.Resources.lblNewsEvents;

                if (sp.Length > 1)
                {
                    if (NABEncryption.Decrypt(sp[1]) == "Event")
                        ViewData["Page_Title"] = NABResources.Resources.lblWebinars;
                }

                traceLog.AppendLine(" & End: NewsAndEventDetailsController, NewsDetail Method");
                return View("~/views/shared/newsDetail.cshtml", indexViewModel);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public JsonResult GetNewsDetail(string xx)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: NewsAndEventDetailsController, GetNewsDetail Method");
                ManageContent content = new ManageContent();
                List<GroupSection> lstNews = content.GetNewsandEvents(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                string newsid = NABEncryption.Decrypt(xx);
                //lstNews = lstNews.FindAll(_item => _item.SubType == "News");
                lstNews = lstNews.FindAll(_item => _item.ItemId == Convert.ToInt16(newsid));
                List<RightSectionNewsContainer> ListNews = new List<RightSectionNewsContainer>();

                RightSectionNewsContainer objNews = null;

                if (lstNews != null)
                {
                    foreach (var ob in lstNews)
                    {
                        objNews = new RightSectionNewsContainer();
                        objNews.ItemId = ob.ItemId;
                        objNews.str_ItemId = NABEncryption.Encrypt(Convert.ToString(ob.ItemId));
                        objNews.ImageId = ob.ImageId;
                        objNews.ImageName = ob.ImageName;
                        objNews.ImageString = Convert.ToBase64String(ob.ImageContent);
                        objNews.LinkId = ob.LinkId;
                        objNews.Title = ob.Title;
                        objNews.SectionId = ob.SectionId;
                        objNews.GroupType = ob.GroupType;
                        objNews.SectionId = ob.SectionId;
                        objNews.SectionOrder = ob.SectionOrder;
                        objNews.NewsEventDate = ob.NewsEventDate;
                        objNews.NewsEventDuration = ob.NewsEventDuration;
                        objNews.DetailText = ob.DetailText;
                        objNews.SubType = ob.SubType;
                        ListNews.Add(objNews);

                    }
                }
                traceLog.AppendLine(" & End: NewsAndEventDetailsController, GetNewsDetail Method");
                return Json(ListNews, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        /// <summary>
        /// Events to be displayed
        /// </summary>
        /// <returns></returns>
        public JsonResult GetEvents()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: NewsAndEventDetailsController, GetEvents Method");
                ManageContent content = new ManageContent();
                List<GroupSection> lstNewsEvents = content.GetNewsandEvents(langcode, Session["RelayUserName"].ToString(), Session["RelayPassWord"].ToString());
                lstNewsEvents = lstNewsEvents.FindAll(_item => _item.SubType == "Event");
                List<RightSectionNewsContainer> ListEvents = new List<RightSectionNewsContainer>();

                RightSectionNewsContainer objEvents = null;

                if (lstNewsEvents != null)
                {
                    foreach (var ob in lstNewsEvents)
                    {
                        objEvents = new RightSectionNewsContainer();
                        objEvents.ItemId = ob.ItemId;
                        objEvents.str_ItemId = NABEncryption.Encrypt(Convert.ToString(ob.ItemId));
                        objEvents.ImageId = ob.ImageId;
                        objEvents.ImageName = ob.ImageName;
                        objEvents.ImageString = Convert.ToBase64String(ob.ImageContent);
                        objEvents.LinkId = ob.LinkId;
                        objEvents.Title = ob.Title;
                        objEvents.SectionId = ob.SectionId;
                        objEvents.GroupType = ob.GroupType;
                        objEvents.SectionId = ob.SectionId;
                        objEvents.SectionOrder = ob.SectionOrder;
                        objEvents.IsClickable = ob.IsClickable;
                        objEvents.NewsEventDate = ob.NewsEventDate;
                        objEvents.NewsEventDuration = ob.NewsEventDuration;
                        objEvents.DetailText = ob.DetailText;
                        ListEvents.Add(objEvents);
                    }
                }
                traceLog.AppendLine(" & End: NewsAndEventDetailsController, GetEvents Method");
                return Json(ListEvents, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        private List<PageSection> ReturnListGenericContainer(PageInfo pageInfo)
        {
            var ListGenericContainer = new List<PageSection>();

            if ((UserDetails)Session[Constants.UserDetails] != null)
            {
                UserDetails userDetails = (UserDetails)Session[Constants.UserDetails];
                var userRole = userDetails.UserRoles != null ? userDetails.UserRoles.First().RoleName : null;
                if (userDetails.SelectedRole != null && ((UserDetails)Session[Constants.UserDetails]).SelectedRole.ToUpperInvariant() == Constants.Payer.ToUpperInvariant())
                {
                    if (Session[Constants.FairCostAccess] != null)
                    {
                        if (Convert.ToBoolean(Session[Constants.FairCostAccess]) == false)
                            ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
                        else
                            ListGenericContainer = pageInfo.PageSections;
                    }
                    else
                        ListGenericContainer = pageInfo.PageSections;
                }
                else if (userRole != null && userRole.ToUpper() == "PAYER" && userDetails.SelectedRole == null)
                {
                    if (Session[Constants.FairCostAccess] != null)
                    {
                        if (Convert.ToBoolean(Session[Constants.FairCostAccess]) == false)
                            ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
                        else
                            ListGenericContainer = pageInfo.PageSections;
                    }
                    else
                    {
                        ListGenericContainer = pageInfo.PageSections;
                    }
                }
                else
                {
                    ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
                }
            }
            else
            {
                ListGenericContainer = pageInfo.PageSections.Where(p => p.LinkUrl != "QPAAssist/Index").ToList();
            }
            return ListGenericContainer;
        }
    }

}
