﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using Utilities;

namespace NABWebsite.Helper
{
    public static class ValidationHelper
    {
        public static bool IsInteger(String number)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsInteger Method with Params number: " + number); 
                if (number != null)
                {
                    Regex objNotIntPattern = new Regex("[^0-9-]");
                    Regex objIntPattern = new Regex("^-[0-9]+$|^[0-9]+$");
                    traceLog.AppendLine(" & End: ValidationHelper, IsInteger Method");

                    return !objNotIntPattern.IsMatch(number) && objIntPattern.IsMatch(number);
                }
                else
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsInteger Method");
                    return false;
                }
            }
            catch(Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        
        public static bool IsNumber(String number)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsNumber Method with Params number: " + number); 
                if (number != null)
                {
                    Regex objNotNumberPattern = new Regex("[^0-9.-]");
                    Regex objTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*");
                    Regex objTwoMinusPattern = new Regex("[0-9]*[-][0-9]*[-][0-9]*");
                    String strValidRealPattern = "^([-]|[.]|[-.]|[0-9])[0-9]*[.]*[0-9]+$";
                    String strValidIntegerPattern = "^([-]|[0-9])[0-9]*$";
                    Regex objNumberPattern = new Regex("(" + strValidRealPattern + ")|(" + strValidIntegerPattern + ")");
                    traceLog.AppendLine(" & End: ValidationHelper, IsNumber Method");
                    return !objNotNumberPattern.IsMatch(number) &&
                        !objTwoDotPattern.IsMatch(number) &&
                        !objTwoMinusPattern.IsMatch(number) &&
                        objNumberPattern.IsMatch(number);
                }
                else
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsNumber Method");
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        public static bool IsAlpha(String value)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsAlpha Method with Params value: " + value); 
                if (value != null)
                {
                    Regex objAlphaPattern = new Regex("[^a-zA-Z]");
                    traceLog.AppendLine(" & End: ValidationHelper, IsAlpha Method");
                    return !objAlphaPattern.IsMatch(value);
                }
                else
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsAlpha Method");
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        public static bool IsAlphanumeric(String value)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsAlphanumeric Method with Params value: " + value); 
                if (value != null)
                {
                    Regex objAlphaNumericPattern = new Regex("[^a-zA-Z0-9]");
                    traceLog.AppendLine(" & End: ValidationHelper, IsAlphanumeric Method");
                    return !objAlphaNumericPattern.IsMatch(value);
                }
                else
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsAlphanumeric Method");
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        public static bool IsAlphanumeric(string pattern, int length)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsAlphanumeric Method with Params pattern: " + pattern + " and with Param length: " + length); 
                string strRegExp = @"^[a-zA-Z0-9]{1," + length + "}$";

                Regex objRegExp = new Regex(strRegExp);

                if (objRegExp.IsMatch(pattern))
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsAlphanumeric Method");
                    return true;
                }
                else
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsAlphanumeric Method");
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }


        public static bool IsValidDate(string date)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsValidDate Method with Params date: " + date); 
                DateTime.ParseExact(date, "m/d/yyyy", DateTimeFormatInfo.InvariantInfo);
                traceLog.AppendLine(" & End: ValidationHelper, IsValidDate Method");
            }
            catch (FormatException)
            {
                return false;
               // throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
            return true;
        }

        public static bool IsEmail(string email)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsEmail Method with Params email: " + email); 
                if (email != null)
                {
                    Regex emailPattern = new Regex(@"^([\w-\.'-]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,8}|[0-9]{1,3})(\]?)$");
                    traceLog.AppendLine(" & End: ValidationHelper, IsEmail Method");
                    return emailPattern.IsMatch(email);
                }
                else
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsEmail Method");
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }



        public static bool IsTenDigitPhoneNumber(string phoneNumber)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsTenDigitPhoneNumber Method with Params phoneNumber: " + phoneNumber); 
                if (phoneNumber != null && phoneNumber.Length > 0)
                {
                    phoneNumber = phoneNumber.Replace("-", "");
                    phoneNumber = phoneNumber.Replace("(", "");
                    phoneNumber = phoneNumber.Replace(")", "");
                    phoneNumber = phoneNumber.Replace(" ", "");
                    phoneNumber = phoneNumber.Trim();
                    if (IsInteger(phoneNumber) && (phoneNumber.Length == 10))
                    {
                        traceLog.AppendLine(" & End: ValidationHelper, IsTenDigitPhoneNumber Method");
                        return true;
                    }

                }
                traceLog.AppendLine(" & End: ValidationHelper, IsTenDigitPhoneNumber Method");
                return false;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

      
        public static bool IsEmpty(object content)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsEmpty Method with Params content: " + content); 
                if (content != null)
                {
                    if (!string.IsNullOrEmpty(content.ToString().Trim()))
                    {
                        traceLog.AppendLine(" & End: ValidationHelper, IsEmpty Method");
                        return false;
                    }
                    else
                    {
                        traceLog.AppendLine(" & End: ValidationHelper, IsEmpty Method");
                        return true;
                    }
                }
                else
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsEmpty Method");
                    return true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

       

        private static String CleanInvalidXmlChars(String text)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, CleanInvalidXmlChars Method with Params text: " + text); 
                string pattern = " *[\\~#%&*{}/';:<>?$^@|\"-]+ *";
                string replacement = " ";
                Regex regEx = new Regex(pattern);
                string sanitized = regEx.Replace(text, replacement);
                traceLog.AppendLine(" & End: ValidationHelper, CleanInvalidXmlChars Method");
                return sanitized;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        public static bool IsValidContent(string content)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsValidContent Method with Params content: " + content); 
                if (content.Length <= 0)
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidContent Method");
                    return false;
                }
                content = CleanInvalidXmlChars(content.ToUpperInvariant());

                if (content.Trim().StartsWith("'", StringComparison.OrdinalIgnoreCase) == true)
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidContent Method");
                    return false;
                }
                if (content.Contains("select ") && content.Contains("from "))
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidContent Method");
                    return false;
                }

                string[] strArray = new string[83] {"drop ", "update ", "truncate ", "delete ","create ","alter ","exe ","exec ","execute ",
												"where ","=",">","<","cmd ","'","command ","+","ascii(","cast(","=0x","char(","declare ","sysobjects",
												"%","javascript","html "," script ","meta ","style ","input "," link ","frame ","frameset ","syscolumns",
												"applet ","object","\"",";","?","* ","$","!","~","`","xml ","^","dump","convert(","fetch ","cursor "," deallocate ",
												"xp_","sp_","rollback ","commit ","kill ","revoke ","grant ","dbcc ","checkpoint "," go ",
												"@@","//","\x3c","\x3e","##","#&","&#","&&","mime","ebcdic",
												"--","|"," CR "," LF ","[","]","}","configure","%27","%3c","setcookie","union"};

                for (int i = 0; i < strArray.Length; i++)
                {
                    if (content.IndexOf(strArray[i].ToString(), StringComparison.OrdinalIgnoreCase) != -1)
                    {
                        traceLog.AppendLine(" & End: ValidationHelper, IsValidContent Method");
                        return false;
                    }
                }


                traceLog.AppendLine(" & End: ValidationHelper, IsValidContent Method");
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        public static bool IsValidCityCountyContent(string content)
        {
            StringBuilder traceLog = new StringBuilder();
            traceLog.AppendLine("Start: ValidationHelper, IsValidCityCountyContent Method with Params content: " + content); 
            if (content == null)
            {
                traceLog.AppendLine(" & End: ValidationHelper, IsValidCityCountyContent Method");
                return false;
            }
            try
            {
                
                if (content.Length <= 0)
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidCityCountyContent Method");
                    return false;
                }
                content = CleanInvalidXmlChars(content.ToUpperInvariant());

                if (content.Trim().StartsWith("'", StringComparison.OrdinalIgnoreCase) == true)
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidCityCountyContent Method");
                    return false;
                }
                if (content.Contains("select ") && content.Contains("from "))
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidCityCountyContent Method");
                    return false;
                }

                string[] strArray = new string[79] {"drop ", "update ", "truncate ", "delete ","create ","alter ","exe ","exec ","execute ", "where ",
                                                "=",">","<","cmd ","'","command ","+","ascii(","cast(","=0x","char(","declare ","sysobjects",
												"%","javascript","html "," script ","meta ","style ","input "," link ","frame ","frameset ","syscolumns",
                                                "applet ","object","\"",";","?","* ","$","xml ","^","dump","convert(","fetch ","cursor "," deallocate ",
												"xp_","sp_","rollback ","commit ","kill ","revoke ","grant ","dbcc ","checkpoint "," go ",
												"@@","//","\x3c","\x3e","##","#&","&#","&&","mime","ebcdic",
												"--","|"," CR "," LF ","[","]","}","configure","%27","%3c","setcookie"};

                for (int i = 0; i < strArray.Length; i++)
                {
                    if (content.IndexOf(strArray[i].ToString(), StringComparison.OrdinalIgnoreCase) != -1)
                    {
                        traceLog.AppendLine(" & End: ValidationHelper, IsValidCityCountyContent Method");
                        return false;
                    }
                }


                traceLog.AppendLine(" & End: ValidationHelper, IsValidCityCountyContent Method");
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
       

     public static bool IsValidTin(string parameter)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsValidTin Method with Params parameter: " + parameter); 
                bool blnResult = false;
                if (parameter != null)
                {
                    Regex objPattern = new Regex("[^0-9,]");
                    blnResult = !objPattern.IsMatch(parameter);
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidTin Method");
                    return blnResult;
                }
                else
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidTin Method");
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        public static bool IsValidContentName(string content)
     {
         StringBuilder traceLog = new StringBuilder();
            if (string.IsNullOrEmpty(content))
                throw new ArgumentNullException("content", "content is null");
            try
            {
                traceLog.AppendLine("Start: ValidationHelper, IsValidContentName Method with Params content: " + content);
                if (content.Length <= 0)
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidContentName Method");
                    return false;
                }

                content = content.ToUpperInvariant();

                if (content.Trim().StartsWith("'", StringComparison.OrdinalIgnoreCase) == true)
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidContentName Method");
                    return false;
                }
                if (content.Contains("select ") && content.Contains("from "))
                {
                    traceLog.AppendLine(" & End: ValidationHelper, IsValidContentName Method");
                    return false;
                }

                string[] strArray = new string[79] {"drop ", "update ", "truncate ", "delete ","create ","alter ","exe ","exec ","execute ",
												"where ","=",">","<","cmd ","command ","+","ascii(","cast(","=0x","char(","declare ","sysobjects",
												"%","javascript","html "," script ","meta ","style ","input "," link ","frame ","frameset ","syscolumns",
												"applet ","object","\"",";","?","* ","$","xml ","^","dump","convert(","fetch ","cursor "," deallocate ",
												"xp_","sp_","rollback ","commit ","kill ","revoke ","grant ","dbcc ","checkpoint "," go ",
												"@@","//","\x3c","\x3e","##","#&","&#","&&","mime","ebcdic",
												"--","|"," CR "," LF ","[","]","}","configure","%27","%3c","setcookie","union"};


                for (int i = 0; i < strArray.Length; i++)
                {
                    if (content.IndexOf(strArray[i].ToString(), StringComparison.OrdinalIgnoreCase) != -1)
                    {
                        traceLog.AppendLine(" & End: ValidationHelper, IsValidContentName Method");
                        return false;
                    }
                }
                traceLog.AppendLine(" & End: ValidationHelper, IsValidContentName Method");
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        
    }
}