﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NABWebsite.Models
{
    public class ExecutiveProfile
    {
        public int ImageId { get; set; }
        public byte[] ImageContent { get; set; }
        public string ImageString { get; set; }
        public string ExecutiveName { get; set; }
        public string ExecutiveTitle { get; set; }
        public string ExecutiveDetails { get; set; }
    }
}