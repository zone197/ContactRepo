﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;

namespace NABWebsite.Controllers
{
    //[OutputCache(Location = OutputCacheLocation.None, NoStore = true)]
    public class ValidationController : Controller
    {
        //List<string> clientSpecificNetwork;
        //public ValidationController()
        //{
        //    clientSpecificNetwork = new List<string>();
        //    clientSpecificNetwork.Add("ASA");
        //    clientSpecificNetwork.Add("ABCD");
        //    clientSpecificNetwork.Add("ADGH");
        //}
        //public JsonResult IsotherClientNetworkValid(string OtherClientNetwork)
        //{
        //    if(!string.IsNullOrEmpty(OtherClientNetwork))
        //    {
        //        throw new ArgumentNullException("OtherClientNetwork is null");
        //    }
        //    if (OtherClientNetwork != null)
        //    {
        //        if (!clientSpecificNetwork.Contains(OtherClientNetwork))
        //            return Json(false, JsonRequestBehavior.AllowGet);
        //        else
        //            return Json(true, JsonRequestBehavior.AllowGet);
        //    }
        //    if (OtherClientNetwork==null||OtherClientNetwork.Trim()=="")
        //    {
        //        return Json(false, JsonRequestBehavior.AllowGet);
        //    }
        //    return Json(true, JsonRequestBehavior.AllowGet);



      //  }
    }
}