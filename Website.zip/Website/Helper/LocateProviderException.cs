﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace NABWebsite.Helper
{
    [Serializable]
    public class LocateProviderException : Exception
    {
        public LocateProviderException()
        { }

        public LocateProviderException(string message)
            : base(message)
        { }

        public LocateProviderException(string message, Exception innerException)
            : base(message, innerException)
        { }

        protected LocateProviderException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        { }
        
    }
}