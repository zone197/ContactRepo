﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NABWebsite.DTO;
using Org.BouncyCastle.Crypto.Parameters;
using System.Text;
using System.Configuration;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Engines;
using System.Globalization;
using NABWebsite.Models;
using NABWebsite.BLL;
using Aetna.Cofinity.Admin.Entities.Response;
using Utilities;
namespace NABWebsite.Controllers
{
    public class ClaimAttachmentController : Controller
    {
        string errorMessage = string.Empty;
        // GET: ClaimAttachment
        /// <summary>
        /// Claim attachment home page
        /// </summary>
        /// <returns>ActionResult</returns>
        [CheckAccess(Function = "Attachment Inquiry")]
        public ActionResult Index()
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimAttachmentController, Index Method");
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimAttachmentController, Index Method");
                    return RedirectToAction("Index", "Home");
                }
                Session[Constants.Header] = Constants.ClaimAttachmentHead;
                traceLog.AppendLine(" & End: ClaimAttachmentController, Index Method");
                return View("Index");
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
        /// <summary>
        /// Fetch Claim attachment for enterd barcode
        /// </summary>
        /// <param name="Attachment"></param>
        /// <returns></returns>
        [ValidateAntiForgeryToken]
        [CheckAccess(Function = "Attachment Inquiry")]
        public ActionResult Attachment(ClaimAttachment attachmentValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimAttachmentController, Attachment Method with Param attachmentValue: " + attachmentValue);
                if ((UserDetails)Session[Constants.UserDetails] == null || !((UserDetails)Session[Constants.UserDetails]).IsAuthenticated)
                {
                    traceLog.AppendLine(" & End: ClaimAttachmentController, Attachment Method");
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    if (attachmentValue != null && !string.IsNullOrEmpty(attachmentValue.Barcode))
                    {
                        if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).UserId) && !string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole) && !string.IsNullOrEmpty(ConfigurationManager.AppSettings[Constants.Site]))
                        {
                            attachmentValue.Role = ((UserDetails)Session[Constants.UserDetails]).SelectedRole;
                            attachmentValue.Site = ConfigurationManager.AppSettings[Constants.Site];
                            attachmentValue.User = ((UserDetails)Session[Constants.UserDetails]).UserId;

                            if (!string.IsNullOrEmpty(((UserDetails)Session[Constants.UserDetails]).SelectedRole)
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles != null
                        && ((UserDetails)Session[Constants.UserDetails]).UserRoles.Count() > 0)
                            {
                                attachmentValue.IsEmployee = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().IsEmployee;
                                IEnumerable<CanCheckRestrictedMember> canCheckRestrictedList = ((UserDetails)Session[Constants.UserDetails]).UserRoles.Where(role => role.RoleName.Equals(((UserDetails)Session[Constants.UserDetails]).SelectedRole)).FirstOrDefault().CanCheckRestrictedMembers;
                                if (canCheckRestrictedList != null) attachmentValue.CanCheckRestrictedMembers = canCheckRestrictedList.FirstOrDefault().RestrictedCheck == 1 ? true : false;
                                else attachmentValue.CanCheckRestrictedMembers = false;
                            }

                            string attchment = string.Empty;
                            ClaimInquiryBL claimBL = new ClaimInquiryBL();
                            attchment = claimBL.GetAllAttachment(attachmentValue.Barcode, attachmentValue.Network,
                                attachmentValue.Role, attachmentValue.Site, attachmentValue.User,
                                attachmentValue.CanCheckRestrictedMembers, attachmentValue.IsEmployee, attachmentValue.SrcSystemId);
                        
                            if (!string.IsNullOrEmpty(attchment))
                            {
                                attachmentValue.AllBarcodeList = attchment;
                            }
                            else
                            {
                                errorMessage = Constants.ErrorNotFound;
                            }
                        }
                    }
                    else
                    {
                        errorMessage = Constants.ErrorValidBarcode;
                    }
                    if (!string.IsNullOrEmpty(errorMessage))
                    {
                        ModelState.AddModelError("Barcode", errorMessage);
                    }
                }
                traceLog.AppendLine(" & End: ClaimAttachmentController, Attachment Method");
                return View("Index", attachmentValue);
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
        }
        }
        /// <summary>
        /// Validate the barcode entered
        /// </summary>
        /// <param name="code"></param>
        /// <returns>bool</returns>
        private bool GenerateBarCode(string code)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimAttachmentController, GenerateBarCode Method with Param code: " + code);
                bool Barcode = true;
                string BarcodeString = string.Empty;
                string batchDateY = string.Empty;
                string batchDateM = string.Empty;
                string batchDateD = string.Empty;
                string batchDate = string.Empty;
                string checkBNum1 = string.Empty;

                char checkBNum2;
                int batchCodeRange = 0;


                System.DateTime batchDate2;
                System.DateTime todaysDate = System.DateTime.Now;
                System.DateTime eighteenMonthsDate = todaysDate.AddMonths(-18);

                try
                {
                    if (!string.IsNullOrEmpty(code) && Validation.IsValidContent(code))
                    {
                        BarcodeString = code;
                        for (int i = 0; i <= BarcodeString.Length - 1; i++)
                        {
                            checkBNum1 = BarcodeString.Substring(i, 1);
                            checkBNum2 = Convert.ToChar(checkBNum1, CultureInfo.InvariantCulture);

                            if (char.IsLetter(checkBNum2))
                            {
                                Barcode = false;
                                errorMessage = Constants.ErrorValidBarcode;
                                break;
                            }
                        }
                    }
                    else
                    {
                        Barcode = false;
                        errorMessage = Constants.ErrorValidBarcode;
                    }

                    //---check if barcode is 10 digits
                    if ((BarcodeString.Length == 10) && (Barcode))
                    {


                        //'--get month/day from barcode
                        batchDateM = BarcodeString.Substring(0, 2);
                        batchDateD = BarcodeString.Substring(2, 2);
                        batchDateY = BarcodeString.Substring(4, 1);
                        batchDateY = "1" + batchDateY;
                        batchDate = batchDateM + "/" + batchDateD + "/" + batchDateY;
                        batchDate2 = Convert.ToDateTime(batchDate, CultureInfo.InvariantCulture);

                        //'--find if date is within past 18 months
                        if (eighteenMonthsDate <= batchDate2)
                        {
                            Barcode = true;
                        }
                        else
                        {
                            Barcode = false;
                            errorMessage = Constants.ErrorMissingInformation;
                        }


                        if (Barcode)
                        {
                            batchCodeRange = Convert.ToInt32(BarcodeString.Substring(5, 3), CultureInfo.InvariantCulture);
                            if (((batchCodeRange > 0) && (batchCodeRange < 201)) || ((batchCodeRange > 210) && (batchCodeRange < 1000)))
                            {
                                Barcode = true;
                            }
                            else
                            {
                                Barcode = false;
                                errorMessage = Constants.ErrorAttachmentArchive;
                            }
                        }

                    }
                    else
                    {
                        Barcode = false;
                        errorMessage = Constants.ErrorValidBarcode;
                    }
                }
                catch (ArgumentOutOfRangeException ex)
                {
                   
                    errorMessage = Constants.ErrorValidBarcode;
                    Barcode = false;
                    LogManager.WriteErrorLog(ex);
                }
                catch (FormatException ex)
                {
                   
                    errorMessage = Constants.ErrorValidBarcode;
                    Barcode = false;
                    LogManager.WriteErrorLog(ex);
                }
                catch (Exception ex)
                {
                   
                    errorMessage = Constants.ErrorValidBarcode;
                    Barcode = false;
                    LogManager.WriteErrorLog(ex);
                }
                finally
                {
                    LogManager.WriteTraceLog(traceLog);
                }
                traceLog.AppendLine(" & End: ClaimAttachmentController, GenerateBarCode Method");
                return Barcode;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }

        }
        /// <summary>
        ///Format the date field
        /// </summary>
        /// <param name="number"></param>
        /// <returns>string</returns>
        private static string AppendZero(int number)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimAttachmentController, AppendZero Method with Param number: " + number);
                if (number > 0 && number < 10)
                    return Constants.Zero + number.ToString(CultureInfo.InvariantCulture);
                else if (number == 0)
                {
                    traceLog.AppendLine(" & End: ClaimAttachmentController, AppendZero Method");
                    return Constants.Zero + Constants.Zero;
                }
                else
                {
                    traceLog.AppendLine(" & End: ClaimAttachmentController, AppendZero Method");
                    return number.ToString(CultureInfo.InvariantCulture);
            }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }

        [HttpPost]
        public ActionResult GetAttachmentFile(ClaimAttachment attachmentValue)
        {
            StringBuilder traceLog = new StringBuilder();
            try
            {
                traceLog.AppendLine("Start: ClaimAttachmentController, GetAttachmentFile Method with Param attachmentValue: " + attachmentValue);
            if (attachmentValue != null)
            {
                ClaimInquiryBL claimBL = new ClaimInquiryBL();
                string attachmentType = string.Empty;
                string barcode = string.Empty;
                attachmentType = attachmentValue.SelectedBarcode.Substring(0, attachmentValue.SelectedBarcode.IndexOf('_'));
                barcode = attachmentValue.SelectedBarcode.Substring(attachmentValue.SelectedBarcode.IndexOf('_') + 1, attachmentValue.SelectedBarcode.Length - attachmentValue.SelectedBarcode.IndexOf('_') - 1);
                if (attachmentType.ToUpperInvariant().Equals(Constants.AttachmentTypeKIT.ToUpperInvariant()))
                {
                    NABWebsite.DTO.FileContent file = claimBL.GetKITFile(barcode);
                    if (file != null && file.Name != null)
                    {
                        string filetype = file.Name.Substring(file.Name.IndexOf('.') + 1, file.Name.Length - file.Name.IndexOf('.') - 1);
                            traceLog.AppendLine(" & End: ClaimAttachmentController, GetAttachmentFile Method");
                        return File(file.Content, filetype, file.Name);
                    }
                }
                else if (attachmentType.ToUpperInvariant().Equals(Constants.AttachmentTypeGEHA))
                {
                    NABWebsite.DTO.FileContent file = claimBL.GetFile(barcode, attachmentValue.Network, attachmentValue.User);
                    if (file != null && file.Name != null)
                    {
                        string filetype = file.Name.Substring(file.Name.IndexOf('.') + 1, file.Name.Length - file.Name.IndexOf('.') - 1);
                            traceLog.AppendLine(" & End: ClaimAttachmentController, GetAttachmentFile Method");
                        return File(file.Content, filetype, file.Name);
                    }
                }
                else if (!string.IsNullOrEmpty(barcode)) //if (GenerateBarCode(barcode))
                {
                    //var barCode = attachmentValue.Barcode;
                    
                    var currentTime = DateTime.UtcNow.AddMinutes(30);
                    var formatGMT = currentTime.Year.ToString(CultureInfo.InvariantCulture) + AppendZero(currentTime.Month) + AppendZero(currentTime.Day) + AppendZero(currentTime.Hour)
                        + AppendZero(currentTime.Minute) + AppendZero(currentTime.Second);
                    var urlToGo = ConfigurationManager.AppSettings[Constants.DocumentUrl];
                    var urlToEncode = string.Empty;
                    urlToEncode = Constants.Barcode + barcode + Constants.Format + formatGMT;
                    var appendUrl = string.Empty;
                    IStreamCipher cipher = new RC4Engine();
                    byte[] key = Encoding.UTF8.GetBytes(ConfigurationManager.AppSettings[Constants.DocumentPrivateKey]);
                    byte[] input = Encoding.UTF8.GetBytes(urlToEncode);
                    byte[] cipherText = new byte[input.Length];
                    cipher.Init(true, new KeyParameter(key));
                    cipher.ProcessBytes(input, 0, input.Length, cipherText, 0);
                    appendUrl = Convert.ToBase64String(cipherText);
                    var path = urlToGo + appendUrl;                   
                    Response.Write(Constants.ScriptWindowOpen + path + Constants.ScriptWindowClose);                    
                }
                else
                {
                    errorMessage = Constants.ErrorNotFound;
                }
                    traceLog.AppendLine(" & End: ClaimAttachmentController, GetAttachmentFile Method");
            }
            return Redirect("/ClaimAttachment/Index");
        }
            catch (Exception ex)
            {
                LogManager.WriteErrorLog(ex);
                throw;
            }
            finally
            {
                LogManager.WriteTraceLog(traceLog);
            }
        }
    }
}